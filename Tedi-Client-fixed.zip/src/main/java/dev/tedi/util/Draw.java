package dev.tedi.util;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.chat.Style;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * All 2D drawing helpers of the client.
 *
 * PERFORMANCE NOTE: every GuiGraphics.fill() becomes its own render element in modern Minecraft, so the number of
 * fills per frame is what makes a HUD / GUI lag. Everything here is built to use as FEW fills as possible:
 * a rounded rectangle is a stack of full-width horizontal bands (about 10-20 fills, no overdraw) instead of
 * four separate corners drawn pixel by pixel.
 */
public final class Draw {
    private Draw() {}

    // ------------------------------------------------------------------ basic shapes
    /** Rectangle with cut corners (looks rounded). */
    public static void round(GuiGraphics g, int x, int y, int w, int h, int c) {
        if (w < 3 || h < 3) { g.fill(x, y, x + w, y + h, c); return; }
        g.fill(x + 1, y, x + w - 1, y + h, c);
        g.fill(x, y + 1, x + 1, y + h - 1, c);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, c);
    }

    public static void outline(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y + 1, x + 1, y + h - 1, c);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, c);
    }

    /** Multiplies the alpha of an ARGB colour. */
    public static int alpha(int argb, float a) {
        a = Math.max(0f, Math.min(1f, a));
        int al = (int) (((argb >>> 24) & 255) * a);
        return (al << 24) | (argb & 0xFFFFFF);
    }

    /** Mixes the RGB part toward white (keeps alpha). */
    public static int lighten(int argb, float k) {
        int r = (argb >> 16) & 255, gg = (argb >> 8) & 255, b = argb & 255;
        r += (int) ((255 - r) * k); gg += (int) ((255 - gg) * k); b += (int) ((255 - b) * k);
        return (argb & 0xFF000000) | (r << 16) | (gg << 8) | b;
    }

    /** Mixes the RGB part toward black (keeps alpha). */
    public static int darken(int argb, float k) {
        int r = (argb >> 16) & 255, gg = (argb >> 8) & 255, b = argb & 255;
        r -= (int) (r * k); gg -= (int) (gg * k); b -= (int) (b * k);
        return (argb & 0xFF000000) | (r << 16) | (gg << 8) | b;
    }

    // ------------------------------------------------------------------ pixel font
    private static Style STYLE;
    private static long nextTry;
    private static final Map<String, Integer> WID = new HashMap<>();

    /** The "tedi_client:bungee" font as a Style (built from JSON so no font-API names are needed). Falls back to vanilla if it did not load. */
    private static Style style(Font f) {
        if (STYLE == null && System.currentTimeMillis() >= nextTry) {
            nextTry = System.currentTimeMillis() + 2000;      // retry until the font is loaded (never stay stuck on the fallback)
            try {
                JsonObject o = new JsonObject();
                o.addProperty("text", "");
                o.addProperty("font", "tedi_client:bungee");
                Component c = ComponentSerialization.CODEC.parse(JsonOps.INSTANCE, o).result().orElse(null);
                if (c != null) {
                    Style st = c.getStyle();
                    int wi = f.width(Component.literal("i").withStyle(st)), ww = f.width(Component.literal("W").withStyle(st));
                    if (wi > 0 && wi != ww) STYLE = st;      // missing-font glyphs all have the same width -> then use vanilla
                }
            } catch (Throwable ignored) {}
        }
        return STYLE;
    }

    private static boolean lastMode = true;

    /** The font style to use right now, or null for the vanilla font. Allocation-free. */
    private static Style activeStyle(Font f) {
        boolean want = dev.tedi.module.Hud.I == null || dev.tedi.module.Hud.I.pixel.value;
        if (want != lastMode) { lastMode = want; WID.clear(); }
        return want ? style(f) : null;
    }

    /** A fresh Component every call (cheap) - reusing cached ones could make text vanish after the first frame. */
    private static Component comp(Font f, String s) {
        Style st = activeStyle(f);
        if (st == null) return null;
        return Component.literal(s).withStyle(st);
    }

    /** Draw text in the client font. Same arguments as GuiGraphics.drawString. */
    public static void str(GuiGraphics g, Font f, String s, int x, int y, int color, boolean shadow) {
        if (((color >>> 24) & 255) < 5) return;
        Component c = comp(f, s);
        if (c != null) g.drawString(f, c, x, y, color, shadow);
        else g.drawString(f, s, x, y, color, shadow);
    }

    /** Text width in the client font. Cached widths cost no allocation (this is called many times per frame). */
    public static int w(Font f, String s) {
        Style st = activeStyle(f);
        if (st == null) return f.width(s);
        Integer w = WID.get(s);
        if (w == null) {
            if (WID.size() > 1500) WID.clear();
            w = f.width(Component.literal(s).withStyle(st)); WID.put(s, w);
        }
        return w;
    }

    public static void text(GuiGraphics g, Font f, String s, int x, int y, int color, boolean bold) {
        str(g, f, s, x, y, color, false);
    }

    public static int width(Font f, String s, boolean bold) { return w(f, s); }

    // ------------------------------------------------------------------ easing
    public static float easeOut(float t) { t = Math.max(0f, Math.min(1f, t)); return 1f - (1f - t) * (1f - t) * (1f - t); }
    public static float smooth(float t) { t = Math.max(0f, Math.min(1f, t)); return t * t * (3f - 2f * t); }
    public static float easeOutBack(float t) {
        t = Math.max(0f, Math.min(1f, t));
        float c1 = 1.70158f, c3 = c1 + 1f, u = t - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    // ------------------------------------------------------------------ rounded rectangles (band based)
    private static final Map<Integer, int[]> PROFILE = new HashMap<>();

    /**
     * Quarter-circle profile for corner radius R (in drawing units): triples [firstRow, rowCount, inset]. Cached.
     * tol = 1 merges rows whose edge differs by at most one unit (half a GUI pixel in smooth mode): ~40% fewer fills, same look.
     */
    private static int[] profile(int R, int tol) {
        int key = R | (tol << 16);
        int[] p = PROFILE.get(key);
        if (p != null) return p;
        int[] raw = new int[R];
        for (int j = 0; j < R; j++) {
            double dy = R - j - 0.5;
            raw[j] = (int) Math.round(R - Math.sqrt((double) R * R - dy * dy));
        }
        List<int[]> segs = new ArrayList<>();      // [firstRow, rowCount, insetSum]
        int[] cur = null; int first = 0;
        for (int j = 0; j < R; j++) {
            boolean join = cur != null && raw[j] > 0 && first > 0 && first - raw[j] <= tol || cur != null && raw[j] == 0 && first == 0;
            if (join) { cur[1]++; cur[2] += raw[j]; }
            else { cur = new int[]{j, 1, raw[j]}; first = raw[j]; segs.add(cur); }
        }
        p = new int[segs.size() * 3];
        for (int k = 0; k < segs.size(); k++) {
            int[] s = segs.get(k);
            p[k * 3] = s[0]; p[k * 3 + 1] = s[1]; p[k * 3 + 2] = Math.round(s[2] / (float) s[1]);
        }
        PROFILE.put(key, p);
        return p;
    }

    /** Draws a rounded rectangle at (ox,oy) of size W x H in the current coordinate system: full-width bands, no overdraw. */
    private static void bands(GuiGraphics g, int ox, int oy, int W, int H, int R, int c1, int c2, boolean grad, int tol) {
        int[] q = profile(R, tol);
        int mid = R;
        for (int k = 0; k < q.length; k += 3) {
            int j = q[k], n = q[k + 1], in = q[k + 2];
            if (in <= 0) { mid = j; break; }
            int tc = c1, bc = c1;
            if (grad) {
                tc = Colors.lerp(c1, c2, (j + n * 0.5f) / H);
                bc = Colors.lerp(c1, c2, (H - j - n * 0.5f) / H);
            }
            g.fill(ox + in, oy + j, ox + W - in, oy + j + n, tc);
            g.fill(ox + in, oy + H - j - n, ox + W - in, oy + H - j, bc);
        }
        if (H - mid <= mid) return;
        if (grad) g.fillGradient(ox, oy + mid, ox + W, oy + H - mid, Colors.lerp(c1, c2, (float) mid / H), Colors.lerp(c1, c2, (float) (H - mid) / H));
        else g.fill(ox, oy + mid, ox + W, oy + H - mid, c1);
    }

    private static void roundAny(GuiGraphics g, int x, int y, int w, int h, int r, int c1, int c2, boolean grad, boolean fine) {
        if (((c1 >>> 24) & 255) == 0 && ((c2 >>> 24) & 255) == 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r <= 1) {
            if (grad) g.fillGradient(x, y, x + w, y + h, c1, c2); else g.fill(x, y, x + w, y + h, c1);
            return;
        }
        if (fine && r >= 4) {
            // corners at double resolution (half-pixel bands) = much smoother, still only ~10-20 fills
            var ps = g.pose();
            ps.pushMatrix();
            ps.translate((float) x, (float) y);
            ps.scale(0.5f, 0.5f);
            bands(g, 0, 0, w * 2, h * 2, r * 2, c1, c2, grad, 1);
            ps.popMatrix();
        } else {
            bands(g, x, y, w, h, r, c1, c2, grad, 0);
        }
    }

    public static void roundR(GuiGraphics g, int x, int y, int w, int h, int r, int c) { roundAny(g, x, y, w, h, r, c, c, false, r >= 8); }

    public static void roundR(GuiGraphics g, int x, int y, int w, int h, int r, int c, boolean fine) { roundAny(g, x, y, w, h, r, c, c, false, fine); }

    /** Rounded rectangle with a vertical colour gradient. */
    public static void roundG(GuiGraphics g, int x, int y, int w, int h, int r, int top, int bottom) { roundAny(g, x, y, w, h, r, top, bottom, true, r >= 8); }

    public static void roundG(GuiGraphics g, int x, int y, int w, int h, int r, int top, int bottom, boolean fine) { roundAny(g, x, y, w, h, r, top, bottom, true, fine); }

    /** Generic panel: 1px border, rounded body with a soft vertical gradient. */
    public static void panel(GuiGraphics g, int x, int y, int w, int h, int r, int bg, int border, float a) {
        roundAny(g, x - 1, y - 1, w + 2, h + 2, r + 1, alpha(border, a), 0, false, true);
        roundAny(g, x, y, w, h, r, alpha(lighten(bg, 0.07f), a), alpha(darken(bg, 0.18f), a), true, true);
    }

    /** One cheap soft shadow under a rounded rectangle. */
    public static void shadow(GuiGraphics g, int x, int y, int w, int h, int r) {
        roundAny(g, x, y + 2, w, h, r, 0x3A000000, 0, false, false);
    }

    /** Same as shadow() but fades with a. */
    public static void drop(GuiGraphics g, int x, int y, int w, int h, int r, float a) {
        roundAny(g, x, y + 2, w, h, r, alpha(0x3A000000, a), 0, false, false);
    }

    /** Old name kept: dark panel with accent bar on the left. */
    public static void softPanel(GuiGraphics g, int x, int y, int w, int h, int accent, float a) {
        panel(g, x, y, w, h, Math.min(8, h / 2), Colors.NAVY, Colors.NAVY_BORDER, a);
        g.fill(x + 4, y + 4, x + 6, y + h - 4, alpha(accent, a));
    }

    /** HUD pill (fully rounded ends). */
    public static void pill(GuiGraphics g, int x, int y, int w, int h, float a) {
        panel(g, x, y, w, h, Math.min(12, h / 2), Colors.NAVY, Colors.NAVY_BORDER, a);
    }

    /** 1px line that is brightest in the middle and fades out to both ends (5 fills). */
    public static void fadeLine(GuiGraphics g, int x, int y, int w, int argb) {
        if (w < 5) { g.fill(x, y, x + w, y + 1, argb); return; }
        float[] k = {0.10f, 0.45f, 1.0f, 0.45f, 0.10f};
        int a = x;
        for (int i = 0; i < 5; i++) {
            int b = x + (w * (i + 1)) / 5;
            g.fill(a, y, b, y + 1, alpha(argb, k[i]));
            a = b;
        }
    }

    /** Header underline (kept for compatibility; static, so it costs nothing extra). */
    public static void shimmer(GuiGraphics g, int x, int y, int w, int argb, float time) {
        fadeLine(g, x, y, w, argb);
    }
}
