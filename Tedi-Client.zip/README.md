# Tedi Client (Fabric, Minecraft 1.21.11 Java)

Press RIGHT SHIFT in a world to open the GUI.
- Left click a module = on/off. Right click a module = its settings.
- Modules: StorageESP, Freecam, SusChunk, AutoTotem, NameProtect, HUD.

Build: push this folder to GitHub (see chat instructions); the Actions tab produces the .jar.
Install: Fabric Loader + Fabric API for 1.21.11, drop the tedi-client jar in .minecraft/mods.
