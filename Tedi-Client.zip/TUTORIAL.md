# Tedi Client - Advanced Tutorial: from the .zip to a working .jar

This guide has 3 parts: (A) build it on GitHub (no installs), (B) build it on your own PC, (C) install and use it.
Requirements: Minecraft **Java Edition 1.21.11**, a free GitHub account.

---------------------------------------------------------------------
## PART A - Build the .jar with GitHub (easiest)

### A1. Unzip
1. Right-click `Tedi-Client.zip` -> Extract All.
2. Open the extracted folder. You must see: `build.gradle`, `settings.gradle`, `gradle.properties`, `src`, `.github`, `README.md`.
3. `.github` is HIDDEN on some systems. Windows: File Explorer -> View -> Show -> Hidden items. Mac: press Cmd+Shift+. in Finder.

### A2. Create a repository
1. Go to https://github.com and sign in.
2. Top-right "+" -> New repository.
3. Name it `tedi-client`. Choose Private (fine) or Public. Do NOT tick "Add a README". Click Create repository.

### A3. Upload the files (web method)
1. On the empty repo page click **uploading an existing file**.
2. Open the extracted folder, select EVERYTHING inside it (Ctrl+A), and drag it into the browser.
   (Drag the contents, not the folder that contains them. `build.gradle` must be at the top level of the repo.)
3. Wait for the upload to finish, then click **Commit changes**.
4. Check the repo page: you should see `.github`, `src`, `build.gradle` ... If `.github` is missing:
   - Add file -> Create new file
   - In the name box type exactly: `.github/workflows/build.yml` (typing the slashes creates the folders)
   - Open `.github/workflows/build.yml` from the zip in Notepad, copy all, paste it, Commit.

### A3-alt. Upload with Git (command-line method)
```
cd path\to\extracted\folder
git init
git add .
git commit -m "Tedi Client"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/tedi-client.git
git push -u origin main
```
(GitHub asks you to log in; use a Personal Access Token as the password if prompted.)

### A4. Let GitHub build it
1. Open the **Actions** tab. If it says workflows are disabled, click "I understand my workflows, enable them".
2. The run "Build Tedi Client" starts automatically after your upload. You can also start it: Actions -> Build Tedi Client -> Run workflow.
3. Wait 2-5 minutes. Green check = success. Red X = a build error (see Troubleshooting).

### A5. Download the .jar
1. Click the finished run.
2. Scroll to **Artifacts** at the bottom -> click **tedi-client-jar**. A zip downloads.
3. Extract it. Inside is `tedi-client-1.0.0.jar`. That is your client.

---------------------------------------------------------------------
## PART B - Build on your own PC (optional)

1. Install **JDK 21** (Temurin 21 from adoptium.net). Check: `java -version` shows 21.
2. Install **Gradle 9.2+** (gradle.org/install), check with `gradle -v`.
3. In the project folder run:  `gradle build`
4. The jar appears in `build/libs/tedi-client-1.0.0.jar`.
5. To test without installing: `gradle runClient` starts Minecraft with the mod.

---------------------------------------------------------------------
## PART C - Install and use

1. Install **Fabric Loader** for 1.21.11 (fabricmc.net/use/installer) and make a Fabric 1.21.11 profile in the launcher.
2. Download **Fabric API** for 1.21.11 (modrinth.com/mod/fabric-api).
3. Put BOTH `fabric-api-....jar` and `tedi-client-1.0.0.jar` in `.minecraft/mods`.
4. Launch the Fabric profile, join a world, press **Right Shift**.

### Controls
- Left click module = on/off. Right click module = settings.
- **KEYBIND** row inside a module: click the empty box, press a key, the box shows it. Backspace clears it. Right-click the box also clears it.
- **Configs panel**: type a name -> SAVE. LOAD / DELETE use the name in the box, or click a saved config in the list. Files live in `.minecraft/config/tedi-client/configs/`. Your last state is auto-saved and auto-loaded.
- **HUD**: pick which HUDs are active in the HUD module settings (FPS HUD, Coordinates HUD, Module List). Press **T** (chat) and drag them with the mouse to move them.
- **Freecam**: your body keeps its old aim. Mining/placing still hits what YOUR BODY was looking at (a light-blue box shows the target). A sneak held when you turn it on stays held.

---------------------------------------------------------------------
## UPDATING after you change code
Edit a file on GitHub (pencil icon) or push again -> Actions rebuilds -> download the new artifact.

## TROUBLESHOOTING
- **"Could not find net.fabricmc.fabric-api:fabric-api:..."** - open `gradle.properties`, go to fabricmc.net/develop, pick 1.21.11, copy the exact `fabric_version`, `loader_version` into the file.
- **Red X with "error: cannot find symbol / method does not override"** - Minecraft 1.21.11 renamed something. Click the failed run -> build step -> copy the lines containing `error:` and send them to Claude to fix.
- **No jar in artifacts** - the build failed; fix the error first.
- **Two jars?** Use the one WITHOUT `-sources` in the name.
- **Game crashes on start mentioning Mixin** - send `.minecraft/logs/latest.log` to Claude.
- **Right Shift does nothing** - you must be inside a world with no other screen open.
- **Wrong Java** - Minecraft 1.21.11 needs Java 21 (the launcher bundles it).
