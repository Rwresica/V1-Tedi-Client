package dev.tedi.config;

import dev.tedi.module.BlockEsp;
import dev.tedi.module.Freecam;
import dev.tedi.module.Hud;
import dev.tedi.module.Module;
import dev.tedi.module.Modules;
import dev.tedi.setting.Setting;
import dev.tedi.util.Toasts;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/** Saves / loads everything (modules, settings, keybinds, HUD positions) to .minecraft/config/tedi-client/configs */
public final class ConfigManager {
    public static final String AUTO = "autosave";
    private ConfigManager() {}

    private static Path dir() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("tedi-client").resolve("configs");
        try { Files.createDirectories(p); } catch (IOException ignored) {}
        return p;
    }

    public static String clean(String n) {
        String c = n == null ? "" : n.trim().replaceAll("[^A-Za-z0-9_-]", "_");
        return c.isEmpty() ? "default" : c;
    }

    private static String k(String s) { return s.replaceAll("[^A-Za-z0-9]", "_"); }

    public static List<String> list() {
        try (Stream<Path> s = Files.list(dir())) {
            return s.map(p -> p.getFileName().toString())
                    .filter(n -> n.endsWith(".properties"))
                    .map(n -> n.substring(0, n.length() - ".properties".length()))
                    .filter(n -> !n.equals(AUTO))
                    .sorted().collect(Collectors.toList());
        } catch (IOException e) { return new ArrayList<>(); }
    }

    /** share = true leaves private things (Discord webhooks) out. */
    private static Properties build(boolean share) {
        Properties p = new Properties();
        for (Module m : Modules.all) {
            String b = "m." + k(m.name);
            if (!(m instanceof Freecam)) p.setProperty(b + ".enabled", String.valueOf(m.enabled));
            p.setProperty(b + ".key", String.valueOf(m.key));
            for (Setting s : m.settings) {
                String key = "s." + k(m.name) + "." + k(s.name);
                if (s instanceof Setting.Bool v) p.setProperty(key, String.valueOf(v.value));
                else if (s instanceof Setting.Num v) p.setProperty(key, String.valueOf(v.value));
                else if (s instanceof Setting.Hue v) p.setProperty(key, v.hue + "," + v.sat + "," + v.val);
                else if (s instanceof Setting.Str v) {
                    if (share && s.name.equalsIgnoreCase("Webhook")) continue;
                    p.setProperty(key, v.value);
                }
            }
        }
        if (BlockEsp.I != null) p.setProperty("blockesp", BlockEsp.I.serialize());
        if (Hud.I != null) {
            for (Hud.El e : Hud.I.elements) {
                if (e.x < 0) continue;
                p.setProperty("h." + k(e.name) + ".x", String.valueOf(e.x));
                p.setProperty("h." + k(e.name) + ".y", String.valueOf(e.y));
            }
        }
        return p;
    }

    private static void apply(Properties p, boolean share) {
        boolean wasMuted = Toasts.mute;
        Toasts.mute = true;
        try {
            for (Module m : Modules.all) {
                String b = "m." + k(m.name);
                String en = p.getProperty(b + ".enabled");
                if (en != null && !(m instanceof Freecam)) m.setEnabled(Boolean.parseBoolean(en));
                String key = p.getProperty(b + ".key");
                if (key != null) { try { m.key = Integer.parseInt(key); } catch (NumberFormatException ignored) {} }
                for (Setting s : m.settings) {
                    String v = p.getProperty("s." + k(m.name) + "." + k(s.name));
                    if (v == null) continue;
                    try {
                        if (s instanceof Setting.Bool x) x.value = Boolean.parseBoolean(v);
                        else if (s instanceof Setting.Num x) x.value = Math.max(x.min, Math.min(x.max, Double.parseDouble(v)));
                        else if (s instanceof Setting.Hue x) {
                            String[] hv = v.split(",");
                            x.hue = Math.max(0, Math.min(360, Double.parseDouble(hv[0])));
                            if (hv.length >= 3) { x.sat = Math.max(0, Math.min(1, Double.parseDouble(hv[1]))); x.val = Math.max(0, Math.min(1, Double.parseDouble(hv[2]))); }
                        } else if (s instanceof Setting.Str x) {
                            if (share && s.name.equalsIgnoreCase("Webhook")) continue;
                            x.value = v.length() > x.maxLen ? v.substring(0, x.maxLen) : v;
                        }
                    } catch (RuntimeException ignored) {}
                }
            }
            if (BlockEsp.I != null && p.getProperty("blockesp") != null) BlockEsp.I.deserialize(p.getProperty("blockesp"));
            if (Hud.I != null) {
                for (Hud.El e : Hud.I.elements) {
                    try {
                        String x = p.getProperty("h." + k(e.name) + ".x"), y = p.getProperty("h." + k(e.name) + ".y");
                        if (x != null && y != null) { e.x = Integer.parseInt(x); e.y = Integer.parseInt(y); }
                    } catch (NumberFormatException ignored) {}
                }
            }
        } finally {
            Toasts.mute = wasMuted;
        }
    }

    public static boolean save(String name) {
        try (Writer w = Files.newBufferedWriter(dir().resolve(clean(name) + ".properties"))) {
            build(false).store(w, "Tedi Client config");
            return true;
        } catch (IOException e) { return false; }
    }

    public static boolean load(String name) {
        Path f = dir().resolve(clean(name) + ".properties");
        if (!Files.exists(f)) return false;
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(f)) { p.load(r); } catch (IOException e) { return false; }
        apply(p, false);
        return true;
    }

    public static boolean delete(String name) {
        try { return Files.deleteIfExists(dir().resolve(clean(name) + ".properties")); }
        catch (IOException e) { return false; }
    }

    /** Current settings as shareable text (webhooks removed). */
    public static String exportText() {
        try (StringWriter w = new StringWriter()) {
            build(true).store(w, "Tedi Client shared config");
            return w.toString();
        } catch (IOException e) { return ""; }
    }

    /** Applies shared text. Only known keys are read; nothing is executed. */
    public static boolean importText(String text) {
        if (text == null || text.length() < 10 || text.length() > 200_000) return false;
        Properties p = new Properties();
        try (Reader r = new StringReader(text)) { p.load(r); } catch (IOException | IllegalArgumentException e) { return false; }
        if (p.getProperty("m.HUD.key") == null && p.stringPropertyNames().stream().noneMatch(s -> s.startsWith("m.") || s.startsWith("s."))) return false;
        apply(p, true);
        return true;
    }
}
