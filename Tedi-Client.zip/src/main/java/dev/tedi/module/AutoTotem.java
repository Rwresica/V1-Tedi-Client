package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;

public class AutoTotem extends Module {
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 1, 0, 10, 1));
    public final Setting.Num health = add(new Setting.Num("Only Below HP", 20, 1, 20, 1));
    private int cooldown;

    public AutoTotem() {
        super("AutoTotem", "Keeps a totem in your offhand.", "COMBAT", true);
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.gameMode == null) return;
        if (cooldown > 0) { cooldown--; return; }
        if (mc.player.containerMenu != mc.player.inventoryMenu) return;
        if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return;
        if (mc.player.getHealth() > health.value) return;
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                int menuSlot = i < 9 ? 36 + i : i;
                mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, menuSlot, 40, ClickType.SWAP, mc.player);
                cooldown = delay.i();
                return;
            }
        }
    }
}
