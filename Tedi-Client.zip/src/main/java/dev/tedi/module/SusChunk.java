package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Scores every loaded chunk by how much it looks player-modified, and highlights the likely bases. */
public class SusChunk extends Module {
    public static SusChunk I;
    public record Info(int cx, int cz, int score, int amethyst, int storage, int blocks, int spawners, int ug, int minY, int maxY) {}
    private record Vis(Info info, int eff, int level) {}

    private static final Set<Block> INDICATORS = new HashSet<>(Arrays.asList(
            Blocks.IRON_BLOCK, Blocks.GOLD_BLOCK, Blocks.DIAMOND_BLOCK, Blocks.EMERALD_BLOCK, Blocks.NETHERITE_BLOCK,
            Blocks.LAPIS_BLOCK, Blocks.REDSTONE_BLOCK, Blocks.COAL_BLOCK, Blocks.COPPER_BLOCK, Blocks.BEACON,
            Blocks.ENCHANTING_TABLE, Blocks.ANVIL, Blocks.TNT, Blocks.PISTON, Blocks.STICKY_PISTON, Blocks.OBSERVER,
            Blocks.REPEATER, Blocks.COMPARATOR, Blocks.REDSTONE_LAMP, Blocks.HOPPER, Blocks.DROPPER, Blocks.DISPENSER,
            Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER, Blocks.BREWING_STAND, Blocks.CRAFTING_TABLE,
            Blocks.SMITHING_TABLE, Blocks.SCAFFOLDING, Blocks.GLASS, Blocks.BARREL));

    /** Things players place underground to light / enter / decorate a hidden base. */
    private static final Set<Block> UG_INDICATORS = new HashSet<>(Arrays.asList(
            Blocks.TORCH, Blocks.WALL_TORCH, Blocks.SOUL_TORCH, Blocks.SOUL_WALL_TORCH, Blocks.LANTERN,
            Blocks.SOUL_LANTERN, Blocks.LADDER, Blocks.IRON_DOOR, Blocks.OAK_DOOR, Blocks.OAK_TRAPDOOR,
            Blocks.IRON_TRAPDOOR, Blocks.OAK_SIGN, Blocks.OAK_WALL_SIGN));

    // detection
    public final Setting.Bool amethyst = add(new Setting.Bool("Grown Amethyst", true));
    public final Setting.Bool storage = add(new Setting.Bool("Storage Blocks", true));
    public final Setting.Bool playerBlocks = add(new Setting.Bool("Player-made Blocks", true));
    public final Setting.Bool spawners = add(new Setting.Bool("Spawners", false));
    public final Setting.Bool smart = add(new Setting.Bool("AI Improvement (Underground)", true));
    public final Setting.Num ugDepth = add(new Setting.Num("Underground Depth", 10, 4, 60, 2));
    public final Setting.Bool cluster = add(new Setting.Bool("Cluster Bonus", true));
    public final Setting.Num minStorage = add(new Setting.Num("Minimum Storage (0=off)", 0, 0, 100, 1));
    public final Setting.Num minScore = add(new Setting.Num("Min Score", 25, 5, 300, 5));
    public final Setting.Num minLevel = add(new Setting.Num("Min Level (1-3)", 1, 1, 3, 1));
    public final Setting.Num minYs = add(new Setting.Num("Min Y", -64, -64, 320, 8));
    public final Setting.Num maxYs = add(new Setting.Num("Max Y", 320, -64, 320, 8));
    // display
    public final Setting.Num maxShown = add(new Setting.Num("Max Chunks Shown", 12, 1, 50, 1));
    public final Setting.Bool fill = add(new Setting.Bool("Fill Chunk", true));
    public final Setting.Num fillOpacity = add(new Setting.Num("Fill Opacity (Density)", 0.30, 0.05, 1.0, 0.05));
    public final Setting.Bool fullHeight = add(new Setting.Bool("Full Height Fill", false));
    public final Setting.Num fillHeight = add(new Setting.Num("Fill Height", 48, 8, 256, 8));
    public final Setting.Bool line = add(new Setting.Bool("Chunk Line", true));
    public final Setting.Bool vertical = add(new Setting.Bool("Vertical Edges", false));
    public final Setting.Num lineWidth = add(new Setting.Num("Line Width", 1.5, 0.5, 4.0, 0.5));
    public final Setting.Bool labels = add(new Setting.Bool("Labels", true));
    public final Setting.Bool tracers = add(new Setting.Bool("Tracers", false));
    public final Setting.Hue color = add(new Setting.Hue("Color", 0, 0.9, 1.0));
    // notifications
    public final Setting.Bool chatNotify = add(new Setting.Bool("Chat Notification", false));
    public final Setting.Bool discordNotify = add(new Setting.Bool("Discord Notification", false));
    public final Setting.Str webhook = add(new Setting.Str("Webhook", "", 200));
    // scanning
    public final Setting.Num scanSpeed = add(new Setting.Num("Chunks Per Tick", 4, 1, 16, 1));
    public final Setting.Action clear = add(new Setting.Action("Clear Flags", () -> { if (I != null) I.reset(); }));

    private final Map<Long, Info> cand = new HashMap<>();
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();
    private final Set<Long> notified = new HashSet<>();
    private List<Vis> visible = new ArrayList<>();
    private int timer;

    public SusChunk() {
        super("SusChunk", "Highlights chunks that look like player bases.", "DONUT", true);
        I = this;
    }

    private void reset() { cand.clear(); queue.clear(); visible = new ArrayList<>(); notified.clear(); }
    private static long key(int x, int z) { return (((long) x) << 32) ^ (z & 0xFFFFFFFFL); }
    @Override public void onDisable() { reset(); }

    private int level(int eff) {
        double m = minScore.value;
        return eff >= m * 3 ? 3 : eff >= m * 1.8 ? 2 : 1;
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        if (queue.isEmpty()) {
            int r = Math.min(mc.options.getEffectiveRenderDistance(), 32);
            int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
            for (int x = pcx - r; x <= pcx + r; x++)
                for (int z = pcz - r; z <= pcz + r; z++) queue.add(new int[]{x, z});
        }
        for (int n = 0; n < scanSpeed.i() && !queue.isEmpty(); n++) {
            int[] c = queue.poll();
            LevelChunk ch = mc.level.getChunkSource().getChunkNow(c[0], c[1]);
            long k = key(c[0], c[1]);
            if (ch == null) { cand.remove(k); continue; }
            Info info = analyze(ch, c[0], c[1]);
            if (info == null) cand.remove(k); else cand.put(k, info);
        }
        if (++timer % 20 == 0) recompute(mc);
    }

    private void recompute(Minecraft mc) {
        List<Vis> out = new ArrayList<>();
        for (Info i : cand.values()) {
            int eff = i.score();
            if (cluster.value) {
                int nb = 0;
                for (int dx = -1; dx <= 1; dx++)
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dz == 0) continue;
                        Info n = cand.get(key(i.cx() + dx, i.cz() + dz));
                        if (n != null) nb += n.score();
                    }
                eff += (int) (nb * 0.35);
            }
            if (eff < minScore.i()) continue;
            int lv = level(eff);
            if (lv < minLevel.i()) continue;
            out.add(new Vis(i, eff, lv));
        }
        out.sort(Comparator.comparingInt((Vis v) -> -v.eff()));
        visible = out;
        for (Vis v : out) {
            long k = key(v.info().cx(), v.info().cz());
            if (notified.add(k)) notifyNew(mc, v);
        }
    }

    private void notifyNew(Minecraft mc, Vis v) {
        String lvl = v.level() == 3 ? "HIGH" : v.level() == 2 ? "MED" : "LOW";
        String msg = "Sus chunk at " + (v.info().cx() * 16) + ", " + (v.info().cz() * 16) + " score " + v.eff() + " " + lvl
                + (v.info().ug() >= 3 ? " UNDERGROUND" : "");
        if (chatNotify.value && mc.player != null) mc.player.displayClientMessage(Component.literal("[Tedi] " + msg), false);
        if (discordNotify.value) sendWebhook(webhook.value.trim(), msg);
    }

    private static void sendWebhook(String url, String msg) {
        if (!(url.startsWith("https://discord.com/api/webhooks/") || url.startsWith("https://discordapp.com/api/webhooks/"))) return;
        Thread t = new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) URI.create(url).toURL().openConnection();
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setConnectTimeout(5000);
                c.setReadTimeout(5000);
                c.setRequestProperty("Content-Type", "application/json");
                String body = "{\"content\":\"" + msg.replace("\\", "\\\\").replace("\"", "\\\"") + "\"}";
                try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
                c.getResponseCode();
                c.disconnect();
            } catch (Exception ignored) {}
        }, "tedi-webhook");
        t.setDaemon(true);
        t.start();
    }

    private Info analyze(LevelChunk ch, int cx, int cz) {
        int am = 0, st = 0, ot = 0, sp = 0, pm = 0, ug = 0, ugStorage = 0;
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        int yLo = minYs.i(), yHi = maxYs.i(), depth = ugDepth.i();
        int[] surf = null;
        if (smart.value) {
            surf = new int[256];
            for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) surf[x * 16 + z] = ch.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
        }

        if (amethyst.value || playerBlocks.value || smart.value) {
            LevelChunkSection[] secs = ch.getSections();
            for (int i = 0; i < secs.length; i++) {
                LevelChunkSection sec = secs[i];
                if (sec.hasOnlyAir()) continue;
                int baseY = ch.getMinY() + i * 16;
                if (baseY + 15 < yLo || baseY > yHi) continue;
                boolean wantA = amethyst.value && sec.maybeHas(s -> s.is(Blocks.AMETHYST_CLUSTER));
                boolean wantP = playerBlocks.value && sec.maybeHas(s -> INDICATORS.contains(s.getBlock()));
                boolean wantU = smart.value && sec.maybeHas(s -> UG_INDICATORS.contains(s.getBlock()));
                if (!wantA && !wantP && !wantU) continue;
                for (int x = 0; x < 16; x++)
                    for (int y = 0; y < 16; y++) {
                        int wy = baseY + y;
                        if (wy < yLo || wy > yHi) continue;
                        for (int z = 0; z < 16; z++) {
                            Block b = sec.getBlockState(x, y, z).getBlock();
                            boolean under = surf != null && wy < surf[x * 16 + z] - depth;
                            if (wantA && b == Blocks.AMETHYST_CLUSTER) {
                                am++; minY = Math.min(minY, wy); maxY = Math.max(maxY, wy);
                            } else if (wantP && INDICATORS.contains(b)) {
                                pm += under ? 2 : 1;
                                if (under) ug++;
                                minY = Math.min(minY, wy); maxY = Math.max(maxY, wy);
                            } else if (wantU && under && UG_INDICATORS.contains(b)) {
                                pm += 2; ug++;
                                minY = Math.min(minY, wy); maxY = Math.max(maxY, wy);
                            }
                        }
                    }
            }
        }
        for (BlockEntity be : ch.getBlockEntities().values()) {
            int y = be.getBlockPos().getY();
            if (y < yLo || y > yHi) continue;
            int t = StorageEsp.classify(be);
            boolean under = surf != null && y < surf[(be.getBlockPos().getX() & 15) * 16 + (be.getBlockPos().getZ() & 15)] - depth;
            if (t >= 0 && t <= 4 && storage.value) {
                st++;
                if (under) { ugStorage++; ug++; }
                minY = Math.min(minY, y); maxY = Math.max(maxY, y);
            } else if (t == 5 && storage.value) ot++;
            else if (t == 6 && spawners.value) { sp++; minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
        }
        int score = am * 6 + st * 3 + ot * 2 + sp * 2 + Math.min(pm, 80) + ugStorage * 3;
        if (minStorage.i() > 0 && st >= minStorage.i()) score += 500;
        if (score < minScore.value * 0.4 || minY == Integer.MAX_VALUE) return null;
        return new Info(cx, cz, score, am, st, pm, sp, ug, minY, maxY);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (visible.isEmpty()) return;
        int shown = 0;
        for (Vis v : visible) {
            if (shown++ >= maxShown.i()) break;
            Info i = v.info();
            int lv = v.level();
            int col = color.argb(lv == 1 ? 0xB0 : 0xFF);
            float w = lineWidth.f() * (lv == 3 ? 1.5f : 1f);
            double x0 = i.cx() * 16, z0 = i.cz() * 16, x1 = x0 + 16, z1 = z0 + 16;
            double mid = (i.minY() + i.maxY()) / 2.0 + 0.5;
            if (fill.value) {
                double lo, hi;
                if (fullHeight.value) { lo = mc.level.getMinY(); hi = lo + mc.level.getHeight(); }
                else { lo = mid - fillHeight.value / 2; hi = mid + fillHeight.value / 2; }
                int fa = (int) (fillOpacity.value * 255 * (0.6 + 0.2 * (lv - 1)));
                int fc = Colors.withAlpha(color.rgb(), Math.min(255, fa));
                Proj.quad(g, new double[]{x0, lo, z0, x1, lo, z0, x1, hi, z0, x0, hi, z0}, fc);
                Proj.quad(g, new double[]{x0, lo, z1, x1, lo, z1, x1, hi, z1, x0, hi, z1}, fc);
                Proj.quad(g, new double[]{x0, lo, z0, x0, lo, z1, x0, hi, z1, x0, hi, z0}, fc);
                Proj.quad(g, new double[]{x1, lo, z0, x1, lo, z1, x1, hi, z1, x1, hi, z0}, fc);
                Proj.quad(g, new double[]{x0, lo, z0, x1, lo, z0, x1, lo, z1, x0, lo, z1}, fc);
                Proj.quad(g, new double[]{x0, hi, z0, x1, hi, z0, x1, hi, z1, x0, hi, z1}, fc);
            }
            if (line.value) {
                Proj.line3d(g, x0, mid, z0, x1, mid, z0, w, col);
                Proj.line3d(g, x1, mid, z0, x1, mid, z1, w, col);
                Proj.line3d(g, x1, mid, z1, x0, mid, z1, w, col);
                Proj.line3d(g, x0, mid, z1, x0, mid, z0, w, col);
            }
            if (vertical.value) {
                double lo = mc.level.getMinY(), hi = mc.level.getMinY() + mc.level.getHeight();
                Proj.line3d(g, x0, lo, z0, x0, hi, z0, w, col);
                Proj.line3d(g, x1, lo, z0, x1, hi, z0, w, col);
                Proj.line3d(g, x1, lo, z1, x1, hi, z1, w, col);
                Proj.line3d(g, x0, lo, z1, x0, hi, z1, w, col);
            }
            if (tracers.value) Proj.tracer(g, x0 + 8, mid, z0 + 8, 1f, col);
            if (labels.value && Proj.project(x0 + 8, mid + 2, z0 + 8)) {
                String lvl = lv == 3 ? "HIGH" : lv == 2 ? "MED" : "LOW";
                Proj.label(g, "Sus " + v.eff() + " " + lvl + (i.ug() >= 3 ? " UNDERGROUND" : ""), Proj.px, Proj.py, color.argb());
            }
        }
    }
}
