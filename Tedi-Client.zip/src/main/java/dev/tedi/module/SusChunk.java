package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.BaseScan;
import dev.tedi.util.ChunkDraw;
import dev.tedi.util.Colors;
import dev.tedi.util.Notify;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.*;

/** Scores every loaded chunk by how much it looks player-dug / player-built, with extra focus on underground bases. */
public class SusChunk extends Module {
    public static SusChunk I;
    public record Info(int cx, int cz, int score, int amethyst, int blocks, int spawners, int ug, int tunnels, int minY, int maxY) {}
    private record Vis(Info info, int eff, int level) {}
    private static class Cache { LevelChunk ch; long t; BaseScan.Blocks_ b; BaseScan.Tunnels tu; }

    // detection
    public final Setting.Bool amethyst = add(new Setting.Bool("Grown Amethyst", true));
    public final Setting.Bool playerBlocks = add(new Setting.Bool("Player-made Blocks", true));
    public final Setting.Bool spawners = add(new Setting.Bool("Spawners", false));
    public final Setting.Bool underground = add(new Setting.Bool("AI Improvement (Underground)", true));
    public final Setting.Num ugDepth = add(new Setting.Num("Underground Depth", 8, 4, 60, 2));
    public final Setting.Bool cluster = add(new Setting.Bool("Cluster Bonus", true));
    public final Setting.Num minScore = add(new Setting.Num("Min Score", 25, 5, 300, 5));
    public final Setting.Num minLevel = add(new Setting.Num("Min Level (1-3)", 1, 1, 3, 1));
    public final Setting.Num minYs = add(new Setting.Num("Min Y", -64, -64, 320, 8));
    public final Setting.Num maxYs = add(new Setting.Num("Max Y", 320, -64, 320, 8));
    // display
    public final Setting.Num maxShown = add(new Setting.Num("Max Chunks Shown", 12, 1, 50, 1));
    public final Setting.Bool fill = add(new Setting.Bool("Border Walls", true));
    public final Setting.Num fillOpacity = add(new Setting.Num("Wall Opacity (Density)", 0.35, 0.05, 1.0, 0.05));
    public final Setting.Bool fullHeight = add(new Setting.Bool("Full Height Walls", false));
    public final Setting.Num fillHeight = add(new Setting.Num("Wall Height", 48, 8, 256, 8));
    public final Setting.Bool line = add(new Setting.Bool("Chunk Line", true));
    public final Setting.Bool vertical = add(new Setting.Bool("Vertical Edges", true));
    public final Setting.Num lineWidth = add(new Setting.Num("Line Width", 1.5, 0.5, 4.0, 0.5));
    public final Setting.Bool labels = add(new Setting.Bool("Labels", true));
    public final Setting.Bool tracers = add(new Setting.Bool("Tracers", false));
    public final Setting.Hue color = add(new Setting.Hue("Color", 0, 0.9, 1.0));
    // notifications
    public final Setting.Bool chatNotify = add(new Setting.Bool("Chat Notification", false));
    public final Setting.Bool discordNotify = add(new Setting.Bool("Discord Notification", false));
    public final Setting.Str webhook = add(new Setting.Str("Webhook", "", 200));
    // scanning
    public final Setting.Num scanSpeed = add(new Setting.Num("Chunks Per Tick", 3, 1, 16, 1));
    public final Setting.Action clear = add(new Setting.Action("Clear Flags", () -> { if (I != null) I.reset(); }));

    private final Map<Long, Info> cand = new HashMap<>();
    private final Map<Long, Cache> cache = new HashMap<>();
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();
    private final Set<Long> notified = new HashSet<>();
    private List<Vis> visible = new ArrayList<>();
    private int timer;

    public SusChunk() {
        super("SusChunk", "Highlights chunks that look like player bases.", "DONUT", true);
        I = this;
    }

    private void reset() { cand.clear(); cache.clear(); queue.clear(); visible = new ArrayList<>(); notified.clear(); }
    private static long key(int x, int z) { return (((long) x) << 32) ^ (z & 0xFFFFFFFFL); }
    @Override public void onDisable() { reset(); }

    private int level(int eff) {
        double m = minScore.value;
        return eff >= m * 3 ? 3 : eff >= m * 1.8 ? 2 : 1;
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        if (queue.isEmpty()) {
            int r = Math.min(mc.options.getEffectiveRenderDistance(), 32);
            int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
            for (int x = pcx - r; x <= pcx + r; x++)
                for (int z = pcz - r; z <= pcz + r; z++) queue.add(new int[]{x, z});
        }
        long now = System.currentTimeMillis();
        for (int n = 0; n < scanSpeed.i() && !queue.isEmpty(); n++) {
            int[] c = queue.poll();
            LevelChunk ch = mc.level.getChunkSource().getChunkNow(c[0], c[1]);
            long k = key(c[0], c[1]);
            if (ch == null) { cand.remove(k); cache.remove(k); continue; }
            Info info = analyze(ch, c[0], c[1], k, now);
            if (info == null) cand.remove(k); else cand.put(k, info);
        }
        if (++timer % 20 == 0) recompute(mc);
    }

    private Info analyze(LevelChunk ch, int cx, int cz, long k, long now) {
        int yLo = minYs.i(), yHi = maxYs.i(), depth = ugDepth.i();
        Cache c = cache.get(k);
        if (c == null || c.ch != ch || now - c.t > 45000) {
            int[] surf = BaseScan.surface(ch);
            c = new Cache();
            c.ch = ch; c.t = now;
            c.b = BaseScan.blocks(ch, amethyst.value, playerBlocks.value, underground.value, yLo, yHi, depth, surf);
            c.tu = underground.value ? BaseScan.tunnels(ch, yLo, yHi, depth, surf) : null;
            cache.put(k, c);
        }
        int sp = 0, minY = c.b.minY(), maxY = c.b.maxY();
        if (spawners.value) {
            BaseScan.Ents e = BaseScan.ents(ch, false, true, yLo, yHi, depth, null);
            sp = e.spawners();
            if (sp > 0) { minY = Math.min(minY, e.minY()); maxY = Math.max(maxY, e.maxY()); }
        }
        int tun = 0, shafts = 0;
        if (c.tu != null) {
            tun = c.tu.tunnels(); shafts = c.tu.shafts();
            if (tun + shafts > 0) { minY = Math.min(minY, c.tu.minY()); maxY = Math.max(maxY, c.tu.maxY()); }
        }
        int score = c.b.am() * 6 + Math.min(c.b.pm(), 80) + sp * 2 + Math.min(tun, 6) * 8 + Math.min(shafts, 4) * 6;
        if (score < minScore.value * 0.4 || minY == Integer.MAX_VALUE) return null;
        int ug = c.b.ug() + tun * 3 + shafts * 3;
        return new Info(cx, cz, score, c.b.am(), c.b.pm(), sp, ug, tun + shafts, minY, maxY);
    }

    private void recompute(Minecraft mc) {
        List<Vis> out = new ArrayList<>();
        for (Info i : cand.values()) {
            int eff = i.score();
            if (cluster.value) {
                int nb = 0;
                for (int dx = -1; dx <= 1; dx++)
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dz == 0) continue;
                        Info n = cand.get(key(i.cx() + dx, i.cz() + dz));
                        if (n != null) nb += n.score();
                    }
                eff += (int) (nb * 0.35);
            }
            if (eff < minScore.i()) continue;
            int lv = level(eff);
            if (lv < minLevel.i()) continue;
            out.add(new Vis(i, eff, lv));
        }
        out.sort(Comparator.comparingInt((Vis v) -> -v.eff()));
        visible = out;
        for (Vis v : out) {
            if (notified.add(key(v.info().cx(), v.info().cz()))) notifyNew(mc, v);
        }
    }

    private void notifyNew(Minecraft mc, Vis v) {
        String lvl = v.level() == 3 ? "HIGH" : v.level() == 2 ? "MED" : "LOW";
        String msg = "Sus chunk at " + (v.info().cx() * 16) + ", " + (v.info().cz() * 16) + " score " + v.eff() + " " + lvl
                + (v.info().ug() >= 3 ? " UNDERGROUND" : "");
        if (chatNotify.value && mc.player != null) mc.player.displayClientMessage(Component.literal("[Tedi] " + msg), false);
        if (discordNotify.value) Notify.webhook(webhook.value, msg);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (visible.isEmpty()) return;
        int shown = 0;
        for (Vis v : visible) {
            if (shown++ >= maxShown.i()) break;
            Info i = v.info();
            int lv = v.level();
            int col = color.argb(lv == 1 ? 0xB0 : 0xFF);
            float w = lineWidth.f() * (lv == 3 ? 1.5f : 1f);
            double mid = (i.minY() + i.maxY()) / 2.0 + 0.5;
            int wa = Math.min(255, (int) (fillOpacity.value * 255 * (0.6 + 0.2 * (lv - 1))));
            ChunkDraw.draw(g, mc, i.cx(), i.cz(), mid, fill.value, Colors.withAlpha(color.rgb(), wa),
                    fullHeight.value, fillHeight.value, line.value, vertical.value, w, col);
            if (tracers.value) Proj.tracer(g, i.cx() * 16 + 8, mid, i.cz() * 16 + 8, 1f, col);
            if (labels.value && Proj.project(i.cx() * 16 + 8, mid + 2, i.cz() * 16 + 8)) {
                String lvl = lv == 3 ? "HIGH" : lv == 2 ? "MED" : "LOW";
                Proj.label(g, "Sus " + v.eff() + " " + lvl + (i.ug() >= 3 ? " UNDERGROUND" : ""), Proj.px, Proj.py, color.argb());
            }
        }
    }
}
