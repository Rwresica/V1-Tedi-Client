package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** Scores every loaded chunk by how much it looks player-modified, and outlines the likely bases. */
public class SusChunk extends Module {
    public static SusChunk I;
    public record Info(int cx, int cz, int score, int amethyst, int storage, int blocks, int spawners, int minY, int maxY) {}

    private static final Set<Block> INDICATORS = new HashSet<>(Arrays.asList(
            Blocks.IRON_BLOCK, Blocks.GOLD_BLOCK, Blocks.DIAMOND_BLOCK, Blocks.EMERALD_BLOCK, Blocks.NETHERITE_BLOCK,
            Blocks.LAPIS_BLOCK, Blocks.REDSTONE_BLOCK, Blocks.COAL_BLOCK, Blocks.COPPER_BLOCK, Blocks.BEACON,
            Blocks.ENCHANTING_TABLE, Blocks.ANVIL, Blocks.TNT, Blocks.PISTON, Blocks.STICKY_PISTON, Blocks.OBSERVER,
            Blocks.REPEATER, Blocks.COMPARATOR, Blocks.REDSTONE_LAMP, Blocks.HOPPER, Blocks.DROPPER, Blocks.DISPENSER,
            Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER, Blocks.BREWING_STAND, Blocks.CRAFTING_TABLE,
            Blocks.SMITHING_TABLE, Blocks.SCAFFOLDING, Blocks.GLASS, Blocks.BARREL));

    public final Setting.Bool amethyst = add(new Setting.Bool("Grown Amethyst", true));
    public final Setting.Bool storage = add(new Setting.Bool("Storage Blocks", true));
    public final Setting.Bool playerBlocks = add(new Setting.Bool("Player-made Blocks", true));
    public final Setting.Bool spawners = add(new Setting.Bool("Spawners", false));
    public final Setting.Num minScore = add(new Setting.Num("Min Score", 25, 5, 300, 5));
    public final Setting.Num minLevel = add(new Setting.Num("Min Level (1-3)", 1, 1, 3, 1));
    public final Setting.Num minYs = add(new Setting.Num("Min Y", -64, -64, 320, 8));
    public final Setting.Num maxYs = add(new Setting.Num("Max Y", 320, -64, 320, 8));
    public final Setting.Num maxShown = add(new Setting.Num("Max Chunks Shown", 12, 1, 50, 1));
    public final Setting.Bool line = add(new Setting.Bool("Chunk Line", true));
    public final Setting.Bool vertical = add(new Setting.Bool("Vertical Edges", false));
    public final Setting.Bool wall = add(new Setting.Bool("Wall Fill", false));
    public final Setting.Num lineWidth = add(new Setting.Num("Line Width", 1.5, 0.5, 4.0, 0.5));
    public final Setting.Bool labels = add(new Setting.Bool("Labels", true));
    public final Setting.Bool tracers = add(new Setting.Bool("Tracers", false));
    public final Setting.Hue color = add(new Setting.Hue("Color", 0, 0.85, 1.0));
    public final Setting.Num scanSpeed = add(new Setting.Num("Chunks Per Tick", 4, 1, 16, 1));
    public final Setting.Action clear = add(new Setting.Action("Clear Flags", () -> { if (I != null) { I.flagged.clear(); I.queue.clear(); } }));

    private final Map<Long, Info> flagged = new HashMap<>();
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();

    public SusChunk() {
        super("SusChunk", "Outlines chunks that look like player bases.", "RENDER", true);
        I = this;
    }

    public boolean isFlagged(int cx, int cz) { return flagged.containsKey(key(cx, cz)); }
    public Collection<Info> flaggedChunks() { return flagged.values(); }
    private static long key(int x, int z) { return (((long) x) << 32) ^ (z & 0xFFFFFFFFL); }

    @Override public void onDisable() { flagged.clear(); queue.clear(); }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        if (queue.isEmpty()) {
            int r = Math.min(mc.options.getEffectiveRenderDistance(), 32);
            int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
            for (int x = pcx - r; x <= pcx + r; x++)
                for (int z = pcz - r; z <= pcz + r; z++) queue.add(new int[]{x, z});
        }
        for (int n = 0; n < scanSpeed.i() && !queue.isEmpty(); n++) {
            int[] c = queue.poll();
            LevelChunk ch = mc.level.getChunkSource().getChunkNow(c[0], c[1]);
            long k = key(c[0], c[1]);
            if (ch == null) { flagged.remove(k); continue; }
            Info info = analyze(ch, c[0], c[1]);
            if (info == null) flagged.remove(k); else flagged.put(k, info);
        }
    }

    private int level(int score) {
        double m = minScore.value;
        return score >= m * 3 ? 3 : score >= m * 1.8 ? 2 : 1;
    }

    private Info analyze(LevelChunk ch, int cx, int cz) {
        int am = 0, st = 0, ot = 0, sp = 0, pm = 0;
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        int yLo = minYs.i(), yHi = maxYs.i();

        if (amethyst.value || playerBlocks.value) {
            LevelChunkSection[] secs = ch.getSections();
            for (int i = 0; i < secs.length; i++) {
                LevelChunkSection sec = secs[i];
                if (sec.hasOnlyAir()) continue;
                int baseY = ch.getMinY() + i * 16;
                if (baseY + 15 < yLo || baseY > yHi) continue;
                boolean wantA = amethyst.value && sec.maybeHas(s -> s.is(Blocks.AMETHYST_CLUSTER));
                boolean wantP = playerBlocks.value && sec.maybeHas(s -> INDICATORS.contains(s.getBlock()));
                if (!wantA && !wantP) continue;
                for (int x = 0; x < 16; x++)
                    for (int y = 0; y < 16; y++) {
                        int wy = baseY + y;
                        if (wy < yLo || wy > yHi) continue;
                        for (int z = 0; z < 16; z++) {
                            Block b = sec.getBlockState(x, y, z).getBlock();
                            if (wantA && b == Blocks.AMETHYST_CLUSTER) {
                                am++; minY = Math.min(minY, wy); maxY = Math.max(maxY, wy);
                            } else if (wantP && INDICATORS.contains(b)) {
                                pm++; minY = Math.min(minY, wy); maxY = Math.max(maxY, wy);
                            }
                        }
                    }
            }
        }
        for (BlockEntity be : ch.getBlockEntities().values()) {
            int y = be.getBlockPos().getY();
            if (y < yLo || y > yHi) continue;
            int t = StorageEsp.classify(be);
            if (t >= 0 && t <= 4 && storage.value) { st++; minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
            else if (t == 5 && storage.value) ot++;
            else if (t == 6 && spawners.value) { sp++; minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
        }
        int score = am * 6 + st * 3 + ot * 2 + sp * 2 + Math.min(pm, 60);
        if (score < minScore.i() || minY == Integer.MAX_VALUE) return null;
        if (level(score) < minLevel.i()) return null;
        return new Info(cx, cz, score, am, st, pm, sp, minY, maxY);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (flagged.isEmpty()) return;
        List<Info> list = new ArrayList<>(flagged.values());
        list.sort(Comparator.comparingInt((Info i) -> -i.score()));
        int sx = g.guiWidth() / 2, sy = g.guiHeight() / 2;
        int shown = 0;
        for (Info i : list) {
            if (shown++ >= maxShown.i()) break;
            int lv = level(i.score());
            int col = color.argb(lv == 1 ? 0xA0 : 0xFF);
            float w = lineWidth.f() * (lv == 3 ? 1.5f : 1f);
            double x0 = i.cx() * 16, z0 = i.cz() * 16, x1 = x0 + 16, z1 = z0 + 16;
            double y = (i.minY() + i.maxY()) / 2.0 + 0.5;
            if (wall.value) {
                int wa = Colors.withAlpha(color.rgb(), 0x30);
                double lo = y - 16, hi = y + 16;
                Proj.quad(g, new double[]{x0, lo, z0, x1, lo, z0, x1, hi, z0, x0, hi, z0}, wa);
                Proj.quad(g, new double[]{x0, lo, z1, x1, lo, z1, x1, hi, z1, x0, hi, z1}, wa);
                Proj.quad(g, new double[]{x0, lo, z0, x0, lo, z1, x0, hi, z1, x0, hi, z0}, wa);
                Proj.quad(g, new double[]{x1, lo, z0, x1, lo, z1, x1, hi, z1, x1, hi, z0}, wa);
            }
            if (line.value) {
                Proj.line3d(g, x0, y, z0, x1, y, z0, w, col);
                Proj.line3d(g, x1, y, z0, x1, y, z1, w, col);
                Proj.line3d(g, x1, y, z1, x0, y, z1, w, col);
                Proj.line3d(g, x0, y, z1, x0, y, z0, w, col);
            }
            if (vertical.value) {
                double lo = mc.level.getMinY(), hi = mc.level.getMinY() + mc.level.getHeight();
                Proj.line3d(g, x0, lo, z0, x0, hi, z0, w, col);
                Proj.line3d(g, x1, lo, z0, x1, hi, z0, w, col);
                Proj.line3d(g, x1, lo, z1, x1, hi, z1, w, col);
                Proj.line3d(g, x0, lo, z1, x0, hi, z1, w, col);
            }
            Vec3 c = new Vec3(x0 + 8, y, z0 + 8);
            if (tracers.value && Proj.project(c.x, c.y, c.z)) Proj.line(g, sx, sy, Proj.px, Proj.py, 1f, col);
            if (labels.value && Proj.project(c.x, y + 2, c.z)) {
                String lvl = lv == 3 ? "HIGH" : lv == 2 ? "MED" : "LOW";
                Proj.label(g, "Sus " + i.score() + " " + lvl, Proj.px, Proj.py, color.argb());
            }
        }
    }
}
