package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.BaseScan;
import dev.tedi.util.ChunkDraw;
import dev.tedi.util.Proj;
import dev.tedi.util.Toasts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;

import java.util.*;

/**
 * Sus Chunk Finder. Flags chunks that were touched by players, with extra effort on underground bases:
 * fully grown kelp / cave vines, vines + bamboo + bee nests underground, cocoa outside jungles,
 * grown amethyst, deepslate that is NOT axis-Y (never natural) and - with Smart Adjustment - dug tunnels,
 * shafts, player-made blocks and torches/ladders/doors underground.
 */
public class SusChunk extends Module {
    public static SusChunk I;
    public record Info(int cx, int cz, int score, int ug, int minY, int maxY) {}
    private record Vis(Info info, int eff, int level) {}
    private static class Cache { LevelChunk ch; long t; Info info; }

    public final Setting.Num simDist = add(new Setting.Num("Simulation Distance", 8, 2, 32, 1));
    public final Setting.Num sensitivity = add(new Setting.Num("Sensitivity", 5, 1, 10, 1));
    public final Setting.Bool smart = add(new Setting.Bool("Smart Adjustment", true));
    public final Setting.Num alpha = add(new Setting.Num("Alpha", 90, 10, 255, 5));
    public final Setting.Bool kelp = add(new Setting.Bool("Kelp", true));
    public final Setting.Bool caveVines = add(new Setting.Bool("Cave Vines", true));
    public final Setting.Bool vines = add(new Setting.Bool("Vines", true));
    public final Setting.Bool amethyst = add(new Setting.Bool("Amethyst", true));
    public final Setting.Bool bamboo = add(new Setting.Bool("Bamboo", true));
    public final Setting.Bool cocoa = add(new Setting.Bool("Cocoa", true));
    public final Setting.Bool beeNest = add(new Setting.Bool("Bee Nest", true));
    public final Setting.Bool rotDeep = add(new Setting.Bool("Rotated Deepslate", true));

    private final Map<Long, Info> cand = new HashMap<>();
    private final Map<Long, Cache> cache = new HashMap<>();
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();
    private final Set<Long> notified = new HashSet<>();
    private List<Vis> visible = new ArrayList<>();
    private int timer;

    public SusChunk() {
        super("SusChunk", "Finds chunks players touched, esp. underground bases.", "DONUT", true);
        I = this;
    }

    private void reset() { cand.clear(); cache.clear(); queue.clear(); visible = new ArrayList<>(); notified.clear(); }
    private static long key(int x, int z) { return (((long) x) << 32) ^ (z & 0xFFFFFFFFL); }
    @Override public void onDisable() { reset(); }

    private double baseThreshold() { return Math.max(6.0, 48.0 - sensitivity.value * 4.2); }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        if (queue.isEmpty()) {
            int r = simDist.i();
            int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
            for (int x = pcx - r; x <= pcx + r; x++)
                for (int z = pcz - r; z <= pcz + r; z++) queue.add(new int[]{x, z});
        }
        long now = System.currentTimeMillis();
        for (int n = 0; n < 3 && !queue.isEmpty(); n++) {
            int[] c = queue.poll();
            long k = key(c[0], c[1]);
            LevelChunk ch = mc.level.getChunkSource().getChunkNow(c[0], c[1]);
            if (ch == null) { cand.remove(k); cache.remove(k); continue; }
            Info info = analyze(ch, c[0], c[1], k, now);
            if (info == null) cand.remove(k); else cand.put(k, info);
        }
        if (++timer % 20 == 0) recompute(mc);
    }

    private Info analyze(LevelChunk ch, int cx, int cz, long k, long now) {
        Cache c = cache.get(k);
        if (c != null && c.ch == ch && now - c.t < 45000) return c.info;
        int yLo = -64, yHi = 320, depth = 8;
        int[] surf = BaseScan.surface(ch);
        BaseScan.Growth gr = BaseScan.growth(ch, cx, cz, yLo, yHi, depth, surf, kelp.value, caveVines.value, vines.value,
                bamboo.value, cocoa.value, beeNest.value, rotDeep.value);
        int score = gr.score(), ug = gr.ug();
        int minY = gr.minY(), maxY = gr.maxY();
        if (amethyst.value || smart.value) {
            BaseScan.Blocks_ b = BaseScan.blocks(ch, amethyst.value, smart.value, smart.value, yLo, yHi, depth, surf);
            score += b.am() * 6;
            if (smart.value) score += Math.min(b.pm(), 60);
            ug += b.ug();
            if (b.minY() != Integer.MAX_VALUE) { minY = Math.min(minY, b.minY()); maxY = Math.max(maxY, b.maxY()); }
        }
        if (smart.value) {
            BaseScan.Tunnels tu = BaseScan.tunnels(ch, yLo, yHi, depth, surf);
            score += Math.min(tu.tunnels(), 6) * 8 + Math.min(tu.shafts(), 4) * 6;
            ug += (tu.tunnels() + tu.shafts()) * 3;
            if (tu.minY() != Integer.MAX_VALUE) { minY = Math.min(minY, tu.minY()); maxY = Math.max(maxY, tu.maxY()); }
        }
        Info info = null;
        if (score >= baseThreshold() * 0.3 && minY != Integer.MAX_VALUE) info = new Info(cx, cz, score, ug, minY, maxY);
        c = new Cache();
        c.ch = ch; c.t = now; c.info = info;
        cache.put(k, c);
        return info;
    }

    private void recompute(Minecraft mc) {
        List<Vis> out = new ArrayList<>();
        for (Info i : cand.values()) {
            int eff = i.score(), nb = 0;
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dz == 0) continue;
                    Info n = cand.get(key(i.cx() + dx, i.cz() + dz));
                    if (n != null) nb += n.score();
                }
            eff += (int) (nb * 0.35);
            double t = baseThreshold();
            if (smart.value && i.ug() >= 3) t *= 0.7;
            if (eff < t) continue;
            int lv = eff >= t * 3 ? 3 : eff >= t * 1.8 ? 2 : 1;
            out.add(new Vis(i, eff, lv));
        }
        out.sort(Comparator.comparingInt((Vis v) -> -v.eff()));
        visible = out;
        for (Vis v : out) {
            if (notified.add(key(v.info().cx(), v.info().cz()))) {
                String lvl = v.level() == 3 ? "HIGH" : v.level() == 2 ? "MED" : "LOW";
                Toasts.push("Sus Chunk Found", (v.info().cx() * 16) + ", " + (v.info().cz() * 16) + "  |  " + lvl
                        + (v.info().ug() >= 3 ? "  |  UNDERGROUND" : ""), 0xFFFF5A5A, "alert");
            }
        }
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        int shown = 0;
        for (Vis v : visible) {
            if (shown++ >= 16) break;
            Info i = v.info();
            double y = Math.floor((i.minY() + i.maxY()) / 2.0) + 0.05;
            int a = Math.min(255, (int) (alpha.value * (0.7 + 0.15 * (v.level() - 1))));
            ChunkDraw.glass(g, i.cx(), i.cz(), y, 0xFF4A4A, a, 0xFFFF9A9A, 0, shown <= 4 ? 2 : 1);
        }
    }
}
