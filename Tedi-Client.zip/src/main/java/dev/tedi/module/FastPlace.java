package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;

/** Removes the delay between right-click uses: place blocks (or use items) as fast as you can click. */
public class FastPlace extends Module {
    public static FastPlace I;
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 0, 0, 3, 1));
    public final Setting.Bool blocksOnly = add(new Setting.Bool("Blocks Only", true));

    public FastPlace() {
        super("FastPlace", "Place blocks with no click delay.", "MISC", true);
        I = this;
    }

    public static int forcedDelay() {
        if (I == null || !I.enabled) return -1;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return -1;
        ItemStack st = mc.player.getMainHandItem();
        if (st.isEmpty()) return -1;
        if (I.blocksOnly.value && !(st.getItem() instanceof BlockItem)) return -1;
        return I.delay.i();
    }
}
