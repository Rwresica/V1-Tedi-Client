package dev.tedi.module;

import dev.tedi.gui.CrosshairEditor;
import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Your own crosshair, drawn pixel by pixel on a 15x15 grid. */
public class CustomCrosshair extends Module {
    public static CustomCrosshair I;
    public static final int N = 15;

    public final Setting.Action edit = add(new Setting.Action("Draw Crosshair...", () -> {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(new CrosshairEditor(mc.screen));
    }));
    public final Setting.Hue color = add(new Setting.Hue("Color", 0, 0.0, 1.0));
    public final Setting.Num size = add(new Setting.Num("Pixel Size", 1, 1, 6, 1));
    public final Setting.Bool outline = add(new Setting.Bool("Outline", true));
    public final Setting.Str bitmap = add(new Setting.Str("Bitmap", preset("plus"), 400));
    { bitmap.hidden = true; }

    public CustomCrosshair() {
        super("CustomCrosshair", "Draw your own crosshair pixel by pixel.", "MISC", true);
        I = this;
    }

    public static boolean active() { return I != null && I.enabled; }

    public static String preset(String name) {
        char[] c = new char[N * N];
        java.util.Arrays.fill(c, '0');
        int m = N / 2;
        switch (name) {
            case "plus", "plusdot" -> {
                for (int d = 2; d <= 5; d++) { c[m * N + m - d] = '1'; c[m * N + m + d] = '1'; c[(m - d) * N + m] = '1'; c[(m + d) * N + m] = '1'; }
                if (name.equals("plusdot")) c[m * N + m] = '1';
            }
            case "cross" -> {
                for (int d = 2; d <= 5; d++) { c[(m - d) * N + m - d] = '1'; c[(m - d) * N + m + d] = '1'; c[(m + d) * N + m - d] = '1'; c[(m + d) * N + m + d] = '1'; }
            }
            case "dot" -> {
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) c[(m + dy) * N + m + dx] = '1';
            }
            default -> {}
        }
        return new String(c);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.screen != null) return;
        String b = bitmap.value;
        if (b.length() < N * N) return;
        int s = size.i(), cx = g.guiWidth() / 2, cy = g.guiHeight() / 2;
        int x0 = cx - (N * s) / 2, y0 = cy - (N * s) / 2;
        int col = color.argb();
        if (outline.value) {
            for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
                if (b.charAt(r * N + c) != '1') continue;
                int px = x0 + c * s, py = y0 + r * s;
                g.fill(px - 1, py - 1, px + s + 1, py + s + 1, 0xC0000000);
            }
        }
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            if (b.charAt(r * N + c) != '1') continue;
            int px = x0 + c * s, py = y0 + r * s;
            g.fill(px, py, px + s, py + s, col);
        }
    }
}
