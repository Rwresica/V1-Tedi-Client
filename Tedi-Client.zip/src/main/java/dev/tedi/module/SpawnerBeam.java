package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.Vec3;

/** A vertical beam rising out of every spawner so you can spot them from far away. */
public class SpawnerBeam extends Module {
    public static SpawnerBeam I;
    public final Setting.Hue color = add(new Setting.Hue("Beam Color", 0, 0.9, 1.0));
    public final Setting.Num height = add(new Setting.Num("Beam Height", 96, 8, 384, 8));
    public final Setting.Num width = add(new Setting.Num("Beam Width", 2.0, 1.0, 6.0, 0.5));
    public final Setting.Bool glow = add(new Setting.Bool("Glow", true));
    public final Setting.Bool labels = add(new Setting.Bool("Label + Distance", true));
    public final Setting.Num range = add(new Setting.Num("Range", 256, 16, 512, 16));

    public SpawnerBeam() {
        super("SpawnerBeam", "Red beam above every spawner.", "RENDER", true);
        I = this;
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        double r2 = range.value * range.value;
        for (StorageEsp.Hit h : StorageEsp.hits) {
            if (h.type() != 6) continue;
            Vec3 c = h.pos().getCenter();
            double d2 = c.distanceToSqr(Proj.cx, Proj.cy, Proj.cz);
            if (d2 > r2) continue;
            double y1 = h.pos().getY() + 1.0, y2 = y1 + height.value;
            if (glow.value) Proj.line3d(g, c.x, y1, c.z, c.x, y2, c.z, width.f() * 3f, color.argb(0x38));
            Proj.line3d(g, c.x, y1, c.z, c.x, y2, c.z, width.f(), color.argb(0xE6));
            if (labels.value && Proj.project(c.x, y1 + 1.5, c.z)) {
                Proj.label(g, "Spawner [" + (int) Math.sqrt(d2) + "m]", Proj.px, Proj.py, color.argb());
            }
        }
    }
}
