package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** A glowing beam that fades out as it rises from every spawner, with a pulsing core and a marked base. */
public class SpawnerBeam extends Module {
    public static SpawnerBeam I;
    public final Setting.Hue color = add(new Setting.Hue("Beam Color", 0, 0.9, 1.0));
    public final Setting.Num height = add(new Setting.Num("Beam Height", 96, 8, 384, 8));
    public final Setting.Num width = add(new Setting.Num("Beam Width", 2.0, 1.0, 6.0, 0.5));
    public final Setting.Bool glow = add(new Setting.Bool("Glow", true));
    public final Setting.Bool pulse = add(new Setting.Bool("Pulse", true));
    public final Setting.Bool baseBox = add(new Setting.Bool("Mark Spawner Block", true));
    public final Setting.Bool labels = add(new Setting.Bool("Label + Distance", true));
    public final Setting.Num range = add(new Setting.Num("Range", 256, 16, 512, 16));

    public SpawnerBeam() {
        super("SpawnerBeam", "Glowing beam above every spawner.", "DONUT", true);
        I = this;
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        double r2 = range.value * range.value;
        double ph = (System.currentTimeMillis() % 1800) / 1800.0 * Math.PI * 2;
        double pl = pulse.value ? 0.78 + 0.22 * Math.sin(ph) : 1.0;
        final int N = 16;
        for (StorageEsp.Hit h : StorageEsp.hits) {
            if (h.type() != 6) continue;
            Vec3 c = h.pos().getCenter();
            double d2 = c.distanceToSqr(Proj.cx, Proj.cy, Proj.cz);
            if (d2 > r2) continue;
            double y1 = h.pos().getY() + 1.0, hh = height.value;
            for (int s = 0; s < N; s++) {
                double f0 = s / (double) N, f1 = (s + 1) / (double) N;
                double fade = Math.pow(1.0 - f0, 0.65) * pl;
                double ya = y1 + hh * f0, yb = y1 + hh * f1;
                if (glow.value) Proj.line3d(g, c.x, ya, c.z, c.x, yb, c.z, width.f() * 3.4f, color.argb((int) (0x34 * fade)));
                Proj.line3d(g, c.x, ya, c.z, c.x, yb, c.z, width.f(), color.argb((int) (0xF0 * fade)));
                Proj.line3d(g, c.x, ya, c.z, c.x, yb, c.z, Math.max(0.5f, width.f() * 0.35f), 0x00FFFFFF | ((int) (0xB0 * fade) << 24));
            }
            if (baseBox.value) {
                AABB bb = new AABB(h.pos());
                Proj.shadedBox(g, bb, color.rgb(), (int) (0x55 * pl), true, color.argb(), 1f);
            }
            if (labels.value && Proj.project(c.x, y1 + 2.0, c.z)) {
                Proj.label(g, "Spawner  " + (int) Math.sqrt(d2) + "m", Proj.px, Proj.py, color.argb());
            }
        }
    }
}
