package dev.tedi.module;

import com.mojang.blaze3d.platform.InputConstants;
import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

public class Freecam extends Module {
    public static Freecam I;
    public final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 0.1, 10.0, 0.1));
    public final Setting.Num smoothness = add(new Setting.Num("Smoothness", 0.7, 0.0, 0.95, 0.05));
    public final Setting.Num boost = add(new Setting.Num("Ctrl Boost", 1.6, 1.1, 4.0, 0.1));
    public final Setting.Bool keepSneak = add(new Setting.Bool("Keep Sneak", true));
    public final Setting.Bool showTarget = add(new Setting.Bool("Show Mining Target", true));

    private Vec3 pos = Vec3.ZERO, prev = Vec3.ZERO, vel = Vec3.ZERO;
    private boolean sneak;
    public float yaw, pitch;

    public Freecam() {
        super("Freecam", "Fly the camera through blocks.", "MISC", true);
        I = this;
    }

    public static boolean active() { return I != null && I.enabled; }

    @Override
    public void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) { enabled = false; return; }
        pos = prev = mc.player.getEyePosition();
        vel = Vec3.ZERO;
        yaw = mc.player.getYRot();
        pitch = mc.player.getXRot();
        sneak = mc.options.keyShift.isDown() || mc.player.isShiftKeyDown();
    }

    public Vec3 renderPos(float pt) { return prev.lerp(pos, pt); }

    /** What the real player "presses" while the camera is detached: nothing, except a held sneak. */
    public Input playerInput() {
        return new Input(false, false, false, false, false, sneak && keepSneak.value, false);
    }

    public void look(double dYaw, double dPitch) {
        yaw += (float) (dYaw * 0.15);
        pitch = Mth.clamp(pitch + (float) (dPitch * 0.15), -90f, 90f);
    }

    @Override
    public void onTick(Minecraft mc) {
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        Vec3 f = new Vec3(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
        Vec3 l = new Vec3(Math.cos(yr), 0, Math.sin(yr));
        boolean free = mc.screen == null;
        boolean ctrl = free && InputConstants.isKeyDown(mc.getWindow(), GLFW.GLFW_KEY_LEFT_CONTROL);
        double fw = free ? ((mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0)) : 0;
        double st = free ? ((mc.options.keyLeft.isDown() ? 1 : 0) - (mc.options.keyRight.isDown() ? 1 : 0)) : 0;
        double vt = free ? ((mc.options.keyJump.isDown() ? 1 : 0) - (mc.options.keyShift.isDown() ? 1 : 0)) : 0;
        Vec3 dir = f.scale(fw).add(l.scale(st)).add(0, vt, 0);
        Vec3 target = dir.lengthSqr() > 1.0E-6 ? dir.normalize().scale(speed.value * 0.5 * (ctrl ? boost.value : 1.0)) : Vec3.ZERO;
        vel = vel.add(target.subtract(vel).scale(1.0 - smoothness.value));
        prev = pos;
        pos = pos.add(vel);
    }

    /** Mining/placing still uses the PLAYER's aim (vanilla picks from the player), so show where that is. */
    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (!showTarget.value) return;
        HitResult hr = mc.hitResult;
        if (hr instanceof BlockHitResult b && hr.getType() == HitResult.Type.BLOCK) {
            Proj.box(g, new AABB(b.getBlockPos()), 1.5f, Colors.ACCENT);
        }
    }
}
