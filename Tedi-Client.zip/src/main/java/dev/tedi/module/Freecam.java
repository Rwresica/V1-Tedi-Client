package dev.tedi.module;

import com.mojang.blaze3d.platform.InputConstants;
import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

public class Freecam extends Module {
    public static Freecam I;
    public final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 0.1, 10.0, 0.1));
    public final Setting.Num vSpeed = add(new Setting.Num("Vertical Speed", 1.0, 0.2, 3.0, 0.1));
    public final Setting.Num smoothness = add(new Setting.Num("Smoothness", 0.7, 0.0, 0.95, 0.05));
    public final Setting.Num lookSmooth = add(new Setting.Num("Smooth Look", 0.35, 0.0, 0.9, 0.05));
    public final Setting.Num boost = add(new Setting.Num("Ctrl Boost", 1.6, 1.1, 4.0, 0.1));
    public final Setting.Bool keepSneak = add(new Setting.Bool("Keep Sneak", true));
    public final Setting.Bool showTarget = add(new Setting.Bool("Show Mining Target", true));

    private Vec3 pos = Vec3.ZERO, prev = Vec3.ZERO, vel = Vec3.ZERO;
    private boolean sneak;
    public float yaw, pitch;
    private float tyaw, tpitch;
    private long lastNano;

    public Freecam() {
        super("Freecam", "Fly the camera through blocks.", "MISC", true);
        I = this;
    }

    public static boolean active() { return I != null && I.enabled; }

    @Override
    public void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) { enabled = false; return; }
        pos = prev = mc.player.getEyePosition();
        vel = Vec3.ZERO;
        yaw = tyaw = mc.player.getYRot();
        pitch = tpitch = mc.player.getXRot();
        lastNano = System.nanoTime();
        sneak = mc.options.keyShift.isDown() || mc.player.isShiftKeyDown();
    }

    public Vec3 renderPos(float pt) { return prev.lerp(pos, pt); }

    public Input playerInput() {
        return new Input(false, false, false, false, false, sneak && keepSneak.value, false);
    }

    public void look(double dYaw, double dPitch) {
        tyaw += (float) (dYaw * 0.15);
        tpitch = Mth.clamp(tpitch + (float) (dPitch * 0.15), -90f, 90f);
    }

    /** Called once per rendered frame: eases the view toward where the mouse points (frame-rate independent). */
    public void frame() {
        long n = System.nanoTime();
        float dt = Math.min(0.05f, (n - lastNano) / 1e9f);
        lastNano = n;
        if (lookSmooth.value <= 0.001) { yaw = tyaw; pitch = tpitch; return; }
        double k = 1.0 - Math.exp(-dt * (34.0 * (1.0 - lookSmooth.value) + 5.0));
        yaw += (float) ((tyaw - yaw) * k);
        pitch += (float) ((tpitch - pitch) * k);
    }

    @Override
    public void onTick(Minecraft mc) {
        double yr = Math.toRadians(tyaw), pr = Math.toRadians(tpitch);
        Vec3 f = new Vec3(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
        Vec3 l = new Vec3(Math.cos(yr), 0, Math.sin(yr));
        boolean free = mc.screen == null;
        boolean ctrl = free && InputConstants.isKeyDown(mc.getWindow(), GLFW.GLFW_KEY_LEFT_CONTROL);
        double fw = free ? ((mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0)) : 0;
        double st = free ? ((mc.options.keyLeft.isDown() ? 1 : 0) - (mc.options.keyRight.isDown() ? 1 : 0)) : 0;
        double vt = free ? ((mc.options.keyJump.isDown() ? 1 : 0) - (mc.options.keyShift.isDown() ? 1 : 0)) : 0;
        Vec3 h = f.scale(fw).add(l.scale(st));
        if (h.lengthSqr() > 1.0E-6) h = h.normalize();
        Vec3 dir = h.add(0, vt * vSpeed.value, 0);
        if (dir.lengthSqr() > 1.0) dir = dir.normalize();
        Vec3 target = dir.scale(speed.value * 0.5 * (ctrl ? boost.value : 1.0));
        vel = vel.add(target.subtract(vel).scale(1.0 - smoothness.value));
        prev = pos;
        pos = pos.add(vel);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (!showTarget.value) return;
        HitResult hr = mc.hitResult;
        if (hr instanceof BlockHitResult b && hr.getType() == HitResult.Type.BLOCK) {
            Proj.box(g, new AABB(b.getBlockPos()), 1.5f, Colors.ACCENT);
        }
    }
}
