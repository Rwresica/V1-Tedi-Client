package dev.tedi.module;

import dev.tedi.gui.BlockPicker;
import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** ESP for any blocks you pick (ores, spawners, bedrock...), each with its own colour + tracer toggle. */
public class BlockEsp extends Module {
    public static BlockEsp I;

    public static class Entry {
        public final Block block;
        public final String id;
        public final Setting.Hue color;
        public boolean tracer = true;
        Entry(Block b, String id, double hue) {
            this.block = b; this.id = id; this.color = new Setting.Hue(id, hue, 0.8, 1.0);
        }
    }

    private record Hit(BlockPos pos, Block block) {}

    public final Map<String, Entry> entries = new LinkedHashMap<>();
    private final Map<Block, Entry> byBlock = new HashMap<>();
    private final Map<Long, List<Hit>> cache = new HashMap<>();
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();
    private Object lastLevel;

    public final Setting.Action pick = add(new Setting.Action("Select Blocks...", () -> {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(new BlockPicker(mc.screen));
    }));
    public final Setting.Bool fill = add(new Setting.Bool("Fill Blocks", true));
    public final Setting.Num fillAlpha = add(new Setting.Num("Fill Opacity", 0.35, 0.05, 1.0, 0.05));
    public final Setting.Bool boxes = add(new Setting.Bool("Outline", true));
    public final Setting.Bool tracers = add(new Setting.Bool("Tracers", true));
    public final Setting.Num tracerWidth = add(new Setting.Num("Tracer Width", 1.0, 0.5, 4.0, 0.5));
    public final Setting.Num rangeChunks = add(new Setting.Num("Scan Range (chunks)", 6, 2, 16, 1));
    public final Setting.Num maxBlocks = add(new Setting.Num("Max Blocks Drawn", 400, 50, 2000, 50));

    private static Map<String, Block> ALL;
    private static List<String> SORTED;

    public BlockEsp() {
        super("BlockESP", "Highlights the blocks you select, each with its own color.", "RENDER", true);
        I = this;
    }

    public static Map<String, Block> allBlocks() {
        if (ALL == null) {
            ALL = new LinkedHashMap<>();
            for (Block b : BuiltInRegistries.BLOCK) {
                if (b == Blocks.AIR || b == Blocks.CAVE_AIR || b == Blocks.VOID_AIR) continue;
                ALL.put(BuiltInRegistries.BLOCK.getKey(b).toString(), b);
            }
        }
        return ALL;
    }

    public static List<Block> sortedBlocks() {
        List<Block> l = new ArrayList<>(allBlocks().values());
        l.sort(Comparator.comparing((Block b) -> b.getName().getString()));
        return l;
    }

    public Entry get(Block b) { return byBlock.get(b); }

    public Entry add(Block b) {
        Entry e = byBlock.get(b);
        if (e != null) return e;
        String id = BuiltInRegistries.BLOCK.getKey(b).toString();
        e = new Entry(b, id, (entries.size() * 47) % 360);
        entries.put(id, e);
        byBlock.put(b, e);
        resetScan();
        return e;
    }

    public void remove(Block b) {
        Entry e = byBlock.remove(b);
        if (e != null) entries.remove(e.id);
        resetScan();
    }

    private void resetScan() { cache.clear(); queue.clear(); }

    public String serialize() {
        StringBuilder sb = new StringBuilder();
        for (Entry e : entries.values()) {
            if (sb.length() > 0) sb.append(';');
            sb.append(e.id).append(',').append(e.color.hue).append(',').append(e.color.sat).append(',')
                    .append(e.color.val).append(',').append(e.tracer);
        }
        return sb.toString();
    }

    public void deserialize(String s) {
        entries.clear(); byBlock.clear(); resetScan();
        if (s == null || s.isEmpty()) return;
        for (String part : s.split(";")) {
            try {
                String[] p = part.split(",");
                Block b = allBlocks().get(p[0]);
                if (b == null) continue;
                Entry e = add(b);
                e.color.hue = Double.parseDouble(p[1]);
                e.color.sat = Double.parseDouble(p[2]);
                e.color.val = Double.parseDouble(p[3]);
                e.tracer = Boolean.parseBoolean(p[4]);
            } catch (Exception ignored) {}
        }
    }

    @Override public void onDisable() { resetScan(); }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null || entries.isEmpty()) return;
        if (lastLevel != mc.level) { lastLevel = mc.level; resetScan(); }
        if (queue.isEmpty()) {
            int r = rangeChunks.i();
            int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
            for (int x = pcx - r; x <= pcx + r; x++)
                for (int z = pcz - r; z <= pcz + r; z++) queue.add(new int[]{x, z});
        }
        Set<Block> targets = byBlock.keySet();
        for (int n = 0; n < 3 && !queue.isEmpty(); n++) {
            int[] c = queue.poll();
            long key = (((long) c[0]) << 32) ^ (c[1] & 0xFFFFFFFFL);
            LevelChunk ch = mc.level.getChunkSource().getChunkNow(c[0], c[1]);
            if (ch == null) { cache.remove(key); continue; }
            List<Hit> list = new ArrayList<>();
            LevelChunkSection[] secs = ch.getSections();
            for (int i = 0; i < secs.length && list.size() < 400; i++) {
                LevelChunkSection sec = secs[i];
                if (sec.hasOnlyAir()) continue;
                if (!sec.maybeHas(s -> targets.contains(s.getBlock()))) continue;
                int baseY = ch.getMinY() + i * 16;
                for (int x = 0; x < 16; x++)
                    for (int y = 0; y < 16; y++)
                        for (int z = 0; z < 16; z++) {
                            Block b = sec.getBlockState(x, y, z).getBlock();
                            if (targets.contains(b)) list.add(new Hit(new BlockPos(c[0] * 16 + x, baseY + y, c[1] * 16 + z), b));
                        }
            }
            if (list.isEmpty()) cache.remove(key); else cache.put(key, list);
        }
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (entries.isEmpty()) return;
        int sx = g.guiWidth() / 2, sy = g.guiHeight() / 2;
        double r2 = rangeChunks.value * 16.0 * rangeChunks.value * 16.0;
        int fa = (int) (fillAlpha.value * 255), drawn = 0, max = maxBlocks.i();
        for (List<Hit> list : cache.values()) {
            for (Hit h : list) {
                if (drawn >= max) return;
                Entry e = byBlock.get(h.block());
                if (e == null) continue;
                Vec3 c = h.pos().getCenter();
                if (c.distanceToSqr(Proj.cx, Proj.cy, Proj.cz) > r2) continue;
                drawn++;
                int col = e.color.argb();
                AABB bb = new AABB(h.pos());
                if (fill.value) Proj.shadedBox(g, bb, col & 0xFFFFFF, fa, true, col, boxes.value ? 1f : 0f);
                else if (boxes.value) Proj.box(g, bb, 1f, col);
                if (tracers.value && e.tracer) Proj.tracer(g, c.x, c.y, c.z, tracerWidth.f(), col);
            }
        }
    }
}
