package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.Items;

/**
 * Faster crystalling:
 *  - Instant Remove: a crystal you hit disappears on your screen at once (no waiting for the server).
 *  - Fast Place: removes the vanilla 4-tick delay between right-click uses while you hold end crystals.
 */
public class CrystalOptimizer extends Module {
    public static CrystalOptimizer I;
    public final Setting.Bool instantRemove = add(new Setting.Bool("Instant Remove", true));
    public final Setting.Bool fastPlace = add(new Setting.Bool("Fast Place", true));
    public final Setting.Num placeDelay = add(new Setting.Num("Place Delay (ticks)", 0, 0, 4, 1));

    public CrystalOptimizer() {
        super("CrystalOptimizer", "Faster crystal break + place (client-side).", "COMBAT", true);
        I = this;
    }

    public static boolean active() { return I != null && I.enabled; }
    public static boolean removeOn() { return active() && I.instantRemove.value; }

    /** Called every tick from the optional Minecraft mixin; returns the delay to force, or -1 for none. */
    public static int forcedPlaceDelay() {
        if (!active() || !I.fastPlace.value) return -1;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return -1;
        boolean crystal = mc.player.getMainHandItem().is(Items.END_CRYSTAL) || mc.player.getOffhandItem().is(Items.END_CRYSTAL);
        return crystal ? I.placeDelay.i() : -1;
    }
}
