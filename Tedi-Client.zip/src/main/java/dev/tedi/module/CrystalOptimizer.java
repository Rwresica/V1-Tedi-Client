package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Faster crystalling:
 *  - Instant Remove: a crystal you hit disappears on your screen at once (no waiting for the server).
 *  - Fast Place: removes the vanilla delay between right-click uses while you hold end crystals.
 *  - Hold To Spam: keep the attack button held on a crystal and it keeps hitting every N ticks.
 */
public class CrystalOptimizer extends Module {
    public static CrystalOptimizer I;
    public final Setting.Bool instantRemove = add(new Setting.Bool("Instant Remove", true));
    public final Setting.Bool fastPlace = add(new Setting.Bool("Fast Place", true));
    public final Setting.Num placeDelay = add(new Setting.Num("Place Delay (ticks)", 0, 0, 4, 1));
    public final Setting.Bool holdSpam = add(new Setting.Bool("Hold To Spam", true));
    public final Setting.Num attackDelay = add(new Setting.Num("Attack Delay (ticks)", 1, 0, 5, 1));
    private int cd;

    public CrystalOptimizer() {
        super("CrystalOptimizer", "Faster crystal break + place (client-side).", "COMBAT", true);
        I = this;
    }

    public static boolean active() { return I != null && I.enabled; }
    public static boolean removeOn() { return active() && I.instantRemove.value; }

    public static int forcedPlaceDelay() {
        if (!active() || !I.fastPlace.value) return -1;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return -1;
        boolean crystal = mc.player.getMainHandItem().is(Items.END_CRYSTAL) || mc.player.getOffhandItem().is(Items.END_CRYSTAL);
        return crystal ? I.placeDelay.i() : -1;
    }

    @Override
    public void onTick(Minecraft mc) {
        if (cd > 0) cd--;
        if (!holdSpam.value || mc.player == null || mc.gameMode == null || mc.screen != null) return;
        if (!mc.options.keyAttack.isDown() || cd > 0) return;
        HitResult hr = mc.hitResult;
        if (hr instanceof EntityHitResult ehr && ehr.getEntity() instanceof EndCrystal crystal) {
            mc.gameMode.attack(mc.player, crystal);
            mc.player.swing(InteractionHand.MAIN_HAND);
            cd = attackDelay.i();
        }
    }
}
