package dev.tedi.module;

/** Crystals vanish on your screen the moment you hit them, so you can place the next one immediately. */
public class CrystalOptimizer extends Module {
    public static CrystalOptimizer I;

    public CrystalOptimizer() {
        super("CrystalOptimizer", "Hit crystals vanish instantly client-side (faster crystal spam).", "COMBAT", true);
        I = this;
    }

    public static boolean active() { return I != null && I.enabled; }
}
