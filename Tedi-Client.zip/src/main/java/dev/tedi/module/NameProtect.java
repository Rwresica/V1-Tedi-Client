package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;

public class NameProtect extends Module {
    public static NameProtect I;
    public final Setting.Str custom = add(new Setting.Str("Name", "Tedi"));
    private static String real = "";

    public NameProtect() {
        super("NameProtect", "Replaces your username in chat, tab and nametags.", "General", true);
        I = this;
    }

    @Override public void onEnable() { refresh(); }
    @Override public void onTick(Minecraft mc) { refresh(); }

    private void refresh() {
        try { real = Minecraft.getInstance().getUser().getName(); } catch (Throwable ignored) {}
    }

    /** Called from the text-rendering mixin. */
    public static String apply(String s) {
        if (I == null || !I.enabled || s == null || real == null || real.isEmpty()) return s;
        if (s.indexOf(real) < 0) return s;
        String rep = I.custom.value.isEmpty() ? "Tedi" : I.custom.value;
        return s.replace(real, rep);
    }
}
