package dev.tedi.module;

import dev.tedi.setting.Setting;

/** Any field of view (30-170), beyond the vanilla slider. */
public class CustomFov extends Module {
    public static CustomFov I;
    public final Setting.Num fov = add(new Setting.Num("FOV", 110, 30, 170, 1));

    public CustomFov() {
        super("CustomFOV", "Set any field of view.", "MISC", true);
        I = this;
    }

    public static boolean active() { return I != null && I.enabled; }
    public static int value() { return I.fov.i(); }
}
