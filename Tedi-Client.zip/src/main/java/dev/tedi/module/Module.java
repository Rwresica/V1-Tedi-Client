package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name, description, category;
    public final boolean bindable;
    public boolean enabled, expanded, wasKeyDown;
    public int key = -1;
    public final List<Setting> settings = new ArrayList<>();

    protected Module(String name, String description, String category, boolean bindable) {
        this.name = name; this.description = description; this.category = category; this.bindable = bindable;
    }

    protected <T extends Setting> T add(T s) { settings.add(s); return s; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean b) {
        if (b == enabled) return;
        enabled = b;
        if (b) onEnable(); else onDisable();
        if (enabled == b) dev.tedi.util.Toasts.moduleToggled(name, enabled, category);
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(Minecraft mc) {}
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {}
}
