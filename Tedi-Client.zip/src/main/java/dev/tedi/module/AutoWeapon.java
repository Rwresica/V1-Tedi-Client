package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Holding attack on a mob/player: swaps to the best weapon in your hotbar (sword, then axe, then mace). */
public class AutoWeapon extends Module {
    public final Setting.Bool switchBack = add(new Setting.Bool("Switch Back", true));
    private int prev = -1;

    public AutoWeapon() {
        super("AutoWeapon", "Auto-swaps to your sword/axe when you attack.", "COMBAT", true);
    }

    private static boolean weapon(ItemStack s) { return s.is(ItemTags.SWORDS) || s.is(ItemTags.AXES) || s.is(Items.MACE); }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.screen != null) return;
        Inventory inv = mc.player.getInventory();
        HitResult hr = mc.hitResult;
        boolean target = mc.options.keyAttack.isDown() && hr instanceof EntityHitResult e && e.getEntity() instanceof LivingEntity;
        if (target) {
            if (weapon(inv.getItem(inv.getSelectedSlot()))) return;
            int best = -1;
            for (int i = 0; i < 9 && best < 0; i++) if (inv.getItem(i).is(ItemTags.SWORDS)) best = i;
            for (int i = 0; i < 9 && best < 0; i++) if (inv.getItem(i).is(ItemTags.AXES)) best = i;
            for (int i = 0; i < 9 && best < 0; i++) if (inv.getItem(i).is(Items.MACE)) best = i;
            if (best >= 0) {
                if (prev < 0) prev = inv.getSelectedSlot();
                inv.setSelectedSlot(best);
            }
        } else if (prev >= 0 && !mc.options.keyAttack.isDown()) {
            if (switchBack.value) inv.setSelectedSlot(prev);
            prev = -1;
        }
    }
}
