package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Switches to an axe from your hotbar while you aim at someone who is blocking with a shield, then switches back. */
public class ShieldBreaker extends Module {
    public final Setting.Num restoreDelay = add(new Setting.Num("Switch Back (ticks)", 6, 1, 20, 1));
    private int prevSlot = -1, timer;

    public ShieldBreaker() {
        super("ShieldBreaker", "Auto-swaps to an axe when your target blocks.", "COMBAT", true);
    }

    @Override public void onDisable() { restore(); }

    private void restore() {
        Minecraft mc = Minecraft.getInstance();
        if (prevSlot >= 0 && mc.player != null) mc.player.getInventory().setSelectedSlot(prevSlot);
        prevSlot = -1;
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.screen != null) return;
        HitResult hr = mc.hitResult;
        Entity t = hr instanceof EntityHitResult ehr ? ehr.getEntity() : null;
        boolean blocking = t instanceof LivingEntity le && le.isBlocking();
        if (blocking) {
            int axe = -1;
            for (int i = 0; i < 9; i++) {
                if (mc.player.getInventory().getItem(i).is(ItemTags.AXES)) { axe = i; break; }
            }
            if (axe >= 0) {
                if (prevSlot < 0) prevSlot = mc.player.getInventory().getSelectedSlot();
                if (mc.player.getInventory().getSelectedSlot() != axe) mc.player.getInventory().setSelectedSlot(axe);
                timer = restoreDelay.i();
            }
        } else if (prevSlot >= 0 && --timer <= 0) {
            restore();
        }
    }
}
