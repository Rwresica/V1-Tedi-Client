package dev.tedi.module;

import dev.tedi.util.Toasts;

import java.util.ArrayList;
import java.util.List;

public final class Modules {
    public static final List<Module> all = new ArrayList<>();
    private Modules() {}

    public static void init() {
        Toasts.mute = true;
        // COMBAT
        all.add(new AutoTotem());
        all.add(new CrystalOptimizer());
        all.add(new AnchorMacro());
        all.add(new TriggerBot());
        all.add(new ShieldBreaker());
        all.add(new AutoJumpReset());
        all.add(new AutoWeapon());
        // MISC
        all.add(new Freecam());
        all.add(new Freelook());
        all.add(new NameProtect());
        all.add(new FastPlace());
        all.add(new AutoTool());
        all.add(new CustomFov());
        all.add(new CustomCrosshair());
        // RENDER
        all.add(new Fullbright());
        Hud hud = new Hud();
        all.add(hud);
        all.add(new PlayerEsp());
        all.add(new StorageEsp());
        all.add(new BlockEsp());
        // DONUT
        all.add(new SpawnerBeam());
        all.add(new SusChunk());
        all.add(new PlayerDetection());
        // CLIENT
        TediClientPlus plus = new TediClientPlus();
        all.add(plus);
        hud.setEnabled(true);
        plus.setEnabled(true);
        Toasts.mute = false;
    }
}
