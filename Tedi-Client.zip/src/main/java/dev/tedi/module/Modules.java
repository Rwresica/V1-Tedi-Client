package dev.tedi.module;

import java.util.ArrayList;
import java.util.List;

public final class Modules {
    public static final List<Module> all = new ArrayList<>();
    private Modules() {}

    public static void init() {
        all.add(new AutoTotem());
        all.add(new CrystalOptimizer());
        all.add(new TriggerBot());
        all.add(new ShieldBreaker());
        all.add(new Freecam());
        all.add(new Freelook());
        all.add(new NameProtect());
        all.add(new Fullbright());
        Hud hud = new Hud();
        all.add(hud);
        all.add(new PlayerEsp());
        all.add(new StorageEsp());
        all.add(new BlockEsp());
        all.add(new SpawnerBeam());
        all.add(new SusChunk());
        all.add(new PlayerDetection());
        hud.setEnabled(true);
    }
}
