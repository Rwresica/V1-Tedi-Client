package dev.tedi.module;

import net.minecraft.client.Minecraft;

/** Jumps the moment you get hit (while on the ground) to cut knockback. */
public class AutoJumpReset extends Module {
    private int cd;

    public AutoJumpReset() {
        super("AutoJumpReset", "Jump when hit to reduce knockback.", "COMBAT", true);
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null) return;
        if (cd > 0) { cd--; return; }
        if (mc.screen == null && mc.player.hurtTime >= 8 && mc.player.onGround()) {
            mc.player.jumpFromGround();
            cd = 10;
        }
    }
}
