package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class Hud extends Module {
    public static Hud I;

    private static class Broken {
        final BlockPos pos; final String name; final long time; final List<Integer> ids = new ArrayList<>();
        Broken(BlockPos pos, String name, long time) { this.pos = pos; this.name = name; this.time = time; }
    }

    /** A movable HUD element. For right-anchored elements x is the RIGHT edge. x < 0 = not placed yet. */
    public static class El {
        public final String name; public int x, y, w = 50, h = 14; public final boolean right;
        public El(String name, int x, int y, boolean right) { this.name = name; this.x = x; this.y = y; this.right = right; }
        int left() { return right ? x - w : x; }
    }

    public final El fpsEl = new El("FPS", 6, 6, false);
    public final El pingEl = new El("Ping", 6, 23, false);
    public final El coordsEl = new El("Coordinates", 6, 40, false);
    public final El armorEl = new El("Armor", 6, 58, false);
    public final El mapEl = new El("RegionMap", -1, -1, false);
    public final El listEl = new El("ModuleList", -1, 4, true);
    public final List<El> elements = List.of(fpsEl, pingEl, coordsEl, armorEl, mapEl, listEl);

    public final Setting.Bool fps = add(new Setting.Bool("FPS HUD", true));
    public final Setting.Bool ping = add(new Setting.Bool("Ping HUD", false));
    public final Setting.Bool coords = add(new Setting.Bool("Coordinates HUD", false));
    public final Setting.Bool armor = add(new Setting.Bool("Armor HUD", false));
    public final Setting.Bool map = add(new Setting.Bool("Region Map HUD", false));
    public final Setting.Bool list = add(new Setting.Bool("Module List", true));
    public final Setting.Num mapSize = add(new Setting.Num("Map Size", 80, 60, 120, 10));
    public final Setting.Num mapZoom = add(new Setting.Num("Map Zoom", 1, 1, 4, 1));
    public final Setting.Hue color = add(new Setting.Hue("HUD Color", 195));
    public final Setting.Bool players = add(new Setting.Bool("Player Nametags", true));
    public final Setting.Bool showHealth = add(new Setting.Bool("Show Health", true));
    public final Setting.Bool showDist = add(new Setting.Bool("Show Distance", true));
    public final Setting.Num playerRange = add(new Setting.Num("Player Range", 128, 16, 256, 8));
    public final Setting.Bool broken = add(new Setting.Bool("Broken Block Nametags", true));
    public final Setting.Num brokenTime = add(new Setting.Num("Nametag Secs", 30, 3, 120, 1));

    private final List<Broken> brokenList = new ArrayList<>();
    private BlockPos mining;
    private String miningName = "";
    private El dragging;
    private int offX, offY, mapTimer;
    private boolean wasDown;

    private int[] mapCol = new int[0], mapH = new int[0];
    private int mapCells, mapBaseX, mapBaseZ, mapZ = 1;

    public Hud() {
        super("HUD", "Pick which HUDs show. Press T and drag them to move.", "RENDER", true);
        I = this;
    }

    private boolean on(El e) {
        if (e == fpsEl) return fps.value;
        if (e == pingEl) return ping.value;
        if (e == coordsEl) return coords.value;
        if (e == armorEl) return armor.value;
        if (e == mapEl) return map.value;
        return list.value;
    }

    public void captureTarget(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        HitResult hr = mc.hitResult;
        if (mc.options.keyAttack.isDown() && hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.level.getBlockState(bhr.getBlockPos());
            if (!st.isAir()) {
                mining = bhr.getBlockPos().immutable();
                miningName = st.getBlock().getName().getString();
            }
        }
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        long now = System.currentTimeMillis();
        if (mining != null) {
            if (mc.level.getBlockState(mining).isAir()) {
                brokenList.add(new Broken(mining, miningName, now));
                mining = null;
            } else if (!mc.options.keyAttack.isDown()) mining = null;
        }
        long life = (long) (brokenTime.value * 1000);
        brokenList.removeIf(b -> now - b.time > life);

        // attach nametags to the item drops that pop out of freshly broken blocks
        Set<Integer> claimed = new HashSet<>();
        for (Broken b : brokenList) claimed.addAll(b.ids);
        for (Broken b : brokenList) {
            if (now - b.time < 1500) {
                Vec3 c = b.pos.getCenter();
                for (Entity e : mc.level.entitiesForRendering()) {
                    if (e instanceof ItemEntity && !claimed.contains(e.getId()) && e.position().distanceToSqr(c) < 9.0) {
                        b.ids.add(e.getId());
                        claimed.add(e.getId());
                    }
                }
            } else {
                b.ids.removeIf(id -> mc.level.getEntity(id) == null);
            }
        }

        if (map.value && ++mapTimer % 6 == 0) updateMap(mc);
    }

    private void updateMap(Minecraft mc) {
        int cells = mapSize.i() / 2;
        mapZ = mapZoom.i();
        if (mapCol.length != cells * cells) { mapCol = new int[cells * cells]; mapH = new int[cells * cells]; }
        mapCells = cells;
        int px = mc.player.blockPosition().getX(), pz = mc.player.blockPosition().getZ(), py = mc.player.blockPosition().getY();
        mapBaseX = px - cells * mapZ / 2;
        mapBaseZ = pz - cells * mapZ / 2;
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        for (int r = 0; r < cells; r++) {
            for (int c = 0; c < cells; c++) {
                int i = r * cells + c;
                int bx = mapBaseX + c * mapZ, bz = mapBaseZ + r * mapZ;
                if (mc.level.getChunkSource().getChunkNow(bx >> 4, bz >> 4) == null) { mapCol[i] = 0; continue; }
                int top = mc.level.getHeight(Heightmap.Types.WORLD_SURFACE, bx, bz);
                int y = Math.min(top - 1, py + 6);
                BlockState s = mc.level.getBlockState(mp.set(bx, y, bz));
                while (y > mc.level.getMinY() && s.isAir()) { y--; s = mc.level.getBlockState(mp.set(bx, y, bz)); }
                int col = s.getMapColor(mc.level, mp).col;
                mapCol[i] = col == 0 ? 0x101418 : col;
                mapH[i] = y;
            }
        }
        for (int r = 1; r < cells; r++) {
            for (int c = 0; c < cells; c++) {
                int i = r * cells + c;
                if (mapCol[i] == 0) continue;
                int d = mapH[i] - mapH[i - cells];
                float k = d > 0 ? 1.12f : d < 0 ? 0.82f : 1f;
                int rr = Math.min(255, (int) (((mapCol[i] >> 16) & 255) * k));
                int gg = Math.min(255, (int) (((mapCol[i] >> 8) & 255) * k));
                int bb = Math.min(255, (int) ((mapCol[i] & 255) * k));
                mapCol[i] = (rr << 16) | (gg << 8) | bb;
            }
        }
    }

    private void small(GuiGraphics g, Font f, El e, String label, String val, int valCol, int col) {
        e.w = f.width(label) + f.width(val) + 17; e.h = 14;
        int x = e.left(), y = e.y;
        Draw.panel(g, x, y, e.w, e.h, col);
        g.drawString(f, label, x + 7, y + 3, col, false);
        g.drawString(f, val, x + 11 + f.width(label), y + 3, valCol, false);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        Font f = mc.font;
        int col = color.argb();
        int W = g.guiWidth(), H = g.guiHeight();

        // ---------- world nametags ----------
        if (players.value) {
            for (AbstractClientPlayer p : mc.level.players()) {
                if (p == mc.player && !(Freecam.active() || Freelook.active())) continue;
                Vec3 pos = p.getPosition(pt);
                double d = Math.sqrt(pos.distanceToSqr(Proj.cx, Proj.cy, Proj.cz));
                if (d > playerRange.value) continue;
                if (!Proj.project(pos.x, pos.y + p.getBbHeight() + 0.9, pos.z)) continue;
                StringBuilder sb = new StringBuilder(p.getName().getString());
                int c = Colors.ACCENT;
                if (showHealth.value) {
                    float hp = p.getHealth();
                    sb.append(" ").append(String.format(Locale.ROOT, "%.1f", hp));
                    c = hp > 14 ? 0xFF7CFF8A : hp > 7 ? 0xFFFFE066 : 0xFFFF6B6B;
                }
                if (showDist.value) sb.append(" [").append((int) d).append("m]");
                Proj.label(g, sb.toString(), Proj.px, Proj.py, c);
            }
        }
        if (broken.value) {
            long now = System.currentTimeMillis(), life = (long) (brokenTime.value * 1000);
            for (Broken b : brokenList) {
                float fade = 1f - (float) (now - b.time) / (float) life;
                int a = Math.max(5, (int) (255 * Math.min(1f, fade * 3f)));
                int tc = (a << 24) | 0xFFD27F;
                boolean any = false;
                for (int id : b.ids) {
                    Entity e = mc.level.getEntity(id);
                    if (e == null) continue;
                    any = true;
                    Vec3 pos = e.getPosition(pt);
                    if (Proj.project(pos.x, pos.y + e.getBbHeight() + 0.55, pos.z)) Proj.label(g, b.name, Proj.px, Proj.py, tc);
                }
                if (!any && now - b.time < life) {
                    Vec3 c = b.pos.getCenter();
                    if (Proj.project(c.x, c.y + 0.9, c.z)) Proj.label(g, b.name, Proj.px, Proj.py, tc);
                }
            }
        }

        // ---------- HUD elements ----------
        if (listEl.x < 0) listEl.x = W - 4;
        if (mapEl.x < 0) { mapEl.x = 6; mapEl.y = Math.max(0, H - (mapSize.i() + 8) - 6); }

        if (fps.value) small(g, f, fpsEl, "FPS", String.valueOf(mc.getFps()), Colors.TEXT, col);
        if (ping.value) {
            int ms = 0;
            if (mc.getConnection() != null) {
                PlayerInfo pi = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (pi != null) ms = pi.getLatency();
            }
            small(g, f, pingEl, "PING", ms + "ms", ms < 80 ? 0xFF7CFF8A : ms < 160 ? 0xFFFFE066 : 0xFFFF6B6B, col);
        }
        if (coords.value) {
            BlockPos bp = mc.player.blockPosition();
            String dir = mc.player.getDirection().getSerializedName().toUpperCase(Locale.ROOT);
            small(g, f, coordsEl, "XYZ", bp.getX() + " " + bp.getY() + " " + bp.getZ() + "  " + dir, Colors.TEXT, col);
        }
        if (armor.value) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            armorEl.w = 62; armorEl.h = 4 * 18 + 4;
            int x = armorEl.left(), y = armorEl.y;
            Draw.panel(g, x, y, armorEl.w, armorEl.h, col);
            for (int i = 0; i < 4; i++) {
                ItemStack st = mc.player.getItemBySlot(slots[i]);
                int ry = y + 3 + i * 18;
                if (st.isEmpty()) { g.drawString(f, "-", x + 26, ry + 4, Colors.DIM, false); continue; }
                g.renderItem(st, x + 6, ry);
                String t = "OK"; int tc = Colors.TEXT;
                if (st.isDamageableItem() && st.getMaxDamage() > 0) {
                    int pc = (int) ((st.getMaxDamage() - st.getDamageValue()) * 100f / st.getMaxDamage());
                    t = pc + "%";
                    tc = pc > 60 ? 0xFF7CFF8A : pc > 25 ? 0xFFFFE066 : 0xFFFF6B6B;
                }
                g.drawString(f, t, x + 26, ry + 4, tc, false);
            }
        }
        if (map.value) drawMap(g, f, col);
        if (list.value) {
            List<Module> act = new ArrayList<>();
            for (Module m : Modules.all) if (m.enabled) act.add(m);
            act.sort(Comparator.comparingInt((Module m) -> -f.width(m.name)));
            int y = listEl.y, maxW = 40;
            for (Module m : act) {
                int w = f.width(m.name) + 11;
                maxW = Math.max(maxW, w);
                int x = listEl.x - w;
                Draw.round(g, x, y, w, 12, 0xB00D1117);
                g.fill(listEl.x - 2, y + 1, listEl.x, y + 11, col);
                g.drawString(f, m.name, x + 4, y + 2, col, false);
                y += 13;
            }
            listEl.w = maxW; listEl.h = Math.max(13, y - listEl.y);
        }

        // ---------- drag-to-move while chat (T) is open ----------
        if (mc.screen instanceof ChatScreen) {
            double mx = mc.mouseHandler.xpos() * W / (double) mc.getWindow().getScreenWidth();
            double my = mc.mouseHandler.ypos() * H / (double) mc.getWindow().getScreenHeight();
            boolean down = mc.mouseHandler.isLeftPressed();
            if (down && !wasDown) {
                for (El e : elements) {
                    if (!on(e)) continue;
                    if (mx >= e.left() && mx < e.left() + e.w && my >= e.y && my < e.y + e.h) {
                        dragging = e; offX = (int) mx - e.left(); offY = (int) my - e.y;
                    }
                }
            }
            if (down && dragging != null) {
                int nl = Math.max(0, Math.min(W - dragging.w, (int) mx - offX));
                dragging.x = dragging.right ? nl + dragging.w : nl;
                dragging.y = Math.max(0, Math.min(H - dragging.h, (int) my - offY));
            }
            if (!down) dragging = null;
            wasDown = down;
            for (El e : elements) if (on(e)) Draw.outline(g, e.left() - 1, e.y - 1, e.w + 2, e.h + 2, e == dragging ? 0xFFFFFFFF : col);
            Proj.label(g, "HUD EDIT MODE - drag the elements", W / 2.0, 14, col);
        } else {
            dragging = null;
            wasDown = false;
        }
    }

    private void drawMap(GuiGraphics g, Font f, int col) {
        int size = mapSize.i();
        mapEl.w = size + 6; mapEl.h = size + 6;
        int x = mapEl.left(), y = mapEl.y;
        Draw.panel(g, x, y, mapEl.w, mapEl.h, col);
        int ox = x + 3, oy = y + 3;
        int cells = mapCells;
        if (cells * 2 != size || mapCol.length != cells * cells) return;
        for (int r = 0; r < cells; r++)
            for (int c = 0; c < cells; c++) {
                int cc = mapCol[r * cells + c];
                if (cc != 0) g.fill(ox + c * 2, oy + r * 2, ox + c * 2 + 2, oy + r * 2 + 2, 0xFF000000 | cc);
            }
        // chunk grid
        for (int c = 0; c < cells; c++) {
            int bx = mapBaseX + c * mapZ;
            if (Math.floorMod(bx, 16) < mapZ) g.fill(ox + c * 2, oy, ox + c * 2 + 1, oy + size, 0x30FFFFFF);
            int bz = mapBaseZ + c * mapZ;
            if (Math.floorMod(bz, 16) < mapZ) g.fill(ox, oy + c * 2, ox + size, oy + c * 2 + 1, 0x30FFFFFF);
        }
        // flagged sus chunks
        SusChunk sc = SusChunk.I;
        if (sc != null && sc.enabled) {
            for (SusChunk.Info i : sc.flaggedChunks()) {
                int l = (i.cx() * 16 - mapBaseX) / mapZ, t = (i.cz() * 16 - mapBaseZ) / mapZ;
                int s = 16 / mapZ;
                int x1 = Math.max(0, l), y1 = Math.max(0, t), x2 = Math.min(cells, l + s), y2 = Math.min(cells, t + s);
                if (x2 > x1 && y2 > y1) g.fill(ox + x1 * 2, oy + y1 * 2, ox + x2 * 2, oy + y2 * 2, sc.color.argb(0x55));
            }
        }
        // player
        int pc = ox + size / 2, pr = oy + size / 2;
        g.fill(pc - 2, pr - 2, pc + 2, pr + 2, 0xFF000000);
        g.fill(pc - 1, pr - 1, pc + 1, pr + 1, 0xFFFFFFFF);
    }
}
