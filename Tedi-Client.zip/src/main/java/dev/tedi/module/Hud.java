package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class Hud extends Module {
    public static Hud I;

    private static class Broken {
        final BlockPos pos; final long time; final List<Integer> ids = new ArrayList<>();
        Broken(BlockPos pos, long time) { this.pos = pos; this.time = time; }
    }

    /** A movable HUD element. For right-anchored elements x is the RIGHT edge. x < 0 = not placed yet. */
    public static class El {
        public final String name; public int x, y, w = 50, h = 14; public final boolean right;
        final int defX, defY;
        public El(String name, int x, int y, boolean right) { this.name = name; this.x = x; this.y = y; this.right = right; this.defX = x; this.defY = y; }
        int left() { return right ? x - w : x; }
        void reset() { x = defX; y = defY; }
    }

    public final El markEl = new El("Watermark", 6, 4, false);
    public final El fpsEl = new El("FPS", 6, 22, false);
    public final El pingEl = new El("Ping", 6, 38, false);
    public final El cpsEl = new El("CPS", 6, 54, false);
    public final El coordsEl = new El("Coordinates", 6, 70, false);
    public final El userEl = new El("Username", 6, 86, false);
    public final El armorEl = new El("Armor", 6, 104, false);
    public final El listEl = new El("ModuleList", -1, 4, true);
    public final List<El> elements = List.of(markEl, fpsEl, pingEl, cpsEl, coordsEl, userEl, armorEl, listEl);

    public final Setting.Bool watermark = add(new Setting.Bool("TediClient Name", true));
    public final Setting.Bool fps = add(new Setting.Bool("FPS HUD", true));
    public final Setting.Bool ping = add(new Setting.Bool("Ping HUD", false));
    public final Setting.Bool cps = add(new Setting.Bool("CPS HUD", false));
    public final Setting.Bool coords = add(new Setting.Bool("Coordinates HUD", false));
    public final Setting.Bool user = add(new Setting.Bool("Username HUD", false));
    public final Setting.Bool armor = add(new Setting.Bool("Armor HUD", false));
    public final Setting.Bool list = add(new Setting.Bool("Module List", true));
    public final Setting.Hue color = add(new Setting.Hue("HUD Color", 195, 0.55, 1.0));
    public final Setting.Action reset = add(new Setting.Action("Reset HUD Positions", () -> { if (I != null) I.resetPositions(); }));
    public final Setting.Bool players = add(new Setting.Bool("Player Nametags", true));
    public final Setting.Bool showHealth = add(new Setting.Bool("Show Health", true));
    public final Setting.Bool showDist = add(new Setting.Bool("Show Distance", true));
    public final Setting.Num playerRange = add(new Setting.Num("Player Range", 128, 16, 256, 8));
    public final Setting.Bool broken = add(new Setting.Bool("Broken Item Nametags", true));
    public final Setting.Num brokenTime = add(new Setting.Num("Nametag Secs", 30, 3, 120, 1));

    private final List<Broken> brokenList = new ArrayList<>();
    private final Map<Integer, double[]> smooth = new HashMap<>();
    private final Map<Object, Float> fade = new HashMap<>();
    private final Map<Module, Float> listY = new HashMap<>();
    private final List<Long> leftClicks = new ArrayList<>(), rightClicks = new ArrayList<>();
    private boolean lastL, lastR;
    private BlockPos mining;
    private El dragging;
    private int offX, offY;
    private boolean wasDown;
    private long lastNano = System.nanoTime();

    public Hud() {
        super("HUD", "Pick which HUDs show. Press T and drag them to move.", "RENDER", true);
        I = this;
    }

    public void resetPositions() { for (El e : elements) e.reset(); listEl.x = -1; }

    private boolean on(El e) {
        if (e == markEl) return watermark.value;
        if (e == fpsEl) return fps.value;
        if (e == pingEl) return ping.value;
        if (e == cpsEl) return cps.value;
        if (e == coordsEl) return coords.value;
        if (e == userEl) return user.value;
        if (e == armorEl) return armor.value;
        return list.value;
    }

    private float step(Object key, float target, float dt) {
        float v = fade.getOrDefault(key, target);
        v += (target - v) * Math.min(1f, dt * 12f);
        if (Math.abs(target - v) < 0.004f) v = target;
        fade.put(key, v);
        return v;
    }

    public void captureTarget(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        HitResult hr = mc.hitResult;
        if (mc.options.keyAttack.isDown() && hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.level.getBlockState(bhr.getBlockPos());
            if (!st.isAir()) mining = bhr.getBlockPos().immutable();
        }
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        long now = System.currentTimeMillis();
        if (mining != null) {
            if (mc.level.getBlockState(mining).isAir()) {
                brokenList.add(new Broken(mining, now));
                mining = null;
            } else if (!mc.options.keyAttack.isDown()) mining = null;
        }
        long life = (long) (brokenTime.value * 1000);

        Set<Integer> claimed = new HashSet<>();
        for (Broken b : brokenList) claimed.addAll(b.ids);
        for (Broken b : brokenList) {
            if (now - b.time < 1200) {
                Vec3 c = b.pos.getCenter();
                for (Entity e : mc.level.entitiesForRendering()) {
                    if (e instanceof ItemEntity && !claimed.contains(e.getId()) && e.position().distanceToSqr(c) < 9.0) {
                        b.ids.add(e.getId());
                        claimed.add(e.getId());
                    }
                }
            } else {
                b.ids.removeIf(id -> mc.level.getEntity(id) == null);
            }
        }
        // nothing dropped -> no nametag at all
        brokenList.removeIf(b -> now - b.time > life || (now - b.time >= 1200 && b.ids.isEmpty()));
    }

    /** Label + value pill, same look as the GUI (dark soft panel, light-blue bar, bold label). */
    private void small(GuiGraphics g, Font f, El e, float a, String label, String val, int valCol, int col) {
        int lw = Draw.width(f, label, true);
        e.w = lw + f.width(val) + 17; e.h = 14;
        int x = e.left(), y = e.y;
        Draw.softPanel(g, x, y, e.w, e.h, col, a);
        Draw.text(g, f, label, x + 6, y + 3, Draw.alpha(col, a), true);
        Draw.text(g, f, val, x + 11 + lw, y + 3, Draw.alpha(valCol, a), false);
    }

    private static int clicks(List<Long> l, long now) {
        l.removeIf(t -> now - t > 1000);
        return l.size();
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        Font f = mc.font;
        int col = color.argb();
        int W = g.guiWidth(), H = g.guiHeight();
        long now = System.currentTimeMillis();
        long nn = System.nanoTime();
        float dt = Math.min(0.05f, (nn - lastNano) / 1e9f);
        lastNano = nn;

        long win = GLFW.glfwGetCurrentContext();
        boolean mL = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean mR = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (mc.screen == null) {
            if (mL && !lastL) leftClicks.add(now);
            if (mR && !lastR) rightClicks.add(now);
        }
        lastL = mL; lastR = mR;

        // ---------- world nametags ----------
        if (players.value) {
            for (AbstractClientPlayer p : mc.level.players()) {
                if (p == mc.player && !(Freecam.active() || Freelook.active())) continue;
                Vec3 pos = p.getPosition(pt);
                double d = Math.sqrt(pos.distanceToSqr(Proj.cx, Proj.cy, Proj.cz));
                if (d > playerRange.value) continue;
                if (!Proj.project(pos.x, pos.y + p.getBbHeight() + 0.9, pos.z)) continue;
                StringBuilder sb = new StringBuilder(p.getName().getString());
                int c = Colors.ACCENT;
                if (showHealth.value) {
                    float hp = p.getHealth();
                    sb.append(" ").append(String.format(Locale.ROOT, "%.1f", hp));
                    c = hp > 14 ? 0xFF7CFF8A : hp > 7 ? 0xFFFFE066 : 0xFFFF6B6B;
                }
                if (showDist.value) sb.append(" [").append((int) d).append("m]");
                Proj.label(g, sb.toString(), Proj.px, Proj.py, c);
            }
        }
        if (broken.value) {
            long life = (long) (brokenTime.value * 1000);
            Set<Integer> seen = new HashSet<>();
            for (Broken b : brokenList) {
                float fd = 1f - (float) (now - b.time) / (float) life;
                int a = Math.max(5, (int) (255 * Math.min(1f, fd * 3f)));
                int tc = (a << 24) | 0xFFD27F;
                for (int id : b.ids) {
                    Entity e = mc.level.getEntity(id);
                    if (!(e instanceof ItemEntity ie)) continue;
                    Vec3 pos = e.getPosition(pt);
                    if (!Proj.project(pos.x, pos.y + e.getBbHeight() + 0.55, pos.z)) continue;
                    seen.add(id);
                    double[] sp = smooth.get(id);
                    if (sp == null) { sp = new double[]{Proj.px, Proj.py}; smooth.put(id, sp); }
                    else { sp[0] += (Proj.px - sp[0]) * 0.45; sp[1] += (Proj.py - sp[1]) * 0.45; }
                    ItemStack st = ie.getItem();
                    String name = st.getHoverName().getString() + (st.getCount() > 1 ? " x" + st.getCount() : "");
                    Proj.label(g, name, sp[0], sp[1], tc);
                }
            }
            smooth.keySet().retainAll(seen);
        } else smooth.clear();

        // ---------- HUD elements ----------
        if (listEl.x < 0) listEl.x = W - 4;

        float aMark = step(markEl, watermark.value ? 1f : 0f, dt);
        if (aMark > 0.02f) {
            String wm = "TediClient";
            markEl.w = Draw.width(f, wm, true) + 15; markEl.h = 14;
            int x = markEl.left(), y = markEl.y;
            Draw.softPanel(g, x, y, markEl.w, markEl.h, col, aMark);
            Draw.text(g, f, wm, x + 7, y + 3, Draw.alpha(col, aMark), true);
        }
        float aFps = step(fpsEl, fps.value ? 1f : 0f, dt);
        if (aFps > 0.02f) small(g, f, fpsEl, aFps, "FPS", String.valueOf(mc.getFps()), Colors.TEXT, col);

        float aPing = step(pingEl, ping.value ? 1f : 0f, dt);
        if (aPing > 0.02f) {
            int ms = 0;
            if (mc.getConnection() != null) {
                PlayerInfo pi = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (pi != null) ms = pi.getLatency();
            }
            small(g, f, pingEl, aPing, "PING", ms + "ms", ms < 80 ? 0xFF7CFF8A : ms < 160 ? 0xFFFFE066 : 0xFFFF6B6B, col);
        }
        float aCps = step(cpsEl, cps.value ? 1f : 0f, dt);
        if (aCps > 0.02f) small(g, f, cpsEl, aCps, "CPS", clicks(leftClicks, now) + " | " + clicks(rightClicks, now), Colors.TEXT, col);

        float aCoords = step(coordsEl, coords.value ? 1f : 0f, dt);
        if (aCoords > 0.02f) {
            BlockPos bp = mc.player.blockPosition();
            String dir = mc.player.getDirection().getSerializedName().toUpperCase(Locale.ROOT);
            small(g, f, coordsEl, aCoords, "XYZ", bp.getX() + " " + bp.getY() + " " + bp.getZ() + "  " + dir, Colors.TEXT, col);
        }
        float aUser = step(userEl, user.value ? 1f : 0f, dt);
        if (aUser > 0.02f) small(g, f, userEl, aUser, "USER", mc.getUser().getName(), Colors.TEXT, col);

        float aArmor = step(armorEl, armor.value ? 1f : 0f, dt);
        if (aArmor > 0.5f) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            armorEl.w = 60; armorEl.h = 4 * 17 + 3;
            int x = armorEl.left(), y = armorEl.y;
            Draw.softPanel(g, x, y, armorEl.w, armorEl.h, col, 1f);
            for (int i = 0; i < 4; i++) {
                ItemStack st = mc.player.getItemBySlot(slots[i]);
                int ry = y + 2 + i * 17;
                if (st.isEmpty()) { g.drawString(f, "-", x + 27, ry + 4, Colors.DIM, false); continue; }
                g.renderItem(st, x + 6, ry);
                String t = "OK"; int tc = Colors.TEXT;
                if (st.isDamageableItem() && st.getMaxDamage() > 0) {
                    int pc = (int) ((st.getMaxDamage() - st.getDamageValue()) * 100f / st.getMaxDamage());
                    t = pc + "%";
                    tc = pc > 60 ? 0xFF7CFF8A : pc > 25 ? 0xFFFFE066 : 0xFFFF6B6B;
                }
                g.drawString(f, t, x + 27, ry + 4, tc, false);
            }
        }

        // module list: entries slide + fade in/out and glide to their place
        float aList = list.value ? 1f : 0f;
        if (aList > 0f || !listY.isEmpty()) {
            List<Module> act = new ArrayList<>();
            for (Module m : Modules.all) {
                float a = step(m, (m.enabled && list.value) ? 1f : 0f, dt);
                if (a > 0.02f) act.add(m);
                else listY.remove(m);
            }
            act.sort(Comparator.comparingInt((Module m) -> -Draw.width(f, m.name, true)));
            int maxW = 40, idx = 0;
            for (Module m : act) {
                float a = step(m, (m.enabled && list.value) ? 1f : 0f, dt);
                float ty = listEl.y + idx * 14f;
                float cy = listY.containsKey(m) ? listY.get(m) : ty;
                cy += (ty - cy) * Math.min(1f, dt * 14f);
                listY.put(m, cy);
                int tw = Draw.width(f, m.name, true);
                int w = tw + 12;
                maxW = Math.max(maxW, w);
                int slide = (int) ((1f - a) * 16);
                int x = listEl.x - w + slide, y = Math.round(cy);
                Draw.round(g, x + 1, y + 1, w, 13, Draw.alpha(0x55000000, a));
                Draw.round(g, x, y, w, 13, Draw.alpha(0xD2141519, a));
                g.fill(listEl.x - 2 + slide, y + 1, listEl.x + slide, y + 12, Draw.alpha(col, a));
                Draw.text(g, f, m.name, x + 5, y + 3, Draw.alpha(col, a), true);
                idx++;
            }
            listEl.w = maxW; listEl.h = Math.max(14, idx * 14);
        }

        // ---------- drag-to-move while chat (T) is open ----------
        if (mc.screen instanceof ChatScreen) {
            double[] cx = new double[1], cy = new double[1];
            int[] ww = new int[1], wh = new int[1];
            GLFW.glfwGetCursorPos(win, cx, cy);
            GLFW.glfwGetWindowSize(win, ww, wh);
            double mx = cx[0] * W / Math.max(1, ww[0]);
            double my = cy[0] * H / Math.max(1, wh[0]);
            if (mL && !wasDown) {
                for (El e : elements) {
                    if (!on(e)) continue;
                    if (mx >= e.left() && mx < e.left() + e.w && my >= e.y && my < e.y + e.h) {
                        dragging = e; offX = (int) mx - e.left(); offY = (int) my - e.y;
                    }
                }
            }
            if (mL && dragging != null) {
                int nl = Math.max(0, Math.min(W - dragging.w, (int) mx - offX));
                dragging.x = dragging.right ? nl + dragging.w : nl;
                dragging.y = Math.max(0, Math.min(H - dragging.h, (int) my - offY));
            }
            if (!mL) dragging = null;
            wasDown = mL;
            for (El e : elements) if (on(e)) Draw.outline(g, e.left() - 1, e.y - 1, e.w + 2, e.h + 2, e == dragging ? 0xFFFFFFFF : col);
            Proj.label(g, "HUD EDIT MODE - drag the elements", W / 2.0, 14, col);
        } else {
            dragging = null;
            wasDown = false;
        }
    }
}
