package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class Hud extends Module {
    public static Hud I;

    private static class Broken {
        final BlockPos pos; final long time; final List<Integer> ids = new ArrayList<>();
        Broken(BlockPos pos, long time) { this.pos = pos; this.time = time; }
    }

    /** A movable HUD element. For right-anchored elements x is the RIGHT edge. x < 0 = not placed yet. */
    public static class El {
        public final String name; public int x, y, w = 50, h = 14; public final boolean right;
        final int defX, defY;
        public El(String name, int x, int y, boolean right) { this.name = name; this.x = x; this.y = y; this.right = right; this.defX = x; this.defY = y; }
        int left() { return right ? x - w : x; }
        void reset() { x = defX; y = defY; }
    }

    public final El markEl = new El("Watermark", 6, 4, false);
    public final El fpsEl = new El("FPS", 6, 22, false);
    public final El pingEl = new El("Ping", 6, 38, false);
    public final El cpsEl = new El("CPS", 6, 54, false);
    public final El coordsEl = new El("Coordinates", 6, 70, false);
    public final El userEl = new El("Username", 6, 86, false);
    public final El armorEl = new El("Armor", 6, 104, false);
    public final El listEl = new El("ModuleList", -1, 4, true);
    public final List<El> elements = List.of(markEl, fpsEl, pingEl, cpsEl, coordsEl, userEl, armorEl, listEl);

    public final Setting.Bool watermark = add(new Setting.Bool("TediClient Name", true));
    public final Setting.Bool fps = add(new Setting.Bool("FPS HUD", true));
    public final Setting.Bool ping = add(new Setting.Bool("Ping HUD", false));
    public final Setting.Bool cps = add(new Setting.Bool("CPS HUD", false));
    public final Setting.Bool coords = add(new Setting.Bool("Coordinates HUD", false));
    public final Setting.Bool user = add(new Setting.Bool("Username HUD", false));
    public final Setting.Bool armor = add(new Setting.Bool("Armor HUD", false));
    public final Setting.Bool list = add(new Setting.Bool("Module List", true));
    public final Setting.Hue color = add(new Setting.Hue("HUD Color", 195, 0.55, 1.0));
    public final Setting.Action reset = add(new Setting.Action("Reset HUD Positions", () -> { if (I != null) I.resetPositions(); }));
    public final Setting.Bool players = add(new Setting.Bool("Player Nametags", true));
    public final Setting.Bool showHealth = add(new Setting.Bool("Show Health", true));
    public final Setting.Bool showDist = add(new Setting.Bool("Show Distance", true));
    public final Setting.Num playerRange = add(new Setting.Num("Player Range", 128, 16, 256, 8));
    public final Setting.Bool broken = add(new Setting.Bool("Broken Item Nametags", true));
    public final Setting.Num brokenTime = add(new Setting.Num("Nametag Secs", 30, 3, 120, 1));

    private final List<Broken> brokenList = new ArrayList<>();
    private final Map<Integer, double[]> smooth = new HashMap<>();
    private final List<Long> leftClicks = new ArrayList<>(), rightClicks = new ArrayList<>();
    private boolean lastL, lastR;
    private BlockPos mining;
    private El dragging;
    private int offX, offY;
    private boolean wasDown;

    public Hud() {
        super("HUD", "Pick which HUDs show. Press T and drag them to move.", "RENDER", true);
        I = this;
    }

    public void resetPositions() { for (El e : elements) e.reset(); listEl.x = -1; }

    private boolean on(El e) {
        if (e == markEl) return watermark.value;
        if (e == fpsEl) return fps.value;
        if (e == pingEl) return ping.value;
        if (e == cpsEl) return cps.value;
        if (e == coordsEl) return coords.value;
        if (e == userEl) return user.value;
        if (e == armorEl) return armor.value;
        return list.value;
    }

    public void captureTarget(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        HitResult hr = mc.hitResult;
        if (mc.options.keyAttack.isDown() && hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.level.getBlockState(bhr.getBlockPos());
            if (!st.isAir()) mining = bhr.getBlockPos().immutable();
        }
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        long now = System.currentTimeMillis();
        if (mining != null) {
            if (mc.level.getBlockState(mining).isAir()) {
                brokenList.add(new Broken(mining, now));
                mining = null;
            } else if (!mc.options.keyAttack.isDown()) mining = null;
        }
        long life = (long) (brokenTime.value * 1000);

        Set<Integer> claimed = new HashSet<>();
        for (Broken b : brokenList) claimed.addAll(b.ids);
        for (Broken b : brokenList) {
            if (now - b.time < 1200) {
                Vec3 c = b.pos.getCenter();
                for (Entity e : mc.level.entitiesForRendering()) {
                    if (e instanceof ItemEntity && !claimed.contains(e.getId()) && e.position().distanceToSqr(c) < 9.0) {
                        b.ids.add(e.getId());
                        claimed.add(e.getId());
                    }
                }
            } else {
                b.ids.removeIf(id -> mc.level.getEntity(id) == null);
            }
        }
        // nothing dropped -> no nametag at all
        brokenList.removeIf(b -> now - b.time > life || (now - b.time >= 1200 && b.ids.isEmpty()));
    }

    private void small(GuiGraphics g, Font f, El e, String label, String val, int valCol, int col) {
        e.w = f.width(label) + f.width(val) + 16; e.h = 13;
        int x = e.left(), y = e.y;
        Draw.round(g, x, y, e.w, e.h, 0xB00E1014);
        g.fill(x + 2, y, x + e.w - 2, y + 1, Colors.withAlpha(col, 0xCC));
        g.drawString(f, label, x + 5, y + 3, col, false);
        g.drawString(f, val, x + 9 + f.width(label), y + 3, valCol, false);
    }

    private static int clicks(List<Long> l, long now) {
        l.removeIf(t -> now - t > 1000);
        return l.size();
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        Font f = mc.font;
        int col = color.argb();
        int W = g.guiWidth(), H = g.guiHeight();
        long now = System.currentTimeMillis();

        // raw mouse state (works even while a screen like chat is open)
        long win = GLFW.glfwGetCurrentContext();
        boolean mL = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean mR = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (mc.screen == null) {
            if (mL && !lastL) leftClicks.add(now);
            if (mR && !lastR) rightClicks.add(now);
        }
        lastL = mL; lastR = mR;

        // ---------- world nametags ----------
        if (players.value) {
            for (AbstractClientPlayer p : mc.level.players()) {
                if (p == mc.player && !(Freecam.active() || Freelook.active())) continue;
                Vec3 pos = p.getPosition(pt);
                double d = Math.sqrt(pos.distanceToSqr(Proj.cx, Proj.cy, Proj.cz));
                if (d > playerRange.value) continue;
                if (!Proj.project(pos.x, pos.y + p.getBbHeight() + 0.9, pos.z)) continue;
                StringBuilder sb = new StringBuilder(p.getName().getString());
                int c = Colors.ACCENT;
                if (showHealth.value) {
                    float hp = p.getHealth();
                    sb.append(" ").append(String.format(Locale.ROOT, "%.1f", hp));
                    c = hp > 14 ? 0xFF7CFF8A : hp > 7 ? 0xFFFFE066 : 0xFFFF6B6B;
                }
                if (showDist.value) sb.append(" [").append((int) d).append("m]");
                Proj.label(g, sb.toString(), Proj.px, Proj.py, c);
            }
        }
        if (broken.value) {
            long life = (long) (brokenTime.value * 1000);
            Set<Integer> seen = new HashSet<>();
            for (Broken b : brokenList) {
                float fade = 1f - (float) (now - b.time) / (float) life;
                int a = Math.max(5, (int) (255 * Math.min(1f, fade * 3f)));
                int tc = (a << 24) | 0xFFD27F;
                for (int id : b.ids) {
                    Entity e = mc.level.getEntity(id);
                    if (!(e instanceof ItemEntity ie)) continue;
                    Vec3 pos = e.getPosition(pt);
                    if (!Proj.project(pos.x, pos.y + e.getBbHeight() + 0.55, pos.z)) continue;
                    seen.add(id);
                    double[] sp = smooth.get(id);
                    if (sp == null) { sp = new double[]{Proj.px, Proj.py}; smooth.put(id, sp); }
                    else { sp[0] += (Proj.px - sp[0]) * 0.45; sp[1] += (Proj.py - sp[1]) * 0.45; }
                    ItemStack st = ie.getItem();
                    String name = st.getHoverName().getString() + (st.getCount() > 1 ? " x" + st.getCount() : "");
                    Proj.label(g, name, sp[0], sp[1], tc);
                }
            }
            smooth.keySet().retainAll(seen);
        } else smooth.clear();

        // ---------- HUD elements ----------
        if (listEl.x < 0) listEl.x = W - 4;
        String wm = "TediClient";
        if (watermark.value) {
            markEl.w = f.width(wm) + 14; markEl.h = 14;
            int x = markEl.left(), y = markEl.y;
            Draw.round(g, x, y, markEl.w, markEl.h, 0xB00E1014);
            g.fill(x + 2, y, x + markEl.w - 2, y + 1, Colors.withAlpha(col, 0xCC));
            g.drawString(f, wm, x + 7, y + 3, col, false);
            g.drawString(f, wm, x + 8, y + 3, Colors.withAlpha(col, 0x55), false);
        }
        if (fps.value) small(g, f, fpsEl, "FPS", String.valueOf(mc.getFps()), Colors.TEXT, col);
        if (ping.value) {
            int ms = 0;
            if (mc.getConnection() != null) {
                PlayerInfo pi = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (pi != null) ms = pi.getLatency();
            }
            small(g, f, pingEl, "PING", ms + "ms", ms < 80 ? 0xFF7CFF8A : ms < 160 ? 0xFFFFE066 : 0xFFFF6B6B, col);
        }
        if (cps.value) small(g, f, cpsEl, "CPS", clicks(leftClicks, now) + " | " + clicks(rightClicks, now), Colors.TEXT, col);
        if (coords.value) {
            BlockPos bp = mc.player.blockPosition();
            String dir = mc.player.getDirection().getSerializedName().toUpperCase(Locale.ROOT);
            small(g, f, coordsEl, "XYZ", bp.getX() + " " + bp.getY() + " " + bp.getZ() + "  " + dir, Colors.TEXT, col);
        }
        if (user.value) small(g, f, userEl, "USER", mc.getUser().getName(), Colors.TEXT, col);
        if (armor.value) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            armorEl.w = 58; armorEl.h = 4 * 17 + 3;
            int x = armorEl.left(), y = armorEl.y;
            Draw.round(g, x, y, armorEl.w, armorEl.h, 0xB00E1014);
            g.fill(x + 2, y, x + armorEl.w - 2, y + 1, Colors.withAlpha(col, 0xCC));
            for (int i = 0; i < 4; i++) {
                ItemStack st = mc.player.getItemBySlot(slots[i]);
                int ry = y + 2 + i * 17;
                if (st.isEmpty()) { g.drawString(f, "-", x + 25, ry + 4, Colors.DIM, false); continue; }
                g.renderItem(st, x + 5, ry);
                String t = "OK"; int tc = Colors.TEXT;
                if (st.isDamageableItem() && st.getMaxDamage() > 0) {
                    int pc = (int) ((st.getMaxDamage() - st.getDamageValue()) * 100f / st.getMaxDamage());
                    t = pc + "%";
                    tc = pc > 60 ? 0xFF7CFF8A : pc > 25 ? 0xFFFFE066 : 0xFFFF6B6B;
                }
                g.drawString(f, t, x + 25, ry + 4, tc, false);
            }
        }
        if (list.value) {
            List<Module> act = new ArrayList<>();
            for (Module m : Modules.all) if (m.enabled) act.add(m);
            act.sort(Comparator.comparingInt((Module m) -> -f.width(m.name)));
            int y = listEl.y, maxW = 40;
            for (Module m : act) {
                int w = f.width(m.name) + 10;
                maxW = Math.max(maxW, w);
                int x = listEl.x - w;
                Draw.round(g, x, y, w, 12, 0xB00E1014);
                g.fill(listEl.x - 2, y + 1, listEl.x, y + 11, col);
                g.drawString(f, m.name, x + 4, y + 2, col, false);
                y += 13;
            }
            listEl.w = maxW; listEl.h = Math.max(13, y - listEl.y);
        }

        // ---------- drag-to-move while chat (T) is open ----------
        if (mc.screen instanceof ChatScreen) {
            double[] cx = new double[1], cy = new double[1];
            int[] ww = new int[1], wh = new int[1];
            GLFW.glfwGetCursorPos(win, cx, cy);
            GLFW.glfwGetWindowSize(win, ww, wh);
            double mx = cx[0] * W / Math.max(1, ww[0]);
            double my = cy[0] * H / Math.max(1, wh[0]);
            if (mL && !wasDown) {
                for (El e : elements) {
                    if (!on(e)) continue;
                    if (mx >= e.left() && mx < e.left() + e.w && my >= e.y && my < e.y + e.h) {
                        dragging = e; offX = (int) mx - e.left(); offY = (int) my - e.y;
                    }
                }
            }
            if (mL && dragging != null) {
                int nl = Math.max(0, Math.min(W - dragging.w, (int) mx - offX));
                dragging.x = dragging.right ? nl + dragging.w : nl;
                dragging.y = Math.max(0, Math.min(H - dragging.h, (int) my - offY));
            }
            if (!mL) dragging = null;
            wasDown = mL;
            for (El e : elements) if (on(e)) Draw.outline(g, e.left() - 1, e.y - 1, e.w + 2, e.h + 2, e == dragging ? 0xFFFFFFFF : col);
            Proj.label(g, "HUD EDIT MODE - drag the elements", W / 2.0, 14, col);
        } else {
            dragging = null;
            wasDown = false;
        }
    }
}
