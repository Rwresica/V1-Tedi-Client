package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class Hud extends Module {
    public static Hud I;
    private record Broken(BlockPos pos, String name, long time) {}

    /** A movable HUD element. For right-anchored elements x is the RIGHT edge. x < 0 = not placed yet. */
    public static class El {
        public final String name; public int x, y, w = 50, h = 13; public final boolean right;
        public El(String name, int x, int y, boolean right) { this.name = name; this.x = x; this.y = y; this.right = right; }
        int left() { return right ? x - w : x; }
    }

    public final El fpsEl = new El("FPS", 6, 6, false);
    public final El coordsEl = new El("Coordinates", 6, 24, false);
    public final El listEl = new El("ModuleList", -1, 4, true);
    public final List<El> elements = List.of(fpsEl, coordsEl, listEl);

    public final Setting.Bool fps = add(new Setting.Bool("FPS HUD", true));
    public final Setting.Bool coords = add(new Setting.Bool("Coordinates HUD", false));
    public final Setting.Bool list = add(new Setting.Bool("Module List", true));
    public final Setting.Hue color = add(new Setting.Hue("HUD Color", 195));
    public final Setting.Bool players = add(new Setting.Bool("Player Nametags", true));
    public final Setting.Bool showHealth = add(new Setting.Bool("Show Health", true));
    public final Setting.Bool showDist = add(new Setting.Bool("Show Distance", true));
    public final Setting.Num playerRange = add(new Setting.Num("Player Range", 128, 16, 256, 8));
    public final Setting.Bool blocks = add(new Setting.Bool("Block Nametags", true));
    public final Setting.Num blockRange = add(new Setting.Num("Block Range", 24, 4, 64, 2));
    public final Setting.Num brokenTime = add(new Setting.Num("Broken Block Secs", 4, 1, 15, 1));

    private final List<Broken> broken = new ArrayList<>();
    private BlockPos mining;
    private String miningName = "";
    private El dragging;
    private int offX, offY;
    private boolean wasDown;

    public Hud() {
        super("HUD", "Choose which HUDs show. Press T and drag them to move.", "HUD", true);
        I = this;
    }

    private boolean on(El e) { return e == fpsEl ? fps.value : e == coordsEl ? coords.value : list.value; }

    public void captureTarget(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        HitResult hr = mc.hitResult;
        if (mc.options.keyAttack.isDown() && hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.level.getBlockState(bhr.getBlockPos());
            if (!st.isAir()) {
                mining = bhr.getBlockPos().immutable();
                miningName = st.getBlock().getName().getString();
            }
        }
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null) return;
        if (mining != null) {
            if (mc.level.getBlockState(mining).isAir()) {
                broken.add(new Broken(mining, miningName, System.currentTimeMillis()));
                mining = null;
            } else if (!mc.options.keyAttack.isDown()) mining = null;
        }
        long life = (long) (brokenTime.value * 1000), now = System.currentTimeMillis();
        broken.removeIf(b -> now - b.time() > life);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        Font f = mc.font;
        int col = color.argb();
        int W = g.guiWidth(), H = g.guiHeight();

        // ---------- world nametags ----------
        if (players.value) {
            for (AbstractClientPlayer p : mc.level.players()) {
                if (p == mc.player && !Freecam.active()) continue;
                Vec3 pos = p.getPosition(pt);
                double d = Math.sqrt(pos.distanceToSqr(Proj.cx, Proj.cy, Proj.cz));
                if (d > playerRange.value) continue;
                if (!Proj.project(pos.x, pos.y + p.getBbHeight() + 0.9, pos.z)) continue;
                StringBuilder sb = new StringBuilder(p.getName().getString());
                int c = Colors.ACCENT;
                if (showHealth.value) {
                    float hp = p.getHealth();
                    sb.append(" ").append(String.format(Locale.ROOT, "%.1f", hp));
                    c = hp > 14 ? 0xFF7CFF8A : hp > 7 ? 0xFFFFE066 : 0xFFFF6B6B;
                }
                if (showDist.value) sb.append(" [").append((int) d).append("m]");
                Proj.label(g, sb.toString(), Proj.px, Proj.py, c);
            }
        }
        if (blocks.value) {
            double r2 = blockRange.value * blockRange.value;
            for (StorageEsp.Hit h : StorageEsp.hits) {
                Vec3 c = h.pos().getCenter();
                if (c.distanceToSqr(Proj.cx, Proj.cy, Proj.cz) > r2) continue;
                if (Proj.project(c.x, c.y + 0.8, c.z)) Proj.label(g, h.name(), Proj.px, Proj.py, Colors.TEXT);
            }
            long now = System.currentTimeMillis(), life = (long) (brokenTime.value * 1000);
            for (Broken b : broken) {
                Vec3 c = b.pos().getCenter();
                float fade = 1f - (float) (now - b.time()) / (float) life;
                int a = Math.max(5, (int) (255 * Math.min(1f, fade * 2f)));
                if (Proj.project(c.x, c.y + 0.9, c.z)) Proj.label(g, b.name(), Proj.px, Proj.py, (a << 24) | 0xFFD27F);
            }
        }

        // ---------- HUD elements ----------
        if (listEl.x < 0) listEl.x = W - 4;

        if (fps.value) {
            String label = "FPS", val = String.valueOf(mc.getFps());
            fpsEl.w = f.width(label) + f.width(val) + 16; fpsEl.h = 14;
            int x = fpsEl.left(), y = fpsEl.y;
            Draw.panel(g, x, y, fpsEl.w, fpsEl.h, col);
            g.drawString(f, label, x + 7, y + 3, col, false);
            g.drawString(f, val, x + 11 + f.width(label), y + 3, Colors.TEXT, false);
        }
        if (coords.value) {
            String label = "XYZ";
            BlockPos bp = mc.player.blockPosition();
            String val = bp.getX() + "  " + bp.getY() + "  " + bp.getZ();
            coordsEl.w = f.width(label) + f.width(val) + 16; coordsEl.h = 14;
            int x = coordsEl.left(), y = coordsEl.y;
            Draw.panel(g, x, y, coordsEl.w, coordsEl.h, col);
            g.drawString(f, label, x + 7, y + 3, col, false);
            g.drawString(f, val, x + 11 + f.width(label), y + 3, Colors.TEXT, false);
        }
        if (list.value) {
            List<Module> act = new ArrayList<>();
            for (Module m : Modules.all) if (m.enabled) act.add(m);
            act.sort(Comparator.comparingInt((Module m) -> -f.width(m.name)));
            int y = listEl.y, maxW = 40;
            for (Module m : act) {
                int w = f.width(m.name) + 11;
                maxW = Math.max(maxW, w);
                int x = listEl.x - w;
                Draw.round(g, x, y, w, 12, 0xB00D1117);
                g.fill(listEl.x - 2, y + 1, listEl.x, y + 11, col);
                g.drawString(f, m.name, x + 4, y + 2, col, false);
                y += 13;
            }
            listEl.w = maxW; listEl.h = Math.max(13, y - listEl.y);
        }

        // ---------- drag-to-move while chat (T) is open ----------
        boolean chat = mc.screen instanceof ChatScreen;
        if (chat) {
            double mx = mc.mouseHandler.xpos() * W / (double) mc.getWindow().getScreenWidth();
            double my = mc.mouseHandler.ypos() * H / (double) mc.getWindow().getScreenHeight();
            boolean down = mc.mouseHandler.isLeftPressed();
            if (down && !wasDown) {
                for (El e : elements) {
                    if (!on(e)) continue;
                    if (mx >= e.left() && mx < e.left() + e.w && my >= e.y && my < e.y + e.h) {
                        dragging = e; offX = (int) mx - e.left(); offY = (int) my - e.y;
                    }
                }
            }
            if (down && dragging != null) {
                int nl = Math.max(0, Math.min(W - dragging.w, (int) mx - offX));
                dragging.x = dragging.right ? nl + dragging.w : nl;
                dragging.y = Math.max(0, Math.min(H - dragging.h, (int) my - offY));
            }
            if (!down) dragging = null;
            wasDown = down;
            for (El e : elements) if (on(e)) Draw.outline(g, e.left() - 1, e.y - 1, e.w + 2, e.h + 2, e == dragging ? 0xFFFFFFFF : col);
            Proj.label(g, "HUD EDIT MODE - drag the elements", W / 2.0, 14, col);
        } else {
            dragging = null;
            wasDown = false;
        }
    }
}
