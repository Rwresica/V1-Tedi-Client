package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Icons;
import dev.tedi.util.Keys;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class Hud extends Module {
    public static Hud I;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static final int[] REGION_COL = {0xFFF28C1E, 0xFF2F6FDF, 0xFF29A8E0, 0xFF8BC34A, 0xFF2EBD59, 0xFFF2B01E};
    private static final String[] REGION_NAME = {"NORTH WEST", "NORTH", "NORTH EAST", "SOUTH EAST", "SOUTH", "SOUTH WEST"};

    private static class Broken {
        final BlockPos pos; final long time; final List<Integer> ids = new ArrayList<>();
        Broken(BlockPos pos, long time) { this.pos = pos; this.time = time; }
    }

    private static class Seg { String label, value; boolean hl, logo; int w, px, py; }

    /** A movable HUD element. For right-anchored elements x is the RIGHT edge. x < 0 = not placed yet. */
    public static class El {
        public final String name; public int x = -1, y = -1, w = 60, h; public final boolean right; final int defY;
        public El(String name, int h, boolean right, int defY) { this.name = name; this.h = h; this.right = right; this.defY = defY; if (right) y = defY; }
        int left() { return right ? x - w : x; }
        void reset() { x = -1; y = right ? defY : -1; }
    }

    public final El statsEl = new El("Stats", 34, false, 0);
    public final El cpsEl = new El("CPS", 15, false, 0);
    public final El coordsEl = new El("Coordinates", 15, false, 0);
    public final El userEl = new El("Username", 15, false, 0);
    public final El armorEl = new El("Armor", 82, false, 0);
    public final El hotkeysEl = new El("Hotkeys", 60, false, 0);
    public final El mapEl = new El("RegionMap", 200, false, 0);
    public final El listEl = new El("ModuleList", 15, true, 4);
    public final List<El> elements = List.of(statsEl, cpsEl, coordsEl, userEl, armorEl, hotkeysEl, mapEl, listEl);

    // stats bar segments
    public final Setting.Bool watermark = add(new Setting.Bool("TediClient Name", true));
    public final Setting.Bool bps = add(new Setting.Bool("Speed HUD", true));
    public final Setting.Bool fps = add(new Setting.Bool("FPS HUD", true));
    public final Setting.Bool clock = add(new Setting.Bool("Time HUD", true));
    public final Setting.Bool server = add(new Setting.Bool("Server HUD", true));
    public final Setting.Bool ping = add(new Setting.Bool("Ping HUD", true));
    // other elements
    public final Setting.Bool cps = add(new Setting.Bool("CPS HUD", false));
    public final Setting.Bool coords = add(new Setting.Bool("Coordinates HUD", false));
    public final Setting.Bool user = add(new Setting.Bool("Username HUD", false));
    public final Setting.Bool armor = add(new Setting.Bool("Armor HUD", false));
    public final Setting.Bool hotkeys = add(new Setting.Bool("Hotkeys HUD", false));
    public final Setting.Bool regionMap = add(new Setting.Bool("Region Map HUD", false));
    public final Setting.Num regionSize = add(new Setting.Num("Region Size", 1000, 250, 5000, 250));
    public final Setting.Bool list = add(new Setting.Bool("Module List", true));
    public final Setting.Hue color = add(new Setting.Hue("HUD Color", 195, 0.55, 1.0));
    public final Setting.Bool toasts = add(new Setting.Bool("Toast Notifications", true));
    public final Setting.Action reset = add(new Setting.Action("Reset HUD Positions", () -> { if (I != null) I.resetPositions(); }));
    public final Setting.Bool players = add(new Setting.Bool("Player Nametags", true));
    public final Setting.Bool showHealth = add(new Setting.Bool("Show Health", true));
    public final Setting.Bool showDist = add(new Setting.Bool("Show Distance", true));
    public final Setting.Num playerRange = add(new Setting.Num("Player Range", 128, 16, 256, 8));
    public final Setting.Bool broken = add(new Setting.Bool("Broken Item Nametags", true));
    public final Setting.Num brokenTime = add(new Setting.Num("Nametag Secs", 30, 3, 120, 1));

    private final List<Broken> brokenList = new ArrayList<>();
    private final Map<Integer, double[]> smooth = new HashMap<>();
    private final Map<Integer, Long> born = new HashMap<>();
    private final Map<Object, Float> fade = new HashMap<>();
    private final Map<Module, Float> listY = new HashMap<>();
    private final List<Long> leftClicks = new ArrayList<>(), rightClicks = new ArrayList<>();
    private boolean lastL, lastR;
    private BlockPos mining;
    private El dragging;
    private int offX, offY;
    private boolean wasDown;
    private long lastNano = System.nanoTime();
    private double lastX, lastZ, bpsVal;
    private boolean haveLast;

    public Hud() {
        super("HUD", "Pick which HUDs show. Press T and drag them to move.", "RENDER", true);
        I = this;
    }

    public void resetPositions() { for (El e : elements) e.reset(); }

    private boolean on(El e) {
        if (e == statsEl) return watermark.value || bps.value || fps.value || clock.value || server.value || ping.value;
        if (e == cpsEl) return cps.value;
        if (e == coordsEl) return coords.value;
        if (e == userEl) return user.value;
        if (e == armorEl) return armor.value;
        if (e == hotkeysEl) return hotkeys.value;
        if (e == mapEl) return regionMap.value;
        return list.value;
    }

    private float step(Object key, float target, float dt) {
        float v = fade.getOrDefault(key, target);
        v += (target - v) * Math.min(1f, dt * 12f);
        if (Math.abs(target - v) < 0.004f) v = target;
        fade.put(key, v);
        return v;
    }

    public void captureTarget(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        HitResult hr = mc.hitResult;
        if (mc.options.keyAttack.isDown() && hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.level.getBlockState(bhr.getBlockPos());
            if (!st.isAir()) mining = bhr.getBlockPos().immutable();
        }
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        long now = System.currentTimeMillis();

        double px = mc.player.getX(), pz = mc.player.getZ();
        if (haveLast) {
            double cur = Math.hypot(px - lastX, pz - lastZ) * 20.0;
            bpsVal += (cur - bpsVal) * 0.25;
        }
        lastX = px; lastZ = pz; haveLast = true;

        if (mining != null) {
            if (mc.level.getBlockState(mining).isAir()) {
                brokenList.add(new Broken(mining, now));
                mining = null;
            } else if (!mc.options.keyAttack.isDown()) mining = null;
        }
        long life = (long) (brokenTime.value * 1000);
        Set<Integer> claimed = new HashSet<>();
        for (Broken b : brokenList) claimed.addAll(b.ids);
        for (Broken b : brokenList) {
            if (now - b.time < 1200) {
                Vec3 c = b.pos.getCenter();
                for (Entity e : mc.level.entitiesForRendering()) {
                    if (e instanceof ItemEntity && !claimed.contains(e.getId()) && e.position().distanceToSqr(c) < 9.0) {
                        b.ids.add(e.getId());
                        claimed.add(e.getId());
                    }
                }
            } else {
                b.ids.removeIf(id -> mc.level.getEntity(id) == null);
            }
        }
        brokenList.removeIf(b -> now - b.time > life || (now - b.time >= 1200 && b.ids.isEmpty()));
    }

    // ------------------------------------------------------------------ helpers

    private void row(GuiGraphics g, Font f, El e, float a, String icon, String text, int textCol, int col) {
        e.w = 6 + 9 + 5 + Draw.width(f, text, true) + 8; e.h = 15;
        int x = e.left(), y = e.y;
        Draw.pill(g, x, y, e.w, e.h, a);
        Icons.draw(g, icon, x + 6, y + 3, Draw.alpha(col, a));
        Draw.text(g, f, text, x + 20, y + 4, Draw.alpha(textCol, a), true);
    }

    private static int pctColor(int pc) {
        return pc > 60 ? 0xFF7CFF8A : pc > 40 ? 0xFFFFE066 : pc > 20 ? 0xFFFFB066 : 0xFFFF6B6B;
    }

    private static int clicks(List<Long> l, long now) {
        l.removeIf(t -> now - t > 1000);
        return l.size();
    }

    private static int spiral(int x, int y) {
        int k = Math.max(Math.abs(x), Math.abs(y));
        if (k == 0) return 1;
        int s = (2 * k - 1) * (2 * k - 1);
        if (x == k && y > -k) return s + (y + k);
        if (y == k) return s + 2 * k + (k - x);
        if (x == -k) return s + 4 * k + (k - y);
        return s + 6 * k + (x + k);
    }

    private static int sector(int gx, int gz) {
        double ang = Math.atan2(gz, gx);
        return Math.max(0, Math.min(5, (int) Math.floor((ang + Math.PI) / (Math.PI / 3.0))));
    }

    /** Nametag pill: bold text + coloured bar on the right (same look as the module list). */
    private void tagPill(GuiGraphics g, int left, int top, int w, int h, int barCol, float a) {
        Draw.roundR(g, left + 1, top + 2, w, h, 5, Draw.alpha(0x55000000, a));
        Draw.roundR(g, left, top, w, h, 5, Draw.alpha(0xDC111318, a));
        g.fill(left + 5, top, left + w - 5, top + 1, Draw.alpha(0x2AFFFFFF, a));
        Draw.roundR(g, left + w - 6, top + 4, 3, h - 8, 1, Draw.alpha(barCol, a));
    }

    private void playerTag(GuiGraphics g, Font f, String name, float hp, float maxHp, double dist, double x, double y, float scale) {
        String hs = String.format(Locale.ROOT, "%.1f", hp), ds = (int) dist + "m";
        int nw = Draw.width(f, name, true);
        int hw = showHealth.value ? f.width(hs) + 6 : 0, dw = showDist.value ? f.width(ds) + 6 : 0;
        int w = nw + hw + dw + 20, h = 17, left = -w / 2;
        int hc = hp > 14 ? 0xFF7CFF8A : hp > 7 ? 0xFFFFE066 : 0xFFFF6B6B;
        var ps = g.pose();
        ps.pushMatrix();
        ps.translate((float) x, (float) y);
        ps.scale(scale, scale);
        tagPill(g, left, -9, w, h, hc, 1f);
        int tx = left + 7;
        Draw.text(g, f, name, tx, -5, 0xFFFFFFFF, true);
        tx += nw + 6;
        if (showHealth.value) { g.drawString(f, hs, tx, -4, hc, false); tx += hw; }
        if (showDist.value) g.drawString(f, ds, tx, -4, 0xFF8D95A1, false);
        float pct = Math.max(0f, Math.min(1f, hp / maxHp));
        Draw.roundR(g, left + 5, 6, w - 16, 2, 1, 0x40FFFFFF);
        Draw.roundR(g, left + 5, 6, Math.max(2, (int) ((w - 16) * pct)), 2, 1, hc);
        ps.popMatrix();
    }

    private void itemTag(GuiGraphics g, Font f, ItemStack st, String text, double x, double y, float a, float scale) {
        int tw = Draw.width(f, text, true), w = tw + 36, left = -w / 2;
        var ps = g.pose();
        ps.pushMatrix();
        ps.translate((float) x, (float) y);
        ps.scale(scale, scale);
        tagPill(g, left, -9, w, 19, Colors.ACCENT, a);
        if (a > 0.35f) g.renderItem(st, left + 3, -8);
        Draw.text(g, f, text, left + 23, -4, Draw.alpha(0xFFFFFFFF, a), true);
        ps.popMatrix();
    }

    private Seg seg(Font f, String label, String value, boolean hl) {
        Seg s = new Seg();
        s.label = label; s.value = value; s.hl = hl;
        s.w = 8 + (label.isEmpty() ? 0 : Draw.width(f, label, true) + 5) + Draw.width(f, value, true) + 8;
        return s;
    }

    private void drawStats(GuiGraphics g, Font f, Minecraft mc, int col) {
        List<Seg> segs = new ArrayList<>();
        if (watermark.value) {
            Seg s = new Seg(); s.logo = true;
            s.w = 6 + 9 + 5 + Draw.width(f, "Tedi", true) + Draw.width(f, "Client", true) + Draw.width(f, " 1.0.0", true) + 8;
            segs.add(s);
        }
        if (bps.value) segs.add(seg(f, "SPEED", String.format(Locale.ROOT, "%.1f B/S", bpsVal), false));
        if (fps.value) segs.add(seg(f, "FPS", String.valueOf(mc.getFps()), false));
        if (clock.value) segs.add(seg(f, "TIME", LocalTime.now().format(CLOCK), false));
        if (server.value) {
            ServerData sd = mc.getCurrentServer();
            String ip = sd != null ? sd.ip : (mc.hasSingleplayerServer() ? "SINGLEPLAYER" : "OFFLINE");
            segs.add(seg(f, "", ip.toUpperCase(Locale.ROOT), true));
        }
        if (ping.value) {
            int ms = 0;
            if (mc.getConnection() != null) {
                PlayerInfo pi = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (pi != null) ms = pi.getLatency();
            }
            segs.add(seg(f, "PING", ms + "MS", false));
        }
        int maxRow = 250, cx = 0, cy = 0, maxX = 0;
        for (Seg s : segs) {
            if (cx > 0 && cx + s.w > maxRow) { cx = 0; cy += 18; }
            s.px = cx; s.py = cy; cx += s.w + 3; maxX = Math.max(maxX, cx - 3);
        }
        statsEl.w = Math.max(20, maxX); statsEl.h = segs.isEmpty() ? 15 : cy + 15;
        int ox = statsEl.left(), oy = statsEl.y;
        for (Seg s : segs) {
            int x = ox + s.px, y = oy + s.py;
            Draw.roundR(g, x + 1, y + 2, s.w, 15, 5, 0x50000000);
            Draw.roundR(g, x, y, s.w, 15, 5, s.hl ? 0xD8123046 : 0xD8111318);
            g.fill(x + 5, y, x + s.w - 5, y + 1, 0x2EFFFFFF);
            if (s.hl) Draw.outline(g, x, y, s.w, 15, Draw.alpha(col, 0.45f));
            if (s.logo) {
                Icons.draw(g, "logo", x + 6, y + 3, col);
                int tx = x + 20;
                Draw.text(g, f, "Tedi", tx, y + 4, col, true);
                tx += Draw.width(f, "Tedi", true);
                Draw.text(g, f, "Client", tx, y + 4, 0xFFFFFFFF, true);
                tx += Draw.width(f, "Client", true);
                Draw.text(g, f, " 1.0.0", tx, y + 4, 0xFF8D95A1, true);
            } else {
                int tx = x + 8;
                if (!s.label.isEmpty()) { Draw.text(g, f, s.label, tx, y + 4, col, true); tx += Draw.width(f, s.label, true) + 5; }
                Draw.text(g, f, s.value, tx, y + 4, s.hl ? col : 0xFFFFFFFF, true);
            }
        }
    }

    private void drawRegionMap(GuiGraphics g, Font f, Minecraft mc, int col) {
        int size = regionSize.i(), cols = 9, cw = 16, chh = 12, gap = 1;
        BlockPos bp = mc.player.blockPosition();
        int rx = Math.floorDiv(bp.getX(), size), rz = Math.floorDiv(bp.getZ(), size);
        int gw = cols * (cw + gap) - gap, w = gw + 12, h = 6 + cols * (chh + gap) + 6 + 22 + 6 + 3 * 12 + 8;
        mapEl.w = w; mapEl.h = h;
        int x = mapEl.left(), y = mapEl.y;
        Draw.shadow(g, x, y, w, h, 6);
        Draw.roundR(g, x, y, w, h, 6, 0xEE0F1220);
        g.fill(x + 6, y, x + w - 6, y + 1, 0x30FFFFFF);
        var ps = g.pose();
        for (int r = 0; r < cols; r++) {
            for (int c = 0; c < cols; c++) {
                int gx = rx + c - 4, gz = rz + r - 4;
                int cx = x + 6 + c * (cw + gap), cy = y + 6 + r * (chh + gap);
                int rc = REGION_COL[sector(gx, gz)];
                Draw.roundR(g, cx, cy, cw, chh, 2, (0xE6 << 24) | (rc & 0xFFFFFF));
                String num = String.valueOf(spiral(gx, gz));
                ps.pushMatrix();
                ps.translate(cx + cw / 2f, cy + chh / 2f);
                ps.scale(0.7f, 0.7f);
                Draw.text(g, f, num, -f.width(num) / 2, -4, 0xFFFFFFFF, true);
                ps.popMatrix();
                if (r == 4 && c == 4) Draw.outline(g, cx - 1, cy - 1, cw + 2, chh + 2, 0xFFFFFFFF);
            }
        }
        int ty = y + 6 + cols * (chh + gap) + 6;
        int cur = spiral(rx, rz), cs = sector(rx, rz);
        ps.pushMatrix();
        ps.translate(x + 7f, ty);
        ps.scale(0.8f, 0.8f);
        Draw.text(g, f, "POSITION: X: " + bp.getX() + "  Z: " + bp.getZ(), 0, 0, 0xFFFFFFFF, true);
        Draw.text(g, f, "CURRENT REGION: " + cur + " (" + REGION_NAME[cs] + ")", 0, 12, col, true);
        ps.popMatrix();
        int ly = ty + 26;
        for (int i = 0; i < 6; i++) {
            int lx = x + 8 + (i / 3) * (w / 2 - 2), lyy = ly + (i % 3) * 12;
            Draw.roundR(g, lx, lyy, 8, 8, 2, REGION_COL[i]);
            ps.pushMatrix();
            ps.translate(lx + 12f, lyy);
            ps.scale(0.75f, 0.75f);
            Draw.text(g, f, REGION_NAME[i], 0, 0, 0xFFE8EAEE, true);
            ps.popMatrix();
        }
    }

    // ------------------------------------------------------------------ render

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        Font f = mc.font;
        int col = color.argb();
        int W = g.guiWidth(), H = g.guiHeight();
        long now = System.currentTimeMillis();
        long nn = System.nanoTime();
        float dt = Math.min(0.05f, (nn - lastNano) / 1e9f);
        lastNano = nn;

        long win = GLFW.glfwGetCurrentContext();
        boolean mL = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean mR = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (mc.screen == null) {
            if (mL && !lastL) leftClicks.add(now);
            if (mR && !lastR) rightClicks.add(now);
        }
        lastL = mL; lastR = mR;

        // ---------- world nametags ----------
        if (players.value) {
            for (AbstractClientPlayer p : mc.level.players()) {
                if (p == mc.player && !(Freecam.active() || Freelook.active())) continue;
                Vec3 pos = p.getPosition(pt);
                double d = Math.sqrt(pos.distanceToSqr(Proj.cx, Proj.cy, Proj.cz));
                if (d > playerRange.value) continue;
                if (!Proj.project(pos.x, pos.y + p.getBbHeight() + 0.85, pos.z)) continue;
                float scale = (float) Math.max(0.7, Math.min(1.2, 1.25 - d * 0.015));
                playerTag(g, f, p.getName().getString(), p.getHealth(), Math.max(1f, p.getMaxHealth()), d, Proj.px, Proj.py, scale);
            }
        }
        if (broken.value) {
            long life = (long) (brokenTime.value * 1000);
            Set<Integer> seen = new HashSet<>();
            for (Broken b : brokenList) {
                float endFade = Math.min(1f, (life - (now - b.time)) / 1500f);
                for (int id : b.ids) {
                    Entity e = mc.level.getEntity(id);
                    if (!(e instanceof ItemEntity ie)) continue;
                    Vec3 pos = e.getPosition(pt);
                    if (!Proj.project(pos.x, pos.y + e.getBbHeight() + 0.6, pos.z)) continue;
                    seen.add(id);
                    double d = Math.sqrt(pos.distanceToSqr(Proj.cx, Proj.cy, Proj.cz));
                    double[] sp = smooth.get(id);
                    if (sp == null) { sp = new double[]{Proj.px, Proj.py}; smooth.put(id, sp); born.put(id, now); }
                    else { double k = 1.0 - Math.exp(-dt * 16.0); sp[0] += (Proj.px - sp[0]) * k; sp[1] += (Proj.py - sp[1]) * k; }
                    float appear = Math.min(1f, (now - born.getOrDefault(id, now)) / 260f);
                    appear = 1f - (1f - appear) * (1f - appear);
                    ItemStack st = ie.getItem();
                    String name = st.getHoverName().getString() + (st.getCount() > 1 ? " x" + st.getCount() : "");
                    float scale = (float) Math.max(0.65, Math.min(1.15, 1.2 - d * 0.02)) * (0.85f + 0.15f * appear);
                    itemTag(g, f, st, name, sp[0], sp[1] - (1f - appear) * 6, appear * endFade, scale);
                }
            }
            smooth.keySet().retainAll(seen);
            born.keySet().retainAll(seen);
        } else { smooth.clear(); born.clear(); }

        // ---------- HUD elements ----------
        if (listEl.x < 0) listEl.x = W - 4;
        int curY = 4;
        for (El e : elements) if (e != listEl && on(e) && e.x >= 0 && e.x < W / 2) curY = Math.max(curY, e.y + e.h + 4);
        for (El e : elements) if (e != listEl && on(e) && e.x < 0) { e.x = 6; e.y = curY; curY += e.h + 4; }

        if (on(statsEl)) drawStats(g, f, mc, col);

        float a;
        a = step(cpsEl, cps.value ? 1f : 0f, dt);
        if (a > 0.02f) row(g, f, cpsEl, a, "cps", clicks(leftClicks, now) + " | " + clicks(rightClicks, now) + " CPS", 0xFFFFFFFF, col);
        a = step(coordsEl, coords.value ? 1f : 0f, dt);
        if (a > 0.02f) {
            BlockPos bp = mc.player.blockPosition();
            row(g, f, coordsEl, a, "coords", bp.getX() + ", " + bp.getY() + ", " + bp.getZ(), 0xFFFFFFFF, col);
        }
        a = step(userEl, user.value ? 1f : 0f, dt);
        if (a > 0.02f) row(g, f, userEl, a, "user", mc.getUser().getName(), 0xFFFFFFFF, col);

        a = step(armorEl, armor.value ? 1f : 0f, dt);
        if (a > 0.5f) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            armorEl.w = 112; armorEl.h = 4 * 19 + 6;
            int x = armorEl.left(), y = armorEl.y;
            Draw.pill(g, x, y, armorEl.w, armorEl.h, 1f);
            for (int i = 0; i < 4; i++) {
                ItemStack st = mc.player.getItemBySlot(slots[i]);
                int ry = y + 4 + i * 19;
                int bx = x + 28, bw = 52;
                Draw.roundR(g, bx, ry + 7, bw, 3, 1, 0x40FFFFFF);
                if (st.isEmpty()) { String t = "-"; g.drawString(f, t, x + armorEl.w - 8 - f.width(t), ry + 4, Colors.DIM, false); continue; }
                g.renderItem(st, x + 7, ry);
                int pc = 100;
                if (st.isDamageableItem() && st.getMaxDamage() > 0)
                    pc = (int) ((st.getMaxDamage() - st.getDamageValue()) * 100f / st.getMaxDamage());
                int pcol = pctColor(pc);
                Draw.roundR(g, bx, ry + 7, Math.max(2, bw * pc / 100), 3, 1, pcol);
                String t = pc + "%";
                Draw.text(g, f, t, x + armorEl.w - 8 - Draw.width(f, t, true), ry + 4, pcol, true);
            }
        }

        a = step(hotkeysEl, hotkeys.value ? 1f : 0f, dt);
        if (a > 0.02f) {
            List<Module> hk = new ArrayList<>();
            for (Module m : Modules.all) if (m.key > 0) hk.add(m);
            int nameW = 40;
            for (Module m : hk) nameW = Math.max(nameW, f.width(m.name));
            int rowH = 14, w = Math.max(104, 19 + nameW + 14 + 26), h = 30 + Math.max(1, hk.size()) * rowH + 3;
            hotkeysEl.w = w; hotkeysEl.h = h;
            int x = hotkeysEl.left(), y = hotkeysEl.y;
            Draw.pill(g, x, y, w, h, a);
            Draw.roundR(g, x + 7, y + 6, 16, 16, 4, Draw.alpha(Colors.withAlpha(col, 0x44), a));
            Icons.draw(g, "keys", x + 10, y + 9, Draw.alpha(col, a));
            Draw.text(g, f, "Hotkeys", x + 29, y + 10, Draw.alpha(0xFFFFFFFF, a), true);
            g.fill(x + 8, y + 26, x + w - 8, y + 27, Draw.alpha(0x30FFFFFF, a));
            if (hk.isEmpty()) g.drawString(f, "none bound", x + 10, y + 32, Draw.alpha(Colors.DIM, a), false);
            for (int i = 0; i < hk.size(); i++) {
                Module m = hk.get(i);
                int ry = y + 30 + i * rowH;
                Draw.roundR(g, x + 9, ry + 4, 5, 5, 2, Draw.alpha(m.enabled ? 0xFF7CFF8A : 0xFF9AA0A8, a));
                g.drawString(f, m.name, x + 19, ry + 3, Draw.alpha(0xFFE8EAEE, a), false);
                String kn = Keys.name(m.key);
                int kw = f.width(kn) + 9;
                Draw.roundR(g, x + w - 8 - kw, ry + 1, kw, 11, 5, Draw.alpha(0x34FFFFFF, a));
                g.drawString(f, kn, x + w - 8 - kw + 4, ry + 3, Draw.alpha(0xFFFFFFFF, a), false);
            }
        }

        if (on(mapEl)) drawRegionMap(g, f, mc, col);

        // module list: dark pills with a coloured bar on the right (like the photo)
        if (list.value || !listY.isEmpty()) {
            List<Module> act = new ArrayList<>();
            for (Module m : Modules.all) {
                float am = step(m, (m.enabled && list.value) ? 1f : 0f, dt);
                if (am > 0.02f) act.add(m); else listY.remove(m);
            }
            act.sort(Comparator.comparingInt((Module m) -> -Draw.width(f, m.name, true)));
            int maxW = 40, idx = 0;
            for (Module m : act) {
                float am = fade.getOrDefault(m, 1f);
                float ty = listEl.y + idx * 17f;
                float cy = listY.containsKey(m) ? listY.get(m) : ty;
                cy += (ty - cy) * Math.min(1f, dt * 14f);
                listY.put(m, cy);
                int tw = Draw.width(f, m.name, true), w = tw + 22;
                maxW = Math.max(maxW, w);
                int x = listEl.x - w + (int) ((1f - am) * 16), y = Math.round(cy);
                Draw.roundR(g, x + 1, y + 2, w, 14, 5, Draw.alpha(0x55000000, am));
                Draw.roundR(g, x, y, w, 14, 5, Draw.alpha(0xDC111318, am));
                g.fill(x + 5, y, x + w - 5, y + 1, Draw.alpha(0x2AFFFFFF, am));
                Draw.text(g, f, m.name, x + 7, y + 3, Draw.alpha(0xFFFFFFFF, am), true);
                Draw.roundR(g, x + w - 6, y + 3, 3, 8, 1, Draw.alpha(col, am));
                idx++;
            }
            listEl.w = maxW; listEl.h = Math.max(15, idx * 17);
        }

        // ---------- drag-to-move while chat (T) is open ----------
        if (mc.screen instanceof ChatScreen) {
            double[] cx = new double[1], cy = new double[1];
            int[] ww = new int[1], wh = new int[1];
            GLFW.glfwGetCursorPos(win, cx, cy);
            GLFW.glfwGetWindowSize(win, ww, wh);
            double mx = cx[0] * W / Math.max(1, ww[0]);
            double my = cy[0] * H / Math.max(1, wh[0]);
            if (mL && !wasDown) {
                for (El e : elements) {
                    if (!on(e)) continue;
                    if (mx >= e.left() && mx < e.left() + e.w && my >= e.y && my < e.y + e.h) {
                        dragging = e; offX = (int) mx - e.left(); offY = (int) my - e.y;
                    }
                }
            }
            if (mL && dragging != null) {
                int nl = Math.max(0, Math.min(W - dragging.w, (int) mx - offX));
                dragging.x = dragging.right ? nl + dragging.w : nl;
                dragging.y = Math.max(0, Math.min(H - dragging.h, (int) my - offY));
            }
            if (!mL) dragging = null;
            wasDown = mL;
            for (El e : elements) if (on(e)) Draw.outline(g, e.left() - 1, e.y - 1, e.w + 2, e.h + 2, e == dragging ? 0xFFFFFFFF : col);
            Proj.label(g, "HUD EDIT MODE - drag the elements", W / 2.0, 14, col);
        } else {
            dragging = null;
            wasDown = false;
        }
    }
}
