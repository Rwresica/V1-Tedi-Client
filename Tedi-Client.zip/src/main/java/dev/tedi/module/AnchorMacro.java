package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Right-click a respawn anchor: charges it with glowstone from your hotbar, then switches to another slot and
 * right-clicks again to detonate it. Plain macro - one action per step, no tricks.
 */
public class AnchorMacro extends Module {
    public final Setting.Bool requireTotem = add(new Setting.Bool("Require Offhand Totem", true));
    public final Setting.Num stepDelay = add(new Setting.Num("Step Delay (ticks)", 1, 0, 5, 1));
    public final Setting.Num explodeSlot = add(new Setting.Num("Explode Slot (0=auto)", 0, 0, 9, 1));

    private int stage, timer, prev, glow;
    private boolean lastUse;
    private BlockHitResult hit;

    public AnchorMacro() {
        super("AnchorMacro", "One click: charge + detonate a respawn anchor.", "COMBAT", true);
    }

    @Override public void onDisable() { stage = 0; }

    private int find(Inventory inv, Item item) {
        for (int i = 0; i < 9; i++) if (inv.getItem(i).is(item)) return i;
        return -1;
    }

    private void use(Minecraft mc) {
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hit);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.gameMode == null || mc.level == null) return;
        Inventory inv = mc.player.getInventory();
        boolean down = mc.options.keyUse.isDown();
        boolean edge = down && !lastUse;
        lastUse = down;

        if (stage == 0) {
            if (!edge || mc.screen != null) return;
            HitResult hr = mc.hitResult;
            if (!(hr instanceof BlockHitResult b) || hr.getType() != HitResult.Type.BLOCK) return;
            BlockState st = mc.level.getBlockState(b.getBlockPos());
            if (!st.is(Blocks.RESPAWN_ANCHOR)) return;
            if (requireTotem.value && !mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return;
            glow = find(inv, Items.GLOWSTONE);
            int charge = st.getValue(RespawnAnchorBlock.CHARGE);
            if (glow < 0 && charge == 0) return;
            hit = b;
            prev = inv.getSelectedSlot();
            if (charge == 0) { inv.setSelectedSlot(glow); stage = 1; } else stage = 2;
            timer = stepDelay.i();
            return;
        }
        if (timer-- > 0) return;
        switch (stage) {
            case 1 -> { use(mc); stage = 2; timer = stepDelay.i(); }
            case 2 -> {
                int slot = explodeSlot.i() > 0 ? explodeSlot.i() - 1 : -1;
                if (slot < 0) {
                    slot = prev;
                    if (inv.getItem(slot).is(Items.GLOWSTONE)) {
                        for (int i = 0; i < 9; i++) if (!inv.getItem(i).is(Items.GLOWSTONE)) { slot = i; break; }
                    }
                }
                inv.setSelectedSlot(slot);
                stage = 3; timer = stepDelay.i();
            }
            case 3 -> { use(mc); stage = 4; timer = 1; }
            default -> { inv.setSelectedSlot(prev); stage = 0; }
        }
    }
}
