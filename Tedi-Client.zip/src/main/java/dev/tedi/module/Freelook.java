package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Orbit the camera around your character while your body keeps its aim (so you can still mine). */
public class Freelook extends Module {
    public static Freelook I;
    public final Setting.Num distance = add(new Setting.Num("Distance", 4.0, 1.0, 12.0, 0.5));
    public final Setting.Bool seeThrough = add(new Setting.Bool("See Through Walls", true));
    public final Setting.Bool showTarget = add(new Setting.Bool("Show Mining Target", true));
    public float yaw, pitch;

    public Freelook() {
        super("Freelook", "Look around your character; your aim stays put.", "MISC", true);
        I = this;
    }

    public static boolean active() { return I != null && I.enabled && !Freecam.active(); }

    @Override
    public void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) { enabled = false; return; }
        yaw = mc.player.getYRot();
        pitch = mc.player.getXRot();
    }

    public void look(double dYaw, double dPitch) {
        yaw += (float) (dYaw * 0.15);
        pitch = Mth.clamp(pitch + (float) (dPitch * 0.15), -90f, 90f);
    }

    public Vec3 camPos(Minecraft mc, float pt) {
        Vec3 eye = mc.player.getEyePosition(pt);
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        Vec3 f = new Vec3(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
        double d = distance.value;
        if (!seeThrough.value && mc.level != null) {
            for (double t = 0.2; t <= d; t += 0.1) {
                Vec3 p = eye.subtract(f.scale(t));
                BlockPos bp = BlockPos.containing(p.x, p.y, p.z);
                if (!mc.level.getBlockState(bp).getCollisionShape(mc.level, bp).isEmpty()) {
                    d = Math.max(0.3, t - 0.2);
                    break;
                }
            }
        }
        return eye.subtract(f.scale(d));
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (!showTarget.value || Freecam.active()) return;
        HitResult hr = mc.hitResult;
        if (hr instanceof BlockHitResult b && hr.getType() == HitResult.Type.BLOCK) {
            Proj.box(g, new AABB(b.getBlockPos()), 1.5f, Colors.ACCENT);
        }
    }
}
