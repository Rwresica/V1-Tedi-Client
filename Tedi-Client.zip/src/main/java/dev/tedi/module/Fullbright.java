package dev.tedi.module;

import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Client-side night vision. */
public class Fullbright extends Module {
    public Fullbright() {
        super("Fullbright", "See clearly in the dark.", "RENDER", true);
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null) return;
        MobEffectInstance e = mc.player.getEffect(MobEffects.NIGHT_VISION);
        if (e == null || e.getDuration() < 5000) {
            mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 100000, 0, false, false));
        }
    }

    @Override
    public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.removeEffect(MobEffects.NIGHT_VISION);
    }
}
