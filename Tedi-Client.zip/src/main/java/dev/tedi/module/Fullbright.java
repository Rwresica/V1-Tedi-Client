package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Everything fully lit: maxed gamma (works even if a server strips potion effects) + night vision. */
public class Fullbright extends Module {
    public static Fullbright I;
    public final Setting.Bool gamma = add(new Setting.Bool("Max Gamma", true));
    public final Setting.Bool nightVision = add(new Setting.Bool("Night Vision Effect", true));
    private boolean applied;

    public Fullbright() {
        super("Fullbright", "Everything fully lit, like night vision.", "RENDER", true);
        I = this;
    }

    public static boolean gammaOn() { return I != null && I.enabled && I.gamma.value; }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null) return;
        if (nightVision.value) {
            MobEffectInstance e = mc.player.getEffect(MobEffects.NIGHT_VISION);
            if (e == null || e.getDuration() < 5000) {
                mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 100000, 0, false, false));
            }
            applied = true;
        } else if (applied) {
            mc.player.removeEffect(MobEffects.NIGHT_VISION);
            applied = false;
        }
    }

    @Override
    public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && applied) mc.player.removeEffect(MobEffects.NIGHT_VISION);
        applied = false;
    }
}
