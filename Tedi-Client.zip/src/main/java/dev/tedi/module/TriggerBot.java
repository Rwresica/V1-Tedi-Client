package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Attacks automatically when your crosshair is on a target and your weapon is recharged. */
public class TriggerBot extends Module {
    public final Setting.Bool players = add(new Setting.Bool("Players", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Mobs", false));
    public final Setting.Num cooldown = add(new Setting.Num("Min Cooldown", 0.95, 0.5, 1.0, 0.05));

    public TriggerBot() {
        super("TriggerBot", "Auto-attacks what your crosshair is on.", "COMBAT", true);
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.gameMode == null || mc.screen != null) return;
        if (Freecam.active()) return;
        HitResult hr = mc.hitResult;
        if (!(hr instanceof EntityHitResult ehr)) return;
        Entity t = ehr.getEntity();
        if (t == mc.player || !(t instanceof LivingEntity le) || !le.isAlive()) return;
        boolean isPlayer = t instanceof Player;
        if (isPlayer ? !players.value : !mobs.value) return;
        if (mc.player.getAttackStrengthScale(0f) < cooldown.value) return;
        mc.gameMode.attack(mc.player, t);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }
}
