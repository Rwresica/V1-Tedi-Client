package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Hold attack on a block and the fastest pickaxe / shovel / axe / hoe in your hotbar is selected.
 * No such tool in the hotbar = nothing happens.
 */
public class AutoTool extends Module {
    public final Setting.Bool switchBack = add(new Setting.Bool("Switch Back", true));
    private int prev = -1;

    public AutoTool() {
        super("AutoTool", "Auto-selects the right tool when mining.", "MISC", true);
    }

    private static boolean tool(ItemStack s) {
        return s.is(ItemTags.PICKAXES) || s.is(ItemTags.SHOVELS) || s.is(ItemTags.AXES) || s.is(ItemTags.HOES);
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null || mc.screen != null) return;
        Inventory inv = mc.player.getInventory();
        HitResult hr = mc.hitResult;
        boolean mining = mc.options.keyAttack.isDown() && hr instanceof BlockHitResult && hr.getType() == HitResult.Type.BLOCK;
        if (mining) {
            BlockState st = mc.level.getBlockState(((BlockHitResult) hr).getBlockPos());
            if (st.isAir()) return;
            int cur = inv.getSelectedSlot();
            float bestSpeed = inv.getItem(cur).getDestroySpeed(st);
            int best = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack s = inv.getItem(i);
                if (!tool(s)) continue;
                float sp = s.getDestroySpeed(st);
                if (sp > bestSpeed + 0.01f) { bestSpeed = sp; best = i; }
            }
            if (best >= 0 && bestSpeed > 1.0f) {
                if (prev < 0) prev = cur;
                inv.setSelectedSlot(best);
            }
        } else if (prev >= 0 && !mc.options.keyAttack.isDown()) {
            if (switchBack.value) inv.setSelectedSlot(prev);
            prev = -1;
        }
    }
}
