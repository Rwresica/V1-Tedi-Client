package dev.tedi.module;

/** Always-on badge. Does nothing. */
public class TediClientPlus extends Module {
    public TediClientPlus() {
        super("TediClient+", "Tedi Client Plus - active.", "CLIENT", false);
    }
}
