package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.BaseScan;
import dev.tedi.util.ChunkDraw;
import dev.tedi.util.Notify;
import dev.tedi.util.Proj;
import dev.tedi.util.Toasts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;

import java.util.*;

/**
 * Estimates, per chunk, the probability that players are/were active there (= likely base).
 * Evidence: other players lingering in it, changes seen while you watch, storage, placed blocks,
 * growth/rotated blocks, dug tunnels/shafts, amethyst, spawners. Only chunks above "Min Probability" (default 65%) are flagged.
 */
public class PlayerDetection extends Module {
    public static PlayerDetection I;

    private static class Act {
        final int cx, cz;
        LevelChunk ch;
        int dwell, changes, sig;
        boolean hasSig;
        long heavyTime;
        BaseScan.Blocks_ blocks;
        BaseScan.Tunnels tun;
        BaseScan.Ents ents;
        BaseScan.Growth growth;
        double prob;
        Act(int cx, int cz) { this.cx = cx; this.cz = cz; }
    }

    public final Setting.Bool trackPlayers = add(new Setting.Bool("Track Other Players", true));
    public final Setting.Bool trackChanges = add(new Setting.Bool("Track Changes", true));
    public final Setting.Bool storage = add(new Setting.Bool("Storage Blocks", true));
    public final Setting.Bool playerBlocks = add(new Setting.Bool("Player-made Blocks", true));
    public final Setting.Bool amethyst = add(new Setting.Bool("Grown Amethyst", true));
    public final Setting.Bool spawners = add(new Setting.Bool("Spawners", true));
    public final Setting.Bool growthOn = add(new Setting.Bool("Growth / Rotated Blocks", true));
    public final Setting.Bool underground = add(new Setting.Bool("Underground Analysis", true));
    public final Setting.Num ugDepth = add(new Setting.Num("Underground Depth", 8, 4, 60, 2));
    public final Setting.Num minProb = add(new Setting.Num("Min Probability %", 65, 30, 95, 5));
    public final Setting.Num minYs = add(new Setting.Num("Min Y", -64, -64, 320, 8));
    public final Setting.Num maxYs = add(new Setting.Num("Max Y", 320, -64, 320, 8));
    public final Setting.Num maxShown = add(new Setting.Num("Max Chunks Shown", 12, 1, 50, 1));
    public final Setting.Num alpha = add(new Setting.Num("Alpha", 80, 10, 255, 5));
    public final Setting.Bool labels = add(new Setting.Bool("Labels", true));
    public final Setting.Bool tracers = add(new Setting.Bool("Tracers", false));
    public final Setting.Hue color = add(new Setting.Hue("Color", 30, 0.9, 1.0));
    public final Setting.Bool chatNotify = add(new Setting.Bool("Chat Notification", false));
    public final Setting.Bool discordNotify = add(new Setting.Bool("Discord Notification", false));
    public final Setting.Str webhook = add(new Setting.Str("Webhook", "", 200));
    public final Setting.Num scanSpeed = add(new Setting.Num("Chunks Per Tick", 3, 1, 16, 1));
    public final Setting.Action clear = add(new Setting.Action("Clear Data", () -> { if (I != null) I.reset(); }));

    private final Map<Long, Act> acts = new HashMap<>();
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();
    private final Set<Long> notified = new HashSet<>();
    private List<Act> visible = new ArrayList<>();
    private int timer;

    public PlayerDetection() {
        super("PlayerDetection", "Flags chunks where players are probably active.", "DONUT", true);
        I = this;
    }

    private void reset() { acts.clear(); queue.clear(); notified.clear(); visible = new ArrayList<>(); }
    private static long key(int x, int z) { return (((long) x) << 32) ^ (z & 0xFFFFFFFFL); }
    @Override public void onDisable() { reset(); }

    private double probability(Act a) {
        double s = 0;
        if (trackPlayers.value) s += Math.min(a.dwell / 20.0, 60.0) / 60.0 * 2.0;
        if (trackChanges.value) s += Math.min(a.changes, 5) * 0.8;
        if (a.ents != null) {
            s += Math.min(a.ents.storage(), 20) / 20.0 * 2.5;
            if (a.ents.ugStorage() > 0) s += 0.8;
            s += Math.min(a.ents.spawners(), 3) * 0.4;
        }
        if (a.blocks != null) {
            s += Math.min(a.blocks.pm(), 60) / 60.0 * 1.5;
            s += Math.min(a.blocks.am(), 6) / 6.0 * 1.5;
        }
        if (a.growth != null) s += Math.min(a.growth.score(), 60) / 60.0 * 2.0;
        if (a.tun != null) s += Math.min(a.tun.tunnels(), 6) / 6.0 * 2.0 + Math.min(a.tun.shafts(), 4) / 4.0;
        return 1.0 / (1.0 + Math.exp(-(s - 3.0)));
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        long now = System.currentTimeMillis();

        if (trackPlayers.value) {
            for (AbstractClientPlayer p : mc.level.players()) {
                if (p == mc.player) continue;
                int cx = p.blockPosition().getX() >> 4, cz = p.blockPosition().getZ() >> 4;
                Act a = acts.computeIfAbsent(key(cx, cz), kk -> new Act(cx, cz));
                a.dwell++;
            }
        }

        if (queue.isEmpty()) {
            int r = Math.min(mc.options.getEffectiveRenderDistance(), 32);
            int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
            for (int x = pcx - r; x <= pcx + r; x++)
                for (int z = pcz - r; z <= pcz + r; z++) queue.add(new int[]{x, z});
        }
        int yLo = minYs.i(), yHi = maxYs.i(), depth = ugDepth.i();
        for (int n = 0; n < scanSpeed.i() && !queue.isEmpty(); n++) {
            int[] c = queue.poll();
            long k = key(c[0], c[1]);
            LevelChunk ch = mc.level.getChunkSource().getChunkNow(c[0], c[1]);
            Act a = acts.get(k);
            if (ch == null) {
                if (a != null) { a.ch = null; if (a.dwell == 0) acts.remove(k); }
                continue;
            }
            if (a == null) { a = new Act(c[0], c[1]); acts.put(k, a); }
            boolean fresh = a.ch != ch;
            if (fresh) { a.ch = ch; a.hasSig = false; a.heavyTime = 0; }
            int[] surf = null;
            if (now - a.heavyTime > 45000) {
                surf = BaseScan.surface(ch);
                a.blocks = BaseScan.blocks(ch, amethyst.value, playerBlocks.value, underground.value, yLo, yHi, depth, surf);
                a.tun = underground.value ? BaseScan.tunnels(ch, yLo, yHi, depth, surf) : null;
                a.growth = growthOn.value
                        ? BaseScan.growth(ch, c[0], c[1], yLo, yHi, depth, surf, true, true, true, true, true, true, true) : null;
                a.heavyTime = now;
            }
            if (surf == null) surf = BaseScan.surface(ch);
            a.ents = BaseScan.ents(ch, storage.value, spawners.value, yLo, yHi, depth, surf);
            int sig = a.ents.storage() * 31 + a.ents.other() * 17 + a.ents.spawners() * 7;
            if (trackChanges.value && a.hasSig && !fresh && sig != a.sig) a.changes++;
            a.sig = sig; a.hasSig = true;
            a.prob = probability(a);
        }
        if (++timer % 20 == 0) recompute(mc);
    }

    private void recompute(Minecraft mc) {
        double min = minProb.value / 100.0;
        List<Act> out = new ArrayList<>();
        for (Act a : acts.values()) {
            a.prob = probability(a);
            if (a.prob >= min) out.add(a);
        }
        out.sort(Comparator.comparingDouble((Act a) -> -a.prob));
        visible = out;
        for (Act a : out) {
            if (notified.add(key(a.cx, a.cz))) {
                String msg = "Players likely active at " + (a.cx * 16) + ", " + (a.cz * 16) + " (" + (int) (a.prob * 100) + "%)";
                Toasts.push("Player Activity", (a.cx * 16) + ", " + (a.cz * 16) + "  |  " + (int) (a.prob * 100) + "%", 0xFFFFB454, "alert");
                if (chatNotify.value && mc.player != null) mc.player.displayClientMessage(Component.literal("[Tedi] " + msg), false);
                if (discordNotify.value) Notify.webhook(webhook.value, msg);
            }
        }
    }

    private int[] range(Act a, Minecraft mc) {
        int lo = Integer.MAX_VALUE, hi = Integer.MIN_VALUE;
        if (a.blocks != null && a.blocks.minY() != Integer.MAX_VALUE) { lo = Math.min(lo, a.blocks.minY()); hi = Math.max(hi, a.blocks.maxY()); }
        if (a.ents != null && a.ents.minY() != Integer.MAX_VALUE) { lo = Math.min(lo, a.ents.minY()); hi = Math.max(hi, a.ents.maxY()); }
        if (a.tun != null && a.tun.minY() != Integer.MAX_VALUE) { lo = Math.min(lo, a.tun.minY()); hi = Math.max(hi, a.tun.maxY()); }
        if (a.growth != null && a.growth.minY() != Integer.MAX_VALUE) { lo = Math.min(lo, a.growth.minY()); hi = Math.max(hi, a.growth.maxY()); }
        if (lo == Integer.MAX_VALUE) { int y = (int) mc.player.getY(); return new int[]{y - 8, y + 16}; }
        return new int[]{lo - 4, Math.max(hi + 6, lo + 20)};
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        int shown = 0;
        for (Act a : visible) {
            if (shown++ >= maxShown.i()) break;
            int[] r = range(a, mc);
            double y = Math.floor((r[0] + r[1]) / 2.0);
            ChunkDraw.ring(g, a.cx, a.cz, y, color.rgb(), alpha.i(), color.argb(0xCC));
            if (tracers.value) Proj.tracer(g, a.cx * 16 + 8, y, a.cz * 16 + 8, 1f, color.argb());
            if (labels.value && Proj.project(a.cx * 16 + 8, y + 1.5, a.cz * 16 + 8))
                Proj.label(g, "Players " + (int) (a.prob * 100) + "%", Proj.px, Proj.py, color.argb());
        }
    }
}
