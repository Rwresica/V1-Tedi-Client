package dev.tedi.gui;

import dev.tedi.config.ConfigManager;
import dev.tedi.module.Hud;
import dev.tedi.module.Module;
import dev.tedi.module.Modules;
import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Icons;
import dev.tedi.util.Keys;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Premium-style click GUI: glassy rounded panels, category icons, search, glow toggles, animated everything. */
public class ClickGui extends Screen {
    private static final int ACCENT = Colors.ACCENT, TEXT = 0xFFE9EBEF, DIM = 0xFF8D95A1, BLUE = 0xFF4CC3F0;
    private static final int PANEL = 0xF2131419, SETBG = 0xF40C0D10, FIELD = 0xFF07080A;
    private static final int PW = 134, GAP = 8, Y0 = 34, HEAD = 24, ROWH = 15;
    private static final String[] CATS = {"COMBAT", "MISC", "RENDER", "DONUT", "CLIENT"};
    private static final String[] ICON = {"combat", "misc", "render", "donut", "client"};

    /** Region list that clips everything to the panel body, so scrolled-away rows can't be clicked. */
    private static class ClipList extends ArrayList<Region> {
        int top, bottom;
        @Override public boolean add(Region r) {
            int y1 = Math.max(r.y(), top), y2 = Math.min(r.y() + r.h(), bottom);
            if (y2 <= y1) return false;
            return super.add(new Region(r.x(), y1, r.w(), y2 - y1, r.click(), r.drag()));
        }
    }

    private final ClipList regions = new ClipList();
    private Region dragging;
    private Module bindTarget;
    private Setting.Str editing;
    private String hoverText;
    private String search = "";
    private boolean searching;
    private float S = 1f, openT;
    private final float[] scroll = new float[CATS.length];
    private final int[] contentH = new int[CATS.length];
    private final Map<Object, Float> anim = new HashMap<>();
    private final Map<Module, Integer> setH = new HashMap<>();
    private long lastNano = System.nanoTime();

    public ClickGui() { super(Component.literal("Tedi Client")); }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float dt) {}

    @Override
    public void onClose() {
        ConfigManager.save(ConfigManager.AUTO);
        super.onClose();
    }

    private float anim(Object key, float target, float dt) {
        float v = anim.getOrDefault(key, target);
        v += (target - v) * Math.min(1f, dt * 14f);
        if (Math.abs(target - v) < 0.003f) v = target;
        anim.put(key, v);
        return v;
    }

    private int total() { return CATS.length * PW + (CATS.length - 1) * GAP; }

    private boolean match(Module m) {
        return search.isEmpty() || m.name.toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT));
    }

    @Override
    public void render(GuiGraphics g, int rmx, int rmy, float partial) {
        Font f = Minecraft.getInstance().font;
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNano) / 1e9f);
        lastNano = now;
        openT = Math.min(1f, openT + dt / 0.22f);
        float ease = 1f - (1f - openT) * (1f - openT) * (1f - openT);

        S = Math.max(0.55f, Math.min(1f, (this.width - 16f) / total()));
        int vw = (int) (this.width / S), vh = (int) (this.height / S);
        int mx = (int) (rmx / S), my = (int) (rmy / S);
        regions.clear();
        hoverText = null;

        g.fillGradient(0, 0, this.width, this.height, Draw.alpha(0x8C000000, ease), Draw.alpha(0x3C000000, ease));
        var ps = g.pose();
        ps.pushMatrix();
        ps.scale(S, S);
        float k = 0.95f + 0.05f * ease;
        ps.translate(vw / 2f, vh / 2f);
        ps.scale(k, k);
        ps.translate(-vw / 2f, -vh / 2f);

        int X0 = (vw - total()) / 2;

        // ----- top bar: logo + search -----
        regions.top = 0; regions.bottom = vh;
        int lw = Draw.width(f, "Tedi", true) + Draw.width(f, "Client", true) + 18;
        Draw.shadow(g, X0, 8, lw, 17, 5);
        Draw.roundR(g, X0, 8, lw, 17, 5, PANEL);
        g.fill(X0 + 4, 8, X0 + lw - 4, 9, 0x28FFFFFF);
        Draw.text(g, f, "Tedi", X0 + 9, 13, ACCENT, true);
        Draw.text(g, f, "Client", X0 + 9 + Draw.width(f, "Tedi", true), 13, 0xFFFFFFFF, true);

        int sw = 170, sx = (vw - sw) / 2;
        float sa = anim("search", searching ? 1f : 0f, dt);
        Draw.shadow(g, sx, 8, sw, 17, 5);
        Draw.roundR(g, sx, 8, sw, 17, 5, PANEL);
        if (sa > 0.01f) Draw.outline(g, sx, 8, sw, 17, Draw.alpha(0xFF7FE8FF, sa * 0.55f));
        Icons.draw(g, "search", sx + 7, 12, searching ? ACCENT : DIM);
        String st = search.isEmpty() && !searching ? "Search modules..." : search + (searching && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        g.drawString(f, st, sx + 20, 13, search.isEmpty() && !searching ? 0xFF535A66 : TEXT, false);
        regions.add(new Region(sx, 8, sw, 17, b -> { if (b == 0) { searching = true; editing = null; bindTarget = null; } }, null));

        for (int pi = 0; pi < CATS.length; pi++) {
            int x = X0 + pi * (PW + GAP);
            int bodyTop = Y0 + HEAD, maxBody = Math.max(40, vh - 44 - bodyTop);
            int bodyH = Math.max(8, Math.min(contentH[pi], maxBody));
            float maxScroll = Math.max(0, contentH[pi] - bodyH);
            scroll[pi] = Math.max(0, Math.min(maxScroll, scroll[pi]));
            int panelH = HEAD + bodyH + 3;

            Draw.shadow(g, x, Y0, PW, panelH, 5);
            Draw.roundR(g, x, Y0, PW, panelH, 5, PANEL);
            g.fillGradient(x + 1, Y0 + 1, x + PW - 1, Y0 + HEAD, 0x22FFFFFF, 0x00000000);
            Draw.roundR(g, x + 7, Y0 + 5, 14, 14, 4, 0x337FE8FF);
            Icons.draw(g, ICON[pi], x + 9, Y0 + 7, ACCENT);
            Draw.text(g, f, CATS[pi], x + 27, Y0 + 8, 0xFFFFFFFF, true);
            int count = 0;
            for (Module m : Modules.all) if (m.category.equals(CATS[pi])) count++;
            String cn = String.valueOf(count);
            g.drawString(f, cn, x + PW - 9 - f.width(cn), Y0 + 8, DIM, false);
            Draw.fadeLine(g, x + 6, Y0 + HEAD - 1, PW - 12, 0xFF7FE8FF);

            regions.top = bodyTop; regions.bottom = bodyTop + bodyH;
            g.enableScissor(x, bodyTop, x + PW, bodyTop + bodyH);
            int start = bodyTop - (int) scroll[pi];
            int y = start + 2;
            if (CATS[pi].equals("CLIENT")) {
                for (Module m : Modules.all) {
                    if (!m.category.equals("CLIENT") || !match(m)) continue;
                    y = drawModule(g, f, m, x, y, mx, my, dt, bodyTop, bodyTop + bodyH);
                }
                y = actionRow(g, f, x, y, mx, my, dt, "CONFIGS", "Save, load and share configs", bodyTop, bodyTop + bodyH,
                        () -> Minecraft.getInstance().setScreen(new ConfigScreen(this)));
                y = actionRow(g, f, x, y, mx, my, dt, "RESET HUD", "Put every HUD element back", bodyTop, bodyTop + bodyH,
                        () -> { if (Hud.I != null) Hud.I.resetPositions(); });
            } else {
                for (Module m : Modules.all) {
                    if (!m.category.equals(CATS[pi]) || !match(m)) continue;
                    y = drawModule(g, f, m, x, y, mx, my, dt, bodyTop, bodyTop + bodyH);
                }
            }
            g.disableScissor();
            contentH[pi] = y - start + 3;

            if (maxScroll > 0) {
                int kh = Math.max(12, bodyH * bodyH / contentH[pi]);
                int ky = bodyTop + (int) ((bodyH - kh) * (scroll[pi] / maxScroll));
                Draw.roundR(g, x + PW - 3, ky, 2, kh, 1, 0x55FFFFFF);
            }
        }

        // ----- bottom bar -----
        regions.top = 0; regions.bottom = vh;
        int bw = 108, bh = 17, bx = (vw - bw) / 2, by = vh - 27;
        boolean hov = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
        float ha = anim("cfgbtn", hov ? 1f : 0f, dt);
        Draw.shadow(g, bx, by, bw, bh, 5);
        Draw.roundR(g, bx, by, bw, bh, 5, Colors.lerp(PANEL, 0xF22A3540, ha));
        g.fill(bx + 4, by, bx + bw - 4, by + 1, 0x28FFFFFF);
        Draw.text(g, f, "CONFIGS", bx + (bw - Draw.width(f, "CONFIGS", true)) / 2, by + 5, ACCENT, true);
        regions.add(new Region(bx, by, bw, bh, b -> {
            if (b == 0) Minecraft.getInstance().setScreen(new ConfigScreen(this));
        }, null));
        String hint = "RIGHT CLICK = SETTINGS   |   SCROLL = MORE";
        g.drawString(f, hint, 10, vh - 14, 0xFF4F5560, false);

        if (dragging != null && dragging.drag() != null) dragging.drag().accept((double) mx, (double) my);

        if (hoverText != null) {
            String t = hoverText;
            int tw = f.width(t);
            Draw.shadow(g, mx + 10, my + 6, tw + 12, 15, 4);
            Draw.roundR(g, mx + 10, my + 6, tw + 12, 15, 4, 0xF2111216);
            g.fill(mx + 12, my + 6, mx + tw + 20, my + 7, 0x30FFFFFF);
            g.drawString(f, t, mx + 16, my + 10, 0xFFFFFFFF, false);
        }
        ps.popMatrix();
    }

    private int actionRow(GuiGraphics g, Font f, int x, int y, int mx, int my, float dt, String name, String desc, int clipTop, int clipBot, Runnable run) {
        boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROWH && my >= clipTop && my < clipBot;
        float ha = anim(name + "#h", hov ? 1f : 0f, dt);
        if (ha > 0.01f) Draw.roundR(g, x + 3, y, PW - 6, ROWH, 4, Draw.alpha(0x26FFFFFF, ha));
        if (hov) hoverText = desc;
        Draw.text(g, f, name, x + 9, y + 4, TEXT, true);
        g.drawString(f, ">", x + PW - 13, y + 4, Colors.lerp(DIM, ACCENT, ha), false);
        regions.add(new Region(x, y, PW, ROWH, b -> { if (b == 0) run.run(); }, null));
        return y + ROWH;
    }

    private int drawModule(GuiGraphics g, Font f, Module m, int x, int y, int mx, int my, float dt, int clipTop, int clipBot) {
        boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROWH && my >= clipTop && my < clipBot;
        float a = anim(m, m.enabled ? 1f : 0f, dt);
        float ha = anim(m.name + "#h", hov ? 1f : 0f, dt);
        if (ha > 0.01f) Draw.roundR(g, x + 3, y, PW - 6, ROWH, 4, Draw.alpha(0x26FFFFFF, ha));
        if (a > 0.02f) {
            Draw.roundR(g, x + 3, y, PW - 6, ROWH, 4, Draw.alpha(0x1A7FE8FF, a));
            g.fill(x + 1, y + 3, x + 3, y + ROWH - 3, Draw.alpha(ACCENT, a));
        }
        Draw.text(g, f, m.name.toUpperCase(Locale.ROOT), x + 9, y + 4, Colors.lerp(TEXT, ACCENT, a), true);

        int px = x + PW - 27, py = y + 3;
        if (a > 0.05f) Draw.roundR(g, px - 1, py - 1, 22, 11, 6, Draw.alpha(0x287FE8FF, a));
        Draw.roundR(g, px, py, 20, 9, 5, Colors.lerp(0xFF2B2D33, BLUE, a));
        int kx = px + 1 + (int) (a * 11);
        Draw.roundR(g, kx, py + 1, 7, 7, 4, Colors.lerp(0xFFB9BCC2, 0xFFFFFFFF, a));
        float ea = anim(m.name + "#ex", m.expanded ? 1f : 0f, dt);
        if (!m.settings.isEmpty() || m.bindable) {
            g.fill(px - 10, y + 7, px - 5, y + 8, DIM);
            if (ea < 0.5f) g.fill(px - 8, y + 5, px - 7, y + 10, DIM);
        }

        regions.add(new Region(x, y, PW, ROWH, b -> {
            if (b == 0) m.toggle(); else if (b == 1) m.expanded = !m.expanded;
        }, null));
        if (hov) hoverText = m.description;
        y += ROWH;

        if (ea > 0.01f) {
            int full = setH.getOrDefault(m, 0);
            int vis = (ea >= 0.99f && m.expanded) ? full : (int) (full * ea);
            int before = regions.size();
            g.enableScissor(x, y, x + PW, y + Math.max(1, vis));
            int end = drawSettings(g, f, m, x, y);
            setH.put(m, end - y);
            g.disableScissor();
            if (!(ea >= 0.99f && m.expanded)) while (regions.size() > before) regions.remove(regions.size() - 1);
            y += vis;
        }
        return y;
    }

    private static String fit(Font f, String s, int maxW) {
        if (f.width(s) <= maxW) return s;
        while (s.length() > 1 && f.width(".." + s) > maxW) s = s.substring(1);
        return ".." + s;
    }

    private int drawSettings(GuiGraphics g, Font f, Module m, int x, int y) {
        int top = y;
        for (Setting s : m.settings) {
            if (s.hidden) continue;
            if (s instanceof Setting.Bool b) {
                g.fill(x, y, x + PW, y + 14, SETBG);
                int bx = x + 10, by = y + 3;
                Draw.roundR(g, bx, by, 8, 8, 3, 0xFF2B2D33);
                if (b.value) { Draw.roundR(g, bx, by, 8, 8, 3, 0xFF9CD8F5); Draw.roundR(g, bx + 1, by + 1, 6, 6, 2, BLUE); }
                g.drawString(f, b.name.toUpperCase(Locale.ROOT), bx + 13, y + 3, b.value ? TEXT : 0xFFB4BAC4, false);
                regions.add(new Region(x, y, PW, 14, bt -> { if (bt == 0) b.value = !b.value; }, null));
                y += 14;
            } else if (s instanceof Setting.Num n) {
                g.fill(x, y, x + PW, y + 21, SETBG);
                g.drawString(f, n.name.toUpperCase(Locale.ROOT), x + 10, y + 3, 0xFFB4BAC4, false);
                String v = n.text();
                g.drawString(f, v, x + PW - 10 - f.width(v), y + 3, BLUE, false);
                int tx = x + 10, tw = PW - 20, ty = y + 15;
                int fw = (int) (tw * n.ratio());
                Draw.roundR(g, tx, ty, tw, 3, 1, 0xFF30333A);
                Draw.roundR(g, tx, ty, Math.max(3, fw), 3, 1, BLUE);
                g.fill(tx + 1, ty, tx + Math.max(3, fw) - 1, ty + 1, 0x55FFFFFF);
                Draw.roundR(g, tx + fw - 4, ty - 3, 9, 9, 4, 0x337FE8FF);
                Draw.roundR(g, tx + fw - 2, ty - 1, 5, 5, 2, 0xFFFFFFFF);
                regions.add(new Region(x, y + 10, PW, 11, null, (mxx, myy) -> n.setFromRatio((mxx - tx) / (double) tw)));
                y += 21;
            } else if (s instanceof Setting.Hue h) {
                g.fill(x, y, x + PW, y + 15, SETBG);
                g.drawString(f, h.name.toUpperCase(Locale.ROOT), x + 10, y + 4, 0xFFB4BAC4, false);
                Draw.roundR(g, x + PW - 30, y + 3, 20, 9, 4, h.argb());
                Draw.outline(g, x + PW - 30, y + 3, 20, 9, 0x44FFFFFF);
                regions.add(new Region(x, y, PW, 15, bt -> { if (bt == 0) h.open = !h.open; }, null));
                y += 15;
                if (h.open) {
                    g.fill(x, y, x + PW, y + 67, SETBG);
                    Widgets.palette(g, x + 9, y + 3, PW - 18, h, regions);
                    y += 67;
                }
            } else if (s instanceof Setting.Str st) {
                g.fill(x, y, x + PW, y + 26, SETBG);
                g.drawString(f, st.name.toUpperCase(Locale.ROOT), x + 10, y + 3, 0xFFB4BAC4, false);
                Draw.roundR(g, x + 9, y + 13, PW - 18, 11, 3, FIELD);
                if (editing == st) Draw.outline(g, x + 9, y + 13, PW - 18, 11, 0x667FE8FF);
                String txt = fit(f, st.value, PW - 30) + (editing == st && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
                g.drawString(f, txt, x + 13, y + 15, editing == st ? ACCENT : TEXT, false);
                regions.add(new Region(x, y, PW, 26, bt -> { if (bt == 0) { editing = st; bindTarget = null; searching = false; } }, null));
                y += 26;
            } else if (s instanceof Setting.Action ac) {
                g.fill(x, y, x + PW, y + 20, SETBG);
                Draw.roundR(g, x + 9, y + 3, PW - 18, 14, 4, 0xFF1B3340);
                Draw.outline(g, x + 9, y + 3, PW - 18, 14, 0x447FE8FF);
                String t = ac.name.toUpperCase(Locale.ROOT);
                Draw.text(g, f, t, x + (PW - Draw.width(f, t, true)) / 2, y + 6, ACCENT, true);
                regions.add(new Region(x + 9, y + 3, PW - 18, 14, bt -> { if (bt == 0) ac.run.run(); }, null));
                y += 20;
            }
        }
        if (m.bindable) {
            g.fill(x, y, x + PW, y + 17, SETBG);
            g.drawString(f, "KEYBIND", x + 10, y + 5, 0xFFB4BAC4, false);
            int bw = 48, bx = x + PW - 9 - bw;
            boolean listening = bindTarget == m;
            Draw.roundR(g, bx, y + 2, bw, 13, 4, FIELD);
            if (listening) Draw.outline(g, bx, y + 2, bw, 13, ACCENT);
            String t = listening ? "..." : (m.key > 0 ? Keys.name(m.key) : "");
            g.drawString(f, t, bx + (bw - f.width(t)) / 2, y + 5, listening ? ACCENT : TEXT, false);
            regions.add(new Region(bx, y + 2, bw, 13, bt -> {
                if (bt == 0) { bindTarget = m; editing = null; searching = false; }
                else if (bt == 1) m.key = -1;
            }, null));
            y += 17;
        }
        if (y > top) { g.fill(x + 3, top, x + 4, y, 0x447FE8FF); g.fill(x + 3, y - 1, x + PW - 3, y, 0x14FFFFFF); }
        return y;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x() / S, my = e.y() / S;
        int b = e.button();
        editing = null;
        bindTarget = null;
        searching = false;
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (!r.in(mx, my)) continue;
            if (r.drag() != null && b == 0) { dragging = r; r.drag().accept(mx, my); }
            if (r.click() != null) r.click().accept(b);
            return true;
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        double vx = mx / S;
        int X0 = (int) ((this.width / S - total()) / 2);
        for (int pi = 0; pi < CATS.length; pi++) {
            int x = X0 + pi * (PW + GAP);
            if (vx >= x && vx < x + PW) { scroll[pi] -= (float) (sy * 14); return true; }
        }
        return super.mouseScrolled(mx, my, sx, sy);
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (bindTarget != null) {
            if (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) bindTarget.key = -1;
            else if (k != GLFW.GLFW_KEY_ESCAPE) bindTarget.key = k;
            bindTarget = null;
            return true;
        }
        if (searching) {
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE) searching = false;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) search = search.substring(0, search.length() - 1);
            return true;
        }
        if (editing != null) {
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE) editing = null;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !editing.value.isEmpty())
                editing.value = editing.value.substring(0, editing.value.length() - 1);
            else if (k == GLFW.GLFW_KEY_V && (e.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0) {
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) {
                    String joined = editing.value + clip.trim();
                    editing.value = joined.substring(0, Math.min(editing.maxLen, joined.length()));
                }
            }
            return true;
        }
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT || k == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (searching && search.length() < 20) { search += Character.toString(e.codepoint()); return true; }
        if (editing != null && editing.value.length() < editing.maxLen) {
            editing.value += Character.toString(e.codepoint());
            return true;
        }
        return super.charTyped(e);
    }
}
