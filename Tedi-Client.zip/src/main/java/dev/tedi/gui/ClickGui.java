package dev.tedi.gui;

import dev.tedi.config.ConfigManager;
import dev.tedi.module.Hud;
import dev.tedi.module.Module;
import dev.tedi.module.Modules;
import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Icons;
import dev.tedi.util.Keys;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Click GUI: rounded glassy panels, staggered open, smooth scrolling, eased dropdowns, glow toggles. */
public class ClickGui extends Screen {
    private static final int ACCENT = Colors.ACCENT, TEXT = 0xFFE9EBEF, DIM = 0xFF8D95A1, BLUE = 0xFF4CC3F0, SUB = 0xFFB4BAC4;
    private static final int PANEL = 0xF2131419, SETBG = 0xF40C0D10, FIELD = 0xFF07080A, BORDER = 0x26FFFFFF;
    private static final int PW = 152, GAP = 8, Y0 = 34, HEAD = 24, ROWH = 16, R = 12;
    private static final String[] CATS = {"COMBAT", "MISC", "RENDER", "DONUT", "CLIENT"};
    private static final String[] ICON = {"combat", "misc", "render", "donut", "client"};

    /** Region list that clips everything to the panel body, so scrolled-away rows can't be clicked. */
    private static class ClipList extends ArrayList<Region> {
        int top, bottom;
        @Override public boolean add(Region r) {
            int y1 = Math.max(r.y(), top), y2 = Math.min(r.y() + r.h(), bottom);
            if (y2 <= y1) return false;
            return super.add(new Region(r.x(), y1, r.w(), y2 - y1, r.click(), r.drag()));
        }
    }

    private final ClipList regions = new ClipList();
    private Region dragging;
    private Module bindTarget;
    private Setting.Str editing;
    private String hoverText, tipText = "";
    private String search = "";
    private boolean searching;
    private float S = 1f, openClock, tipA, tipX, tipY;
    private final float[] scroll = new float[CATS.length], scrollT = new float[CATS.length];
    private final int[] contentH = new int[CATS.length];
    private final Map<Object, Float> anim = new HashMap<>();
    private final Map<Module, Integer> setH = new HashMap<>();
    private long lastNano = System.nanoTime();

    public ClickGui() { super(Component.literal("Tedi Client")); }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float dt) {}

    @Override
    public void onClose() {
        ConfigManager.save(ConfigManager.AUTO);
        super.onClose();
    }

    private float anim(Object key, float target, float dt) {
        float v = anim.getOrDefault(key, target);
        v += (target - v) * (1f - (float) Math.exp(-dt * 16.0));
        if (Math.abs(target - v) < 0.003f) v = target;
        anim.put(key, v);
        return v;
    }

    private int total() { return CATS.length * PW + (CATS.length - 1) * GAP; }

    private boolean match(Module m) {
        return search.isEmpty() || m.name.toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT));
    }

    private static String clip(Font f, String s, int maxW) {
        if (Draw.w(f, s) <= maxW) return s;
        while (s.length() > 1 && Draw.w(f, s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    @Override
    public void render(GuiGraphics g, int rmx, int rmy, float partial) {
        Font f = Minecraft.getInstance().font;
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNano) / 1e9f);
        lastNano = now;
        openClock += dt;
        float bgE = Draw.easeOut(openClock / 0.25f);

        S = Math.max(0.55f, Math.min(1f, (this.width - 16f) / total()));
        int vw = (int) (this.width / S), vh = (int) (this.height / S);
        int mx = (int) (rmx / S), my = (int) (rmy / S);
        regions.clear();
        hoverText = null;

        g.fillGradient(0, 0, this.width, this.height, Draw.alpha(0x8C000000, bgE), Draw.alpha(0x3C000000, bgE));
        var ps = g.pose();
        ps.pushMatrix();
        ps.scale(S, S);

        int X0 = (vw - total()) / 2;
        float ks = 1f - (float) Math.exp(-dt * 18.0);

        // ----- top bar: logo + search -----
        regions.top = 0; regions.bottom = vh;
        float topE = Draw.easeOut(openClock / 0.22f);
        int topOff = (int) ((1f - topE) * -12);
        int lw = Draw.width(f, "Tedi", true) + Draw.width(f, "Client", true) + 20;
        Draw.panel(g, X0, 8 + topOff, lw, 18, 9, PANEL, BORDER, 1f);
        Draw.text(g, f, "Tedi", X0 + 10, 13 + topOff, ACCENT, true);
        Draw.text(g, f, "Client", X0 + 10 + Draw.width(f, "Tedi", true), 13 + topOff, 0xFFFFFFFF, true);

        int sw = 176, sx = (vw - sw) / 2;
        float sa = anim("search", searching ? 1f : 0f, dt);
        Draw.panel(g, sx, 8 + topOff, sw, 18, 9, PANEL, Colors.lerp(BORDER, 0x887FE8FF, sa), 1f);
        Icons.draw(g, "search", sx + 8, 12 + topOff, Colors.lerp(DIM, ACCENT, sa));
        String st = search.isEmpty() && !searching ? "Search modules..." : search + (searching && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        Draw.str(g, f, st, sx + 22, 13 + topOff, search.isEmpty() && !searching ? 0xFF535A66 : TEXT, false);
        regions.add(new Region(sx, 8, sw, 18, b -> { if (b == 0) { searching = true; editing = null; bindTarget = null; } }, null));

        for (int pi = 0; pi < CATS.length; pi++) {
            int x = X0 + pi * (PW + GAP);
            float pe = Draw.easeOut((openClock - pi * 0.05f) / 0.26f);
            int off = (int) ((1f - pe) * 18);
            int bodyTop = Y0 + HEAD, maxBody = Math.max(40, vh - 46 - bodyTop);
            int bodyH = Math.max(8, Math.min(contentH[pi], maxBody));
            float maxScroll = Math.max(0, contentH[pi] - bodyH);
            scrollT[pi] = Math.max(0, Math.min(maxScroll, scrollT[pi]));
            scroll[pi] += (scrollT[pi] - scroll[pi]) * ks;
            if (Math.abs(scrollT[pi] - scroll[pi]) < 0.25f) scroll[pi] = scrollT[pi];
            int panelH = HEAD + bodyH + 3;
            if (pe < 0.02f) continue;

            ps.pushMatrix();
            ps.translate(0f, off);
            Draw.panel(g, x, Y0, PW, panelH, R, PANEL, BORDER, 1f);
            Draw.roundR(g, x + 7, Y0 + 5, 15, 15, 5, 0x337FE8FF);
            Icons.draw(g, ICON[pi], x + 10, Y0 + 8, ACCENT);
            Draw.text(g, f, CATS[pi], x + 28, Y0 + 8, 0xFFFFFFFF, true);
            int count = 0;
            for (Module m : Modules.all) if (m.category.equals(CATS[pi])) count++;
            String cn = String.valueOf(count);
            Draw.str(g, f, cn, x + PW - 10 - Draw.w(f, cn), Y0 + 8, DIM, false);
            g.fillGradient(x + 2, Y0 + 1, x + PW - 2, Y0 + HEAD + 4, 0x147FE8FF, 0x00000000);
            Draw.shimmer(g, x + 8, Y0 + HEAD - 1, PW - 16, 0xFF7FE8FF, (System.currentTimeMillis() % 100000) / 1000f + pi * 0.45f);

            regions.top = bodyTop + off; regions.bottom = bodyTop + bodyH + off;
            g.enableScissor(x, bodyTop, x + PW, bodyTop + bodyH);
            int start = bodyTop - Math.round(scroll[pi]);
            int y = start + 3;
            if (CATS[pi].equals("CLIENT")) {
                for (Module m : Modules.all) {
                    if (!m.category.equals("CLIENT") || !match(m)) continue;
                    y = drawModule(g, f, m, x, y, mx, my - off, dt, bodyTop, bodyTop + bodyH);
                }
                y = actionRow(g, f, x, y, mx, my - off, dt, "CONFIGS", "Save, load and share configs", bodyTop, bodyTop + bodyH,
                        () -> Minecraft.getInstance().setScreen(new ConfigScreen(this)));
                y = actionRow(g, f, x, y, mx, my - off, dt, "RESET HUD", "Put every HUD element back", bodyTop, bodyTop + bodyH,
                        () -> { if (Hud.I != null) Hud.I.resetPositions(); });
            } else {
                for (Module m : Modules.all) {
                    if (!m.category.equals(CATS[pi]) || !match(m)) continue;
                    y = drawModule(g, f, m, x, y, mx, my - off, dt, bodyTop, bodyTop + bodyH);
                }
            }
            g.disableScissor();
            contentH[pi] = y - start + 4;

            if (maxScroll > 0) {
                int kh = Math.max(14, bodyH * bodyH / contentH[pi]);
                int ky = bodyTop + (int) ((bodyH - kh) * (scroll[pi] / maxScroll));
                Draw.roundR(g, x + PW - 4, ky, 2, kh, 1, 0x55FFFFFF);
            }
            ps.popMatrix();
        }

        // ----- bottom bar -----
        regions.top = 0; regions.bottom = vh;
        int bw = 112, bh = 18, bx = (vw - bw) / 2, by = vh - 28;
        boolean hov = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
        float ha = anim("cfgbtn", hov ? 1f : 0f, dt);
        float botE = Draw.easeOut((openClock - 0.2f) / 0.25f);
        int botOff = (int) ((1f - botE) * 14);
        Draw.panel(g, bx, by + botOff, bw, bh, 9, Colors.lerp(PANEL, 0xF22A3540, ha), Colors.lerp(BORDER, 0x667FE8FF, ha), 1f);
        Draw.text(g, f, "CONFIGS", bx + (bw - Draw.width(f, "CONFIGS", true)) / 2, by + 5 + botOff, ACCENT, true);
        regions.add(new Region(bx, by, bw, bh, b -> {
            if (b == 0) Minecraft.getInstance().setScreen(new ConfigScreen(this));
        }, null));

        if (dragging != null && dragging.drag() != null) dragging.drag().accept((double) mx, (double) my);

        // tooltip: fades + glides after the cursor
        if (hoverText != null) tipText = hoverText;
        tipA += ((hoverText != null ? 1f : 0f) - tipA) * (1f - (float) Math.exp(-dt * 14.0));
        tipX += ((mx + 14) - tipX) * (1f - (float) Math.exp(-dt * 22.0));
        tipY += ((my + 8) - tipY) * (1f - (float) Math.exp(-dt * 22.0));
        if (tipA > 0.03f && !tipText.isEmpty()) {
            int tw = Draw.w(f, tipText);
            int tx = Math.round(tipX), ty = Math.round(tipY);
            Draw.panel(g, tx, ty, tw + 14, 16, 8, 0xF2111216, 0x33FFFFFF, tipA);
            Draw.str(g, f, tipText, tx + 7, ty + 4, Draw.alpha(0xFFFFFFFF, tipA), false);
        }
        ps.popMatrix();
    }

    private final Map<Module, Object[]> modKeys = new HashMap<>();
    private final Map<String, Object> rowKeys = new HashMap<>();

    private Object[] keys(Module m) {
        Object[] k = modKeys.get(m);
        if (k == null) { k = new Object[]{new Object(), new Object()}; modKeys.put(m, k); }
        return k;
    }

    private Object rowKey(String name) {
        Object k = rowKeys.get(name);
        if (k == null) { k = new Object(); rowKeys.put(name, k); }
        return k;
    }

    private int actionRow(GuiGraphics g, Font f, int x, int y, int mx, int my, float dt, String name, String desc, int clipTop, int clipBot, Runnable run) {
        if (y + ROWH < clipTop || y > clipBot) return y + ROWH;          // off-screen: don't draw
        boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROWH && my >= clipTop && my < clipBot;
        float ha = anim(rowKey(name), hov ? 1f : 0f, dt);
        if (ha > 0.01f) Draw.roundR(g, x + 4, y, PW - 8, ROWH, 6, Draw.alpha(0x26FFFFFF, ha));
        if (hov) hoverText = desc;
        Draw.text(g, f, name, x + 10, y + 4, TEXT, true);
        Draw.str(g, f, ">", x + PW - 14, y + 4, Colors.lerp(DIM, ACCENT, ha), false);
        regions.add(new Region(x, y, PW, ROWH, b -> { if (b == 0) run.run(); }, null));
        return y + ROWH;
    }

    private int drawModule(GuiGraphics g, Font f, Module m, int x, int y, int mx, int my, float dt, int clipTop, int clipBot) {
        Object[] k = keys(m);
        float a = anim(m, m.enabled ? 1f : 0f, dt);
        float ea = anim(k[1], m.expanded ? 1f : 0f, dt);
        int full = setH.getOrDefault(m, 0);
        boolean open = ea >= 0.99f && m.expanded;
        int vis = ea > 0.01f ? (open ? full : (int) (full * Draw.smooth(ea))) : 0;

        boolean rowVisible = y + ROWH > clipTop && y < clipBot;
        if (rowVisible) {
            boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROWH && my >= clipTop && my < clipBot;
            float ha = anim(k[0], hov ? 1f : 0f, dt);
            if (ha > 0.01f) Draw.roundR(g, x + 4, y, PW - 8, ROWH, 6, Draw.alpha(0x26FFFFFF, ha));
            if (a > 0.02f) {
                Draw.roundR(g, x + 4, y, PW - 8, ROWH, 6, Draw.alpha(0x1A7FE8FF, a));
                Draw.roundR(g, x + 2, y + 3, 2, ROWH - 6, 1, Draw.alpha(ACCENT, a));
            }
            Draw.text(g, f, clip(f, m.name, PW - 46), x + 10, y + 4, Colors.lerp(TEXT, ACCENT, a), true);

            int px = x + PW - 29, py = y + 3;
            if (a > 0.05f) Draw.roundR(g, px - 1, py - 1, 24, 12, 6, Draw.alpha(0x287FE8FF, a), false);
            Draw.roundR(g, px, py, 22, 10, 5, Colors.lerp(0xFF2B2D33, BLUE, a));
            int kx = px + 1 + (int) (a * 12);
            Draw.roundR(g, kx, py + 1, 8, 8, 4, Colors.lerp(0xFFB9BCC2, 0xFFFFFFFF, a));
            if (!m.settings.isEmpty() || m.bindable) {
                g.fill(px - 10, y + 8, px - 5, y + 9, DIM);
                if (ea < 0.5f) g.fill(px - 8, y + 6, px - 7, y + 11, DIM);
            }
            regions.add(new Region(x, y, PW, ROWH, b -> {
                if (b == 0) m.toggle(); else if (b == 1) m.expanded = !m.expanded;
            }, null));
            if (hov) hoverText = m.description;
        }
        y += ROWH;

        if (ea > 0.01f) {
            int top = y, bottom = y + Math.max(1, vis);
            boolean areaVisible = bottom > clipTop && top < clipBot;
            if (areaVisible || full == 0) {
                int before = regions.size();
                g.enableScissor(x, y, x + PW, bottom);
                int end = drawSettings(g, f, m, x, y, dt, Math.max(clipTop, top), Math.min(clipBot, bottom));
                setH.put(m, end - y);
                g.disableScissor();
                if (!open) while (regions.size() > before) regions.remove(regions.size() - 1);
            }
            y += vis;
        }
        return y;
    }

    private static String fit(Font f, String s, int maxW) {
        if (Draw.w(f, s) <= maxW) return s;
        while (s.length() > 1 && Draw.w(f, ".." + s) > maxW) s = s.substring(1);
        return ".." + s;
    }

    /** Draws a module's settings. Rows outside [visTop, visBot] are only measured, not drawn (saves a lot of fills). */
    private int drawSettings(GuiGraphics g, Font f, Module m, int x, int y, float dt, int visTop, int visBot) {
        int top = y;
        for (Setting s : m.settings) {
            if (s.hidden) continue;
            if (s instanceof Setting.Bool b) {
                boolean v = y + 15 > visTop && y < visBot;
                if (v) {
                    g.fill(x, y, x + PW, y + 15, SETBG);
                    float ca = anim(b, b.value ? 1f : 0f, dt);
                    int bx = x + 11, by = y + 3;
                    Draw.roundR(g, bx, by, 9, 9, 3, Colors.lerp(0xFF2B2D33, 0xFF9CD8F5, ca));
                    if (ca > 0.02f) Draw.roundR(g, bx + 1, by + 1, 7, 7, 2, Draw.alpha(BLUE, ca));
                    Draw.str(g, f, clip(f, b.name, PW - 38), bx + 14, y + 4, Colors.lerp(SUB, TEXT, ca), false);
                    regions.add(new Region(x, y, PW, 15, bt -> { if (bt == 0) b.value = !b.value; }, null));
                }
                y += 15;
            } else if (s instanceof Setting.Num n) {
                boolean v = y + 22 > visTop && y < visBot;
                if (v) {
                    g.fill(x, y, x + PW, y + 22, SETBG);
                    String val = n.text();
                    Draw.str(g, f, clip(f, n.name, PW - 28 - Draw.w(f, val)), x + 11, y + 3, SUB, false);
                    Draw.str(g, f, val, x + PW - 11 - Draw.w(f, val), y + 3, BLUE, false);
                    int tx = x + 11, tw = PW - 22, ty = y + 16;
                    int fw = (int) (tw * n.ratio());
                    Draw.roundR(g, tx, ty, tw, 3, 1, 0xFF30333A);
                    Draw.roundR(g, tx, ty, Math.max(3, fw), 3, 1, BLUE);
                    g.fill(tx + 1, ty, tx + Math.max(3, fw) - 1, ty + 1, 0x55FFFFFF);
                    Draw.roundR(g, tx + fw - 4, ty - 3, 9, 9, 4, 0x337FE8FF, false);
                    Draw.roundR(g, tx + fw - 2, ty - 1, 5, 5, 2, 0xFFFFFFFF);
                    regions.add(new Region(x, y + 10, PW, 12, null, (mxx, myy) -> n.setFromRatio((mxx - tx) / (double) tw)));
                }
                y += 22;
            } else if (s instanceof Setting.Hue h) {
                boolean v = y + 16 > visTop && y < visBot;
                if (v) {
                    g.fill(x, y, x + PW, y + 16, SETBG);
                    Draw.str(g, f, clip(f, h.name, PW - 50), x + 11, y + 4, SUB, false);
                    Draw.roundR(g, x + PW - 33, y + 2, 23, 12, 6, 0x22FFFFFF, false);
                    Draw.roundR(g, x + PW - 32, y + 3, 21, 10, 5, h.argb());
                    regions.add(new Region(x, y, PW, 16, bt -> { if (bt == 0) h.open = !h.open; }, null));
                }
                y += 16;
                if (h.open) {
                    if (y + 67 > visTop && y < visBot) {
                        g.fill(x, y, x + PW, y + 67, SETBG);
                        Widgets.palette(g, x + 10, y + 3, PW - 20, h, regions);
                    }
                    y += 67;
                }
            } else if (s instanceof Setting.Str st) {
                boolean v = y + 27 > visTop && y < visBot;
                if (v) {
                    g.fill(x, y, x + PW, y + 27, SETBG);
                    Draw.str(g, f, clip(f, st.name, PW - 22), x + 11, y + 3, SUB, false);
                    Draw.roundR(g, x + 10, y + 13, PW - 20, 12, 4, FIELD);
                    if (editing == st) Draw.outline(g, x + 10, y + 13, PW - 20, 12, 0x667FE8FF);
                    String txt = fit(f, st.value, PW - 34) + (editing == st && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
                    Draw.str(g, f, txt, x + 14, y + 16, editing == st ? ACCENT : TEXT, false);
                    regions.add(new Region(x, y, PW, 27, bt -> { if (bt == 0) { editing = st; bindTarget = null; searching = false; } }, null));
                }
                y += 27;
            } else if (s instanceof Setting.Action ac) {
                boolean v = y + 21 > visTop && y < visBot;
                if (v) {
                    g.fill(x, y, x + PW, y + 21, SETBG);
                    Draw.roundR(g, x + 10, y + 3, PW - 20, 15, 6, 0xFF1B3340);
                    Draw.outline(g, x + 11, y + 4, PW - 22, 13, 0x337FE8FF);
                    String t = ac.name;
                    Draw.text(g, f, t, x + (PW - Draw.width(f, t, true)) / 2, y + 7, ACCENT, true);
                    regions.add(new Region(x + 10, y + 3, PW - 20, 15, bt -> { if (bt == 0) ac.run.run(); }, null));
                }
                y += 21;
            }
        }
        if (m.bindable) {
            boolean v = y + 18 > visTop && y < visBot;
            if (v) {
                g.fill(x, y, x + PW, y + 18, SETBG);
                Draw.str(g, f, "Keybind", x + 11, y + 5, SUB, false);
                int bw = 50, bx = x + PW - 10 - bw;
                boolean listening = bindTarget == m;
                Draw.roundR(g, bx, y + 2, bw, 14, 5, FIELD);
                if (listening) Draw.outline(g, bx, y + 2, bw, 14, ACCENT);
                String t = listening ? "..." : (m.key > 0 ? Keys.name(m.key) : "");
                Draw.str(g, f, t, bx + (bw - Draw.w(f, t)) / 2, y + 5, listening ? ACCENT : TEXT, false);
                regions.add(new Region(bx, y + 2, bw, 14, bt -> {
                    if (bt == 0) { bindTarget = m; editing = null; searching = false; }
                    else if (bt == 1) m.key = -1;
                }, null));
            }
            y += 18;
        }
        if (y > top) { g.fill(x + 4, top, x + 5, y, 0x447FE8FF); g.fill(x + 4, y - 1, x + PW - 4, y, 0x14FFFFFF); }
        return y;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x() / S, my = e.y() / S;
        int b = e.button();
        editing = null;
        bindTarget = null;
        searching = false;
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (!r.in(mx, my)) continue;
            if (r.drag() != null && b == 0) { dragging = r; r.drag().accept(mx, my); }
            if (r.click() != null) r.click().accept(b);
            return true;
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        double vx = mx / S;
        int X0 = (int) ((this.width / S - total()) / 2);
        for (int pi = 0; pi < CATS.length; pi++) {
            int x = X0 + pi * (PW + GAP);
            if (vx >= x && vx < x + PW) { scrollT[pi] -= (float) (sy * 22); return true; }
        }
        return super.mouseScrolled(mx, my, sx, sy);
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (bindTarget != null) {
            if (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) bindTarget.key = -1;
            else if (k != GLFW.GLFW_KEY_ESCAPE) bindTarget.key = k;
            bindTarget = null;
            return true;
        }
        if (searching) {
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE) searching = false;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) search = search.substring(0, search.length() - 1);
            return true;
        }
        if (editing != null) {
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE) editing = null;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !editing.value.isEmpty())
                editing.value = editing.value.substring(0, editing.value.length() - 1);
            else if (k == GLFW.GLFW_KEY_V && (e.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0) {
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) {
                    String joined = editing.value + clip.trim();
                    editing.value = joined.substring(0, Math.min(editing.maxLen, joined.length()));
                }
            }
            return true;
        }
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT || k == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (searching && search.length() < 20) { search += Character.toString(e.codepoint()); return true; }
        if (editing != null && editing.value.length() < editing.maxLen) {
            editing.value += Character.toString(e.codepoint());
            return true;
        }
        return super.charTyped(e);
    }
}
