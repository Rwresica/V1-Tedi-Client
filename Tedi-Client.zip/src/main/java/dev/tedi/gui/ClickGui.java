package dev.tedi.gui;

import dev.tedi.config.ConfigManager;
import dev.tedi.module.Module;
import dev.tedi.module.Modules;
import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

public class ClickGui extends Screen {
    private static final int ACCENT = Colors.ACCENT, TEXT = Colors.TEXT, DIM = Colors.DIM;
    private static final int PANEL = 0xF0111720, ROW = 0xD8141A22, ROW_HOVER = 0xD81C2530, TRACK = 0xFF2A323C, FIELD = 0xFF0A0D12;
    private static final int PW = 152, X0 = 24, Y0 = 34, GAP = 10, HEAD = 18, ROWH = 17;

    private record Region(int x, int y, int w, int h, IntConsumer click, DoubleConsumer drag) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private final List<Region> regions = new ArrayList<>();
    private Region dragging;
    private Module bindTarget, hoverMod;
    private Setting.Str editing;

    private final Setting.Str cfgName = new Setting.Str("Config Name", "default");
    private List<String> configs = new ArrayList<>();
    private String status = "";
    private boolean statusOk;
    private long statusTime;

    public ClickGui() { super(Component.literal("Tedi Client")); }

    @Override protected void init() { configs = ConfigManager.list(); }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float dt) {}

    @Override
    public void onClose() {
        ConfigManager.save(ConfigManager.AUTO);
        super.onClose();
    }

    private void say(String s, boolean ok) { status = s; statusOk = ok; statusTime = System.currentTimeMillis(); }

    private int header(GuiGraphics g, Font f, int x, int y, String t) {
        Draw.round(g, x, y, PW, HEAD, PANEL);
        g.fillGradient(x + 1, y + 1, x + PW - 1, y + HEAD - 1, 0x2A7FDBFF, 0x00000000);
        g.drawString(f, t, x + (PW - f.width(t)) / 2, y + 5, ACCENT, false);
        g.fill(x + 6, y + HEAD - 1, x + PW - 6, y + HEAD, 0xB07FDBFF);
        return y + HEAD;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float dt) {
        Font f = Minecraft.getInstance().font;
        regions.clear();
        hoverMod = null;
        g.fillGradient(0, 0, this.width, this.height, 0x90000000, 0x50000000);

        String[] cats = {"General", "HUD"};
        for (int pi = 0; pi < cats.length; pi++) {
            int x = X0 + pi * (PW + GAP), y = header(g, f, x, Y0, cats[pi].toUpperCase());
            for (Module m : Modules.all) {
                if (!m.category.equals(cats[pi])) continue;
                boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROWH;
                g.fill(x, y, x + PW, y + ROWH, hov ? ROW_HOVER : ROW);
                if (m.enabled) {
                    g.fillGradient(x, y, x + PW, y + ROWH, 0x2A7FDBFF, 0x107FDBFF);
                    g.fill(x, y, x + 2, y + ROWH, ACCENT);
                }
                g.drawString(f, m.name.toUpperCase(), x + 8, y + 5, m.enabled ? ACCENT : TEXT, false);
                int px = x + PW - 26, py = y + 4;
                Draw.round(g, px, py, 20, 9, m.enabled ? 0xFF2C6E85 : 0xFF38414C);
                int kx = m.enabled ? px + 12 : px + 2;
                Draw.round(g, kx, py + 1, 6, 7, m.enabled ? ACCENT : 0xFFB8C4CF);
                final Module fm = m;
                regions.add(new Region(x, y, PW, ROWH, b -> {
                    if (b == 0) fm.toggle(); else if (b == 1) fm.expanded = !fm.expanded;
                }, null));
                if (hov) hoverMod = m;
                y += ROWH;
                if (m.expanded) y = drawSettings(g, f, m, x, y);
            }
            g.fill(x + 3, y, x + PW - 3, y + 2, 0xB0111720);
        }

        drawConfigPanel(g, f, X0 + 2 * (PW + GAP));

        if (dragging != null && dragging.drag() != null) dragging.drag().accept(mx);

        if (hoverMod != null) {
            int tw = f.width(hoverMod.description);
            Draw.round(g, mx + 8, my + 6, tw + 10, 14, 0xF0111720);
            g.drawString(f, hoverMod.description, mx + 13, my + 10, ACCENT, false);
        }
    }

    private int drawSettings(GuiGraphics g, Font f, Module m, int x, int y) {
        for (Setting s : m.settings) {
            int top = y;
            if (s instanceof Setting.Bool b) {
                g.fill(x, y, x + PW, y + 15, ROW);
                int bx = x + 9, by = y + 3;
                Draw.round(g, bx, by, 9, 9, 0xFF38414C);
                if (b.value) Draw.round(g, bx + 1, by + 1, 7, 7, ACCENT);
                g.drawString(f, b.name.toUpperCase(), bx + 14, y + 4, TEXT, false);
                regions.add(new Region(x, y, PW, 15, bt -> { if (bt == 0) b.value = !b.value; }, null));
                y += 15;
            } else if (s instanceof Setting.Num n) {
                g.fill(x, y, x + PW, y + 23, ROW);
                g.drawString(f, n.name.toUpperCase(), x + 9, y + 3, TEXT, false);
                String v = n.text();
                g.drawString(f, v, x + PW - 9 - f.width(v), y + 3, ACCENT, false);
                int tx = x + 9, tw = PW - 18, ty = y + 17;
                int fw = (int) (tw * n.ratio());
                Draw.round(g, tx, ty, tw, 3, TRACK);
                Draw.round(g, tx, ty, Math.max(2, fw), 3, ACCENT);
                Draw.round(g, tx + fw - 2, ty - 2, 5, 7, 0xFFFFFFFF);
                regions.add(new Region(x, y + 11, PW, 12, null, mxx -> n.setFromRatio((mxx - tx) / (double) tw)));
                y += 23;
            } else if (s instanceof Setting.Hue h) {
                g.fill(x, y, x + PW, y + 23, ROW);
                g.drawString(f, h.name.toUpperCase(), x + 9, y + 3, TEXT, false);
                Draw.round(g, x + PW - 23, y + 2, 14, 9, h.argb());
                int tx = x + 9, tw = PW - 18, ty = y + 16;
                for (int i = 0; i < tw; i += 2)
                    g.fill(tx + i, ty, tx + Math.min(i + 2, tw), ty + 4, 0xFF000000 | Colors.hsv(i / (double) tw * 360.0));
                int kx = tx + (int) (tw * h.hue / 360.0);
                Draw.round(g, kx - 2, ty - 2, 5, 8, 0xFFFFFFFF);
                regions.add(new Region(x, y + 11, PW, 12, null, mxx -> h.hue = Math.max(0, Math.min(360, (mxx - tx) / (double) tw * 360.0))));
                y += 23;
            } else if (s instanceof Setting.Str st) {
                g.fill(x, y, x + PW, y + 27, ROW);
                g.drawString(f, st.name.toUpperCase(), x + 9, y + 3, TEXT, false);
                Draw.round(g, x + 9, y + 13, PW - 18, 11, FIELD);
                String shown = st.value + (editing == st && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
                g.drawString(f, shown, x + 13, y + 15, editing == st ? ACCENT : TEXT, false);
                regions.add(new Region(x, y, PW, 27, bt -> { if (bt == 0) { editing = st; bindTarget = null; } }, null));
                y += 27;
            }
            g.fill(x, top, x + 1, y, 0x887FDBFF);
        }
        if (m.bindable) {
            g.fill(x, y, x + PW, y + 17, ROW);
            g.drawString(f, "KEYBIND", x + 9, y + 5, TEXT, false);
            int bw = 48, bx = x + PW - 9 - bw;
            boolean listening = bindTarget == m;
            Draw.round(g, bx, y + 2, bw, 13, FIELD);
            if (listening) Draw.outline(g, bx, y + 2, bw, 13, ACCENT);
            String t = listening ? "..." : (m.key > 0 ? keyName(m.key) : "");
            g.drawString(f, t, bx + (bw - f.width(t)) / 2, y + 5, listening ? ACCENT : TEXT, false);
            regions.add(new Region(bx, y + 2, bw, 13, bt -> {
                if (bt == 0) { bindTarget = m; editing = null; }
                else if (bt == 1) m.key = -1;
            }, null));
            g.fill(x, y, x + 1, y + 17, 0x887FDBFF);
            y += 17;
        }
        return y;
    }

    private void drawConfigPanel(GuiGraphics g, Font f, int x) {
        int y = header(g, f, x, Y0, "CONFIGS");
        // name field
        g.fill(x, y, x + PW, y + 28, ROW);
        g.drawString(f, "CONFIG NAME", x + 9, y + 3, TEXT, false);
        Draw.round(g, x + 9, y + 14, PW - 18, 11, FIELD);
        String shown = cfgName.value + (editing == cfgName && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        g.drawString(f, shown, x + 13, y + 16, editing == cfgName ? ACCENT : TEXT, false);
        regions.add(new Region(x, y, PW, 28, bt -> { if (bt == 0) { editing = cfgName; bindTarget = null; } }, null));
        y += 28;

        // buttons
        g.fill(x, y, x + PW, y + 20, ROW);
        int bw = (PW - 18 - 8) / 3;
        String[] names = {"SAVE", "LOAD", "DELETE"};
        for (int i = 0; i < 3; i++) {
            int bx = x + 9 + i * (bw + 4);
            Draw.round(g, bx, y + 3, bw, 14, 0xFF1F3A47);
            Draw.outline(g, bx, y + 3, bw, 14, 0x887FDBFF);
            g.drawString(f, names[i], bx + (bw - f.width(names[i])) / 2, y + 7, ACCENT, false);
            final int idx = i;
            regions.add(new Region(bx, y + 3, bw, 14, bt -> { if (bt == 0) configAction(idx); }, null));
        }
        y += 20;

        // status
        if (!status.isEmpty() && System.currentTimeMillis() - statusTime < 4000) {
            g.fill(x, y, x + PW, y + 14, ROW);
            g.drawString(f, status, x + 9, y + 3, statusOk ? 0xFF7CFF8A : 0xFFFF6B6B, false);
            y += 14;
        }

        // list
        g.fill(x, y, x + PW, y + 14, ROW);
        g.drawString(f, "SAVED CONFIGS", x + 9, y + 3, DIM, false);
        y += 14;
        if (configs.isEmpty()) {
            g.fill(x, y, x + PW, y + 15, ROW);
            g.drawString(f, "none yet", x + 9, y + 4, DIM, false);
            y += 15;
        }
        for (int i = 0; i < Math.min(configs.size(), 14); i++) {
            String c = configs.get(i);
            boolean sel = c.equals(ConfigManager.clean(cfgName.value));
            g.fill(x, y, x + PW, y + 15, sel ? ROW_HOVER : ROW);
            if (sel) g.fill(x, y, x + 2, y + 15, ACCENT);
            g.drawString(f, c, x + 9, y + 4, sel ? ACCENT : TEXT, false);
            regions.add(new Region(x, y, PW, 15, bt -> { if (bt == 0) { cfgName.value = c; editing = null; } }, null));
            y += 15;
        }
        g.fill(x + 3, y, x + PW - 3, y + 2, 0xB0111720);
    }

    private void configAction(int idx) {
        String name = ConfigManager.clean(cfgName.value);
        switch (idx) {
            case 0 -> { boolean ok = ConfigManager.save(name); say(ok ? "Saved " + name : "Save failed", ok); }
            case 1 -> { boolean ok = ConfigManager.load(name); say(ok ? "Loaded " + name : "No config named " + name, ok); }
            default -> { boolean ok = ConfigManager.delete(name); say(ok ? "Deleted " + name : "No config named " + name, ok); }
        }
        configs = ConfigManager.list();
    }

    private static String keyName(int k) {
        if (k <= 0) return "";
        if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F12) return "F" + (k - GLFW.GLFW_KEY_F1 + 1);
        switch (k) {
            case GLFW.GLFW_KEY_SPACE: return "SPACE";
            case GLFW.GLFW_KEY_TAB: return "TAB";
            case GLFW.GLFW_KEY_ENTER: return "ENTER";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LALT";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCTRL";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RALT";
            case GLFW.GLFW_KEY_UP: return "UP";
            case GLFW.GLFW_KEY_DOWN: return "DOWN";
            case GLFW.GLFW_KEY_LEFT: return "LEFT";
            case GLFW.GLFW_KEY_RIGHT: return "RIGHT";
            default: break;
        }
        String n = null;
        try { n = GLFW.glfwGetKeyName(k, 0); } catch (Throwable ignored) {}
        return n != null ? n.toUpperCase() : "K" + k;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        int b = e.button();
        editing = null;
        bindTarget = null;
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (!r.in(mx, my)) continue;
            if (r.drag() != null && b == 0) { dragging = r; r.drag().accept(mx); }
            if (r.click() != null) r.click().accept(b);
            return true;
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        return super.mouseReleased(e);
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (bindTarget != null) {
            if (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) bindTarget.key = -1;
            else if (k != GLFW.GLFW_KEY_ESCAPE) bindTarget.key = k;
            bindTarget = null;
            return true;
        }
        if (editing != null) {
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE) editing = null;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !editing.value.isEmpty())
                editing.value = editing.value.substring(0, editing.value.length() - 1);
            return true;
        }
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT || k == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (editing != null && editing.value.length() < 20) {
            editing.value += Character.toString(e.codepoint());
            return true;
        }
        return super.charTyped(e);
    }
}
