package dev.tedi.gui;

import dev.tedi.config.ConfigManager;
import dev.tedi.module.Module;
import dev.tedi.module.Modules;
import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ClickGui extends Screen {
    private static final int ACCENT = Colors.ACCENT, TEXT = Colors.TEXT, DIM = Colors.DIM;
    private static final int PANEL = 0xEB1A1B1F, SETBG = 0xF0121317, FIELD = 0xFF0B0C0F;
    private static final int PW = 146, GAP = 8, X0 = 28, Y0 = 28, HEAD = 17, ROWH = 15;
    private static final String[] CATS = {"COMBAT", "MISC", "RENDER"};

    /** Region list that clips everything to the panel body, so scrolled-away rows can't be clicked. */
    private static class ClipList extends ArrayList<Region> {
        int top, bottom;
        @Override public boolean add(Region r) {
            int y1 = Math.max(r.y(), top), y2 = Math.min(r.y() + r.h(), bottom);
            if (y2 <= y1) return false;
            return super.add(new Region(r.x(), y1, r.w(), y2 - y1, r.click(), r.drag()));
        }
    }

    private final ClipList regions = new ClipList();
    private Region dragging;
    private Module bindTarget, hoverMod;
    private Setting.Str editing;
    private final float[] scroll = new float[CATS.length];
    private final int[] contentH = new int[CATS.length];
    private final Map<Object, Float> anim = new HashMap<>();
    private long lastNano = System.nanoTime();

    public ClickGui() { super(Component.literal("Tedi Client")); }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float dt) {}

    @Override
    public void onClose() {
        ConfigManager.save(ConfigManager.AUTO);
        super.onClose();
    }

    private float anim(Object key, float target, float dt) {
        float v = anim.getOrDefault(key, target);
        v += (target - v) * Math.min(1f, dt * 16f);
        anim.put(key, v);
        return v;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        Font f = Minecraft.getInstance().font;
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNano) / 1e9f);
        lastNano = now;
        regions.clear();
        hoverMod = null;
        g.fillGradient(0, 0, this.width, this.height, 0x78000000, 0x3C000000);

        for (int pi = 0; pi < CATS.length; pi++) {
            int x = X0 + pi * (PW + GAP);
            int bodyTop = Y0 + HEAD, maxBody = Math.max(40, this.height - 38 - bodyTop);
            int bodyH = Math.max(8, Math.min(contentH[pi], maxBody));
            float maxScroll = Math.max(0, contentH[pi] - bodyH);
            scroll[pi] = Math.max(0, Math.min(maxScroll, scroll[pi]));

            Draw.round(g, x, Y0, PW, HEAD + bodyH + 3, PANEL);
            String title = CATS[pi];
            g.drawString(f, title, x + (PW - f.width(title)) / 2, Y0 + 5, ACCENT, false);
            g.drawString(f, title, x + (PW - f.width(title)) / 2 + 1, Y0 + 5, 0x557FE8FF, false);

            regions.top = bodyTop; regions.bottom = bodyTop + bodyH;
            g.enableScissor(x, bodyTop, x + PW, bodyTop + bodyH);
            int start = bodyTop - (int) scroll[pi];
            int y = start;
            for (Module m : Modules.all) {
                if (!m.category.equals(CATS[pi])) continue;
                y = drawModule(g, f, m, x, y, mx, my, dt, bodyTop, bodyTop + bodyH);
            }
            g.disableScissor();
            contentH[pi] = y - start + 3;
        }

        // CONFIGS button at the bottom
        regions.top = 0; regions.bottom = this.height;
        int bw = 100, bh = 17, bx = (this.width - bw) / 2, by = this.height - 28;
        boolean hov = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
        Draw.round(g, bx, by, bw, bh, hov ? 0xF0262E38 : PANEL);
        g.drawString(f, "CONFIGS", bx + (bw - f.width("CONFIGS")) / 2, by + 5, ACCENT, false);
        regions.add(new Region(bx, by, bw, bh, b -> {
            if (b == 0) Minecraft.getInstance().setScreen(new ConfigScreen(this));
        }, null));

        if (dragging != null && dragging.drag() != null) dragging.drag().accept((double) mx, (double) my);

        if (hoverMod != null) {
            g.drawString(f, hoverMod.description.toUpperCase(), mx + 10, my + 8, 0xFFFFFFFF, true);
        }
    }

    private int drawModule(GuiGraphics g, Font f, Module m, int x, int y, int mx, int my, float dt, int clipTop, int clipBot) {
        boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROWH && my >= clipTop && my < clipBot;
        float a = anim(m, m.enabled ? 1f : 0f, dt);
        if (hov) g.fill(x, y, x + PW, y + ROWH, 0x16FFFFFF);
        if (a > 0.03f) g.fill(x, y + 1, x + 2, y + ROWH - 1, ((int) (a * 255) << 24) | 0x7FE8FF);
        g.drawString(f, m.name.toUpperCase(), x + 8, y + 4, Colors.lerp(TEXT, ACCENT, a), false);

        int px = x + PW - 25, py = y + 4;
        Draw.round(g, px, py, 18, 7, Colors.lerp(0xFF2E3036, 0xFF3FB6E6, a));
        int kx = px + 1 + (int) (a * 11);
        Draw.round(g, kx, py + 1, 5, 5, Colors.lerp(0xFFB4B8BE, 0xFFFFFFFF, a));
        g.drawString(f, m.expanded ? "-" : "+", px - 9, y + 4, DIM, false);

        regions.add(new Region(x, y, PW, ROWH, b -> {
            if (b == 0) m.toggle(); else if (b == 1) m.expanded = !m.expanded;
        }, null));
        if (hov) hoverMod = m;
        y += ROWH;
        if (m.expanded) y = drawSettings(g, f, m, x, y);
        return y;
    }

    private int drawSettings(GuiGraphics g, Font f, Module m, int x, int y) {
        for (Setting s : m.settings) {
            if (s instanceof Setting.Bool b) {
                g.fill(x, y, x + PW, y + 14, SETBG);
                int bx = x + 8, by = y + 3;
                Draw.round(g, bx, by, 8, 8, 0xFF2B2E34);
                if (b.value) Draw.round(g, bx + 1, by + 1, 6, 6, 0xFF3FB6E6);
                g.drawString(f, b.name.toUpperCase(), bx + 13, y + 3, TEXT, false);
                regions.add(new Region(x, y, PW, 14, bt -> { if (bt == 0) b.value = !b.value; }, null));
                y += 14;
            } else if (s instanceof Setting.Num n) {
                g.fill(x, y, x + PW, y + 22, SETBG);
                g.drawString(f, n.name.toUpperCase(), x + 8, y + 3, TEXT, false);
                String v = n.text();
                g.drawString(f, v, x + PW - 8 - f.width(v), y + 3, 0xFF3FB6E6, false);
                int tx = x + 8, tw = PW - 16, ty = y + 16;
                int fw = (int) (tw * n.ratio());
                g.fill(tx, ty, tx + tw, ty + 1, 0xFF33363D);
                g.fill(tx, ty, tx + fw, ty + 1, 0xFF3FB6E6);
                Draw.round(g, tx + fw - 2, ty - 2, 5, 5, 0xFF3FB6E6);
                regions.add(new Region(x, y + 10, PW, 12, null, (mxx, myy) -> n.setFromRatio((mxx - tx) / (double) tw)));
                y += 22;
            } else if (s instanceof Setting.Hue h) {
                g.fill(x, y, x + PW, y + 15, SETBG);
                g.drawString(f, h.name.toUpperCase(), x + 8, y + 4, TEXT, false);
                Draw.round(g, x + PW - 26, y + 3, 18, 9, h.argb());
                Draw.outline(g, x + PW - 26, y + 3, 18, 9, 0x66FFFFFF);
                regions.add(new Region(x, y, PW, 15, bt -> { if (bt == 0) h.open = !h.open; }, null));
                y += 15;
                if (h.open) {
                    g.fill(x, y, x + PW, y + 68, SETBG);
                    Widgets.palette(g, x + 8, y + 3, PW - 16, h, regions);
                    y += 68;
                }
            } else if (s instanceof Setting.Str st) {
                g.fill(x, y, x + PW, y + 27, SETBG);
                g.drawString(f, st.name.toUpperCase(), x + 8, y + 3, TEXT, false);
                Draw.round(g, x + 8, y + 13, PW - 16, 11, FIELD);
                String shown = st.value + (editing == st && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
                g.drawString(f, shown, x + 12, y + 15, editing == st ? ACCENT : TEXT, false);
                regions.add(new Region(x, y, PW, 27, bt -> { if (bt == 0) { editing = st; bindTarget = null; } }, null));
                y += 27;
            } else if (s instanceof Setting.Action ac) {
                g.fill(x, y, x + PW, y + 20, SETBG);
                Draw.round(g, x + 8, y + 3, PW - 16, 14, 0xFF1F3A47);
                Draw.outline(g, x + 8, y + 3, PW - 16, 14, 0x667FE8FF);
                String t = ac.name.toUpperCase();
                g.drawString(f, t, x + (PW - f.width(t)) / 2, y + 7, ACCENT, false);
                regions.add(new Region(x + 8, y + 3, PW - 16, 14, bt -> { if (bt == 0) ac.run.run(); }, null));
                y += 20;
            }
        }
        if (m.bindable) {
            g.fill(x, y, x + PW, y + 17, SETBG);
            g.drawString(f, "KEYBIND", x + 8, y + 5, TEXT, false);
            int bw = 48, bx = x + PW - 8 - bw;
            boolean listening = bindTarget == m;
            Draw.round(g, bx, y + 2, bw, 13, FIELD);
            if (listening) Draw.outline(g, bx, y + 2, bw, 13, ACCENT);
            String t = listening ? "..." : (m.key > 0 ? keyName(m.key) : "");
            g.drawString(f, t, bx + (bw - f.width(t)) / 2, y + 5, listening ? ACCENT : TEXT, false);
            regions.add(new Region(bx, y + 2, bw, 13, bt -> {
                if (bt == 0) { bindTarget = m; editing = null; }
                else if (bt == 1) m.key = -1;
            }, null));
            y += 17;
        }
        return y;
    }

    static String keyName(int k) {
        if (k <= 0) return "";
        if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F12) return "F" + (k - GLFW.GLFW_KEY_F1 + 1);
        switch (k) {
            case GLFW.GLFW_KEY_SPACE: return "SPACE";
            case GLFW.GLFW_KEY_TAB: return "TAB";
            case GLFW.GLFW_KEY_ENTER: return "ENTER";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LALT";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCTRL";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RALT";
            case GLFW.GLFW_KEY_UP: return "UP";
            case GLFW.GLFW_KEY_DOWN: return "DOWN";
            case GLFW.GLFW_KEY_LEFT: return "LEFT";
            case GLFW.GLFW_KEY_RIGHT: return "RIGHT";
            default: break;
        }
        String n = null;
        try { n = GLFW.glfwGetKeyName(k, 0); } catch (Throwable ignored) {}
        return n != null ? n.toUpperCase() : "K" + k;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        int b = e.button();
        editing = null;
        bindTarget = null;
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (!r.in(mx, my)) continue;
            if (r.drag() != null && b == 0) { dragging = r; r.drag().accept(mx, my); }
            if (r.click() != null) r.click().accept(b);
            return true;
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        for (int pi = 0; pi < CATS.length; pi++) {
            int x = X0 + pi * (PW + GAP);
            if (mx >= x && mx < x + PW) { scroll[pi] -= (float) (sy * 14); return true; }
        }
        return super.mouseScrolled(mx, my, sx, sy);
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (bindTarget != null) {
            if (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) bindTarget.key = -1;
            else if (k != GLFW.GLFW_KEY_ESCAPE) bindTarget.key = k;
            bindTarget = null;
            return true;
        }
        if (editing != null) {
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE) editing = null;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !editing.value.isEmpty())
                editing.value = editing.value.substring(0, editing.value.length() - 1);
            return true;
        }
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT || k == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (editing != null && editing.value.length() < 20) {
            editing.value += Character.toString(e.codepoint());
            return true;
        }
        return super.charTyped(e);
    }
}
