package dev.tedi.gui;

import dev.tedi.config.ConfigManager;
import dev.tedi.module.Hud;
import dev.tedi.module.Module;
import dev.tedi.module.Modules;
import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Icons;
import dev.tedi.util.Keys;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Click GUI. Dark-blue panels, white text, smooth animations.
 *  - drag a panel's header to MOVE it, drag the grip in its bottom-right corner to RESIZE it (right-click header = reset)
 *  - layout adapts to the window: fewer columns on small screens, never shrunk to unreadable text
 *  - no scissor / global scaling is used, so it renders the same on every resolution
 */
public class ClickGui extends Screen {
    private static final int ACCENT = Colors.ACCENT, TEXT = 0xFFFFFFFF, DIM = 0xFFAAB6D6, BLUE = 0xFF4CC3F0, SUB = 0xFFE6EEFF;
    private static final int PANEL = Colors.NAVY, SETBG = Colors.NAVY_DEEP, FIELD = Colors.NAVY_FIELD, BORDER = Colors.NAVY_BORDER;
    private static final int PW = 152, GAP = 8, Y0 = 34, HEAD = 24, ROWH = 16, R = 12;
    private static final String[] CATS = {"COMBAT", "MISC", "RENDER", "DONUT", "CLIENT"};
    private static final String[] ICON = {"combat", "misc", "render", "donut", "client"};

    /** Saved panel layout (NaN = automatic position). Stored in the config. */
    public static final float[] PX = new float[CATS.length], PY = new float[CATS.length], PS = new float[CATS.length];
    static {
        Arrays.fill(PX, Float.NaN);
        Arrays.fill(PY, Float.NaN);
        Arrays.fill(PS, 1f);
    }

    private final List<List<Region>> panelRegs = new ArrayList<>();
    private final List<Region> topRegs = new ArrayList<>();
    private Region dragging;
    private int dragPanel = -1, moving = -1, resizing = -1;
    private float grabX, grabY;
    private double clickX, clickY;
    private Module bindTarget;
    private Setting.Str editing;
    private String hoverText, tipText = "";
    private String search = "";
    private boolean searching;
    private float openClock, tipA, tipX, tipY;
    private final float[] scroll = new float[CATS.length], scrollT = new float[CATS.length];
    private final int[] contentH = new int[CATS.length], panelH = new int[CATS.length];
    private final float[] panelX = new float[CATS.length], panelY = new float[CATS.length];
    private final Map<Object, Float> anim = new HashMap<>();
    private final Map<Module, Integer> setH = new HashMap<>();
    private final Map<Module, Object[]> modKeys = new HashMap<>();
    private final Map<String, Object> rowKeys = new HashMap<>();
    private long lastNano = System.nanoTime();

    public ClickGui() {
        super(Component.literal("Tedi Client"));
        for (int i = 0; i < CATS.length; i++) panelRegs.add(new ArrayList<>());
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float dt) {}

    @Override
    public void onClose() {
        ConfigManager.save(ConfigManager.AUTO);
        super.onClose();
    }

    private float anim(Object key, float target, float dt) {
        float v = anim.getOrDefault(key, target);
        v += (target - v) * (1f - (float) Math.exp(-dt * 16.0));
        if (Math.abs(target - v) < 0.003f) v = target;
        anim.put(key, v);
        return v;
    }

    private Object[] keys(Module m) {
        Object[] k = modKeys.get(m);
        if (k == null) { k = new Object[]{new Object(), new Object()}; modKeys.put(m, k); }
        return k;
    }

    private Object rowKey(String name) {
        Object k = rowKeys.get(name);
        if (k == null) { k = new Object(); rowKeys.put(name, k); }
        return k;
    }

    private boolean match(Module m) {
        return search.isEmpty() || m.name.toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT));
    }

    private static String clip(Font f, String s, int maxW) {
        if (Draw.w(f, s) <= maxW) return s;
        while (s.length() > 1 && Draw.w(f, s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        Font f = Minecraft.getInstance().font;
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNano) / 1e9f);
        lastNano = now;
        openClock += dt;
        float bgE = Draw.easeOut(openClock / 0.25f);
        int vw = this.width, vh = this.height;
        topRegs.clear();
        for (List<Region> l : panelRegs) l.clear();
        hoverText = null;

        g.fillGradient(0, 0, vw, vh, Draw.alpha(0x8C000000, bgE), Draw.alpha(0x3C000000, bgE));
        var ps = g.pose();
        float ks = 1f - (float) Math.exp(-dt * 18.0);

        // ----- top bar: logo + search (absolute coordinates) -----
        float topE = Draw.easeOut(openClock / 0.22f);
        int topOff = (int) ((1f - topE) * -12);
        int lw = Draw.width(f, "Tedi", true) + Draw.width(f, "Client", true) + 22;
        Draw.panel(g, 8, 8 + topOff, lw, 18, 9, PANEL, BORDER, 1f);
        Draw.text(g, f, "Tedi", 18, 13 + topOff, TEXT, true);
        Draw.text(g, f, "Client", 18 + Draw.width(f, "Tedi", true), 13 + topOff, TEXT, true);

        int sw = Math.min(190, vw - lw - 40), sx = (vw - sw) / 2;
        float sa = anim("search", searching ? 1f : 0f, dt);
        Draw.panel(g, sx, 8 + topOff, sw, 18, 9, PANEL, Colors.lerp(BORDER, 0xFF7FE8FF, sa), 1f);
        Icons.draw(g, "search", sx + 8, 12 + topOff, Colors.lerp(DIM, ACCENT, sa));
        String st = search.isEmpty() && !searching ? "Search modules..." : search + (searching && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        Draw.str(g, f, st, sx + 22, 13 + topOff, search.isEmpty() && !searching ? 0xFF7C8AB4 : TEXT, false);
        topRegs.add(new Region(sx, 8, sw, 18, b -> { if (b == 0) { searching = true; editing = null; bindTarget = null; } }, null));

        // ----- panels: automatic grid, or wherever you dragged them -----
        int cols = Math.max(1, Math.min(CATS.length, (vw - 16 + GAP) / (PW + GAP)));
        int rows = (CATS.length + cols - 1) / cols;
        int gridW = cols * PW + (cols - 1) * GAP, gx0 = (vw - gridW) / 2;
        int rowH = (vh - Y0 - 46) / rows;
        for (int pi = 0; pi < CATS.length; pi++) {
            float baseX = gx0 + (pi % cols) * (PW + GAP), baseY = Y0 + (pi / cols) * rowH;
            boolean placed = !Float.isNaN(PX[pi]);
            float sc = PS[pi];
            if (resizing == pi) {
                float ox = placed ? PX[pi] : baseX;
                sc = Math.max(0.6f, Math.min(1.6f, Math.round((mx - ox) / PW * 20f) / 20f));
                PS[pi] = sc;
            }
            float x = placed ? PX[pi] : baseX, y = placed ? PY[pi] : baseY;
            if (moving == pi) {
                x = mx - grabX; y = my - grabY;
                PX[pi] = x; PY[pi] = y;
            }
            x = Math.max(-PW * sc + 40, Math.min(vw - 40, x));
            y = Math.max(0, Math.min(vh - 30, y));
            panelX[pi] = x; panelY[pi] = y;

            float pe = Draw.easeOut((openClock - pi * 0.05f) / 0.26f);
            int off = (int) ((1f - pe) * 18);
            if (pe < 0.02f) continue;

            int maxBody = Math.max(40, (int) ((vh - y - 12) / sc) - HEAD - 6);
            if (!placed && rows > 1) maxBody = Math.min(maxBody, Math.max(40, (int) (rowH / sc) - HEAD - 8));
            int bodyTop = HEAD;
            int bodyH = Math.max(8, Math.min(contentH[pi], maxBody));
            float maxScroll = Math.max(0, contentH[pi] - bodyH);
            scrollT[pi] = Math.max(0, Math.min(maxScroll, scrollT[pi]));
            scroll[pi] += (scrollT[pi] - scroll[pi]) * ks;
            if (Math.abs(scrollT[pi] - scroll[pi]) < 0.25f) scroll[pi] = scrollT[pi];
            int pH = HEAD + bodyH + 3;
            panelH[pi] = pH;
            List<Region> regs = panelRegs.get(pi);
            float lmx = (mx - x) / sc, lmy = (my - (y + off)) / sc;

            ps.pushMatrix();
            ps.translate(x, y + off);
            ps.scale(sc, sc);
            Draw.shadow(g, 0, 0, PW, pH, R);
            Draw.panel(g, 0, 0, PW, pH, R, PANEL, BORDER, 1f);
            g.fillGradient(3, 1, PW - 3, HEAD + 4, 0x147FE8FF, 0x00000000);
            Draw.roundR(g, 7, 5, 15, 15, 5, 0x337FE8FF);
            Icons.draw(g, ICON[pi], 10, 8, ACCENT);
            Draw.text(g, f, CATS[pi], 28, 8, TEXT, true);
            int count = 0;
            for (Module m : Modules.all) if (m.category.equals(CATS[pi])) count++;
            String cn = String.valueOf(count);
            Draw.str(g, f, cn, PW - 10 - Draw.w(f, cn), 8, DIM, false);
            Draw.shimmer(g, 8, HEAD - 1, PW - 16, 0xFF7FE8FF, (System.currentTimeMillis() % 100000) / 1000f + pi * 0.45f);
            final int fpi = pi;
            regs.add(new Region(0, 0, PW, HEAD, b -> {
                if (b == 0) { moving = fpi; grabX = (float) (clickX - panelX[fpi]); grabY = (float) (clickY - panelY[fpi]); }
                else if (b == 1) { PX[fpi] = Float.NaN; PY[fpi] = Float.NaN; PS[fpi] = 1f; }
            }, null));

            int start = bodyTop - Math.round(scroll[pi]);
            int yy = start + 3, bodyBot = bodyTop + bodyH;
            if (CATS[pi].equals("CLIENT")) {
                for (Module m : Modules.all) {
                    if (!m.category.equals("CLIENT") || !match(m)) continue;
                    yy = drawModule(g, f, regs, m, 0, yy, lmx, lmy, dt, bodyTop, bodyBot);
                }
                yy = actionRow(g, f, regs, 0, yy, lmx, lmy, dt, "CONFIGS", "Save, load and share configs", bodyTop, bodyBot,
                        () -> Minecraft.getInstance().setScreen(new ConfigScreen(this)));
                yy = actionRow(g, f, regs, 0, yy, lmx, lmy, dt, "EDIT HUD", "Move and resize HUD elements", bodyTop, bodyBot,
                        () -> Minecraft.getInstance().setScreen(new HudEditorScreen(this)));
                yy = actionRow(g, f, regs, 0, yy, lmx, lmy, dt, "RESET HUD", "Put every HUD element back", bodyTop, bodyBot,
                        () -> { if (Hud.I != null) Hud.I.resetPositions(); });
            } else {
                for (Module m : Modules.all) {
                    if (!m.category.equals(CATS[pi]) || !match(m)) continue;
                    yy = drawModule(g, f, regs, m, 0, yy, lmx, lmy, dt, bodyTop, bodyBot);
                }
            }
            contentH[pi] = yy - start + 4;

            if (maxScroll > 0) {
                int kh = Math.max(14, bodyH * bodyH / contentH[pi]);
                int ky = bodyTop + (int) ((bodyH - kh) * (scroll[pi] / maxScroll));
                Draw.roundR(g, PW - 4, ky, 2, kh, 1, 0x66FFFFFF);
            }
            // resize grip (bottom-right)
            boolean gripHov = lmx >= PW - 16 && lmy >= pH - 16 && lmx < PW && lmy < pH;
            float gripA = anim(rowKey("grip" + pi), (gripHov || resizing == pi) ? 1f : 0.55f, dt);
            int gc = Draw.alpha(0xFFFFFFFF, gripA);
            for (int k = 0; k < 3; k++) g.fill(PW - 6 - k * 3, pH - 5, PW - 5 - k * 3, pH - 4, gc);
            for (int k = 0; k < 2; k++) g.fill(PW - 6, pH - 8 - k * 3, PW - 5, pH - 7 - k * 3, gc);
            g.fill(PW - 9, pH - 8, PW - 8, pH - 7, gc);
            regs.add(new Region(PW - 16, pH - 16, 16, 16, b -> { if (b == 0) resizing = fpi; }, null));
            ps.popMatrix();
        }

        // ----- bottom bar: CONFIGS + EDIT HUD -----
        float botE = Draw.easeOut((openClock - 0.2f) / 0.25f);
        int botOff = (int) ((1f - botE) * 14);
        int bw = 112, bh = 18, by = vh - 28, bx1 = vw / 2 - bw - 4, bx2 = vw / 2 + 4;
        bottomButton(g, f, bx1, by, bw, bh, botOff, mx, my, dt, "CONFIGS", () -> Minecraft.getInstance().setScreen(new ConfigScreen(this)));
        bottomButton(g, f, bx2, by, bw, bh, botOff, mx, my, dt, "EDIT HUD", () -> Minecraft.getInstance().setScreen(new HudEditorScreen(this)));

        if (dragging != null && dragging.drag() != null && dragPanel >= 0) {
            float sc = PS[dragPanel];
            dragging.drag().accept((double) ((mx - panelX[dragPanel]) / sc), (double) ((my - panelY[dragPanel]) / sc));
        }

        // tooltip: fades + glides after the cursor
        if (hoverText != null) tipText = hoverText;
        tipA += ((hoverText != null ? 1f : 0f) - tipA) * (1f - (float) Math.exp(-dt * 14.0));
        tipX += ((mx + 14) - tipX) * (1f - (float) Math.exp(-dt * 22.0));
        tipY += ((my + 8) - tipY) * (1f - (float) Math.exp(-dt * 22.0));
        if (tipA > 0.03f && !tipText.isEmpty()) {
            int tw = Draw.w(f, tipText);
            int tx = Math.round(tipX), ty = Math.round(tipY);
            Draw.panel(g, tx, ty, tw + 14, 16, 8, PANEL, BORDER, tipA);
            Draw.str(g, f, tipText, tx + 7, ty + 4, Draw.alpha(0xFFFFFFFF, tipA), false);
        }
    }

    private void bottomButton(GuiGraphics g, Font f, int bx, int by, int bw, int bh, int botOff, int mx, int my, float dt, String label, Runnable run) {
        boolean hov = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
        float ha = anim(rowKey("btn" + label), hov ? 1f : 0f, dt);
        Draw.panel(g, bx, by + botOff, bw, bh, 9, Colors.lerp(PANEL, Colors.NAVY_HL, ha), Colors.lerp(BORDER, 0xFF7FE8FF, ha), 1f);
        Draw.text(g, f, label, bx + (bw - Draw.width(f, label, true)) / 2, by + 5 + botOff, TEXT, true);
        topRegs.add(new Region(bx, by, bw, bh, b -> { if (b == 0) run.run(); }, null));
    }

    private int actionRow(GuiGraphics g, Font f, List<Region> regs, int x, int y, float mx, float my, float dt, String name, String desc, int top, int bot, Runnable run) {
        if (y < top || y + ROWH > bot) return y + ROWH;
        boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROWH;
        float ha = anim(rowKey(name), hov ? 1f : 0f, dt);
        if (ha > 0.01f) Draw.roundR(g, x + 4, y, PW - 8, ROWH, 6, Draw.alpha(0x30FFFFFF, ha));
        if (hov) hoverText = desc;
        Draw.text(g, f, name, x + 10, y + 4, TEXT, true);
        Draw.str(g, f, ">", x + PW - 14, y + 4, Colors.lerp(DIM, ACCENT, ha), false);
        regs.add(new Region(x, y, PW, ROWH, b -> { if (b == 0) run.run(); }, null));
        return y + ROWH;
    }

    private int drawModule(GuiGraphics g, Font f, List<Region> regs, Module m, int x, int y, float mx, float my, float dt, int top, int bot) {
        Object[] k = keys(m);
        float a = anim(m, m.enabled ? 1f : 0f, dt);
        float ea = anim(k[1], m.expanded ? 1f : 0f, dt);
        int full = setH.getOrDefault(m, 0);
        boolean open = ea >= 0.99f && m.expanded;
        int vis = ea > 0.01f ? (open ? full : (int) (full * Draw.smooth(ea))) : 0;

        if (y >= top && y + ROWH <= bot) {
            boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROWH;
            float ha = anim(k[0], hov ? 1f : 0f, dt);
            if (ha > 0.01f) Draw.roundR(g, x + 4, y, PW - 8, ROWH, 6, Draw.alpha(0x30FFFFFF, ha));
            if (a > 0.02f) {
                Draw.roundR(g, x + 4, y, PW - 8, ROWH, 6, Draw.alpha(0x2A7FE8FF, a));
                Draw.roundR(g, x + 2, y + 3, 2, ROWH - 6, 1, Draw.alpha(ACCENT, a));
            }
            Draw.text(g, f, clip(f, m.name, PW - 46), x + 10, y + 4, TEXT, true);

            int px = x + PW - 29, py = y + 3;
            if (a > 0.05f) Draw.roundR(g, px - 1, py - 1, 24, 12, 6, Draw.alpha(0x287FE8FF, a), false);
            Draw.roundR(g, px, py, 22, 10, 5, Colors.lerp(0xFF23305A, BLUE, a));
            int kx = px + 1 + (int) (a * 12);
            Draw.roundR(g, kx, py + 1, 8, 8, 4, Colors.lerp(0xFFB9C4E6, 0xFFFFFFFF, a));
            if (!m.settings.isEmpty() || m.bindable) {
                g.fill(px - 10, y + 8, px - 5, y + 9, DIM);
                if (ea < 0.5f) g.fill(px - 8, y + 6, px - 7, y + 11, DIM);
            }
            regs.add(new Region(x, y, PW, ROWH, b -> {
                if (b == 0) m.toggle(); else if (b == 1) m.expanded = !m.expanded;
            }, null));
            if (hov) hoverText = m.description;
        }
        y += ROWH;

        if (ea > 0.01f) {
            int before = regs.size();
            int end = drawSettings(g, f, regs, m, x, y, mx, my, dt, top, Math.min(bot, y + vis));
            setH.put(m, end - y);
            if (!open) while (regs.size() > before) regs.remove(regs.size() - 1);
            y += vis;
        }
        return y;
    }

    private static String fit(Font f, String s, int maxW) {
        if (Draw.w(f, s) <= maxW) return s;
        while (s.length() > 1 && Draw.w(f, ".." + s) > maxW) s = s.substring(1);
        return ".." + s;
    }

    /** Rows are drawn only when fully inside [visTop, visBot]; otherwise they are just measured. */
    private int drawSettings(GuiGraphics g, Font f, List<Region> regs, Module m, int x, int y, float mx, float my, float dt, int visTop, int visBot) {
        int top = y;
        for (Setting s : m.settings) {
            if (s.hidden) continue;
            if (s instanceof Setting.Bool b) {
                if (y >= visTop && y + 15 <= visBot) {
                    g.fill(x, y, x + PW, y + 15, SETBG);
                    float ca = anim(b, b.value ? 1f : 0f, dt);
                    int bx = x + 11, by = y + 3;
                    Draw.roundR(g, bx, by, 9, 9, 3, Colors.lerp(0xFF23305A, 0xFF9CD8F5, ca));
                    if (ca > 0.02f) Draw.roundR(g, bx + 1, by + 1, 7, 7, 2, Draw.alpha(BLUE, ca));
                    Draw.str(g, f, clip(f, b.name, PW - 38), bx + 14, y + 4, SUB, false);
                    regs.add(new Region(x, y, PW, 15, bt -> { if (bt == 0) b.value = !b.value; }, null));
                }
                y += 15;
            } else if (s instanceof Setting.Num n) {
                if (y >= visTop && y + 22 <= visBot) {
                    g.fill(x, y, x + PW, y + 22, SETBG);
                    String val = n.text();
                    Draw.str(g, f, clip(f, n.name, PW - 28 - Draw.w(f, val)), x + 11, y + 3, SUB, false);
                    Draw.str(g, f, val, x + PW - 11 - Draw.w(f, val), y + 3, TEXT, false);
                    int tx = x + 11, tw = PW - 22, ty = y + 16;
                    int fw = (int) (tw * n.ratio());
                    Draw.roundR(g, tx, ty, tw, 3, 1, 0xFF2A3A6C);
                    Draw.roundR(g, tx, ty, Math.max(3, fw), 3, 1, BLUE);
                    g.fill(tx + 1, ty, tx + Math.max(3, fw) - 1, ty + 1, 0x55FFFFFF);
                    Draw.roundR(g, tx + fw - 4, ty - 3, 9, 9, 4, 0x337FE8FF, false);
                    Draw.roundR(g, tx + fw - 2, ty - 1, 5, 5, 2, 0xFFFFFFFF);
                    regs.add(new Region(x, y + 10, PW, 12, null, (mxx, myy) -> n.setFromRatio((mxx - tx) / (double) tw)));
                }
                y += 22;
            } else if (s instanceof Setting.Hue h) {
                if (y >= visTop && y + 16 <= visBot) {
                    g.fill(x, y, x + PW, y + 16, SETBG);
                    Draw.str(g, f, clip(f, h.name, PW - 50), x + 11, y + 4, SUB, false);
                    Draw.roundR(g, x + PW - 33, y + 2, 23, 12, 6, 0x33FFFFFF, false);
                    Draw.roundR(g, x + PW - 32, y + 3, 21, 10, 5, h.argb());
                    regs.add(new Region(x, y, PW, 16, bt -> { if (bt == 0) h.open = !h.open; }, null));
                }
                y += 16;
                if (h.open) {
                    if (y >= visTop && y + 67 <= visBot) {
                        g.fill(x, y, x + PW, y + 67, SETBG);
                        Widgets.palette(g, x + 10, y + 3, PW - 20, h, regs);
                    }
                    y += 67;
                }
            } else if (s instanceof Setting.Str st) {
                if (y >= visTop && y + 27 <= visBot) {
                    g.fill(x, y, x + PW, y + 27, SETBG);
                    Draw.str(g, f, clip(f, st.name, PW - 22), x + 11, y + 3, SUB, false);
                    Draw.roundR(g, x + 10, y + 13, PW - 20, 12, 4, FIELD);
                    if (editing == st) Draw.outline(g, x + 10, y + 13, PW - 20, 12, 0x667FE8FF);
                    String txt = fit(f, st.value, PW - 34) + (editing == st && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
                    Draw.str(g, f, txt, x + 14, y + 16, editing == st ? ACCENT : TEXT, false);
                    regs.add(new Region(x, y, PW, 27, bt -> { if (bt == 0) { editing = st; bindTarget = null; searching = false; } }, null));
                }
                y += 27;
            } else if (s instanceof Setting.Action ac) {
                if (y >= visTop && y + 21 <= visBot) {
                    g.fill(x, y, x + PW, y + 21, SETBG);
                    Draw.roundR(g, x + 10, y + 3, PW - 20, 15, 6, 0xFF1B3A78);
                    Draw.outline(g, x + 11, y + 4, PW - 22, 13, 0x447FE8FF);
                    String t = ac.name;
                    Draw.text(g, f, t, x + (PW - Draw.width(f, t, true)) / 2, y + 7, TEXT, true);
                    regs.add(new Region(x + 10, y + 3, PW - 20, 15, bt -> { if (bt == 0) ac.run.run(); }, null));
                }
                y += 21;
            }
        }
        if (m.bindable) {
            if (y >= visTop && y + 18 <= visBot) {
                g.fill(x, y, x + PW, y + 18, SETBG);
                Draw.str(g, f, "Keybind", x + 11, y + 5, SUB, false);
                int bw = 50, bx = x + PW - 10 - bw;
                boolean listening = bindTarget == m;
                Draw.roundR(g, bx, y + 2, bw, 14, 5, FIELD);
                if (listening) Draw.outline(g, bx, y + 2, bw, 14, ACCENT);
                String t = listening ? "..." : (m.key > 0 ? Keys.name(m.key) : "");
                Draw.str(g, f, t, bx + (bw - Draw.w(f, t)) / 2, y + 5, listening ? ACCENT : TEXT, false);
                regs.add(new Region(bx, y + 2, bw, 14, bt -> {
                    if (bt == 0) { bindTarget = m; editing = null; searching = false; }
                    else if (bt == 1) m.key = -1;
                }, null));
            }
            y += 18;
        }
        if (y > top && top >= visTop && y <= visBot) { g.fill(x + 4, top, x + 5, y, 0x447FE8FF); g.fill(x + 4, y - 1, x + PW - 4, y, 0x18FFFFFF); }
        return y;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        int b = e.button();
        editing = null;
        bindTarget = null;
        searching = false;
        clickX = mx; clickY = my;
        for (int i = topRegs.size() - 1; i >= 0; i--) {
            Region r = topRegs.get(i);
            if (!r.in(mx, my)) continue;
            if (r.click() != null) r.click().accept(b);
            return true;
        }
        for (int pi = CATS.length - 1; pi >= 0; pi--) {
            float sc = PS[pi], x = panelX[pi], y = panelY[pi];
            if (mx < x || my < y || mx >= x + PW * sc || my >= y + panelH[pi] * sc) continue;
            double lx = (mx - x) / sc, ly = (my - y) / sc;
            List<Region> regs = panelRegs.get(pi);
            for (int i = regs.size() - 1; i >= 0; i--) {
                Region r = regs.get(i);
                if (!r.in(lx, ly)) continue;
                if (r.drag() != null && b == 0) { dragging = r; dragPanel = pi; r.drag().accept(lx, ly); }
                if (r.click() != null) r.click().accept(b);
                return true;
            }
            return true;
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null; dragPanel = -1; moving = -1; resizing = -1;
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        for (int pi = CATS.length - 1; pi >= 0; pi--) {
            float sc = PS[pi], x = panelX[pi], y = panelY[pi];
            if (mx >= x && my >= y && mx < x + PW * sc && my < y + panelH[pi] * sc) { scrollT[pi] -= (float) (sy * 22); return true; }
        }
        return super.mouseScrolled(mx, my, sx, sy);
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (bindTarget != null) {
            if (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) bindTarget.key = -1;
            else if (k != GLFW.GLFW_KEY_ESCAPE) bindTarget.key = k;
            bindTarget = null;
            return true;
        }
        if (searching) {
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE) searching = false;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) search = search.substring(0, search.length() - 1);
            return true;
        }
        if (editing != null) {
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE) editing = null;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !editing.value.isEmpty())
                editing.value = editing.value.substring(0, editing.value.length() - 1);
            else if (k == GLFW.GLFW_KEY_V && (e.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0) {
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) {
                    String joined = editing.value + clip.trim();
                    editing.value = joined.substring(0, Math.min(editing.maxLen, joined.length()));
                }
            }
            return true;
        }
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT || k == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (searching && search.length() < 20) { search += Character.toString(e.codepoint()); return true; }
        if (editing != null && editing.value.length() < editing.maxLen) {
            editing.value += Character.toString(e.codepoint());
            return true;
        }
        return super.charTyped(e);
    }
}
