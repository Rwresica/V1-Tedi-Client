package dev.tedi.gui;

import dev.tedi.config.ConfigManager;
import dev.tedi.module.Hud;
import dev.tedi.module.Module;
import dev.tedi.module.Modules;
import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/** Krypton-style click GUI: 5 compact columns, bold names, small pill toggles, smooth animations. */
public class ClickGui extends Screen {
    private static final int ACCENT = Colors.ACCENT, TEXT = 0xFFE4E6EA, DIM = Colors.DIM, BLUE = 0xFF4CC3F0;
    private static final int PANEL = 0xF0141519, SETBG = 0xF00D0E11, FIELD = 0xFF08090B;
    private static final int PW = 132, GAP = 7, Y0 = 20, HEAD = 17, ROWH = 14;
    private static final String[] CATS = {"COMBAT", "MISC", "RENDER", "DONUT", "CLIENT"};

    /** Region list that clips everything to the panel body, so scrolled-away rows can't be clicked. */
    private static class ClipList extends ArrayList<Region> {
        int top, bottom;
        @Override public boolean add(Region r) {
            int y1 = Math.max(r.y(), top), y2 = Math.min(r.y() + r.h(), bottom);
            if (y2 <= y1) return false;
            return super.add(new Region(r.x(), y1, r.w(), y2 - y1, r.click(), r.drag()));
        }
    }

    private final ClipList regions = new ClipList();
    private Region dragging;
    private Module bindTarget;
    private Setting.Str editing;
    private String hoverText;
    private float S = 1f, openT;
    private final float[] scroll = new float[CATS.length];
    private final int[] contentH = new int[CATS.length];
    private final Map<Object, Float> anim = new HashMap<>();
    private final Map<Module, Integer> setH = new HashMap<>();
    private long lastNano = System.nanoTime();

    public ClickGui() { super(Component.literal("Tedi Client")); }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float dt) {}

    @Override
    public void onClose() {
        ConfigManager.save(ConfigManager.AUTO);
        super.onClose();
    }

    private float anim(Object key, float target, float dt) {
        float v = anim.getOrDefault(key, target);
        v += (target - v) * Math.min(1f, dt * 14f);
        if (Math.abs(target - v) < 0.003f) v = target;
        anim.put(key, v);
        return v;
    }

    private int total() { return CATS.length * PW + (CATS.length - 1) * GAP; }

    @Override
    public void render(GuiGraphics g, int rmx, int rmy, float partial) {
        Font f = Minecraft.getInstance().font;
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNano) / 1e9f);
        lastNano = now;
        openT = Math.min(1f, openT + dt / 0.2f);
        float ease = 1f - (1f - openT) * (1f - openT) * (1f - openT);

        S = Math.max(0.55f, Math.min(1f, (this.width - 16f) / total()));
        int vw = (int) (this.width / S), vh = (int) (this.height / S);
        int mx = (int) (rmx / S), my = (int) (rmy / S);
        regions.clear();
        hoverText = null;

        g.fillGradient(0, 0, this.width, this.height, Draw.alpha(0x80000000, ease), Draw.alpha(0x40000000, ease));
        var ps = g.pose();
        ps.pushMatrix();
        ps.scale(S, S);
        float k = 0.95f + 0.05f * ease;
        ps.translate(vw / 2f, vh / 2f);
        ps.scale(k, k);
        ps.translate(-vw / 2f, -vh / 2f);

        int X0 = (vw - total()) / 2;
        for (int pi = 0; pi < CATS.length; pi++) {
            int x = X0 + pi * (PW + GAP);
            int bodyTop = Y0 + HEAD, maxBody = Math.max(40, vh - 40 - bodyTop);
            int bodyH = Math.max(8, Math.min(contentH[pi], maxBody));
            float maxScroll = Math.max(0, contentH[pi] - bodyH);
            scroll[pi] = Math.max(0, Math.min(maxScroll, scroll[pi]));

            Draw.round(g, x + 1, Y0 + 2, PW, HEAD + bodyH + 2, 0x44000000);
            Draw.round(g, x, Y0, PW, HEAD + bodyH + 2, PANEL);
            String title = CATS[pi];
            Draw.text(g, f, title, x + (PW - Draw.width(f, title, true)) / 2, Y0 + 5, ACCENT, true);

            regions.top = bodyTop; regions.bottom = bodyTop + bodyH;
            g.enableScissor(x, bodyTop, x + PW, bodyTop + bodyH);
            int start = bodyTop - (int) scroll[pi];
            int y = start;
            if (CATS[pi].equals("CLIENT")) {
                for (Module m : Modules.all) {
                    if (!m.category.equals("CLIENT")) continue;
                    y = drawModule(g, f, m, x, y, mx, my, dt, bodyTop, bodyTop + bodyH);
                }
                y = actionRow(g, f, x, y, mx, my, dt, "CONFIGS", "Save and load your settings", bodyTop, bodyTop + bodyH,
                        () -> Minecraft.getInstance().setScreen(new ConfigScreen(this)));
                y = actionRow(g, f, x, y, mx, my, dt, "RESET HUD", "Put every HUD element back", bodyTop, bodyTop + bodyH,
                        () -> { if (Hud.I != null) Hud.I.resetPositions(); });
            } else {
                for (Module m : Modules.all) {
                    if (!m.category.equals(CATS[pi])) continue;
                    y = drawModule(g, f, m, x, y, mx, my, dt, bodyTop, bodyTop + bodyH);
                }
            }
            g.disableScissor();
            contentH[pi] = y - start + 2;
        }

        // CONFIGS button at the bottom
        regions.top = 0; regions.bottom = vh;
        int bw = 100, bh = 16, bx = (vw - bw) / 2, by = vh - 26;
        boolean hov = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
        float ha = anim("cfgbtn", hov ? 1f : 0f, dt);
        Draw.round(g, bx + 1, by + 2, bw, bh, 0x44000000);
        Draw.round(g, bx, by, bw, bh, Colors.lerp(PANEL, 0xF0252D37, ha));
        Draw.text(g, f, "CONFIGS", bx + (bw - Draw.width(f, "CONFIGS", true)) / 2, by + 4, ACCENT, true);
        regions.add(new Region(bx, by, bw, bh, b -> {
            if (b == 0) Minecraft.getInstance().setScreen(new ConfigScreen(this));
        }, null));

        if (dragging != null && dragging.drag() != null) dragging.drag().accept((double) mx, (double) my);

        if (hoverText != null) Draw.text(g, f, hoverText.toUpperCase(), mx + 10, my + 8, 0xFFFFFFFF, true);
        ps.popMatrix();
    }

    private int actionRow(GuiGraphics g, Font f, int x, int y, int mx, int my, float dt, String name, String desc, int clipTop, int clipBot, Runnable run) {
        boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROWH && my >= clipTop && my < clipBot;
        float ha = anim(name + "#h", hov ? 1f : 0f, dt);
        if (ha > 0.01f) g.fill(x, y, x + PW, y + ROWH, Draw.alpha(0x22FFFFFF, ha));
        if (hov) hoverText = desc;
        Draw.text(g, f, name, x + 7, y + 3, TEXT, true);
        g.drawString(f, ">", x + PW - 12, y + 3, DIM, false);
        regions.add(new Region(x, y, PW, ROWH, b -> { if (b == 0) run.run(); }, null));
        return y + ROWH;
    }

    private int drawModule(GuiGraphics g, Font f, Module m, int x, int y, int mx, int my, float dt, int clipTop, int clipBot) {
        boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROWH && my >= clipTop && my < clipBot;
        float a = anim(m, m.enabled ? 1f : 0f, dt);
        float ha = anim(m.name + "#h", hov ? 1f : 0f, dt);
        if (ha > 0.01f) g.fill(x, y, x + PW, y + ROWH, Draw.alpha(0x22FFFFFF, ha));
        if (a > 0.03f) g.fill(x, y + 1, x + 2, y + ROWH - 1, ((int) (a * 255) << 24) | 0x7FE8FF);
        Draw.text(g, f, m.name.toUpperCase(), x + 7, y + 3, Colors.lerp(TEXT, ACCENT, a), true);

        int px = x + PW - 25, py = y + 3;
        Draw.round(g, px, py, 18, 8, Colors.lerp(0xFF2B2C31, BLUE, a));
        int kx = px + 1 + (int) (a * 10);
        Draw.round(g, kx, py + 1, 6, 6, Colors.lerp(0xFFB9BCC2, 0xFFFFFFFF, a));
        float ea = anim(m.name + "#ex", m.expanded ? 1f : 0f, dt);
        g.fill(px - 9, y + 7, px - 4, y + 8, DIM);
        if (ea < 0.5f) g.fill(px - 7, y + 5, px - 6, y + 10, DIM);

        regions.add(new Region(x, y, PW, ROWH, b -> {
            if (b == 0) m.toggle(); else if (b == 1) m.expanded = !m.expanded;
        }, null));
        if (hov) hoverText = m.description;
        y += ROWH;

        if (ea > 0.01f) {
            int full = setH.getOrDefault(m, 0);
            int vis = (ea >= 0.99f && m.expanded) ? full : (int) (full * ea);
            int before = regions.size();
            g.enableScissor(x, y, x + PW, y + Math.max(1, vis));
            int end = drawSettings(g, f, m, x, y);
            setH.put(m, end - y);
            g.disableScissor();
            if (!(ea >= 0.99f && m.expanded)) while (regions.size() > before) regions.remove(regions.size() - 1);
            y += vis;
        }
        return y;
    }

    private static String fit(Font f, String s, int maxW) {
        if (f.width(s) <= maxW) return s;
        while (s.length() > 1 && f.width(".." + s) > maxW) s = s.substring(1);
        return ".." + s;
    }

    private int drawSettings(GuiGraphics g, Font f, Module m, int x, int y) {
        for (Setting s : m.settings) {
            if (s.hidden) continue;
            if (s instanceof Setting.Bool b) {
                g.fill(x, y, x + PW, y + 13, SETBG);
                int bx = x + 8, by = y + 3;
                Draw.round(g, bx, by, 7, 7, 0xFF2B2C31);
                if (b.value) { Draw.round(g, bx, by, 7, 7, 0xFF9CD8F5); Draw.round(g, bx + 1, by + 1, 5, 5, BLUE); }
                g.drawString(f, b.name.toUpperCase(), bx + 12, y + 3, TEXT, false);
                regions.add(new Region(x, y, PW, 13, bt -> { if (bt == 0) b.value = !b.value; }, null));
                y += 13;
            } else if (s instanceof Setting.Num n) {
                g.fill(x, y, x + PW, y + 19, SETBG);
                g.drawString(f, n.name.toUpperCase(), x + 8, y + 2, TEXT, false);
                String v = n.text();
                g.drawString(f, v, x + PW - 8 - f.width(v), y + 2, BLUE, false);
                int tx = x + 8, tw = PW - 16, ty = y + 14;
                int fw = (int) (tw * n.ratio());
                g.fill(tx, ty, tx + tw, ty + 1, 0xFF30333A);
                g.fill(tx, ty, tx + fw, ty + 1, BLUE);
                Draw.round(g, tx + fw - 2, ty - 2, 5, 5, 0xFF8FD6F5);
                regions.add(new Region(x, y + 9, PW, 10, null, (mxx, myy) -> n.setFromRatio((mxx - tx) / (double) tw)));
                y += 19;
            } else if (s instanceof Setting.Hue h) {
                g.fill(x, y, x + PW, y + 14, SETBG);
                g.drawString(f, h.name.toUpperCase(), x + 8, y + 3, TEXT, false);
                Draw.round(g, x + PW - 26, y + 3, 18, 8, h.argb());
                Draw.outline(g, x + PW - 26, y + 3, 18, 8, 0x55FFFFFF);
                regions.add(new Region(x, y, PW, 14, bt -> { if (bt == 0) h.open = !h.open; }, null));
                y += 14;
                if (h.open) {
                    g.fill(x, y, x + PW, y + 66, SETBG);
                    Widgets.palette(g, x + 8, y + 3, PW - 16, h, regions);
                    y += 66;
                }
            } else if (s instanceof Setting.Str st) {
                g.fill(x, y, x + PW, y + 25, SETBG);
                g.drawString(f, st.name.toUpperCase(), x + 8, y + 2, TEXT, false);
                Draw.round(g, x + 8, y + 12, PW - 16, 11, FIELD);
                String txt = fit(f, st.value, PW - 28) + (editing == st && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
                g.drawString(f, txt, x + 12, y + 14, editing == st ? ACCENT : TEXT, false);
                regions.add(new Region(x, y, PW, 25, bt -> { if (bt == 0) { editing = st; bindTarget = null; } }, null));
                y += 25;
            } else if (s instanceof Setting.Action ac) {
                g.fill(x, y, x + PW, y + 18, SETBG);
                Draw.round(g, x + 8, y + 2, PW - 16, 14, 0xFF1B3340);
                Draw.outline(g, x + 8, y + 2, PW - 16, 14, 0x557FE8FF);
                String t = ac.name.toUpperCase();
                g.drawString(f, t, x + (PW - f.width(t)) / 2, y + 5, ACCENT, false);
                regions.add(new Region(x + 8, y + 2, PW - 16, 14, bt -> { if (bt == 0) ac.run.run(); }, null));
                y += 18;
            }
        }
        if (m.bindable) {
            g.fill(x, y, x + PW, y + 16, SETBG);
            g.drawString(f, "KEYBIND", x + 8, y + 4, TEXT, false);
            int bw = 46, bx = x + PW - 8 - bw;
            boolean listening = bindTarget == m;
            Draw.round(g, bx, y + 2, bw, 12, FIELD);
            if (listening) Draw.outline(g, bx, y + 2, bw, 12, ACCENT);
            String t = listening ? "..." : (m.key > 0 ? keyName(m.key) : "");
            g.drawString(f, t, bx + (bw - f.width(t)) / 2, y + 4, listening ? ACCENT : TEXT, false);
            regions.add(new Region(bx, y + 2, bw, 12, bt -> {
                if (bt == 0) { bindTarget = m; editing = null; }
                else if (bt == 1) m.key = -1;
            }, null));
            y += 16;
        }
        return y;
    }

    static String keyName(int k) {
        if (k <= 0) return "";
        if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F12) return "F" + (k - GLFW.GLFW_KEY_F1 + 1);
        switch (k) {
            case GLFW.GLFW_KEY_SPACE: return "SPACE";
            case GLFW.GLFW_KEY_TAB: return "TAB";
            case GLFW.GLFW_KEY_ENTER: return "ENTER";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LALT";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCTRL";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RALT";
            case GLFW.GLFW_KEY_UP: return "UP";
            case GLFW.GLFW_KEY_DOWN: return "DOWN";
            case GLFW.GLFW_KEY_LEFT: return "LEFT";
            case GLFW.GLFW_KEY_RIGHT: return "RIGHT";
            default: break;
        }
        String n = null;
        try { n = GLFW.glfwGetKeyName(k, 0); } catch (Throwable ignored) {}
        return n != null ? n.toUpperCase() : "K" + k;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x() / S, my = e.y() / S;
        int b = e.button();
        editing = null;
        bindTarget = null;
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (!r.in(mx, my)) continue;
            if (r.drag() != null && b == 0) { dragging = r; r.drag().accept(mx, my); }
            if (r.click() != null) r.click().accept(b);
            return true;
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        double vx = mx / S;
        int X0 = (int) ((this.width / S - total()) / 2);
        for (int pi = 0; pi < CATS.length; pi++) {
            int x = X0 + pi * (PW + GAP);
            if (vx >= x && vx < x + PW) { scroll[pi] -= (float) (sy * 14); return true; }
        }
        return super.mouseScrolled(mx, my, sx, sy);
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (bindTarget != null) {
            if (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) bindTarget.key = -1;
            else if (k != GLFW.GLFW_KEY_ESCAPE) bindTarget.key = k;
            bindTarget = null;
            return true;
        }
        if (editing != null) {
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE) editing = null;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !editing.value.isEmpty())
                editing.value = editing.value.substring(0, editing.value.length() - 1);
            else if (k == GLFW.GLFW_KEY_V && (e.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0) {
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) {
                    String joined = editing.value + clip.trim();
                    editing.value = joined.substring(0, Math.min(editing.maxLen, joined.length()));
                }
            }
            return true;
        }
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT || k == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (editing != null && editing.value.length() < editing.maxLen) {
            editing.value += Character.toString(e.codepoint());
            return true;
        }
        return super.charTyped(e);
    }
}
