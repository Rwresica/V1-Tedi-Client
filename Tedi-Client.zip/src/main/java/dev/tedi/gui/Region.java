package dev.tedi.gui;

import java.util.function.BiConsumer;
import java.util.function.IntConsumer;

/** A clickable / draggable rectangle recorded while a screen renders. */
public record Region(int x, int y, int w, int h, IntConsumer click, BiConsumer<Double, Double> drag) {
    public boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
}
