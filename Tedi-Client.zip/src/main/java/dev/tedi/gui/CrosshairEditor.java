package dev.tedi.gui;

import dev.tedi.module.CustomCrosshair;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Pixel editor for the custom crosshair: left-drag paints, right-drag erases. */
public class CrosshairEditor extends Screen {
    private static final int N = CustomCrosshair.N, CELL = 14;
    private static final int ACCENT = Colors.ACCENT, PANEL = 0xF0141519, FIELD = 0xFF08090B;

    private final Screen parent;
    private final List<Region> regions = new ArrayList<>();

    public CrosshairEditor(Screen parent) {
        super(Component.literal("Crosshair"));
        this.parent = parent;
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float dt) {}
    @Override public void onClose() { Minecraft.getInstance().setScreen(parent); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float dt) {
        Font f = Minecraft.getInstance().font;
        CustomCrosshair cc = CustomCrosshair.I;
        regions.clear();
        g.fillGradient(0, 0, this.width, this.height, 0x90000000, 0x50000000);

        int gridW = N * CELL, pw = gridW + 150, ph = gridW + 44;
        int x = (this.width - pw) / 2, y = (this.height - ph) / 2;
        Draw.roundR(g, x + 1, y + 2, pw, ph, 5, 0x44000000);
        Draw.roundR(g, x, y, pw, ph, 5, PANEL);
        Draw.text(g, f, "DRAW YOUR CROSSHAIR", x + (pw - Draw.width(f, "DRAW YOUR CROSSHAIR", true)) / 2, y + 6, ACCENT, true);

        int gx = x + 10, gy = y + 24;
        // painting with raw mouse state
        long win = GLFW.glfwGetCurrentContext();
        boolean L = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean R = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        StringBuilder sb = new StringBuilder(cc.bitmap.value);
        while (sb.length() < N * N) sb.append('0');
        if ((L || R) && mx >= gx && my >= gy && mx < gx + gridW && my < gy + gridW) {
            int c = (mx - gx) / CELL, r = (my - gy) / CELL;
            sb.setCharAt(r * N + c, L ? '1' : '0');
            cc.bitmap.value = sb.toString();
        }
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            boolean on = sb.charAt(r * N + c) == '1';
            boolean center = r == N / 2 && c == N / 2;
            int cx = gx + c * CELL, cy = gy + r * CELL;
            g.fill(cx, cy, cx + CELL - 1, cy + CELL - 1, on ? cc.color.argb() : (center ? 0xFF1E2430 : 0xFF0D0E11));
            if (!on && (r + c) % 2 == 0) g.fill(cx, cy, cx + CELL - 1, cy + CELL - 1, 0x10FFFFFF);
        }

        // side panel: presets + preview
        int sx = gx + gridW + 12;
        String[][] pre = {{"PLUS", "plus"}, {"PLUS + DOT", "plusdot"}, {"CROSS", "cross"}, {"DOT", "dot"}};
        for (int i = 0; i < pre.length; i++) {
            int by = gy + i * 18;
            boolean hov = mx >= sx && mx < sx + 118 && my >= by && my < by + 15;
            Draw.roundR(g, sx, by, 118, 15, 4, hov ? 0xFF26323C : 0xFF1B3340);
            Draw.text(g, f, pre[i][0], sx + (118 - Draw.width(f, pre[i][0], true)) / 2, by + 4, ACCENT, true);
            final String key = pre[i][1];
            regions.add(new Region(sx, by, 118, 15, b -> { if (b == 0) cc.bitmap.value = CustomCrosshair.preset(key); }, null));
        }
        int cy2 = gy + pre.length * 18;
        Draw.roundR(g, sx, cy2, 118, 15, 4, 0xFF4A2229);
        Draw.text(g, f, "CLEAR", sx + (118 - Draw.width(f, "CLEAR", true)) / 2, cy2 + 4, 0xFFFF8A8A, true);
        regions.add(new Region(sx, cy2, 118, 15, b -> { if (b == 0) cc.bitmap.value = "0".repeat(N * N); }, null));

        int py = cy2 + 24;
        Draw.text(g, f, "PREVIEW", sx, py, 0xFF8A9099, false);
        Draw.roundR(g, sx, py + 11, 118, 60, 4, FIELD);
        int s = cc.size.i(), pcx = sx + 59, pcy = py + 11 + 30;
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            if (sb.charAt(r * N + c) != '1') continue;
            int px = pcx - (N * s) / 2 + c * s, pyy = pcy - (N * s) / 2 + r * s;
            if (cc.outline.value) g.fill(px - 1, pyy - 1, px + s + 1, pyy + s + 1, 0xC0000000);
        }
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            if (sb.charAt(r * N + c) != '1') continue;
            int px = pcx - (N * s) / 2 + c * s, pyy = pcy - (N * s) / 2 + r * s;
            g.fill(px, pyy, px + s, pyy + s, cc.color.argb());
        }
        Draw.text(g, f, "LEFT DRAG = DRAW   RIGHT DRAG = ERASE", x + 10, y + ph - 14, 0xFF8A9099, false);
        Draw.text(g, f, "ESC = DONE", x + pw - 10 - Draw.width(f, "ESC = DONE", true), y + ph - 14, ACCENT, true);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (r.in(e.x(), e.y())) { if (r.click() != null) r.click().accept(e.button()); return true; }
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        if (e.key() == GLFW.GLFW_KEY_ESCAPE || e.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; }
        return super.keyPressed(e);
    }
}
