package dev.tedi.gui;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

public final class Widgets {
    private Widgets() {}

    private static double clamp01(double v) { return Math.max(0, Math.min(1, v)); }

    /** Colour palette: saturation/brightness square + hue bar. Returns the height used. */
    public static int palette(GuiGraphics g, int x, int y, int w, Setting.Hue c, List<Region> regs) {
        int sh = 46;
        for (int i = 0; i < w; i += 2) {
            double s = Math.min(1.0, (i + 1) / (double) w);
            g.fillGradient(x + i, y, x + Math.min(i + 2, w), y + sh, 0xFF000000 | Colors.hsv(c.hue, s, 1.0), 0xFF000000);
        }
        int kx = x + (int) (c.sat * (w - 1)), ky = y + (int) ((1 - c.val) * (sh - 1));
        Draw.outline(g, kx - 3, ky - 3, 7, 7, 0xFF000000);
        Draw.outline(g, kx - 2, ky - 2, 5, 5, 0xFFFFFFFF);
        regs.add(new Region(x, y, w, sh, null, (mx, my) -> {
            c.sat = clamp01((mx - x) / (double) w);
            c.val = 1 - clamp01((my - y) / (double) sh);
        }));

        int hy = y + sh + 4;
        for (int i = 0; i < w; i += 2) {
            g.fill(x + i, hy, x + Math.min(i + 2, w), hy + 8, 0xFF000000 | Colors.hsv(i / (double) w * 360.0, 1.0, 1.0));
        }
        int hx = x + (int) (c.hue / 360.0 * (w - 1));
        Draw.outline(g, hx - 1, hy - 2, 4, 12, 0xFFFFFFFF);
        regs.add(new Region(x, hy - 2, w, 12, null, (mx, my) -> c.hue = clamp01((mx - x) / (double) w) * 360.0));
        return sh + 4 + 8 + 4;
    }
}
