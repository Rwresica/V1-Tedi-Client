package dev.tedi.gui;

import dev.tedi.module.BlockEsp;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Pick which blocks BlockESP shows, and give each its own colour / tracer. */
public class BlockPicker extends Screen {
    private static final int ACCENT = Colors.ACCENT, TEXT = Colors.TEXT, DIM = Colors.DIM;
    private static final int PANEL = 0xEB1A1B1F, ROW = 0xF0121317, FIELD = 0xFF0B0C0F;
    private static final int LW = 210, RW = 150, GAP = 8, ROWH = 17;

    private final Screen parent;
    private final List<Region> regions = new ArrayList<>();
    private final List<Block> all = BlockEsp.sortedBlocks();
    private List<Block> filtered = new ArrayList<>(all);
    private String search = "";
    private float scroll;
    private Region dragging;
    private BlockEsp.Entry active;

    public BlockPicker(Screen parent) {
        super(Component.literal("Select Blocks"));
        this.parent = parent;
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float dt) {}
    @Override public void onClose() { Minecraft.getInstance().setScreen(parent); }

    private void refilter() {
        String q = search.toLowerCase(Locale.ROOT);
        filtered = new ArrayList<>();
        for (Block b : all) if (q.isEmpty() || b.getName().getString().toLowerCase(Locale.ROOT).contains(q)) filtered.add(b);
        scroll = 0;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float dt) {
        Font f = Minecraft.getInstance().font;
        regions.clear();
        BlockEsp esp = BlockEsp.I;
        g.fillGradient(0, 0, this.width, this.height, 0x90000000, 0x50000000);

        int totalW = LW + GAP + RW;
        int lx = (this.width - totalW) / 2, rx = lx + LW + GAP, y0 = 26;
        int panelH = this.height - 52;
        int visible = Math.max(3, (panelH - 17 - 24 - 18) / ROWH);

        // ----- left: list -----
        Draw.round(g, lx, y0, LW, panelH, PANEL);
        dev.tedi.util.Draw.text(g, f, "SELECT BLOCKS", lx + (LW - dev.tedi.util.Draw.width(f, "SELECT BLOCKS", true)) / 2, y0 + 5, ACCENT, true);
        Draw.round(g, lx + 8, y0 + 19, LW - 16, 13, FIELD);
        Draw.outline(g, lx + 8, y0 + 19, LW - 16, 13, 0x667FE8FF);
        String sh = search.isEmpty() ? "TYPE TO SEARCH..." : search + ((System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        g.drawString(f, sh, lx + 12, y0 + 22, search.isEmpty() ? DIM : ACCENT, false);

        int maxScroll = Math.max(0, filtered.size() - visible);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        int ly = y0 + 36;
        for (int i = 0; i < visible; i++) {
            int idx = i + (int) scroll;
            if (idx >= filtered.size()) break;
            Block b = filtered.get(idx);
            BlockEsp.Entry e = esp.get(b);
            int ry = ly + i * ROWH;
            boolean hov = mx >= lx && mx < lx + LW && my >= ry && my < ry + ROWH;
            g.fill(lx, ry, lx + LW, ry + ROWH, hov ? 0xF01C2028 : ROW);
            if (e != null && e == active) g.fill(lx, ry + 1, lx + 2, ry + ROWH - 1, ACCENT);
            g.renderItem(new ItemStack(b.asItem()), lx + 6, ry);
            g.drawString(f, b.getName().getString(), lx + 28, ry + 5, e != null ? ACCENT : TEXT, false);
            if (e != null) Draw.round(g, lx + LW - 44, ry + 4, 9, 9, e.color.argb());
            int cx = lx + LW - 24;
            Draw.round(g, cx, ry + 4, 10, 10, 0xFF2B2E34);
            if (e != null) Draw.round(g, cx + 1, ry + 5, 8, 8, 0xFF3FB6E6);
            regions.add(new Region(lx, ry, LW - 28, ROWH, bt -> {
                if (bt == 0) active = esp.add(b);
            }, null));
            regions.add(new Region(cx - 2, ry, 30, ROWH, bt -> {
                if (bt != 0) return;
                if (esp.get(b) != null) { if (active != null && active.block == b) active = null; esp.remove(b); }
                else active = esp.add(b);
            }, null));
        }
        g.drawString(f, esp.entries.size() + " SELECTED   -   " + filtered.size() + " SHOWN", lx + 8, y0 + panelH - 12, DIM, false);

        // ----- right: editor -----
        Draw.round(g, rx, y0, RW, panelH, PANEL);
        g.drawString(f, "EDIT BLOCK", rx + (RW - f.width("EDIT BLOCK")) / 2, y0 + 5, ACCENT, false);
        if (active == null || esp.get(active.block) == null) {
            active = null;
            g.drawString(f, "CLICK A BLOCK TO", rx + 10, y0 + 30, DIM, false);
            g.drawString(f, "CHOOSE ITS COLOR", rx + 10, y0 + 42, DIM, false);
        } else {
            BlockEsp.Entry e = active;
            g.renderItem(new ItemStack(e.block.asItem()), rx + 8, y0 + 20);
            g.drawString(f, e.block.getName().getString(), rx + 30, y0 + 25, TEXT, false);
            int py = y0 + 44;
            py += Widgets.palette(g, rx + 8, py, RW - 16, e.color, regions);
            Draw.round(g, rx + 8, py, 20, 10, e.color.argb());
            g.drawString(f, "PREVIEW", rx + 34, py + 1, DIM, false);
            py += 18;
            g.fill(rx, py, rx + RW, py + 15, ROW);
            Draw.round(g, rx + 8, py + 3, 8, 8, 0xFF2B2E34);
            if (e.tracer) Draw.round(g, rx + 9, py + 4, 6, 6, 0xFF3FB6E6);
            g.drawString(f, "TRACER", rx + 21, py + 3, TEXT, false);
            regions.add(new Region(rx, py, RW, 15, bt -> { if (bt == 0) e.tracer = !e.tracer; }, null));
            py += 20;
            Draw.round(g, rx + 8, py, RW - 16, 14, 0xFF4A2229);
            g.drawString(f, "REMOVE", rx + (RW - f.width("REMOVE")) / 2, py + 3, 0xFFFF8A8A, false);
            regions.add(new Region(rx + 8, py, RW - 16, 14, bt -> { if (bt == 0) { esp.remove(e.block); active = null; } }, null));
        }
        g.drawString(f, "ESC = BACK", (this.width - f.width("ESC = BACK")) / 2, this.height - 20, DIM, false);

        if (dragging != null && dragging.drag() != null) dragging.drag().accept((double) mx, (double) my);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (!r.in(e.x(), e.y())) continue;
            if (r.drag() != null && e.button() == 0) { dragging = r; r.drag().accept(e.x(), e.y()); }
            if (r.click() != null) r.click().accept(e.button());
            return true;
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scroll -= (float) (sy * 3);
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; }
        if (k == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
            search = search.substring(0, search.length() - 1);
            refilter();
            return true;
        }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (search.length() < 24) {
            search += Character.toString(e.codepoint());
            refilter();
            return true;
        }
        return super.charTyped(e);
    }
}
