package dev.tedi.gui;

import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Empty screen: the HUD editor (drag / resize / reset) runs on top of it, exactly like pressing T. */
public class HudEditorScreen extends Screen {
    private final Screen parent;

    public HudEditorScreen(Screen parent) {
        super(Component.literal("HUD Editor"));
        this.parent = parent;
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float dt) {}
    @Override public void onClose() { Minecraft.getInstance().setScreen(parent); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float dt) {
        g.fillGradient(0, 0, this.width, this.height, 0x40000000, 0x20000000);
        var f = Minecraft.getInstance().font;
        String t = "ESC = BACK";
        Draw.str(g, f, t, (this.width - Draw.w(f, t)) / 2, this.height - 16, 0xFFFFFFFF, false);
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        if (e.key() == GLFW.GLFW_KEY_ESCAPE || e.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; }
        return super.keyPressed(e);
    }
}
