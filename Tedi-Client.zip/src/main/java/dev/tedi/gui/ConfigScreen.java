package dev.tedi.gui;

import dev.tedi.config.ConfigManager;
import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Second GUI (opened with the CONFIGS button) for saving / loading configs. */
public class ConfigScreen extends Screen {
    private static final int ACCENT = Colors.ACCENT, TEXT = Colors.TEXT, DIM = Colors.DIM;
    private static final int PANEL = 0xEB1A1B1F, ROW = 0xF0121317, FIELD = 0xFF0B0C0F;
    private static final int PW = 190;

    private final Screen parent;
    private final List<Region> regions = new ArrayList<>();
    private final Setting.Str cfgName = new Setting.Str("Name", "default");
    private boolean editing = true;
    private List<String> configs = new ArrayList<>();
    private String status = "";
    private boolean statusOk;
    private long statusTime;
    private float scroll;

    public ConfigScreen(Screen parent) {
        super(Component.literal("Configs"));
        this.parent = parent;
    }

    @Override protected void init() { configs = ConfigManager.list(); }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float dt) {}
    @Override public void onClose() { Minecraft.getInstance().setScreen(parent); }

    private void say(String s, boolean ok) { status = s; statusOk = ok; statusTime = System.currentTimeMillis(); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float dt) {
        Font f = Minecraft.getInstance().font;
        regions.clear();
        g.fillGradient(0, 0, this.width, this.height, 0x90000000, 0x50000000);

        int x = (this.width - PW) / 2, y = 34;
        int listRows = Math.max(3, Math.min(12, (this.height - 190) / 15));
        int bodyH = 17 + 30 + 22 + 16 + 15 + listRows * 15 + 6;
        Draw.round(g, x, y, PW, bodyH, PANEL);

        dev.tedi.util.Draw.text(g, f, "CONFIGS", x + (PW - dev.tedi.util.Draw.width(f, "CONFIGS", true)) / 2, y + 5, ACCENT, true);
        y += 17;

        g.fill(x, y, x + PW, y + 30, ROW);
        g.drawString(f, "CONFIG NAME", x + 8, y + 4, TEXT, false);
        Draw.round(g, x + 8, y + 15, PW - 16, 12, FIELD);
        if (editing) Draw.outline(g, x + 8, y + 15, PW - 16, 12, 0x887FE8FF);
        String shown = cfgName.value + (editing && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        g.drawString(f, shown, x + 12, y + 17, editing ? ACCENT : TEXT, false);
        regions.add(new Region(x, y, PW, 30, b -> { if (b == 0) editing = true; }, null));
        y += 30;

        g.fill(x, y, x + PW, y + 22, ROW);
        String[] names = {"SAVE", "LOAD", "DELETE"};
        int bw = (PW - 16 - 8) / 3;
        for (int i = 0; i < 3; i++) {
            int bx = x + 8 + i * (bw + 4);
            Draw.round(g, bx, y + 4, bw, 14, 0xFF1F3A47);
            Draw.outline(g, bx, y + 4, bw, 14, 0x667FE8FF);
            g.drawString(f, names[i], bx + (bw - f.width(names[i])) / 2, y + 8, ACCENT, false);
            final int idx = i;
            regions.add(new Region(bx, y + 4, bw, 14, b -> { if (b == 0) action(idx); }, null));
        }
        y += 22;

        g.fill(x, y, x + PW, y + 16, ROW);
        if (!status.isEmpty() && System.currentTimeMillis() - statusTime < 4000)
            g.drawString(f, status, x + 8, y + 4, statusOk ? 0xFF7CFF8A : 0xFFFF6B6B, false);
        else g.drawString(f, "SAVED CONFIGS", x + 8, y + 4, DIM, false);
        y += 16;

        int maxScroll = Math.max(0, configs.size() - listRows);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        if (configs.isEmpty()) {
            g.fill(x, y, x + PW, y + 15, ROW);
            g.drawString(f, "none yet", x + 8, y + 4, DIM, false);
        }
        for (int i = 0; i < listRows; i++) {
            int idx = i + (int) scroll;
            int ry = y + i * 15;
            g.fill(x, ry, x + PW, ry + 15, ROW);
            if (idx >= configs.size()) continue;
            String c = configs.get(idx);
            boolean sel = c.equals(ConfigManager.clean(cfgName.value));
            boolean hov = mx >= x && mx < x + PW && my >= ry && my < ry + 15;
            if (hov) g.fill(x, ry, x + PW, ry + 15, 0x16FFFFFF);
            if (sel) g.fill(x, ry + 1, x + 2, ry + 14, ACCENT);
            g.drawString(f, c, x + 8, ry + 4, sel ? ACCENT : TEXT, false);
            regions.add(new Region(x, ry, PW, 15, b -> { if (b == 0) { cfgName.value = c; editing = false; } }, null));
        }
        y += listRows * 15 + 6;
        g.drawString(f, "ESC = BACK", (this.width - f.width("ESC = BACK")) / 2, y + 14, DIM, false);
    }

    private void action(int idx) {
        String name = ConfigManager.clean(cfgName.value);
        switch (idx) {
            case 0 -> { boolean ok = ConfigManager.save(name); say(ok ? "Saved " + name : "Save failed", ok); }
            case 1 -> { boolean ok = ConfigManager.load(name); say(ok ? "Loaded " + name : "No config named " + name, ok); }
            default -> { boolean ok = ConfigManager.delete(name); say(ok ? "Deleted " + name : "No config named " + name, ok); }
        }
        configs = ConfigManager.list();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        editing = false;
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (r.in(e.x(), e.y())) { if (r.click() != null) r.click().accept(e.button()); return true; }
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scroll -= (float) sy;
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (editing) {
            if (k == GLFW.GLFW_KEY_ENTER) { editing = false; action(0); }
            else if (k == GLFW.GLFW_KEY_ESCAPE) editing = false;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !cfgName.value.isEmpty())
                cfgName.value = cfgName.value.substring(0, cfgName.value.length() - 1);
            return true;
        }
        if (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (editing && cfgName.value.length() < 24) {
            cfgName.value += Character.toString(e.codepoint());
            return true;
        }
        return super.charTyped(e);
    }
}
