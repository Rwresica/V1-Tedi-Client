package dev.tedi.gui;

import dev.tedi.config.ConfigManager;
import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.ShareService;
import dev.tedi.util.Toasts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Config manager: save / load / delete, plus SHARE (get a code) and IMPORT (paste someone's code). */
public class ConfigScreen extends Screen {
    private static final int ACCENT = Colors.ACCENT, TEXT = 0xFFE4E6EA, DIM = Colors.DIM, BLUE = 0xFF4CC3F0;
    private static final int PANEL = 0xF0141519, ROW = 0xF00D0E11, FIELD = 0xFF08090B;
    private static final int PW = 236;

    private final Screen parent;
    private final List<Region> regions = new ArrayList<>();
    private final Setting.Str cfgName = new Setting.Str("Name", "default", 24);
    private final Setting.Str shareCode = new Setting.Str("Code", "", 20);
    private Setting.Str editing = cfgName;
    private List<String> configs = new ArrayList<>();
    private String status = "";
    private boolean statusOk;
    private long statusTime;
    private float scroll, openT;
    private boolean busy;
    private final Map<Object, Float> anim = new HashMap<>();
    private long lastNano = System.nanoTime();

    public ConfigScreen(Screen parent) {
        super(Component.literal("Configs"));
        this.parent = parent;
    }

    @Override protected void init() { configs = ConfigManager.list(); }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float dt) {}
    @Override public void onClose() { Minecraft.getInstance().setScreen(parent); }

    private void say(String s, boolean ok) { status = s; statusOk = ok; statusTime = System.currentTimeMillis(); }

    private float anim(Object key, float target, float dt) {
        float v = anim.getOrDefault(key, target);
        v += (target - v) * Math.min(1f, dt * 14f);
        anim.put(key, v);
        return v;
    }

    private void button(GuiGraphics g, Font f, int x, int y, int w, int h, String label, int mx, int my, float dt, int base, int text, Runnable run) {
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
        float a = anim(label + x + y, hov ? 1f : 0f, dt);
        Draw.roundR(g, x, y, w, h, 4, Colors.lerp(base, 0xFF2A4452, a));
        Draw.text(g, f, label, x + (w - Draw.width(f, label, true)) / 2, y + (h - 8) / 2, text, true);
        regions.add(new Region(x, y, w, h, b -> { if (b == 0 && !busy) run.run(); }, null));
    }

    private void field(GuiGraphics g, Font f, int x, int y, int w, Setting.Str s, String hint) {
        Draw.roundR(g, x, y, w, 13, 4, FIELD);
        boolean ed = editing == s;
        if (ed) Draw.outline(g, x, y, w, 13, 0x887FE8FF);
        String t = s.value;
        while (t.length() > 1 && f.width(t) > w - 10) t = t.substring(1);
        if (s.value.isEmpty() && !ed) g.drawString(f, hint, x + 5, y + 3, 0xFF4F5560, false);
        else g.drawString(f, t + (ed && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : ""), x + 5, y + 3, ed ? ACCENT : TEXT, false);
        regions.add(new Region(x, y, w, 13, b -> { if (b == 0) editing = s; }, null));
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        Font f = Minecraft.getInstance().font;
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNano) / 1e9f);
        lastNano = now;
        openT = Math.min(1f, openT + dt / 0.2f);
        float ease = 1f - (1f - openT) * (1f - openT) * (1f - openT);
        regions.clear();
        g.fillGradient(0, 0, this.width, this.height, Draw.alpha(0x90000000, ease), Draw.alpha(0x50000000, ease));

        int listRows = Math.max(3, Math.min(8, (this.height - 270) / 15));
        int h = 20 + 38 + 24 + 17 + listRows * 15 + 8 + 17 + 38 + 24 + 20;
        int x = (this.width - PW) / 2, y = Math.max(8, (this.height - h) / 2) + (int) ((1f - ease) * 10);
        Draw.roundR(g, x + 1, y + 2, PW, h, 6, 0x44000000);
        Draw.roundR(g, x, y, PW, h, 6, PANEL);
        Draw.text(g, f, "CONFIGS", x + (PW - Draw.width(f, "CONFIGS", true)) / 2, y + 6, ACCENT, true);
        y += 20;

        // ----- name + buttons -----
        g.fill(x, y, x + PW, y + 38, ROW);
        g.drawString(f, "CONFIG NAME", x + 9, y + 3, DIM, false);
        field(g, f, x + 9, y + 13, PW - 18, cfgName, "name");
        int bw = (PW - 18 - 8) / 3;
        y += 38;
        g.fill(x, y, x + PW, y + 24, ROW);
        button(g, f, x + 9, y + 3, bw, 16, "SAVE", mx, my, dt, 0xFF1B3340, ACCENT, () -> action(0));
        button(g, f, x + 9 + bw + 4, y + 3, bw, 16, "LOAD", mx, my, dt, 0xFF1B3340, ACCENT, () -> action(1));
        button(g, f, x + 9 + 2 * (bw + 4), y + 3, bw, 16, "DELETE", mx, my, dt, 0xFF3A2026, 0xFFFF8A8A, () -> action(2));
        y += 24;

        // ----- saved list -----
        g.fill(x, y, x + PW, y + 17, ROW);
        g.drawString(f, "SAVED CONFIGS  (" + configs.size() + ")", x + 9, y + 5, DIM, false);
        y += 17;
        int maxScroll = Math.max(0, configs.size() - listRows);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        for (int i = 0; i < listRows; i++) {
            int idx = i + (int) scroll, ry = y + i * 15;
            g.fill(x, ry, x + PW, ry + 15, ROW);
            if (idx >= configs.size()) { if (configs.isEmpty() && i == 0) g.drawString(f, "none yet", x + 9, ry + 4, 0xFF4F5560, false); continue; }
            String c = configs.get(idx);
            boolean sel = c.equals(ConfigManager.clean(cfgName.value));
            boolean hov = mx >= x && mx < x + PW && my >= ry && my < ry + 15;
            float ha = anim("row" + c, hov ? 1f : 0f, dt);
            if (ha > 0.01f) g.fill(x, ry, x + PW, ry + 15, Draw.alpha(0x22FFFFFF, ha));
            if (sel) g.fill(x, ry + 1, x + 2, ry + 14, ACCENT);
            Draw.text(g, f, c, x + 9, ry + 3, sel ? ACCENT : TEXT, true);
            regions.add(new Region(x, ry, PW, 15, b -> { if (b == 0) { cfgName.value = c; editing = cfgName; } }, null));
        }
        if (configs.size() > listRows) {
            int th = listRows * 15, kh = Math.max(10, th * listRows / configs.size());
            int ky = y + (int) ((th - kh) * (scroll / Math.max(1, maxScroll)));
            Draw.roundR(g, x + PW - 4, ky, 2, kh, 1, 0x66FFFFFF);
        }
        y += listRows * 15;
        g.fill(x, y, x + PW, y + 8, ROW);
        y += 8;

        // ----- share -----
        g.fill(x, y, x + PW, y + 17, ROW);
        g.fill(x + 9, y + 1, x + PW - 9, y + 2, 0x30FFFFFF);
        g.drawString(f, "SHARE A CONFIG", x + 9, y + 5, DIM, false);
        y += 17;
        g.fill(x, y, x + PW, y + 38, ROW);
        g.drawString(f, "SHARE CODE", x + 9, y + 3, DIM, false);
        field(g, f, x + 9, y + 13, PW - 18, shareCode, "paste a code here");
        y += 38;
        g.fill(x, y, x + PW, y + 24, ROW);
        int sw = (PW - 18 - 8) / 3;
        button(g, f, x + 9, y + 3, sw, 16, "SHARE", mx, my, dt, 0xFF1F3A2A, 0xFF7CFF8A, this::doShare);
        button(g, f, x + 9 + sw + 4, y + 3, sw, 16, "IMPORT", mx, my, dt, 0xFF1F3A2A, 0xFF7CFF8A, this::doImport);
        button(g, f, x + 9 + 2 * (sw + 4), y + 3, sw, 16, "COPY TEXT", mx, my, dt, 0xFF1B3340, ACCENT, this::copyText);
        y += 24;

        // ----- status -----
        g.fill(x, y, x + PW, y + 20, ROW);
        if (busy) Draw.text(g, f, "Working...", x + 9, y + 6, ACCENT, true);
        else if (!status.isEmpty() && System.currentTimeMillis() - statusTime < 6000)
            Draw.text(g, f, status, x + 9, y + 6, statusOk ? 0xFF7CFF8A : 0xFFFF6B6B, true);
        else g.drawString(f, "ESC = BACK   |   CTRL+V PASTES", x + 9, y + 6, 0xFF4F5560, false);
    }

    private void action(int idx) {
        String name = ConfigManager.clean(cfgName.value);
        switch (idx) {
            case 0 -> { boolean ok = ConfigManager.save(name); say(ok ? "Saved " + name : "Save failed", ok); if (ok) Toasts.push("Config Saved", name, 0xFF7CFF8A, "check"); }
            case 1 -> { boolean ok = ConfigManager.load(name); say(ok ? "Loaded " + name : "No config named " + name, ok); if (ok) Toasts.push("Config Loaded", name, 0xFF7FE8FF, "check"); }
            default -> { boolean ok = ConfigManager.delete(name); say(ok ? "Deleted " + name : "No config named " + name, ok); }
        }
        configs = ConfigManager.list();
    }

    private void doShare() {
        final String text = ConfigManager.exportText();
        busy = true;
        Thread t = new Thread(() -> {
            try {
                String code = ShareService.upload(text);
                Minecraft.getInstance().execute(() -> {
                    busy = false;
                    shareCode.value = code;
                    Minecraft.getInstance().keyboardHandler.setClipboard(code);
                    say("Code " + code + " (copied)", true);
                    Toasts.push("Config Shared", "Code: " + code + "  (copied)", 0xFF7CFF8A, "check");
                });
            } catch (Exception e) {
                Minecraft.getInstance().execute(() -> { busy = false; say("Share failed: " + e.getMessage(), false); });
            }
        }, "tedi-share");
        t.setDaemon(true);
        t.start();
    }

    private void doImport() {
        final String code = shareCode.value.trim();
        if (code.isEmpty()) { say("Paste a code first", false); return; }
        busy = true;
        Thread t = new Thread(() -> {
            try {
                String text = ShareService.download(code);
                Minecraft.getInstance().execute(() -> {
                    busy = false;
                    boolean ok = ConfigManager.importText(text);
                    say(ok ? "Imported config " + code : "That code is not a Tedi config", ok);
                    if (ok) Toasts.push("Config Imported", "Code: " + code, 0xFF7FE8FF, "check");
                });
            } catch (Exception e) {
                Minecraft.getInstance().execute(() -> { busy = false; say("Import failed: " + e.getMessage(), false); });
            }
        }, "tedi-import");
        t.setDaemon(true);
        t.start();
    }

    private void copyText() {
        Minecraft.getInstance().keyboardHandler.setClipboard(ConfigManager.exportText());
        say("Config text copied to clipboard", true);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        editing = null;
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (r.in(e.x(), e.y())) { if (r.click() != null) r.click().accept(e.button()); return true; }
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scroll -= (float) sy;
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (editing != null) {
            if (k == GLFW.GLFW_KEY_ENTER) { if (editing == cfgName) action(0); else doImport(); editing = null; }
            else if (k == GLFW.GLFW_KEY_ESCAPE) editing = null;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !editing.value.isEmpty())
                editing.value = editing.value.substring(0, editing.value.length() - 1);
            else if (k == GLFW.GLFW_KEY_V && (e.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0) {
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) {
                    String joined = editing.value + clip.trim();
                    editing.value = joined.substring(0, Math.min(editing.maxLen, joined.length()));
                }
            }
            return true;
        }
        if (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (editing != null && editing.value.length() < editing.maxLen) {
            editing.value += Character.toString(e.codepoint());
            return true;
        }
        return super.charTyped(e);
    }
}
