package dev.tedi.setting;

import dev.tedi.util.Colors;

import java.util.Locale;

public abstract class Setting {
    public final String name;
    protected Setting(String name) { this.name = name; }

    public static class Bool extends Setting {
        public boolean value;
        public Bool(String name, boolean value) { super(name); this.value = value; }
    }

    public static class Num extends Setting {
        public double value, min, max, step;
        public Num(String name, double value, double min, double max, double step) {
            super(name); this.value = value; this.min = min; this.max = max; this.step = step;
        }
        public float f() { return (float) value; }
        public int i() { return (int) Math.round(value); }
        public double ratio() { return (value - min) / (max - min); }
        public void setFromRatio(double r) {
            r = Math.max(0, Math.min(1, r));
            double v = min + (max - min) * r;
            if (step > 0) v = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, v));
        }
        public String text() {
            return step >= 1 ? String.valueOf((int) Math.round(value)) : String.format(Locale.ROOT, "%.2f", value);
        }
    }

    /** Free colour (hue 0-360, saturation 0-1, value 0-1) picked with a palette. */
    public static class Hue extends Setting {
        public double hue, sat, val;
        public boolean open; // GUI state only
        public Hue(String name, double hue) { this(name, hue, 0.75, 1.0); }
        public Hue(String name, double hue, double sat, double val) {
            super(name); this.hue = hue; this.sat = sat; this.val = val;
        }
        public int rgb() { return Colors.hsv(hue, sat, val); }
        public int argb() { return 0xFF000000 | rgb(); }
        public int argb(int alpha) { return (alpha << 24) | rgb(); }
    }

    public static class Str extends Setting {
        public String value;
        public Str(String name, String value) { super(name); this.value = value; }
    }

    /** A button inside a module's settings. */
    public static class Action extends Setting {
        public final Runnable run;
        public Action(String name, Runnable run) { super(name); this.run = run; }
    }
}
