package dev.tedi.setting;

import java.util.Locale;

public abstract class Setting {
    public final String name;
    protected Setting(String name) { this.name = name; }

    public static class Bool extends Setting {
        public boolean value;
        public Bool(String name, boolean value) { super(name); this.value = value; }
    }

    public static class Num extends Setting {
        public double value, min, max, step;
        public Num(String name, double value, double min, double max, double step) {
            super(name); this.value = value; this.min = min; this.max = max; this.step = step;
        }
        public float f() { return (float) value; }
        public int i() { return (int) Math.round(value); }
        public double ratio() { return (value - min) / (max - min); }
        public void setFromRatio(double r) {
            r = Math.max(0, Math.min(1, r));
            double v = min + (max - min) * r;
            if (step > 0) v = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, v));
        }
        public String text() {
            return step >= 1 ? String.valueOf((int) Math.round(value)) : String.format(Locale.ROOT, "%.2f", value);
        }
    }

    /** Colour picked with a hue slider (0-360). 360 = white. */
    public static class Hue extends Setting {
        public double hue;
        public Hue(String name, double hue) { super(name); this.hue = hue; }
        public int rgb() { return dev.tedi.util.Colors.hsv(hue); }
        public int argb() { return 0xFF000000 | rgb(); }
    }

    public static class Str extends Setting {
        public String value;
        public Str(String name, String value) { super(name); this.value = value; }
    }
}
