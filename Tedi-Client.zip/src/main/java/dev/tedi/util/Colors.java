package dev.tedi.util;

public final class Colors {
    public static final int ACCENT = 0xFF7FDBFF;   // light blue
    public static final int TEXT = 0xFFDCEFFF;
    public static final int DIM = 0xFF8FA3B5;

    private Colors() {}

    public static int hsv(double hue) {
        if (hue >= 359.5) return 0xFFFFFF;
        float h = (float) (hue / 60.0);
        int i = ((int) Math.floor(h)) % 6;
        float f = h - (float) Math.floor(h);
        float s = 0.75f, v = 1f;
        float p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        float r, g, b;
        switch (i) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}
