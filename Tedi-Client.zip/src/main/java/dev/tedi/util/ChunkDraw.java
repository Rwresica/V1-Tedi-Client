package dev.tedi.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Flagged-chunk markers: a flat, glossy plate with rounded corners (+ optional radar ripples). */
public final class ChunkDraw {
    private ChunkDraw() {}

    /** Rounded rectangle on the XZ plane at height y, as 3D points going around the edge. */
    private static double[] roundedRect(double x0, double z0, double x1, double z1, double r, double y, int seg) {
        int n = 4 * (seg + 1);
        double[] p = new double[n * 3];
        double[][] c = {{x1 - r, z0 + r, -90}, {x1 - r, z1 - r, 0}, {x0 + r, z1 - r, 90}, {x0 + r, z0 + r, 180}};
        int k = 0;
        for (double[] corner : c) {
            for (int i = 0; i <= seg; i++) {
                double a = Math.toRadians(corner[2] + 90.0 * i / seg);
                p[k++] = corner[0] + r * Math.cos(a);
                p[k++] = y;
                p[k++] = corner[1] + r * Math.sin(a);
            }
        }
        return p;
    }

    /**
     * Glossy rounded plate over a whole chunk. detail 0 = cheap (fill only), 1 = + border, 2 = + glow border.
     * rings > 0 adds expanding radar ripples in the middle.
     */
    public static void glass(GuiGraphics g, int cx, int cz, double y, int rgb, int alpha, int edgeArgb, int rings, int detail) {
        double x0 = cx * 16 + 0.4, z0 = cz * 16 + 0.4, x1 = cx * 16 + 15.6, z1 = cz * 16 + 15.6;
        int seg = 3;
        double[] outer = roundedRect(x0, z0, x1, z1, 3.4, y, seg);
        int n = outer.length / 3;
        Proj.poly(g, outer, n, (Math.max(0, Math.min(255, alpha)) << 24) | (rgb & 0xFFFFFF));
        // lighter inner plate = glass depth
        int lr = ((rgb >> 16 & 255) + 255 * 2) / 3, lg = ((rgb >> 8 & 255) + 255 * 2) / 3, lb = ((rgb & 255) + 255 * 2) / 3;
        double[] inner = roundedRect(x0 + 1.6, z0 + 1.6, x1 - 1.6, z1 - 1.6, 2.0, y + 0.02, seg);
        Proj.poly(g, inner, n, ((int) (alpha * 0.40) << 24) | (lr << 16) | (lg << 8) | lb);
        if (detail >= 1) {
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                if (detail >= 2) Proj.line3d(g, outer[i * 3], y, outer[i * 3 + 2], outer[j * 3], y, outer[j * 3 + 2], 3.2f, Draw.alpha(edgeArgb, 0.18f));
                Proj.line3d(g, outer[i * 3], y, outer[i * 3 + 2], outer[j * 3], y, outer[j * 3 + 2], 1.2f, edgeArgb);
            }
        }
        if (rings > 0) {
            double mx = cx * 16 + 8, mz = cz * 16 + 8;
            double t = (System.currentTimeMillis() % 3000) / 3000.0;
            int segs = 18;
            for (int k = 0; k < rings; k++) {
                double ph = (t + k / (double) rings) % 1.0;
                double rad = 0.8 + ph * 6.4;
                int col = Draw.alpha(edgeArgb, (float) (1.0 - ph));
                for (int i = 0; i < segs; i++) {
                    double a0 = Math.PI * 2 * i / segs, a1 = Math.PI * 2 * (i + 1) / segs;
                    Proj.line3d(g, mx + rad * Math.cos(a0), y + 0.03, mz + rad * Math.sin(a0),
                            mx + rad * Math.cos(a1), y + 0.03, mz + rad * Math.sin(a1), 1.1f, col);
                }
            }
        }
    }
}
