package dev.tedi.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Draws a flagged chunk as 4 translucent border walls + lines (never a filled volume). */
public final class ChunkDraw {
    private ChunkDraw() {}

    public static void draw(GuiGraphics g, Minecraft mc, int cx, int cz, double mid, boolean walls, int wallArgb,
                            boolean full, double height, boolean line, boolean vertical, float lw, int lineArgb) {
        double x0 = cx * 16, z0 = cz * 16, x1 = x0 + 16, z1 = z0 + 16;
        double lo, hi;
        if (full) { lo = mc.level.getMinY(); hi = lo + mc.level.getHeight(); }
        else { lo = mid - height / 2; hi = mid + height / 2; }
        if (walls) {
            Proj.quad(g, new double[]{x0, lo, z0, x1, lo, z0, x1, hi, z0, x0, hi, z0}, wallArgb);
            Proj.quad(g, new double[]{x0, lo, z1, x1, lo, z1, x1, hi, z1, x0, hi, z1}, wallArgb);
            Proj.quad(g, new double[]{x0, lo, z0, x0, lo, z1, x0, hi, z1, x0, hi, z0}, wallArgb);
            Proj.quad(g, new double[]{x1, lo, z0, x1, lo, z1, x1, hi, z1, x1, hi, z0}, wallArgb);
        }
        if (line) {
            Proj.line3d(g, x0, mid, z0, x1, mid, z0, lw, lineArgb);
            Proj.line3d(g, x1, mid, z0, x1, mid, z1, lw, lineArgb);
            Proj.line3d(g, x1, mid, z1, x0, mid, z1, lw, lineArgb);
            Proj.line3d(g, x0, mid, z1, x0, mid, z0, lw, lineArgb);
        }
        if (vertical) {
            Proj.line3d(g, x0, lo, z0, x0, hi, z0, lw, lineArgb);
            Proj.line3d(g, x1, lo, z0, x1, hi, z0, lw, lineArgb);
            Proj.line3d(g, x1, lo, z1, x1, hi, z1, lw, lineArgb);
            Proj.line3d(g, x0, lo, z1, x0, hi, z1, lw, lineArgb);
        }
    }
}
