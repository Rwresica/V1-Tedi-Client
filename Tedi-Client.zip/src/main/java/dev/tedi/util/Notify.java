package dev.tedi.util;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;

public final class Notify {
    private Notify() {}

    /** Posts a message to YOUR OWN Discord webhook (only discord webhook URLs are accepted). */
    public static void webhook(String url, String msg) {
        if (url == null) return;
        url = url.trim();
        if (!(url.startsWith("https://discord.com/api/webhooks/") || url.startsWith("https://discordapp.com/api/webhooks/"))) return;
        final String u = url;
        Thread t = new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) URI.create(u).toURL().openConnection();
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setConnectTimeout(5000);
                c.setReadTimeout(5000);
                c.setRequestProperty("Content-Type", "application/json");
                String body = "{\"content\":\"" + msg.replace("\\", "\\\\").replace("\"", "\\\"") + "\"}";
                try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
                c.getResponseCode();
                c.disconnect();
            } catch (Exception ignored) {}
        }, "tedi-webhook");
        t.setDaemon(true);
        t.start();
    }
}
