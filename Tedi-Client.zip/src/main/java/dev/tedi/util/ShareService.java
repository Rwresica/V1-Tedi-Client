package dev.tedi.util;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/** Uploads / downloads shared configs through dpaste.com. The "code" is the paste id. (Blocking: call off the main thread.) */
public final class ShareService {
    private ShareService() {}

    public static String upload(String text) throws Exception {
        HttpClient c = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
        String body = "content=" + URLEncoder.encode(text, StandardCharsets.UTF_8) + "&syntax=text&expiry_days=30";
        HttpRequest r = HttpRequest.newBuilder(URI.create("https://dpaste.com/api/v2/"))
                .timeout(Duration.ofSeconds(12))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .header("User-Agent", "TediClient")
                .POST(HttpRequest.BodyPublishers.ofString(body)).build();
        HttpResponse<String> resp = c.send(r, HttpResponse.BodyHandlers.ofString());
        String url = resp.body().trim();
        if (resp.statusCode() / 100 != 2 || !url.startsWith("http")) throw new IllegalStateException("upload failed (" + resp.statusCode() + ")");
        return url.substring(url.lastIndexOf('/') + 1);
    }

    public static String download(String code) throws Exception {
        if (!code.matches("[A-Za-z0-9]{3,20}")) throw new IllegalArgumentException("bad code");
        HttpClient c = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
        HttpRequest r = HttpRequest.newBuilder(URI.create("https://dpaste.com/" + code + ".txt"))
                .timeout(Duration.ofSeconds(12)).header("User-Agent", "TediClient").GET().build();
        HttpResponse<String> resp = c.send(r, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() / 100 != 2) throw new IllegalStateException("code not found");
        return resp.body();
    }
}
