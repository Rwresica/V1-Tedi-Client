package dev.tedi.util;

import dev.tedi.module.Freecam;
import dev.tedi.module.Freelook;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** World -> GUI-screen projection so ESP / tracers / fills / nametags can be drawn in 2D. */
public final class Proj {
    public static double cx, cy, cz, px, py;
    private static double fx, fy, fz, rx, rz, ux, uy, uz, tanHalf, aspect, tx, ty, tz;
    private static int w, h;
    private static final double NEAR = 0.05;

    private Proj() {}

    public static void begin(Minecraft mc, GuiGraphics g, float pt) {
        double yaw, pitch;
        if (Freecam.active()) {
            Vec3 p = Freecam.I.renderPos(pt);
            cx = p.x; cy = p.y; cz = p.z;
            yaw = Freecam.I.yaw; pitch = Freecam.I.pitch;
        } else if (Freelook.active()) {
            Vec3 p = Freelook.I.camPos(mc, pt);
            cx = p.x; cy = p.y; cz = p.z;
            yaw = Freelook.I.yaw; pitch = Freelook.I.pitch;
        } else {
            Vec3 p = mc.player.getEyePosition(pt);
            cx = p.x; cy = p.y; cz = p.z;
            yaw = mc.player.getViewYRot(pt); pitch = mc.player.getViewXRot(pt);
        }
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        fx = -Math.sin(yr) * Math.cos(pr);
        fy = -Math.sin(pr);
        fz = Math.cos(yr) * Math.cos(pr);
        rx = -Math.cos(yr);
        rz = -Math.sin(yr);
        ux = -rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy;
        double fov = mc.options.fov().get();
        tanHalf = Math.tan(Math.toRadians(fov) / 2.0);
        w = g.guiWidth(); h = g.guiHeight();
        aspect = (double) w / (double) h;
    }

    private static void toCam(double x, double y, double z) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        tx = dx * rx + dz * rz;
        ty = dx * ux + dy * uy + dz * uz;
        tz = dx * fx + dy * fy + dz * fz;
    }

    private static double sx(double xx, double zz) { return w / 2.0 + (xx / zz) / (tanHalf * aspect) * (w / 2.0); }
    private static double sy(double yy, double zz) { return h / 2.0 - (yy / zz) / tanHalf * (h / 2.0); }

    /** Result goes to px/py. Returns false if the point is behind the camera. */
    public static boolean project(double x, double y, double z) {
        toCam(x, y, z);
        if (tz < NEAR) return false;
        px = sx(tx, tz);
        py = sy(ty, tz);
        return true;
    }

    /** 2D line (clipped to the screen). */
    public static void line(GuiGraphics g, double x1, double y1, double x2, double y2, float width, int argb) {
        double minX = -20, minY = -20, maxX = w + 20, maxY = h + 20;
        double dx = x2 - x1, dy = y2 - y1, t0 = 0, t1 = 1;
        double[] p = {-dx, dx, -dy, dy};
        double[] q = {x1 - minX, maxX - x1, y1 - minY, maxY - y1};
        for (int i = 0; i < 4; i++) {
            if (p[i] == 0) { if (q[i] < 0) return; }
            else {
                double r = q[i] / p[i];
                if (p[i] < 0) { if (r > t1) return; if (r > t0) t0 = r; }
                else { if (r < t0) return; if (r < t1) t1 = r; }
            }
        }
        double ax = x1 + t0 * dx, ay = y1 + t0 * dy, bx = x1 + t1 * dx, by = y1 + t1 * dy;
        float len = (float) Math.hypot(bx - ax, by - ay);
        if (len < 0.5f) return;
        var ps = g.pose();
        ps.pushMatrix();
        ps.translate((float) ax, (float) ay);
        ps.rotate((float) Math.atan2(dy, dx));
        ps.translate(0f, -width / 2f);
        ps.scale(1f, width);
        g.fill(0, 0, (int) Math.ceil(len), 1, argb);
        ps.popMatrix();
    }

    /** 3D line, clipped against the camera so it works even when one end is behind you. */
    public static void line3d(GuiGraphics g, double x1, double y1, double z1, double x2, double y2, double z2, float width, int argb) {
        toCam(x1, y1, z1);
        double ax = tx, ay = ty, az = tz;
        toCam(x2, y2, z2);
        double bx = tx, by = ty, bz = tz;
        if (az < NEAR && bz < NEAR) return;
        if (az < NEAR) { double t = (NEAR - az) / (bz - az); ax += (bx - ax) * t; ay += (by - ay) * t; az = NEAR; }
        else if (bz < NEAR) { double t = (NEAR - bz) / (az - bz); bx += (ax - bx) * t; by += (ay - by) * t; bz = NEAR; }
        line(g, sx(ax, az), sy(ay, az), sx(bx, bz), sy(by, bz), width, argb);
    }

    public static void box(GuiGraphics g, AABB b, float width, int argb) {
        for (int i = 0; i < 8; i++) {
            for (int bit = 1; bit <= 4; bit <<= 1) {
                if ((i & bit) == 0) {
                    int j = i | bit;
                    line3d(g,
                            (i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ,
                            (j & 1) == 0 ? b.minX : b.maxX, (j & 2) == 0 ? b.minY : b.maxY, (j & 4) == 0 ? b.minZ : b.maxZ,
                            width, argb);
                }
            }
        }
    }

    /** Solid fill of a whole block / box (silhouette of the projected cube). */
    public static void fillBox(GuiGraphics g, AABB b, int argb) {
        double[] xs = new double[8], ys = new double[8];
        for (int i = 0; i < 8; i++) {
            toCam((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            if (tz < NEAR) return;
            xs[i] = sx(tx, tz); ys[i] = sy(ty, tz);
        }
        int[] idx = {0, 1, 2, 3, 4, 5, 6, 7};
        for (int i = 1; i < 8; i++) {
            int v = idx[i], j = i - 1;
            while (j >= 0 && (xs[idx[j]] > xs[v] || (xs[idx[j]] == xs[v] && ys[idx[j]] > ys[v]))) { idx[j + 1] = idx[j]; j--; }
            idx[j + 1] = v;
        }
        double[] hx = new double[17], hy = new double[17];
        int k = 0;
        for (int ii = 0; ii < 8; ii++) {
            int i = idx[ii];
            while (k >= 2 && cross(hx[k - 2], hy[k - 2], hx[k - 1], hy[k - 1], xs[i], ys[i]) <= 0) k--;
            hx[k] = xs[i]; hy[k] = ys[i]; k++;
        }
        int lower = k + 1;
        for (int ii = 6; ii >= 0; ii--) {
            int i = idx[ii];
            while (k >= lower && cross(hx[k - 2], hy[k - 2], hx[k - 1], hy[k - 1], xs[i], ys[i]) <= 0) k--;
            hx[k] = xs[i]; hy[k] = ys[i]; k++;
        }
        k--;
        if (k >= 3) fillConvex(g, hx, hy, k, argb);
    }

    /** Filled vertical (or any) quad from 4 world points; skipped if any corner is behind the camera. */
    public static void quad(GuiGraphics g, double[] p, int argb) {
        double[] xs = new double[4], ys = new double[4];
        for (int i = 0; i < 4; i++) {
            toCam(p[i * 3], p[i * 3 + 1], p[i * 3 + 2]);
            if (tz < NEAR) return;
            xs[i] = sx(tx, tz); ys[i] = sy(ty, tz);
        }
        fillConvex(g, xs, ys, 4, argb);
    }

    private static double cross(double ax, double ay, double bx, double by, double cx, double cy) {
        return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
    }

    private static void fillConvex(GuiGraphics g, double[] xs, double[] ys, int n, int argb) {
        double minY = Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < n; i++) { minY = Math.min(minY, ys[i]); maxY = Math.max(maxY, ys[i]); }
        int y0 = (int) Math.max(Math.ceil(minY), 0), y1 = (int) Math.min(Math.floor(maxY), h - 1);
        if (y1 - y0 > 700) return;
        for (int y = y0; y <= y1; y++) {
            double yc = y + 0.5, lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                double ya = ys[i], yb = ys[j];
                if ((ya <= yc && yb > yc) || (yb <= yc && ya > yc)) {
                    double x = xs[i] + (yc - ya) / (yb - ya) * (xs[j] - xs[i]);
                    lo = Math.min(lo, x); hi = Math.max(hi, x);
                }
            }
            if (hi > lo) {
                int xl = (int) Math.max(lo, 0), xr = (int) Math.min(hi, w);
                if (xr > xl) g.fill(xl, y, xr, y + 1, argb);
            }
        }
    }

    public static void label(GuiGraphics g, String text, double x, double y, int argb) {
        Font f = Minecraft.getInstance().font;
        int tw = f.width(text);
        int ix = (int) x - tw / 2, iy = (int) y - 4;
        g.fill(ix - 2, iy - 2, ix + tw + 2, iy + 10, 0x90000000);
        g.drawString(f, text, ix, iy, argb, false);
    }
}
