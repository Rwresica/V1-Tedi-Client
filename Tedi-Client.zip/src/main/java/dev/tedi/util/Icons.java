package dev.tedi.util;

import net.minecraft.client.gui.GuiGraphics;

import java.util.HashMap;
import java.util.Map;

/** Tiny 9x9 pixel icons for the HUD pills. */
public final class Icons {
    private static final Map<String, String[]> MAP = new HashMap<>();
    static {
        MAP.put("fps", new String[]{"..#.#.#..", ".#.....#.", "#.......#", ".........", "#.......#", ".........", "#.......#", ".#.....#.", "..#.#.#.."});
        MAP.put("clock", new String[]{"..#####..", ".#.....#.", "#...#...#", "#...#...#", "#...###.#", "#.......#", "#.......#", ".#.....#.", "..#####.."});
        MAP.put("bps", new String[]{".........", "#..#.....", ".#..#....", "..#..#...", "...#..#..", "..#..#...", ".#..#....", "#..#.....", "........."});
        MAP.put("coords", new String[]{"..#####..", ".#.....#.", "#.......#", "#...#...#", "#..###..#", "#...#...#", "#.......#", ".#.....#.", "..#####.."});
        MAP.put("ping", new String[]{".........", "......#..", "......#..", "....#.#..", "....#.#..", "..#.#.#..", "..#.#.#..", "#.#.#.#..", "#.#.#.#.."});
        MAP.put("user", new String[]{"...###...", "..#####..", "..#####..", "...###...", ".........", ".#######.", "#########", "#########", "........."});
        MAP.put("cps", new String[]{"#........", "##.......", "###......", "####.....", "#####....", "######...", "###......", "#.##.....", "...#....."});
        MAP.put("check", new String[]{".........", "........#.", "......##..", "#....##...", "##..##....", ".####.....", "..##......", ".........", "........."});
        MAP.put("cross", new String[]{"#.......#", ".#.....#.", "..#...#..", "...#.#...", "....#....", "...#.#...", "..#...#..", ".#.....#.", "#.......#"});
        MAP.put("alert", new String[]{"....#....", "...###...", "...###...", "...###...", "....#....", "....#....", ".........", "....#....", "....#...."});
        MAP.put("keys", new String[]{"#########", "#.......#", "#.#.#.#.#", "#.......#", "#.#####.#", "#.......#", "#########", ".........", "........."});
    }

    private Icons() {}

    public static void draw(GuiGraphics g, String name, int x, int y, int color) {
        String[] rows = MAP.get(name);
        if (rows == null) return;
        for (int r = 0; r < rows.length; r++) {
            String row = rows[r];
            int start = -1;
            for (int c = 0; c <= row.length(); c++) {
                boolean on = c < row.length() && row.charAt(c) == '#';
                if (on && start < 0) start = c;
                if (!on && start >= 0) { g.fill(x + start, y + r, x + c, y + r + 1, color); start = -1; }
            }
        }
    }
}
