package dev.tedi.util;

import dev.tedi.module.Hud;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Slide-in notifications in the bottom-right corner (big bold title, coloured status, big icon). */
public final class Toasts {
    public static boolean mute;

    private static class T {
        String title, text, icon; int color; long born, life;
    }
    private static final List<T> LIST = new ArrayList<>();

    private Toasts() {}

    private static boolean enabled() { return Hud.I == null || Hud.I.toasts.value; }

    public static void push(String title, String text, int color, String icon) {
        if (mute || !enabled()) return;
        T t = new T();
        t.title = title.toUpperCase(Locale.ROOT); t.text = text.toUpperCase(Locale.ROOT); t.color = color; t.icon = icon;
        t.born = System.currentTimeMillis(); t.life = 3600;
        LIST.add(t);
        while (LIST.size() > 5) LIST.remove(0);
    }

    public static void moduleToggled(String name, boolean on, String category) {
        push(name, on ? "Enabled" : "Disabled", on ? 0xFF7CFF8A : 0xFFFF6B6B, category.toLowerCase(Locale.ROOT));
    }

    public static void render(GuiGraphics g, Font f) {
        long now = System.currentTimeMillis();
        LIST.removeIf(t -> now - t.born > t.life);
        int W = g.guiWidth(), H = g.guiHeight();
        int y = H - 10;
        var ps = g.pose();
        for (int i = LIST.size() - 1; i >= 0; i--) {
            T t = LIST.get(i);
            long age = now - t.born;
            float in = Math.min(1f, age / 280f);
            in = 1f - (1f - in) * (1f - in) * (1f - in);
            float out = Math.min(1f, (t.life - age) / 300f);
            float a = in * out;
            int tw = (int) (Draw.width(f, t.title, true) * 1.15f), sw = Draw.width(f, t.text, true);
            int w = Math.max(150, 46 + Math.max(tw, sw) + 14), h = 37;
            int x = W - w - 8 + (int) ((1f - in) * (w + 16));
            y -= h + 5;
            Draw.shadow(g, x, y, w, h, 7);
            Draw.roundR(g, x, y, w, h, 7, Draw.alpha(0xEE0E1220, a));
            g.fill(x + 6, y, x + w - 6, y + 1, Draw.alpha(0x30FFFFFF, a));
            g.fill(x + 3, y + 7, x + 6, y + h - 7, Draw.alpha(t.color, a));
            Draw.roundR(g, x + 11, y + 7, 23, 23, 7, Draw.alpha((0x3A << 24) | (t.color & 0xFFFFFF), a));
            ps.pushMatrix();
            ps.translate(x + 14f, y + 10f);
            ps.scale(1.8f, 1.8f);
            Icons.draw(g, t.icon, 0, 0, Draw.alpha(t.color, a));
            ps.popMatrix();
            ps.pushMatrix();
            ps.translate(x + 42f, y + 8f);
            ps.scale(1.15f, 1.15f);
            Draw.text(g, f, t.title, 0, 0, Draw.alpha(0xFFFFFFFF, a), true);
            ps.popMatrix();
            Draw.text(g, f, t.text, x + 42, y + 22, Draw.alpha(t.color, a), true);
            float p = Math.max(0f, 1f - (float) age / t.life);
            g.fill(x + 10, y + h - 3, x + 10 + (int) ((w - 20) * p), y + h - 2, Draw.alpha(t.color, a * 0.7f));
        }
    }
}
