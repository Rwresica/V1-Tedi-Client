package dev.tedi.util;

import dev.tedi.module.Hud;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/** Slide-in notifications in the bottom-right corner. */
public final class Toasts {
    public static boolean mute;

    private static class T {
        String title, text, icon; int color; long born, life;
    }
    private static final List<T> LIST = new ArrayList<>();

    private Toasts() {}

    private static boolean enabled() { return Hud.I == null || Hud.I.toasts.value; }

    public static void push(String title, String text, int color, String icon) {
        if (mute || !enabled()) return;
        T t = new T();
        t.title = title; t.text = text; t.color = color; t.icon = icon;
        t.born = System.currentTimeMillis(); t.life = 3600;
        LIST.add(t);
        while (LIST.size() > 5) LIST.remove(0);
    }

    public static void moduleToggled(String name, boolean on) {
        push(name, on ? "Enabled" : "Disabled", on ? 0xFF7CFF8A : 0xFFFF6B6B, on ? "check" : "cross");
    }

    public static void render(GuiGraphics g, Font f) {
        long now = System.currentTimeMillis();
        LIST.removeIf(t -> now - t.born > t.life);
        int W = g.guiWidth(), H = g.guiHeight();
        int y = H - 10;
        for (int i = LIST.size() - 1; i >= 0; i--) {
            T t = LIST.get(i);
            long age = now - t.born;
            float in = Math.min(1f, age / 260f);
            in = 1f - (1f - in) * (1f - in) * (1f - in);
            float out = Math.min(1f, (t.life - age) / 300f);
            float a = in * out;
            int tw = Math.max(Draw.width(f, t.title, true), f.width(t.text));
            int w = Math.max(124, tw + 46), h = 27;
            int x = W - w - 8 + (int) ((1f - in) * (w + 16));
            y -= h + 4;
            Draw.roundR(g, x + 1, y + 2, w, h, 6, Draw.alpha(0x55000000, a));
            Draw.roundR(g, x, y, w, h, 6, Draw.alpha(0xE8121318, a));
            g.fill(x + 1, y + 7, x + 3, y + h - 7, Draw.alpha(t.color, a));
            Draw.roundR(g, x + 8, y + 6, 15, 15, 4, Draw.alpha((0x38 << 24) | (t.color & 0xFFFFFF), a));
            Icons.draw(g, t.icon, x + 11, y + 9, Draw.alpha(t.color, a));
            Draw.text(g, f, t.title, x + 29, y + 5, Draw.alpha(0xFFFFFFFF, a), true);
            Draw.text(g, f, t.text, x + 29, y + 16, Draw.alpha(0xFFA9B0BA, a), false);
            float p = Math.max(0f, 1f - (float) age / t.life);
            g.fill(x + 8, y + h - 3, x + 8 + (int) ((w - 16) * p), y + h - 2, Draw.alpha(t.color, a * 0.75f));
        }
    }
}
