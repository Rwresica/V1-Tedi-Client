package dev.tedi.util;

import dev.tedi.module.Hud;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Slide-in notifications (bottom-right). They glide into place when another one disappears. */
public final class Toasts {
    public static boolean mute;

    private static class T {
        String title, text, icon; int color; long born, life; float y = Float.NaN;
    }
    private static final List<T> LIST = new ArrayList<>();
    private static long lastNano = System.nanoTime();

    private Toasts() {}

    private static boolean enabled() { return Hud.I == null || Hud.I.toasts.value; }

    public static void push(String title, String text, int color, String icon) {
        if (mute || !enabled()) return;
        T t = new T();
        t.title = title.toUpperCase(Locale.ROOT); t.text = text.toUpperCase(Locale.ROOT); t.color = color; t.icon = icon;
        t.born = System.currentTimeMillis(); t.life = 3600;
        LIST.add(t);
        while (LIST.size() > 5) LIST.remove(0);
    }

    public static void moduleToggled(String name, boolean on, String category) {
        push(name, on ? "Enabled" : "Disabled", on ? 0xFF7CFF8A : 0xFFFF6B6B, category.toLowerCase(Locale.ROOT));
    }

    public static void render(GuiGraphics g, Font f) {
        long now = System.currentTimeMillis();
        long nn = System.nanoTime();
        float dt = Math.min(0.05f, (nn - lastNano) / 1e9f);
        lastNano = nn;
        LIST.removeIf(t -> now - t.born > t.life);
        int W = g.guiWidth(), H = g.guiHeight();
        float k = 1f - (float) Math.exp(-dt * 14.0);
        var ps = g.pose();
        float ty = H - 10;
        for (int i = LIST.size() - 1; i >= 0; i--) {
            T t = LIST.get(i);
            int tw = (int) (Draw.width(f, t.title, true) * 1.15f), sw = Draw.width(f, t.text, true);
            int w = Math.max(150, 46 + Math.max(tw, sw) + 14), h = 37;
            ty -= h + 5;
            if (Float.isNaN(t.y)) t.y = ty;
            t.y += (ty - t.y) * k;
            long age = now - t.born;
            float in = Draw.easeOutBack(Math.min(1f, age / 340f));
            float out = Math.min(1f, (t.life - age) / 300f);
            float a = Math.min(1f, Math.min(1f, age / 180f) * out);
            int x = W - w - 8 + (int) ((1f - Math.min(1f, in)) * (w + 16)), y = Math.round(t.y);
            Draw.panel(g, x, y, w, h, 9, 0xEE0E1220, 0x30FFFFFF, a);
            g.fill(x + 3, y + 8, x + 6, y + h - 8, Draw.alpha(t.color, a));
            Draw.roundR(g, x + 11, y + 7, 23, 23, 8, Draw.alpha((0x3A << 24) | (t.color & 0xFFFFFF), a));
            ps.pushMatrix();
            ps.translate(x + 14f, y + 10f);
            ps.scale(1.8f, 1.8f);
            Icons.draw(g, t.icon, 0, 0, Draw.alpha(t.color, a));
            ps.popMatrix();
            ps.pushMatrix();
            ps.translate(x + 42f, y + 8f);
            ps.scale(1.15f, 1.15f);
            Draw.text(g, f, t.title, 0, 0, Draw.alpha(0xFFFFFFFF, a), true);
            ps.popMatrix();
            Draw.text(g, f, t.text, x + 42, y + 22, Draw.alpha(t.color, a), true);
            float p = Math.max(0f, 1f - (float) age / t.life);
            Draw.roundR(g, x + 10, y + h - 4, Math.max(2, (int) ((w - 20) * p)), 2, 1, Draw.alpha(t.color, a * 0.75f));
        }
    }
}
