package dev.tedi.util;

import dev.tedi.module.Hud;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Notification pills (anchored at the Notifications HUD element - move / resize it with T).
 * Look: dark navy pill, coloured bar on the left, the module's item as the icon, white title, coloured status.
 */
public final class Toasts {
    public static boolean mute;
    public static final int CW = 196, CH = 38;

    private static class T {
        String title, text, icon; ItemStack stack; int color; long born, life; float y = Float.NaN;
    }
    private static final List<T> LIST = new ArrayList<>();
    private static long lastNano = System.nanoTime();

    private Toasts() {}

    private static boolean enabled() { return Hud.I == null || Hud.I.toasts.value; }

    private static Item iconItem(String module) {
        return switch (module) {
            case "StorageESP" -> Items.CHEST;
            case "BlockESP" -> Items.DIAMOND_ORE;
            case "PlayerESP" -> Items.PLAYER_HEAD;
            case "Fullbright" -> Items.SEA_LANTERN;
            case "Freecam" -> Items.ENDER_EYE;
            case "Freelook" -> Items.SPYGLASS;
            case "SpawnerBeam" -> Items.SPAWNER;
            case "SusChunk" -> Items.COMPASS;
            case "PlayerDetection" -> Items.SKELETON_SKULL;
            case "AutoTotem" -> Items.TOTEM_OF_UNDYING;
            case "CrystalOptimizer" -> Items.END_CRYSTAL;
            case "AnchorMacro" -> Items.RESPAWN_ANCHOR;
            case "TriggerBot" -> Items.IRON_SWORD;
            case "ShieldBreaker" -> Items.SHIELD;
            case "AutoJumpReset" -> Items.FEATHER;
            case "AutoWeapon" -> Items.DIAMOND_SWORD;
            case "NameProtect" -> Items.NAME_TAG;
            case "FastPlace" -> Items.GRASS_BLOCK;
            case "AutoTool" -> Items.DIAMOND_PICKAXE;
            case "CustomFOV" -> Items.ENDER_PEARL;
            case "CustomCrosshair" -> Items.TARGET;
            case "HUD" -> Items.PAINTING;
            case "TediClient+" -> Items.NETHER_STAR;
            default -> null;
        };
    }

    public static void push(String title, String text, int color, String icon) {
        push(title, text, color, icon, null);
    }

    public static void push(String title, String text, int color, String icon, ItemStack stack) {
        if (mute || !enabled()) return;
        T t = new T();
        t.title = title.toUpperCase(Locale.ROOT); t.text = text.toUpperCase(Locale.ROOT); t.color = color; t.icon = icon; t.stack = stack;
        t.born = System.currentTimeMillis(); t.life = 3800;
        LIST.add(t);
        while (LIST.size() > 5) LIST.remove(0);
    }

    public static void moduleToggled(String name, boolean on, String category) {
        Item it = iconItem(name);
        push(name, on ? "Enabled" : "Disabled", on ? 0xFF3FD07A : 0xFFFF5A74, category.toLowerCase(Locale.ROOT),
                it != null ? new ItemStack(it) : null);
    }

    private static String clip(Font f, String s, int maxW) {
        if (Draw.w(f, s) <= maxW) return s;
        while (s.length() > 1 && Draw.w(f, s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private static void card(GuiGraphics g, Font f, int x, int y, float a, T t, float prog, boolean preview) {
        int tint = t.color & 0xFFFFFF;
        Draw.panel(g, x, y, CW, CH, 17, Colors.NAVY, Colors.NAVY_BORDER, a);
        g.fillGradient(x + 8, y + 2, x + CW - 8, y + CH / 2, Draw.alpha(0x14FFFFFF, a), 0x00000000);
        // coloured bar (like the reference)
        Draw.roundR(g, x + 12, y + 9, 3, CH - 18, 1, Draw.alpha(t.color, a));
        // icon: the module's item, or a pixel icon
        var ps = g.pose();
        if (t.stack != null) {
            if (a > 0.4f) {
                ps.pushMatrix();
                ps.translate(x + 25f, y + 8f);
                ps.scale(1.375f, 1.375f);
                g.renderItem(t.stack, 0, 0);
                ps.popMatrix();
            }
        } else {
            ps.pushMatrix();
            ps.translate(x + 27f, y + 10f);
            ps.scale(2f, 2f);
            Icons.draw(g, t.icon, 0, 0, Draw.alpha(t.color, a));
            ps.popMatrix();
        }
        int tx = x + 54;
        Draw.str(g, f, clip(f, t.title, CW - 66), tx, y + 9, Draw.alpha(0xFFFFFFFF, a), false);
        Draw.str(g, f, clip(f, t.text, CW - 66), tx, y + 21, Draw.alpha(t.color, a), false);
    }

    public static void render(GuiGraphics g, Font f, boolean editPreview) {
        Hud hud = Hud.I;
        if (hud == null || hud.toastEl.x < 0) return;
        long now = System.currentTimeMillis();
        long nn = System.nanoTime();
        float dt = Math.min(0.05f, (nn - lastNano) / 1e9f);
        lastNano = nn;
        LIST.removeIf(t -> now - t.born > t.life);
        float k = 1f - (float) Math.exp(-dt * 14.0);
        var ps = g.pose();
        ps.pushMatrix();
        ps.translate(hud.toastEl.x, hud.toastEl.y);
        ps.scale(hud.toastEl.scale, hud.toastEl.scale);
        float ty = 0;
        for (int i = LIST.size() - 1; i >= 0; i--) {
            T t = LIST.get(i);
            ty -= CH + 6;
            if (Float.isNaN(t.y)) t.y = ty;
            t.y += (ty - t.y) * k;
            long age = now - t.born;
            float in = Draw.easeOutBack(Math.min(1f, age / 360f));
            float out = Math.min(1f, (t.life - age) / 320f);
            float a = Math.min(1f, Math.min(1f, age / 200f) * out);
            int x = -CW + (int) ((1f - Math.min(1f, in)) * (CW + 24));
            card(g, f, x, Math.round(t.y), a, t, 0f, false);
        }
        if (editPreview && LIST.isEmpty()) {
            T t = new T();
            t.title = "NOTIFICATION"; t.text = "PREVIEW"; t.color = 0xFF3FD07A; t.icon = "client";
            t.stack = new ItemStack(Items.NETHER_STAR);
            card(g, f, -CW, -CH - 6, 0.95f, t, 0f, true);
        }
        ps.popMatrix();
    }
}
