package dev.tedi.util;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.chat.Style;

public final class Draw {
    private Draw() {}

    /** Rectangle with cut corners (looks rounded). */
    public static void round(GuiGraphics g, int x, int y, int w, int h, int c) {
        if (w < 3 || h < 3) { g.fill(x, y, x + w, y + h, c); return; }
        g.fill(x + 1, y, x + w - 1, y + h, c);
        g.fill(x, y + 1, x + 1, y + h - 1, c);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, c);
    }

    public static void outline(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    /** Multiplies the alpha of an ARGB colour. */
    public static int alpha(int argb, float a) {
        a = Math.max(0f, Math.min(1f, a));
        int al = (int) (((argb >>> 24) & 255) * a);
        return (al << 24) | (argb & 0xFFFFFF);
    }

    // ------------------------------------------------------------------ Bungee font
    private static Style STYLE;
    private static boolean styleTried;
    private static final java.util.Map<String, Component> COMP = new java.util.HashMap<>();
    private static final java.util.Map<String, Integer> WID = new java.util.HashMap<>();

    /** The "tedi_client:bungee" font as a Style (built from JSON so no font-API names are needed). Falls back to vanilla if it did not load. */
    private static Style style(Font f) {
        if (!styleTried) {
            styleTried = true;
            try {
                JsonObject o = new JsonObject();
                o.addProperty("text", "");
                o.addProperty("font", "tedi_client:bungee");
                Component c = ComponentSerialization.CODEC.parse(JsonOps.INSTANCE, o).result().orElse(null);
                if (c != null) {
                    Style st = c.getStyle();
                    int wi = f.width(Component.literal("i").withStyle(st)), ww = f.width(Component.literal("W").withStyle(st));
                    if (wi > 0 && wi != ww) STYLE = st;      // missing-font glyphs all have the same width -> then use vanilla
                }
            } catch (Throwable ignored) {}
        }
        return STYLE;
    }

    private static Component comp(Font f, String s) {
        Style st = style(f);
        if (st == null) return null;
        Component c = COMP.get(s);
        if (c == null) {
            if (COMP.size() > 900) { COMP.clear(); WID.clear(); }
            c = Component.literal(s).withStyle(st);
            COMP.put(s, c);
        }
        return c;
    }

    private static boolean warmed;

    private static void warm(GuiGraphics g, Font f) {
        warmed = true;
        Component c = comp(f, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 .,:;!?+-_/\\|()[]%&*#@<>=~'\"");
        if (c != null) g.drawString(f, c, 2, 2, 0x05FFFFFF, false);
    }

    /** Draw text in the client font (Bungee). Same arguments as GuiGraphics.drawString. */
    public static void str(GuiGraphics g, Font f, String s, int x, int y, int color, boolean shadow) {
        if (((color >>> 24) & 255) < 5) return;
        if (!warmed) warm(g, f);
        Component c = comp(f, s);
        if (c != null) g.drawString(f, c, x, y, color, shadow);
        else g.drawString(f, s, x, y, color, shadow);
    }

    /** Text width in the client font. */
    public static int w(Font f, String s) {
        Component c = comp(f, s);
        if (c == null) return f.width(s);
        Integer w = WID.get(s);
        if (w == null) { w = f.width(c); WID.put(s, w); }
        return w;
    }

    public static void text(GuiGraphics g, Font f, String s, int x, int y, int color, boolean bold) {
        str(g, f, s, x, y, color, false);
    }

    public static int width(Font f, String s, boolean bold) { return w(f, s); }

    // ---- easing ----
    public static float easeOut(float t) { t = Math.max(0f, Math.min(1f, t)); return 1f - (1f - t) * (1f - t) * (1f - t); }
    public static float smooth(float t) { t = Math.max(0f, Math.min(1f, t)); return t * t * (3f - 2f * t); }
    public static float easeOutBack(float t) {
        t = Math.max(0f, Math.min(1f, t));
        float c1 = 1.70158f, c3 = c1 + 1f, u = t - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    /** Soft dark panel with a faint top highlight (used by every HUD element). */
    public static void softPanel(GuiGraphics g, int x, int y, int w, int h, int accent, float a) {
        round(g, x + 1, y + 1, w, h, alpha(0x55000000, a));
        round(g, x, y, w, h, alpha(0xD2141519, a));
        g.fillGradient(x + 1, y + 1, x + w - 1, y + 1 + h / 2, alpha(0x16FFFFFF, a), 0x00000000);
        g.fill(x, y + 1, x + 2, y + h - 1, alpha(accent, a));
    }

    private static final java.util.Map<Integer, int[]> PROFILE = new java.util.HashMap<>();

    /** Corner profile for radius r as runs of rows with the same inset: [firstRow, rowCount, inset, aaLevel(0..4)] ... */
    private static int[] profile(int r) {
        int[] p = PROFILE.get(r);
        if (p != null) return p;
        java.util.List<int[]> segs = new java.util.ArrayList<>();
        int[] cur = null;
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            double xe = r - Math.sqrt(r * r - dy * dy);
            int inset = (int) Math.ceil(xe);
            double cov = inset - xe;
            int lvl = (inset > 0 && cov > 0.18) ? Math.max(1, Math.min(4, (int) Math.round(cov * 4))) : 0;
            if (cur != null && cur[2] == inset && cur[3] == lvl) cur[1]++;
            else { cur = new int[]{i, 1, inset, lvl}; segs.add(cur); }
        }
        p = new int[segs.size() * 4];
        for (int k = 0; k < segs.size(); k++) System.arraycopy(segs.get(k), 0, p, k * 4, 4);
        PROFILE.put(r, p);
        return p;
    }

    /** Rounded rectangle with smooth (anti-aliased) corners, drawn with as few fills as possible. */
    public static void roundR(GuiGraphics g, int x, int y, int w, int h, int r, int c) { roundR(g, x, y, w, h, r, c, true); }

    public static void roundR(GuiGraphics g, int x, int y, int w, int h, int r, int c, boolean aa) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { g.fill(x, y, x + w, y + h, c); return; }
        int ca = (c >>> 24) & 255, rgb = c & 0xFFFFFF;
        int[] p = profile(r);
        for (int k = 0; k < p.length; k += 4) {
            int i = p[k], n = p[k + 1], inset = p[k + 2], lvl = p[k + 3];
            if (w - 2 * inset > 0) {
                g.fill(x + inset, y + i, x + w - inset, y + i + n, c);
                g.fill(x + inset, y + h - i - n, x + w - inset, y + h - i, c);
            }
            if (aa && lvl > 0) {
                int ac = ((ca * lvl / 4) << 24) | rgb;
                g.fill(x + inset - 1, y + i, x + inset, y + i + n, ac);
                g.fill(x + w - inset, y + i, x + w - inset + 1, y + i + n, ac);
                g.fill(x + inset - 1, y + h - i - n, x + inset, y + h - i, ac);
                g.fill(x + w - inset, y + h - i - n, x + w - inset + 1, y + h - i, ac);
            }
        }
        if (h - 2 * r > 0) g.fill(x, y + r, x + w, y + h - r, c);
    }

    /** Generic premium panel: soft shadow, 1px border, rounded body, faint top gloss. */
    public static void panel(GuiGraphics g, int x, int y, int w, int h, int r, int bg, int border, float a) {
        roundR(g, x + 1, y + 2, w, h, r, alpha(0x4A000000, a), false);
        roundR(g, x - 1, y - 1, w + 2, h + 2, r + 1, alpha(border, a));
        roundR(g, x, y, w, h, r, alpha(bg, a));
        g.fillGradient(x + r / 2 + 1, y + 1, x + w - r / 2 - 1, y + Math.min(h / 2, 10), alpha(0x16FFFFFF, a), 0x00000000);
    }

    /** HUD pill (fully rounded ends). */
    public static void pill(GuiGraphics g, int x, int y, int w, int h, float a) {
        panel(g, x, y, w, h, Math.min(12, h / 2), 0xDC0F1626, 0x55468CDC, a);
    }

    /** 1px line that is brightest in the middle and fades out to both ends. */
    public static void fadeLine(GuiGraphics g, int x, int y, int w, int argb) {
        int seg = Math.max(1, w / 28);
        for (int i = 0; i < w; i += seg) {
            double t = (i + seg / 2.0) / w, k = 1.0 - Math.abs(t - 0.5) * 2.0;
            g.fill(x + i, y, x + Math.min(i + seg, w), y + 1, alpha(argb, (float) (0.12 + 0.88 * k)));
        }
    }

    /** Soft layered shadow under a rounded rectangle. */
    public static void shadow(GuiGraphics g, int x, int y, int w, int h, int r) {
        roundR(g, x - 2, y, w + 4, h + 4, r + 2, 0x14000000);
        roundR(g, x - 1, y + 1, w + 2, h + 3, r + 1, 0x1E000000);
        roundR(g, x, y + 2, w, h + 1, r, 0x30000000);
    }

    /** Header underline with a soft highlight that slowly sweeps across. */
    public static void shimmer(GuiGraphics g, int x, int y, int w, int argb, float time) {
        int seg = Math.max(1, w / 20);
        double peak = ((time * 0.32) % 1.5) - 0.25;
        for (int i = 0; i < w; i += seg) {
            double t = (i + seg / 2.0) / w, base = 1.0 - Math.abs(t - 0.5) * 2.0;
            double d = (t - peak) * 7.0, glow = Math.exp(-d * d);
            float k = (float) Math.min(1.0, 0.10 + 0.55 * base + 0.9 * glow);
            g.fill(x + i, y, x + Math.min(i + seg, w), y + 1, alpha(argb, k));
        }
    }
}
