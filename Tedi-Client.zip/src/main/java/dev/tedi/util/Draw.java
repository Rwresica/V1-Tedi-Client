package dev.tedi.util;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

public final class Draw {
    private Draw() {}

    /** Rectangle with cut corners (looks rounded). */
    public static void round(GuiGraphics g, int x, int y, int w, int h, int c) {
        if (w < 3 || h < 3) { g.fill(x, y, x + w, y + h, c); return; }
        g.fill(x + 1, y, x + w - 1, y + h, c);
        g.fill(x, y + 1, x + 1, y + h - 1, c);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, c);
    }

    public static void outline(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    /** Multiplies the alpha of an ARGB colour. */
    public static int alpha(int argb, float a) {
        a = Math.max(0f, Math.min(1f, a));
        int al = (int) (((argb >>> 24) & 255) * a);
        return (al << 24) | (argb & 0xFFFFFF);
    }

    /** Minecraft's own bold style = chunkier, closer to the Krypton look. */
    public static void text(GuiGraphics g, Font f, String s, int x, int y, int color, boolean bold) {
        if (((color >>> 24) & 255) < 5) return;
        if (bold) g.drawString(f, Component.literal(s).withStyle(ChatFormatting.BOLD), x, y, color, false);
        else g.drawString(f, s, x, y, color, false);
    }

    public static int width(Font f, String s, boolean bold) {
        return bold ? f.width(Component.literal(s).withStyle(ChatFormatting.BOLD)) : f.width(s);
    }

    /** Soft dark panel with a faint top highlight (used by every HUD element). */
    public static void softPanel(GuiGraphics g, int x, int y, int w, int h, int accent, float a) {
        round(g, x + 1, y + 1, w, h, alpha(0x55000000, a));
        round(g, x, y, w, h, alpha(0xD2141519, a));
        g.fillGradient(x + 1, y + 1, x + w - 1, y + 1 + h / 2, alpha(0x16FFFFFF, a), 0x00000000);
        g.fill(x, y + 1, x + 2, y + h - 1, alpha(accent, a));
    }

    /** Truly rounded rectangle. Uses ~2r+1 fills instead of one per row (that was causing GUI lag). */
    public static void roundR(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { g.fill(x, y, x + w, y + h, c); return; }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, c);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, c);
        }
        if (h - 2 * r > 0) g.fill(x, y + r, x + w, y + h - r, c);
    }

    /** Dark translucent pill with soft shadow + top highlight (HUD look). */
    public static void pill(GuiGraphics g, int x, int y, int w, int h, float a) {
        int r = Math.min(5, h / 2);
        roundR(g, x + 1, y + 2, w, h, r, alpha(0x40000000, a));
        roundR(g, x, y, w, h, r, alpha(0xD0121318, a));
        g.fillGradient(x + r, y + 1, x + w - r, y + h - 1, alpha(0x16FFFFFF, a), 0x00000000);
        g.fill(x + r, y, x + w - r, y + 1, alpha(0x30FFFFFF, a));
    }

    /** 1px line that is brightest in the middle and fades out to both ends. */
    public static void fadeLine(GuiGraphics g, int x, int y, int w, int argb) {
        int seg = Math.max(1, w / 28);
        for (int i = 0; i < w; i += seg) {
            double t = (i + seg / 2.0) / w, k = 1.0 - Math.abs(t - 0.5) * 2.0;
            g.fill(x + i, y, x + Math.min(i + seg, w), y + 1, alpha(argb, (float) (0.12 + 0.88 * k)));
        }
    }

    /** Soft layered shadow under a rounded rectangle. */
    public static void shadow(GuiGraphics g, int x, int y, int w, int h, int r) {
        roundR(g, x - 2, y, w + 4, h + 4, r + 2, 0x14000000);
        roundR(g, x - 1, y + 1, w + 2, h + 3, r + 1, 0x1E000000);
        roundR(g, x, y + 2, w, h + 1, r, 0x30000000);
    }
}
