package dev.tedi.util;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

public final class Draw {
    private Draw() {}

    /** Rectangle with cut corners (looks rounded). */
    public static void round(GuiGraphics g, int x, int y, int w, int h, int c) {
        if (w < 3 || h < 3) { g.fill(x, y, x + w, y + h, c); return; }
        g.fill(x + 1, y, x + w - 1, y + h, c);
        g.fill(x, y + 1, x + 1, y + h - 1, c);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, c);
    }

    public static void outline(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    /** Multiplies the alpha of an ARGB colour. */
    public static int alpha(int argb, float a) {
        a = Math.max(0f, Math.min(1f, a));
        int al = (int) (((argb >>> 24) & 255) * a);
        return (al << 24) | (argb & 0xFFFFFF);
    }

    /** Minecraft's own bold style = chunkier, closer to the Krypton look. */
    public static void text(GuiGraphics g, Font f, String s, int x, int y, int color, boolean bold) {
        if (((color >>> 24) & 255) < 5) return;
        if (bold) g.drawString(f, Component.literal(s).withStyle(ChatFormatting.BOLD), x, y, color, false);
        else g.drawString(f, s, x, y, color, false);
    }

    public static int width(Font f, String s, boolean bold) {
        return bold ? f.width(Component.literal(s).withStyle(ChatFormatting.BOLD)) : f.width(s);
    }

    /** Soft dark panel with a faint top highlight (used by every HUD element). */
    public static void softPanel(GuiGraphics g, int x, int y, int w, int h, int accent, float a) {
        round(g, x + 1, y + 1, w, h, alpha(0x55000000, a));
        round(g, x, y, w, h, alpha(0xD2141519, a));
        g.fillGradient(x + 1, y + 1, x + w - 1, y + 1 + h / 2, alpha(0x16FFFFFF, a), 0x00000000);
        g.fill(x, y + 1, x + 2, y + h - 1, alpha(accent, a));
    }
}
