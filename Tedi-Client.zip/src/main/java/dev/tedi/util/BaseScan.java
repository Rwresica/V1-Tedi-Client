package dev.tedi.util;

import dev.tedi.module.StorageEsp;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Chunk analysis shared by SusChunk and PlayerDetection: placed blocks, storage, and dug tunnels / shafts. */
public final class BaseScan {
    private BaseScan() {}

    public static final Set<Block> INDICATORS = new HashSet<>(Arrays.asList(
            Blocks.IRON_BLOCK, Blocks.GOLD_BLOCK, Blocks.DIAMOND_BLOCK, Blocks.EMERALD_BLOCK, Blocks.NETHERITE_BLOCK,
            Blocks.LAPIS_BLOCK, Blocks.REDSTONE_BLOCK, Blocks.COAL_BLOCK, Blocks.COPPER_BLOCK, Blocks.BEACON,
            Blocks.ENCHANTING_TABLE, Blocks.ANVIL, Blocks.TNT, Blocks.PISTON, Blocks.STICKY_PISTON, Blocks.OBSERVER,
            Blocks.REPEATER, Blocks.COMPARATOR, Blocks.REDSTONE_LAMP, Blocks.HOPPER, Blocks.DROPPER, Blocks.DISPENSER,
            Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER, Blocks.BREWING_STAND, Blocks.CRAFTING_TABLE,
            Blocks.SMITHING_TABLE, Blocks.SCAFFOLDING, Blocks.GLASS, Blocks.BARREL));

    /** Things players put underground to light / enter / decorate a hidden base. */
    public static final Set<Block> UG_INDICATORS = new HashSet<>(Arrays.asList(
            Blocks.TORCH, Blocks.WALL_TORCH, Blocks.SOUL_TORCH, Blocks.SOUL_WALL_TORCH, Blocks.LANTERN,
            Blocks.SOUL_LANTERN, Blocks.LADDER, Blocks.IRON_DOOR, Blocks.OAK_DOOR, Blocks.OAK_TRAPDOOR,
            Blocks.IRON_TRAPDOOR, Blocks.OAK_SIGN, Blocks.OAK_WALL_SIGN));

    public record Blocks_(int am, int pm, int ug, int minY, int maxY) {}
    public record Tunnels(int tunnels, int shafts, int minY, int maxY) {}
    public record Growth(int score, int ug, int minY, int maxY) {}
    public record Ents(int storage, int other, int spawners, int ugStorage, int minY, int maxY) {}

    public static int[] surface(LevelChunk ch) {
        int[] s = new int[256];
        for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) s[x * 16 + z] = ch.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
        return s;
    }

    public static Blocks_ blocks(LevelChunk ch, boolean wantAm, boolean wantPb, boolean wantUg, int yLo, int yHi, int depth, int[] surf) {
        int am = 0, pm = 0, ug = 0, minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        LevelChunkSection[] secs = ch.getSections();
        for (int i = 0; i < secs.length; i++) {
            LevelChunkSection sec = secs[i];
            if (sec.hasOnlyAir()) continue;
            int baseY = ch.getMinY() + i * 16;
            if (baseY + 15 < yLo || baseY > yHi) continue;
            boolean a = wantAm && sec.maybeHas(s -> s.is(Blocks.AMETHYST_CLUSTER));
            boolean p = wantPb && sec.maybeHas(s -> INDICATORS.contains(s.getBlock()));
            boolean u = wantUg && sec.maybeHas(s -> UG_INDICATORS.contains(s.getBlock()));
            if (!a && !p && !u) continue;
            for (int x = 0; x < 16; x++)
                for (int y = 0; y < 16; y++) {
                    int wy = baseY + y;
                    if (wy < yLo || wy > yHi) continue;
                    for (int z = 0; z < 16; z++) {
                        Block b = sec.getBlockState(x, y, z).getBlock();
                        boolean under = surf != null && wy < surf[x * 16 + z] - depth;
                        if (a && b == Blocks.AMETHYST_CLUSTER) {
                            am++; minY = Math.min(minY, wy); maxY = Math.max(maxY, wy);
                        } else if (p && INDICATORS.contains(b)) {
                            pm += under ? 2 : 1;
                            if (under) ug++;
                            minY = Math.min(minY, wy); maxY = Math.max(maxY, wy);
                        } else if (u && under && UG_INDICATORS.contains(b)) {
                            pm += 2; ug++;
                            minY = Math.min(minY, wy); maxY = Math.max(maxY, wy);
                        }
                    }
                }
        }
        return new Blocks_(am, pm, ug, minY, maxY);
    }

    public static Ents ents(LevelChunk ch, boolean wantStorage, boolean wantSpawners, int yLo, int yHi, int depth, int[] surf) {
        int st = 0, ot = 0, sp = 0, ugs = 0, minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        for (BlockEntity be : ch.getBlockEntities().values()) {
            int y = be.getBlockPos().getY();
            if (y < yLo || y > yHi) continue;
            int t = StorageEsp.classify(be);
            if (t >= 0 && t <= 4 && wantStorage) {
                st++;
                if (surf != null && y < surf[(be.getBlockPos().getX() & 15) * 16 + (be.getBlockPos().getZ() & 15)] - depth) ugs++;
                minY = Math.min(minY, y); maxY = Math.max(maxY, y);
            } else if (t == 5 && wantStorage) ot++;
            else if (t == 6 && wantSpawners) { sp++; minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
        }
        return new Ents(st, ot, sp, ugs, minY, maxY);
    }

    private static boolean air(boolean[][] a, int minWy, int x, int wy, int z) {
        int si = (wy - minWy) >> 4;
        if (si < 0 || si >= a.length) return false;
        boolean[] arr = a[si];
        if (arr == null) return false;
        return arr[(((wy - minWy) & 15) << 8) | (z << 4) | x];
    }

    private static boolean corridorX(boolean[][] a, int minWy, int x, int wy, int z0, int w) {
        for (int k = 0; k < w; k++) {
            int z = z0 + k;
            if (!air(a, minWy, x, wy, z) || !air(a, minWy, x, wy + 1, z)) return false;
            if (air(a, minWy, x, wy - 1, z) || air(a, minWy, x, wy + 2, z)) return false;
        }
        return !air(a, minWy, x, wy, z0 - 1) && !air(a, minWy, x, wy + 1, z0 - 1)
                && !air(a, minWy, x, wy, z0 + w) && !air(a, minWy, x, wy + 1, z0 + w);
    }

    private static boolean corridorZ(boolean[][] a, int minWy, int x0, int wy, int z, int w) {
        for (int k = 0; k < w; k++) {
            int x = x0 + k;
            if (!air(a, minWy, x, wy, z) || !air(a, minWy, x, wy + 1, z)) return false;
            if (air(a, minWy, x, wy - 1, z) || air(a, minWy, x, wy + 2, z)) return false;
        }
        return !air(a, minWy, x0 - 1, wy, z) && !air(a, minWy, x0 - 1, wy + 1, z)
                && !air(a, minWy, x0 + w, wy, z) && !air(a, minWy, x0 + w, wy + 1, z);
    }

    /**
     * Finds dug-out structure below the surface: straight tunnels (1 or 2 wide, 2 high, >= 6 long, along X or Z)
     * and 1x1 vertical shafts (>= 6 tall). Natural caves almost never look like this.
     */
    public static Tunnels tunnels(LevelChunk ch, int yLo, int yHi, int depth, int[] surf) {
        LevelChunkSection[] secs = ch.getSections();
        int n = secs.length, minWy = ch.getMinY();
        int maxSurf = Integer.MIN_VALUE;
        for (int sv : surf) maxSurf = Math.max(maxSurf, sv);
        int top = Math.min(yHi, maxSurf - depth);
        boolean[][] air = new boolean[n][];
        for (int i = 0; i < n; i++) {
            int base = minWy + i * 16;
            if (base > top + 3 || base + 15 < yLo - 3) continue;
            LevelChunkSection sec = secs[i];
            if (sec.hasOnlyAir()) { boolean[] a = new boolean[4096]; Arrays.fill(a, true); air[i] = a; continue; }
            if (!sec.maybeHas(st -> st.isAir())) continue;
            boolean[] a = new boolean[4096];
            for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++)
                a[(y << 8) | (z << 4) | x] = sec.getBlockState(x, y, z).isAir();
            air[i] = a;
        }
        int tun = 0, sh = 0, mn = Integer.MAX_VALUE, mx = Integer.MIN_VALUE;
        int wy0 = Math.max(yLo, minWy + 1), wy1 = top;
        for (int wy = wy0; wy <= wy1; wy++) {
            for (int w = 1; w <= 2; w++) {
                for (int z0 = 1; z0 + w <= 15; z0++) {
                    int run = 0;
                    for (int x = 0; x <= 16; x++) {
                        boolean cell = x < 16 && wy < surf[x * 16 + z0] - depth && corridorX(air, minWy, x, wy, z0, w);
                        if (cell) run++;
                        else { if (run >= 6) { tun++; mn = Math.min(mn, wy); mx = Math.max(mx, wy); } run = 0; }
                    }
                }
                for (int x0 = 1; x0 + w <= 15; x0++) {
                    int run = 0;
                    for (int z = 0; z <= 16; z++) {
                        boolean cell = z < 16 && wy < surf[x0 * 16 + z] - depth && corridorZ(air, minWy, x0, wy, z, w);
                        if (cell) run++;
                        else { if (run >= 6) { tun++; mn = Math.min(mn, wy); mx = Math.max(mx, wy); } run = 0; }
                    }
                }
            }
        }
        for (int x = 1; x <= 14; x++) {
            for (int z = 1; z <= 14; z++) {
                int run = 0;
                for (int wy = wy0; wy <= wy1 + 1; wy++) {
                    boolean cell = wy <= wy1 && wy < surf[x * 16 + z] - depth
                            && air(air, minWy, x, wy, z)
                            && !air(air, minWy, x - 1, wy, z) && !air(air, minWy, x + 1, wy, z)
                            && !air(air, minWy, x, wy, z - 1) && !air(air, minWy, x, wy, z + 1);
                    if (cell) run++;
                    else { if (run >= 6) { sh++; mn = Math.min(mn, wy - run); mx = Math.max(mx, wy); } run = 0; }
                }
            }
        }
        return new Tunnels(tun, sh, mn, mx);
    }

    private static final Set<Block> GROWTH = new HashSet<>(Arrays.asList(
            Blocks.KELP, Blocks.CAVE_VINES, Blocks.VINE, Blocks.BAMBOO, Blocks.COCOA,
            Blocks.BEE_NEST, Blocks.BEEHIVE, Blocks.DEEPSLATE));

    private static boolean jungle(LevelChunk ch, int cx, int cz) {
        try {
            Holder<Biome> b = ch.getNoiseBiome((cx * 16 + 8) >> 2, 16, (cz * 16 + 8) >> 2);
            return b.is(Biomes.JUNGLE) || b.is(Biomes.BAMBOO_JUNGLE) || b.is(Biomes.SPARSE_JUNGLE);
        } catch (Throwable t) { return false; }
    }

    /**
     * Blocks that tell a chunk was touched by players: fully grown kelp / cave vines (needs the chunk to have been
     * loaded for a long time), vines / bamboo / bee nests underground, cocoa outside jungles, and deepslate that is
     * NOT axis-Y (natural deepslate never is).
     */
    public static Growth growth(LevelChunk ch, int cx, int cz, int yLo, int yHi, int depth, int[] surf,
                                boolean kelp, boolean cave, boolean vines, boolean bamboo, boolean cocoa, boolean bee, boolean deep) {
        int kelpN = 0, caveN = 0, vineN = 0, bambN = 0, cocoaN = 0, beeN = 0, deepN = 0, ug = 0;
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        boolean jg = (bamboo || cocoa) && jungle(ch, cx, cz);
        LevelChunkSection[] secs = ch.getSections();
        for (int i = 0; i < secs.length; i++) {
            LevelChunkSection sec = secs[i];
            if (sec.hasOnlyAir()) continue;
            int baseY = ch.getMinY() + i * 16;
            if (baseY + 15 < yLo || baseY > yHi) continue;
            if (!sec.maybeHas(st -> GROWTH.contains(st.getBlock()))) continue;
            for (int x = 0; x < 16; x++)
                for (int y = 0; y < 16; y++) {
                    int wy = baseY + y;
                    if (wy < yLo || wy > yHi) continue;
                    for (int z = 0; z < 16; z++) {
                        BlockState st = sec.getBlockState(x, y, z);
                        Block b = st.getBlock();
                        if (!GROWTH.contains(b)) continue;
                        boolean under = wy < surf[x * 16 + z] - depth;
                        boolean hit = false;
                        if (b == Blocks.KELP) { if (kelp && st.getValue(BlockStateProperties.AGE_25) == 25) { kelpN++; hit = true; } }
                        else if (b == Blocks.CAVE_VINES) { if (cave && st.getValue(BlockStateProperties.AGE_25) == 25) { caveN++; hit = true; } }
                        else if (b == Blocks.VINE) { if (vines && under) { vineN++; hit = true; } }
                        else if (b == Blocks.BAMBOO) { if (bamboo && (under || !jg)) { bambN += under ? 3 : 1; hit = true; } }
                        else if (b == Blocks.COCOA) { if (cocoa && !jg && st.getValue(BlockStateProperties.AGE_2) == 2) { cocoaN++; hit = true; } }
                        else if (b == Blocks.BEEHIVE) { if (bee) { beeN++; hit = true; } }
                        else if (b == Blocks.BEE_NEST) { if (bee && under) { beeN++; hit = true; } }
                        else if (b == Blocks.DEEPSLATE) {
                            if (deep && st.getValue(BlockStateProperties.AXIS) != Direction.Axis.Y) { deepN++; hit = true; }
                        }
                        if (hit) {
                            if (under) ug++;
                            minY = Math.min(minY, wy); maxY = Math.max(maxY, wy);
                        }
                    }
                }
        }
        int score = Math.min(deepN * 3, 60) + Math.min(kelpN * 4, 24) + Math.min(caveN, 10) + Math.min(vineN * 2, 20)
                + Math.min(bambN, 20) + Math.min(cocoaN * 4, 20) + Math.min(beeN * 6, 24);
        return new Growth(score, ug, minY, maxY);
    }
}
