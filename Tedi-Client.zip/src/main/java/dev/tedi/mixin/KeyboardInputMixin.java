package dev.tedi.mixin;

import dev.tedi.module.Freecam;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.world.phys.Vec2;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Character stands still while Freecam is on (a sneak held at activation stays held). */
@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends ClientInput {
    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void tedi$tick(CallbackInfo ci) {
        if (Freecam.active()) {
            this.keyPresses = Freecam.I.playerInput();
            this.moveVector = Vec2.ZERO;
        }
    }
}
