package dev.tedi.mixin;

import dev.tedi.module.Freecam;
import dev.tedi.module.Freelook;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Turns off Minecraft's cave/occlusion culling while Freecam (or Freelook "See Through Walls") is on,
 * so every chunk in render distance is drawn - you can look through rock all the way to the horizon.
 * Optional mixin config: if a name differs, only this feature stops working.
 */
@Mixin(Minecraft.class)
public abstract class MinecraftCullMixin {
    @Shadow public boolean smartCull;
    @Unique private boolean tedi$off, tedi$old;

    @Inject(method = "tick", at = @At("HEAD"), require = 0)
    private void tedi$cull(CallbackInfo ci) {
        boolean want = Freecam.active() || (Freelook.active() && Freelook.I.seeThrough.value);
        if (want) {
            if (!tedi$off) { tedi$old = this.smartCull; tedi$off = true; }
            this.smartCull = false;
        } else if (tedi$off) {
            this.smartCull = tedi$old;
            tedi$off = false;
        }
    }
}
