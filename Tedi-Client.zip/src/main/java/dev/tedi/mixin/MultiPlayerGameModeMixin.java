package dev.tedi.mixin;

import dev.tedi.module.CrystalOptimizer;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** CrystalOptimizer: remove a crystal on your screen the instant you hit it (no waiting for the server). */
@Mixin(MultiPlayerGameMode.class)
public abstract class MultiPlayerGameModeMixin {
    @Inject(method = "attack", at = @At("TAIL"), require = 0)
    private void tedi$attack(Player player, Entity target, CallbackInfo ci) {
        if (CrystalOptimizer.removeOn() && target instanceof EndCrystal) target.discard();
    }
}
