package dev.tedi.mixin;

import dev.tedi.module.NameProtect;
import net.minecraft.util.StringDecomposer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Every piece of text drawn by the game passes through here, so NameProtect hooks it. */
@Mixin(StringDecomposer.class)
public class StringDecomposerMixin {
    @ModifyVariable(method = {"iterate", "iterateBackwards", "iterateFormatted"},
            at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private static String tedi$protect(String text) {
        return NameProtect.apply(text);
    }
}
