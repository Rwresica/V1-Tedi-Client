package dev.tedi.mixin;

import dev.tedi.module.CustomCrosshair;
import dev.tedi.module.Freelook;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hides the vanilla crosshair while Freelook / CustomCrosshair is on. */
@Mixin(Gui.class)
public abstract class GuiMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void tedi$crosshair(GuiGraphics g, DeltaTracker dt, CallbackInfo ci) {
        if ((Freelook.active() && Freelook.I.hideCrosshair.value) || CustomCrosshair.active()) ci.cancel();
    }
}
