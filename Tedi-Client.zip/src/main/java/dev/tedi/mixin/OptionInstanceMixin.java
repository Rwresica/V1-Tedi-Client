package dev.tedi.mixin;

import dev.tedi.module.Fullbright;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Fullbright: the gamma option reads as a huge value, which lights everything up. */
@Mixin(OptionInstance.class)
public abstract class OptionInstanceMixin<T> {
    @SuppressWarnings("unchecked")
    @Inject(method = "get", at = @At("HEAD"), cancellable = true, require = 0)
    private void tedi$get(CallbackInfoReturnable<T> cir) {
        if (!Fullbright.gammaOn()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc != null && mc.options != null && (Object) this == mc.options.gamma()) {
            cir.setReturnValue((T) (Object) Double.valueOf(15.0));
        }
    }
}
