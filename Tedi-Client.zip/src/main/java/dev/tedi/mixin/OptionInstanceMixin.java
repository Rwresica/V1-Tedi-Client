package dev.tedi.mixin;

import dev.tedi.module.CustomFov;
import dev.tedi.module.Fullbright;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Fullbright (gamma reads huge) and CustomFOV (fov reads your value). */
@Mixin(OptionInstance.class)
public abstract class OptionInstanceMixin<T> {
    @SuppressWarnings("unchecked")
    @Inject(method = "get", at = @At("HEAD"), cancellable = true, require = 0)
    private void tedi$get(CallbackInfoReturnable<T> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.options == null) return;
        if (Fullbright.gammaOn() && (Object) this == mc.options.gamma()) {
            cir.setReturnValue((T) (Object) Double.valueOf(15.0));
        } else if (CustomFov.active() && (Object) this == mc.options.fov()) {
            cir.setReturnValue((T) (Object) Integer.valueOf(CustomFov.value()));
        }
    }
}
