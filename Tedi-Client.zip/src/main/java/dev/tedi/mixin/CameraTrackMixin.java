package dev.tedi.mixin;

import dev.tedi.util.Proj;
import net.minecraft.client.Camera;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Optional: reports the exact camera of every frame so ESP / nametags line up with the world perfectly. */
@Mixin(value = Camera.class, priority = 1500)
public abstract class CameraTrackMixin {
    @Shadow private Vec3 position;
    @Shadow private float xRot;
    @Shadow private float yRot;

    @Inject(method = "setup", at = @At("TAIL"), require = 0)
    private void tedi$track(CallbackInfo ci) {
        if (position != null) Proj.onCamera(position.x, position.y, position.z, yRot, xRot);
    }
}
