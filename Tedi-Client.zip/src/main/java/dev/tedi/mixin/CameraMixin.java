package dev.tedi.mixin;

import dev.tedi.module.Freecam;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Moves the render camera to the Freecam position (smoothly interpolated every frame). */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setPosition(Vec3 pos);
    @Shadow protected abstract void setRotation(float yRot, float xRot);
    @Shadow private boolean detached;

    @Inject(method = "setup", at = @At("TAIL"), require = 0)
    private void tedi$setup(CallbackInfo ci) {
        if (!Freecam.active()) return;
        float pt = Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(false);
        Freecam fc = Freecam.I;
        this.setPosition(fc.renderPos(pt));
        this.setRotation(fc.yaw, fc.pitch);
        this.detached = true;
    }
}
