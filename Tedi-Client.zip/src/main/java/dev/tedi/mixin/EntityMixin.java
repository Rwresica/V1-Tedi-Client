package dev.tedi.mixin;

import dev.tedi.module.Freecam;
import dev.tedi.module.Freelook;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** While Freecam / Freelook is on, mouse look rotates the camera instead of the player. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true, require = 0)
    private void tedi$turn(double yRot, double xRot, CallbackInfo ci) {
        if ((Object) this != Minecraft.getInstance().player) return;
        if (Freecam.active()) {
            Freecam.I.look(yRot, xRot);
            ci.cancel();
        } else if (Freelook.active()) {
            Freelook.I.look(yRot, xRot);
            ci.cancel();
        }
    }
}
