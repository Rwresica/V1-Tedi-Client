package dev.tedi.mixin;

import dev.tedi.module.CrystalOptimizer;
import dev.tedi.module.FastPlace;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Lives in its own OPTIONAL mixin config: if a name ever differs, only Fast Place stops working (no crash). */
@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    @Shadow private int rightClickDelay;

    @Inject(method = "tick", at = @At("HEAD"), require = 0)
    private void tedi$fastPlace(CallbackInfo ci) {
        int d = CrystalOptimizer.forcedPlaceDelay();
        int e = FastPlace.forcedDelay();
        if (d < 0) d = e; else if (e >= 0) d = Math.min(d, e);
        if (d >= 0 && this.rightClickDelay > d) this.rightClickDelay = d;
    }
}
