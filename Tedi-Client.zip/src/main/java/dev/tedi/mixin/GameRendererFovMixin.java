package dev.tedi.mixin;

import dev.tedi.util.Proj;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Optional: reports the real field of view (including sprint / speed / potion changes). */
@Mixin(GameRenderer.class)
public abstract class GameRendererFovMixin {
    @Inject(method = "getFov", at = @At("RETURN"), require = 0)
    private void tedi$fov(CallbackInfoReturnable<?> cir) {
        Object v = cir.getReturnValue();
        if (v instanceof Number n) Proj.onFov(n.doubleValue());
    }
}
