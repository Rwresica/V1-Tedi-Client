package dev.tedi.util;

import dev.tedi.module.Freecam;
import dev.tedi.module.Freelook;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** World -> GUI-screen projection so ESP / tracers / fills / nametags can be drawn in 2D. */
public final class Proj {
    public static double cx, cy, cz, px, py;
    private static double fx, fy, fz, rx, rz, ux, uy, uz, tanHalf, aspect, tx, ty, tz;
    private static int w, h;
    private static final double NEAR = 0.05;
    // real camera / projection, reported by optional mixins every frame
    private static double camX, camY, camZ, camYaw, camPitch;
    private static long camT, fovT;
    private static float levelFov = -1f;
    private static int fovCalls;

    /** Called after Camera.setup: exact camera position + rotation of this frame. */
    public static void onCamera(double x, double y, double z, float yaw, float pitch) {
        camX = x; camY = y; camZ = z; camYaw = yaw; camPitch = pitch;
        camT = System.nanoTime();
        fovCalls = 0;
    }

    /** Called from GameRenderer.getFov: the first call each frame is the world's real field of view. */
    public static void onFov(double v) {
        if (fovCalls++ == 0) { levelFov = (float) v; fovT = System.nanoTime(); }
    }

    private Proj() {}

    public static void begin(Minecraft mc, GuiGraphics g, float pt) {
        double yaw, pitch;
        long now = System.nanoTime();
        if (now - camT < 300_000_000L) {                  // exact camera of the frame that was just rendered
            cx = camX; cy = camY; cz = camZ;
            yaw = camYaw; pitch = camPitch;
        } else if (Freecam.active()) {
            Vec3 p = Freecam.I.renderPos(pt);
            cx = p.x; cy = p.y; cz = p.z;
            yaw = Freecam.I.yaw; pitch = Freecam.I.pitch;
        } else if (Freelook.active()) {
            Vec3 p = Freelook.I.camPos(mc, pt);
            cx = p.x; cy = p.y; cz = p.z;
            yaw = Freelook.I.yaw; pitch = Freelook.I.pitch;
        } else {
            Vec3 p = mc.player.getEyePosition(pt);
            cx = p.x; cy = p.y; cz = p.z;
            yaw = mc.player.getViewYRot(pt); pitch = mc.player.getViewXRot(pt);
        }
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        fx = -Math.sin(yr) * Math.cos(pr);
        fy = -Math.sin(pr);
        fz = Math.cos(yr) * Math.cos(pr);
        rx = -Math.cos(yr);
        rz = -Math.sin(yr);
        ux = -rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy;
        double fov = (now - fovT < 300_000_000L && levelFov > 1f) ? levelFov : mc.options.fov().get();   // includes sprint / speed FOV
        tanHalf = Math.tan(Math.toRadians(fov) / 2.0);
        w = g.guiWidth(); h = g.guiHeight();
        aspect = (double) w / (double) h;
    }

    private static void toCam(double x, double y, double z) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        tx = dx * rx + dz * rz;
        ty = dx * ux + dy * uy + dz * uz;
        tz = dx * fx + dy * fy + dz * fz;
    }

    private static double sx(double xx, double zz) { return w / 2.0 + (xx / zz) / (tanHalf * aspect) * (w / 2.0); }
    private static double sy(double yy, double zz) { return h / 2.0 - (yy / zz) / tanHalf * (h / 2.0); }

    /** Result goes to px/py. Returns false if the point is behind the camera. */
    public static boolean project(double x, double y, double z) {
        toCam(x, y, z);
        if (tz < NEAR) return false;
        px = sx(tx, tz);
        py = sy(ty, tz);
        return true;
    }

    private static double ct0, ct1;

    private static boolean clip(double p, double q) {
        if (p == 0) return q >= 0;
        double r = q / p;
        if (p < 0) { if (r > ct1) return false; if (r > ct0) ct0 = r; }
        else { if (r < ct0) return false; if (r < ct1) ct1 = r; }
        return true;
    }

    /** 2D line (clipped to the screen). No allocations - this runs hundreds of times per frame. */
    public static void line(GuiGraphics g, double x1, double y1, double x2, double y2, float width, int argb) {
        double dx = x2 - x1, dy = y2 - y1;
        ct0 = 0; ct1 = 1;
        if (!clip(-dx, x1 + 20) || !clip(dx, w + 20 - x1) || !clip(-dy, y1 + 20) || !clip(dy, h + 20 - y1)) return;
        double ax = x1 + ct0 * dx, ay = y1 + ct0 * dy, bx = x1 + ct1 * dx, by = y1 + ct1 * dy;
        float len = (float) Math.hypot(bx - ax, by - ay);
        if (len < 0.5f) return;
        var ps = g.pose();
        ps.pushMatrix();
        ps.translate((float) ax, (float) ay);
        ps.rotate((float) Math.atan2(dy, dx));
        ps.translate(0f, -width / 2f);
        ps.scale(1f, width);
        g.fill(0, 0, (int) Math.ceil(len), 1, argb);
        ps.popMatrix();
    }

    /** 3D line, clipped against the camera so it works even when one end is behind you. */
    public static void line3d(GuiGraphics g, double x1, double y1, double z1, double x2, double y2, double z2, float width, int argb) {
        toCam(x1, y1, z1);
        double ax = tx, ay = ty, az = tz;
        toCam(x2, y2, z2);
        double bx = tx, by = ty, bz = tz;
        if (az < NEAR && bz < NEAR) return;
        if (az < NEAR) { double t = (NEAR - az) / (bz - az); ax += (bx - ax) * t; ay += (by - ay) * t; az = NEAR; }
        else if (bz < NEAR) { double t = (NEAR - bz) / (az - bz); bx += (ax - bx) * t; by += (ay - by) * t; bz = NEAR; }
        line(g, sx(ax, az), sy(ay, az), sx(bx, bz), sy(by, bz), width, argb);
    }

    public static void box(GuiGraphics g, AABB b, float width, int argb) {
        for (int i = 0; i < 8; i++) {
            for (int bit = 1; bit <= 4; bit <<= 1) {
                if ((i & bit) == 0) {
                    int j = i | bit;
                    line3d(g,
                            (i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ,
                            (j & 1) == 0 ? b.minX : b.maxX, (j & 2) == 0 ? b.minY : b.maxY, (j & 4) == 0 ? b.minZ : b.maxZ,
                            width, argb);
                }
            }
        }
    }

    /** Solid fill of a whole block / box (silhouette of the projected cube). */
    public static void fillBox(GuiGraphics g, AABB b, int argb) {
        double[] xs = new double[8], ys = new double[8];
        for (int i = 0; i < 8; i++) {
            toCam((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            if (tz < NEAR) return;
            xs[i] = sx(tx, tz); ys[i] = sy(ty, tz);
        }
        int[] idx = {0, 1, 2, 3, 4, 5, 6, 7};
        for (int i = 1; i < 8; i++) {
            int v = idx[i], j = i - 1;
            while (j >= 0 && (xs[idx[j]] > xs[v] || (xs[idx[j]] == xs[v] && ys[idx[j]] > ys[v]))) { idx[j + 1] = idx[j]; j--; }
            idx[j + 1] = v;
        }
        double[] hx = new double[17], hy = new double[17];
        int k = 0;
        for (int ii = 0; ii < 8; ii++) {
            int i = idx[ii];
            while (k >= 2 && cross(hx[k - 2], hy[k - 2], hx[k - 1], hy[k - 1], xs[i], ys[i]) <= 0) k--;
            hx[k] = xs[i]; hy[k] = ys[i]; k++;
        }
        int lower = k + 1;
        for (int ii = 6; ii >= 0; ii--) {
            int i = idx[ii];
            while (k >= lower && cross(hx[k - 2], hy[k - 2], hx[k - 1], hy[k - 1], xs[i], ys[i]) <= 0) k--;
            hx[k] = xs[i]; hy[k] = ys[i]; k++;
        }
        k--;
        if (k >= 3) fillConvex(g, hx, hy, k, argb);
    }

    /** Filled convex polygon from n world points (3 doubles each), clipped against the camera. */
    public static void poly(GuiGraphics g, double[] p, int n, int argb) { polyGen(g, p, n, argb, false); }

    private static void polyGen(GuiGraphics g, double[] p, int n, int argb, boolean exact) {
        double[] ax = new double[n], ay = new double[n], az = new double[n];
        for (int i = 0; i < n; i++) { toCam(p[i * 3], p[i * 3 + 1], p[i * 3 + 2]); ax[i] = tx; ay[i] = ty; az[i] = tz; }
        double[] ox = new double[n * 2], oy = new double[n * 2], oz = new double[n * 2];
        int m = 0;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            boolean ina = az[i] >= NEAR, inb = az[j] >= NEAR;
            if (ina) { ox[m] = ax[i]; oy[m] = ay[i]; oz[m] = az[i]; m++; }
            if (ina != inb) {
                double t = (NEAR - az[i]) / (az[j] - az[i]);
                ox[m] = ax[i] + (ax[j] - ax[i]) * t; oy[m] = ay[i] + (ay[j] - ay[i]) * t; oz[m] = NEAR; m++;
            }
        }
        if (m < 3) return;
        double[] xs = new double[m], ys = new double[m];
        for (int i = 0; i < m; i++) { xs[i] = sx(ox[i], oz[i]); ys[i] = sy(oy[i], oz[i]); }
        if (exact) fillConvexExact(g, xs, ys, m, argb); else fillConvex(g, xs, ys, m, argb);
    }

    public static void quad(GuiGraphics g, double[] p, int argb) { poly(g, p, 4, argb); }

    /** Filled convex polygon in screen coordinates (cheap: a few fills for small shapes). */
    public static void fillPoly2d(GuiGraphics g, double[] xs, double[] ys, int n, int argb) { fillConvex(g, xs, ys, n, argb); }

    /** Exact projected silhouette of a whole box (clipped at the near plane, so it never pops out when you get close). */
    public static void fillBoxExact(GuiGraphics g, AABB b, int argb) {
        double[] cxs = new double[8], cys = new double[8], czs = new double[8];
        for (int i = 0; i < 8; i++) {
            toCam((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            cxs[i] = tx; cys[i] = ty; czs[i] = tz;
        }
        double[] px2 = new double[20], py2 = new double[20];
        int m = 0;
        for (int i = 0; i < 8; i++) {                       // corners in front of the camera
            if (czs[i] >= NEAR) { px2[m] = sx(cxs[i], czs[i]); py2[m] = sy(cys[i], czs[i]); m++; }
        }
        for (int i = 0; i < 8; i++) {                       // edge crossings with the near plane
            for (int bit = 1; bit <= 4; bit <<= 1) {
                if ((i & bit) != 0) continue;
                int j = i | bit;
                boolean ia = czs[i] >= NEAR, ib = czs[j] >= NEAR;
                if (ia == ib) continue;
                double t = (NEAR - czs[i]) / (czs[j] - czs[i]);
                double x = cxs[i] + (cxs[j] - cxs[i]) * t, y = cys[i] + (cys[j] - cys[i]) * t;
                px2[m] = sx(x, NEAR); py2[m] = sy(y, NEAR); m++;
            }
        }
        if (m < 3) return;
        double[] hx = new double[2 * m + 2], hy = new double[2 * m + 2];
        int k = hull(px2, py2, m, hx, hy);
        if (k >= 3) fillConvexExact(g, hx, hy, k, argb);
    }

    /** Convex hull (monotone chain). Writes into hx/hy, returns the vertex count. */
    private static int hull(double[] xs, double[] ys, int n, double[] hx, double[] hy) {
        int[] id = new int[n];
        for (int i = 0; i < n; i++) id[i] = i;
        for (int i = 1; i < n; i++) {
            int v = id[i], j = i - 1;
            while (j >= 0 && (xs[id[j]] > xs[v] || (xs[id[j]] == xs[v] && ys[id[j]] > ys[v]))) { id[j + 1] = id[j]; j--; }
            id[j + 1] = v;
        }
        int k = 0;
        for (int ii = 0; ii < n; ii++) {
            int i = id[ii];
            while (k >= 2 && cross(hx[k - 2], hy[k - 2], hx[k - 1], hy[k - 1], xs[i], ys[i]) <= 0) k--;
            hx[k] = xs[i]; hy[k] = ys[i]; k++;
        }
        int lower = k + 1;
        for (int ii = n - 2; ii >= 0; ii--) {
            int i = id[ii];
            while (k >= lower && cross(hx[k - 2], hy[k - 2], hx[k - 1], hy[k - 1], xs[i], ys[i]) <= 0) k--;
            hx[k] = xs[i]; hy[k] = ys[i]; k++;
        }
        return k - 1;
    }

    /** Convex polygon filled pixel-exactly (a pixel is filled when its centre is inside). Rows with the same
     *  span are merged into one rectangle, so a box costs a handful of fill calls instead of one per pixel row. */
    private static void fillConvexExact(GuiGraphics g, double[] xs, double[] ys, int n, int argb) {
        double minY = Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < n; i++) { minY = Math.min(minY, ys[i]); maxY = Math.max(maxY, ys[i]); }
        int y0 = (int) Math.max(Math.ceil(minY - 0.5), 0), y1 = (int) Math.min(Math.floor(maxY - 0.5), h - 1);
        int runY = -1, runL = 0, runR = 0;
        for (int y = y0; y <= y1 + 1; y++) {                 // y1 + 1 is a sentinel row that closes the last run
            int xl = 1, xr = 0;
            boolean has = false;
            if (y <= y1) {
                double yc = y + 0.5, lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
                for (int i = 0; i < n; i++) {
                    int j = (i + 1) % n;
                    double ya = ys[i], yb = ys[j];
                    if ((ya <= yc && yb > yc) || (yb <= yc && ya > yc)) {
                        double x = xs[i] + (yc - ya) / (yb - ya) * (xs[j] - xs[i]);
                        lo = Math.min(lo, x); hi = Math.max(hi, x);
                    }
                }
                if (hi >= lo) {
                    xl = Math.max((int) Math.ceil(lo - 0.5), 0);
                    xr = Math.min((int) Math.floor(hi - 0.5), w - 1);
                    has = xr >= xl;
                }
            }
            if (runY >= 0 && has && xl == runL && xr == runR) continue;   // same span: keep extending the run
            if (runY >= 0) g.fill(runL, runY, runR + 1, y, argb);
            runY = -1;
            if (has) { runY = y; runL = xl; runR = xr; }
        }
    }

    /** Translucent box with per-face shading, drawn with exact polygon edges (same look as shadedBox). */
    public static void shadedBoxExact(GuiGraphics g, AABB b, int rgb, int alpha, boolean darkEdge, int edgeArgb, float edgeW) {
        double x0 = b.minX, x1 = b.maxX, y0 = b.minY, y1 = b.maxY, z0 = b.minZ, z1 = b.maxZ;
        boolean in = cx > x0 && cx < x1 && cy > y0 && cy < y1 && cz > z0 && cz < z1;
        int a = Math.max(0, Math.min(255, alpha)) << 24;
        if (in || cz < z0) polyExact(new double[]{x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0}, a | shade(rgb, 0.70), g);
        if (in || cz > z1) polyExact(new double[]{x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1}, a | shade(rgb, 0.70), g);
        if (in || cx < x0) polyExact(new double[]{x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0}, a | shade(rgb, 0.85), g);
        if (in || cx > x1) polyExact(new double[]{x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0}, a | shade(rgb, 0.85), g);
        if (in || cy < y0) polyExact(new double[]{x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1}, a | shade(rgb, 0.55), g);
        if (in || cy > y1) polyExact(new double[]{x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1}, a | shade(rgb, 1.0), g);
        if (darkEdge) box(g, b, edgeW + 1.2f, 0xB0000000);
        if (edgeW > 0) box(g, b, edgeW, edgeArgb);
    }

    private static void polyExact(double[] p, int argb, GuiGraphics g) {
        polyGen(g, p, 4, argb, true);
    }

    /** Very cheap box marker (one rectangle + outline) for far-away targets. */
    public static void rectBox(GuiGraphics g, AABB b, int fillArgb, int outlineArgb) {
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (int i = 0; i < 8; i++) {
            toCam((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            if (tz < NEAR) return;
            double X = sx(tx, tz), Y = sy(ty, tz);
            if (X < minX) minX = X; if (X > maxX) maxX = X;
            if (Y < minY) minY = Y; if (Y > maxY) maxY = Y;
        }
        int x0 = (int) minX, y0 = (int) minY, x1 = (int) Math.ceil(maxX), y1 = (int) Math.ceil(maxY);
        if (x1 < 0 || y1 < 0 || x0 > w || y0 > h) return;
        if (x1 - x0 < 3) x1 = x0 + 3;
        if (y1 - y0 < 3) y1 = y0 + 3;
        if (fillArgb != 0) g.fill(x0, y0, x1, y1, fillArgb);
        if (outlineArgb != 0) Draw.outline(g, x0, y0, x1 - x0, y1 - y0, outlineArgb);
    }

    private static int shade(int rgb, double k) {
        int r = (int) (((rgb >> 16) & 255) * k), g = (int) (((rgb >> 8) & 255) * k), b = (int) ((rgb & 255) * k);
        return (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, b);
    }

    /** Translucent solid box with a different shade per face (looks 3D), optional dark + coloured edges. Works from inside too. */
    public static void shadedBox(GuiGraphics g, AABB b, int rgb, int alpha, boolean darkEdge, int edgeArgb, float edgeW) {
        double x0 = b.minX, x1 = b.maxX, y0 = b.minY, y1 = b.maxY, z0 = b.minZ, z1 = b.maxZ;
        boolean in = cx > x0 && cx < x1 && cy > y0 && cy < y1 && cz > z0 && cz < z1;
        int a = Math.max(0, Math.min(255, alpha)) << 24;
        if (in || cz < z0) quad(g, new double[]{x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0}, a | shade(rgb, 0.70));
        if (in || cz > z1) quad(g, new double[]{x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1}, a | shade(rgb, 0.70));
        if (in || cx < x0) quad(g, new double[]{x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0}, a | shade(rgb, 0.85));
        if (in || cx > x1) quad(g, new double[]{x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0}, a | shade(rgb, 0.85));
        if (in || cy < y0) quad(g, new double[]{x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1}, a | shade(rgb, 0.55));
        if (in || cy > y1) quad(g, new double[]{x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1}, a | shade(rgb, 1.0));
        if (darkEdge) box(g, b, edgeW + 1.2f, 0xB0000000);
        if (edgeW > 0) box(g, b, edgeW, edgeArgb);
    }

    /** Solid silhouette of a storage box in one flat colour (matches the reference look). */
    public static void solidBlock(GuiGraphics g, AABB b, int rgb, int alpha) {
        int a = Math.max(0, Math.min(255, alpha)) << 24;
        fillBoxExact(g, b, a | (rgb & 0xFFFFFF));
    }

    private static double cross(double ax, double ay, double bx, double by, double cx, double cy) {
        return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
    }

    private static void fillConvex(GuiGraphics g, double[] xs, double[] ys, int n, int argb) {
        double minY = Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < n; i++) { minY = Math.min(minY, ys[i]); maxY = Math.max(maxY, ys[i]); }
        int y0 = (int) Math.max(Math.ceil(minY), 0), y1 = (int) Math.min(Math.floor(maxY), h - 1);
        if (y1 < y0) return;
        int rowsN = y1 - y0 + 1, bandsN = Math.min(44, Math.max(4, rowsN / 2));
        int step = Math.max(1, (int) Math.ceil(rowsN / (double) bandsN));
        for (int y = y0; y <= y1; y += step) {
            double yc = Math.min(y + step * 0.5, y1 + 0.5), lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                double ya = ys[i], yb = ys[j];
                if ((ya <= yc && yb > yc) || (yb <= yc && ya > yc)) {
                    double x = xs[i] + (yc - ya) / (yb - ya) * (xs[j] - xs[i]);
                    lo = Math.min(lo, x); hi = Math.max(hi, x);
                }
            }
            if (hi > lo) {
                int xl = (int) Math.max(lo, 0), xr = (int) Math.min(hi, w);
                if (xr > xl) g.fill(xl, y, xr, Math.min(y + step, y1 + 1), argb);
            }
        }
    }

    public static void label(GuiGraphics g, String text, double x, double y, int argb) {
        Font f = Minecraft.getInstance().font;
        int tw = Draw.w(f, text);
        int left = -(tw / 2);
        var ps = g.pose();
        ps.pushMatrix();
        ps.translate((float) x, (float) y);
        Draw.roundR(g, left - 2, -5, tw + 7, 14, 4, 0x55000000);
        Draw.roundR(g, left - 3, -6, tw + 7, 14, 4, 0xD0121318);
        g.fill(left, -6, left + tw + 1, -5, 0x28FFFFFF);
        Draw.str(g, f, text, left, -3, argb, false);
        ps.popMatrix();
    }

    /** Tracer from the crosshair; works for targets behind you too (points toward them). */
    public static void tracer(GuiGraphics g, double x, double y, double z, float width, int argb) {
        toCam(x, y, z);
        double c0 = w / 2.0, c1 = h / 2.0;
        if (tz >= NEAR) {
            double ex = sx(tx, tz), ey = sy(ty, tz);
            line(g, c0, c1, ex, ey, width * 3f, Draw.alpha(argb, 0.14f));
            line(g, c0, c1, ex, ey, width, argb);
            return;
        }
        double dx = tx, dy = -ty, len = Math.hypot(dx, dy);
        if (len < 1e-6) { dx = 0; dy = 1; len = 1; }
        double k = Math.max(w, h) / len;
        line(g, c0, c1, c0 + dx * k, c1 + dy * k, width * 3f, Draw.alpha(argb, 0.14f));
        line(g, c0, c1, c0 + dx * k, c1 + dy * k, width, argb);
    }

    /** Tracer without the glow layer (half the cost) - used when there are many tracers. */
    public static void tracerFast(GuiGraphics g, double x, double y, double z, float width, int argb) {
        toCam(x, y, z);
        double c0 = w / 2.0, c1 = h / 2.0;
        if (tz >= NEAR) { line(g, c0, c1, sx(tx, tz), sy(ty, tz), width, argb); return; }
        double dx = tx, dy = -ty, len = Math.hypot(dx, dy);
        if (len < 1e-6) { dx = 0; dy = 1; len = 1; }
        double k = Math.max(w, h) / len;
        line(g, c0, c1, c0 + dx * k, c1 + dy * k, width, argb);
    }
}
