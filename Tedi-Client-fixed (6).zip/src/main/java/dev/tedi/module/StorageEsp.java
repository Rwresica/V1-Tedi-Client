package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Storage ESP: clean shaded boxes that match the real block shapes (chests are slightly inset, double chests are ONE box),
 * with level-of-detail so it stays smooth with hundreds of chests.
 */
public class StorageEsp extends Module {
    public static StorageEsp I;
    /** pos2 = other half of a double chest (or null). */
    public record Hit(BlockPos pos, int type, BlockPos pos2) {}
    public static final List<Hit> hits = new ArrayList<>();
    private static int timer;

    public final Setting.Bool chests = add(new Setting.Bool("Chests", true));
    public final Setting.Bool trapped = add(new Setting.Bool("Trapped Chests", true));
    public final Setting.Bool ender = add(new Setting.Bool("Ender Chests", true));
    public final Setting.Bool barrels = add(new Setting.Bool("Barrels", true));
    public final Setting.Bool shulkers = add(new Setting.Bool("Shulkers", true));
    public final Setting.Bool others = add(new Setting.Bool("Hoppers/Furnaces/etc", false));
    public final Setting.Hue cChest = add(new Setting.Hue("Chest Color", 170));
    public final Setting.Hue cTrapped = add(new Setting.Hue("Trapped Color", 0));
    public final Setting.Hue cEnder = add(new Setting.Hue("Ender Color", 280));
    public final Setting.Hue cBarrel = add(new Setting.Hue("Barrel Color", 100));
    public final Setting.Hue cShulker = add(new Setting.Hue("Shulker Color", 320));
    public final Setting.Hue cOther = add(new Setting.Hue("Other Color", 195));
    public final Setting.Bool solid = add(new Setting.Bool("Solid Style", true));
    public final Setting.Num solidAlpha = add(new Setting.Num("Solid Opacity", 0.92, 0.3, 1.0, 0.02));
    public final Setting.Bool fill = add(new Setting.Bool("Fill Blocks", true));
    public final Setting.Num fillAlpha = add(new Setting.Num("Fill Opacity", 0.34, 0.05, 1.0, 0.05));
    public final Setting.Bool boxes = add(new Setting.Bool("Outline", false));
    public final Setting.Bool tracers = add(new Setting.Bool("Tracers", true));
    public final Setting.Num tracerWidth = add(new Setting.Num("Tracer Width", 1.0, 0.5, 4.0, 0.5));
    public final Setting.Num maxTracers = add(new Setting.Num("Max Tracers", 60, 5, 300, 5));
    public final Setting.Num tracerRange = add(new Setting.Num("Tracer Range (0=all)", 0, 0, 512, 16));
    public final Setting.Num range = add(new Setting.Num("Box Range", 128, 16, 256, 8));
    public final Setting.Num maxBoxes = add(new Setting.Num("Max Boxes", 120, 10, 400, 10));

    public StorageEsp() {
        super("StorageESP", "Highlights storage blocks through walls.", "RENDER", true);
        I = this;
    }

    /** 0 chest, 1 trapped, 2 ender, 3 barrel, 4 shulker, 5 other, 6 spawner, -1 nothing */
    public static int classify(BlockEntity be) {
        if (be instanceof TrappedChestBlockEntity) return 1;
        if (be instanceof ChestBlockEntity) return 0;
        if (be instanceof EnderChestBlockEntity) return 2;
        if (be instanceof BarrelBlockEntity) return 3;
        if (be instanceof ShulkerBoxBlockEntity) return 4;
        if (be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity
                || be instanceof AbstractFurnaceBlockEntity || be instanceof BrewingStandBlockEntity) return 5;
        if (be instanceof SpawnerBlockEntity) return 6;
        return -1;
    }

    public static void scan(Minecraft mc) {
        if (mc.level == null || mc.player == null) { hits.clear(); return; }
        if (++timer % 10 != 0) return;
        hits.clear();
        int r = Math.min(mc.options.getEffectiveRenderDistance(), 16);
        int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
        for (int x = pcx - r; x <= pcx + r; x++) {
            for (int z = pcz - r; z <= pcz + r; z++) {
                LevelChunk ch = mc.level.getChunkSource().getChunkNow(x, z);
                if (ch == null) continue;
                for (BlockEntity be : ch.getBlockEntities().values()) {
                    int t = classify(be);
                    if (t < 0) continue;
                    BlockPos p2 = null;
                    if (t <= 1) {
                        BlockState st = be.getBlockState();
                        if (st.hasProperty(ChestBlock.TYPE)) {
                            ChestType ct = st.getValue(ChestBlock.TYPE);
                            if (ct == ChestType.RIGHT) continue;               // drawn together with its LEFT half
                            if (ct == ChestType.LEFT) p2 = be.getBlockPos().relative(ChestBlock.getConnectedDirection(st));
                        }
                    }
                    hits.add(new Hit(be.getBlockPos(), t, p2));
                }
            }
        }
        BlockPos me = mc.player.blockPosition();
        hits.sort(Comparator.comparingDouble(h -> h.pos().distSqr(me)));
    }

    public boolean typeEnabled(int t) {
        return switch (t) {
            case 0 -> chests.value; case 1 -> trapped.value; case 2 -> ender.value;
            case 3 -> barrels.value; case 4 -> shulkers.value; case 5 -> others.value;
            default -> false;
        };
    }

    public int colorFor(int t) {
        return switch (t) {
            case 0 -> cChest.argb(); case 1 -> cTrapped.argb(); case 2 -> cEnder.argb();
            case 3 -> cBarrel.argb(); case 4 -> cShulker.argb(); default -> cOther.argb();
        };
    }

    /** Real block shape: chests/ender chests are 14/16 wide and 14/16 tall. */
    private static AABB shape(Hit h) {
        double ins = h.type() <= 2 ? 0.0625 : 0.0, top = h.type() <= 2 ? 0.875 : 1.0;
        BlockPos p = h.pos();
        AABB a = new AABB(p.getX() + ins, p.getY(), p.getZ() + ins, p.getX() + 1 - ins, p.getY() + top, p.getZ() + 1 - ins);
        if (h.pos2() != null) {
            BlockPos q = h.pos2();
            a = a.minmax(new AABB(q.getX() + ins, q.getY(), q.getZ() + ins, q.getX() + 1 - ins, q.getY() + top, q.getZ() + 1 - ins));
        }
        return a;
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        double r2 = range.value * range.value;
        double tr2 = tracerRange.value <= 0 ? Double.MAX_VALUE : tracerRange.value * tracerRange.value;
        int alphaVal = (int) ((solid.value ? solidAlpha.value : fillAlpha.value) * 255);
        int tr = 0, maxT = maxTracers.i(), maxB = maxBoxes.i(), drawn = 0;
        boolean glow = maxT <= 40;
        for (Hit h : hits) {                       // nearest first
            if (!typeEnabled(h.type())) continue;
            BlockPos p = h.pos();
            double dx = p.getX() + 0.5 - Proj.cx, dy = p.getY() + 0.5 - Proj.cy, dz = p.getZ() + 0.5 - Proj.cz;
            double d2 = dx * dx + dy * dy + dz * dz;
            int col = colorFor(h.type());
            AABB bb = null;
            if (d2 <= r2) {
                bb = shape(h);
                if (fill.value && drawn < maxB) {
                    drawn++;
                    Proj.solidBlock(g, bb, col & 0xFFFFFF, alphaVal);
                }
                if (boxes.value && drawn <= maxB) Proj.box(g, bb, 1f, Colors.lerp(col, 0xFFFFFFFF, 0.35f));
            }
            if (tracers.value && tr < maxT && d2 <= tr2) {
                tr++;
                Vec3 c = bb != null ? bb.getCenter() : p.getCenter();
                if (glow && !solid.value) Proj.tracer(g, c.x, c.y, c.z, tracerWidth.f(), col);
                else Proj.tracerFast(g, c.x, c.y, c.z, tracerWidth.f(), col);
            }
        }
    }
}
