package dev.tedi.util;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Drawing of the busiest HUD parts (module list rows, keystroke keys), kept here so they are cheap, consistent and previewable. */
public final class HudFx {
    private HudFx() {}

    /**
     * One module-list entry. (x, y) = top-left, w = width, eh = row height (15 = full style, less = compact),
     * col = theme accent, am = fade-in 0..1, idx/count = position in the list (the accent walks a little along the list).
     */
    /** The line at the end of a row: a short 2px core with a soft glow and rounded ends, centred vertically in the row. */
    private static void endLine(GuiGraphics g, int x, int y, int w, int eh, int c, float am) {
        int hgt = eh >= 15 ? 7 : Math.max(4, eh / 2);
        int top = y + (eh - hgt) / 2;
        int lx = x + w - 7;
        g.fill(lx - 1, top + 1, lx + 3, top + hgt - 1, Draw.alpha(c, am * 0.20f));                      // soft glow
        g.fill(lx, top, lx + 2, top + hgt, Draw.alpha(Draw.lighten(c, 0.45f), am));                    // core
        g.fill(lx, top, lx + 2, top + 1, Draw.alpha(0xFFFFFFFF, am * 0.55f));                          // bright top cap
    }

    public static void listRow(GuiGraphics g, Font f, String name, int x, int y, int w, int eh, int col, float am, int idx, int count) {
        float k = count <= 1 ? 0f : Math.min(1f, idx / (float) (count - 1));
        int c = Colors.lerp(col, Draw.lighten(col, 0.55f), k * 0.7f);                      // top of the list = pure accent, bottom = lighter
        int top = Colors.lerp(Colors.B(0xF03C3292), c, 0.14f), bot = Colors.lerp(Colors.B(0xF01B1555), c, 0.06f), bd = Colors.lerp(Colors.B(0x668A78F0), c, 0.35f);
        if (eh >= 15) {
            Draw.roundG(g, x - 1, y - 1, w + 2, 17, 8, Draw.alpha(Draw.lighten(bd, 0.25f), am), Draw.alpha(Draw.darken(bd, 0.3f), am), false);   // border lit from above
            Draw.roundG(g, x, y, w, 15, 7, Draw.alpha(top, am), Draw.alpha(bot, am), false);
            g.fill(x + 7, y, x + w - 7, y + 1, Draw.alpha(0x1CFFF6EC, am));                                                                    // sheen
            Draw.text(g, f, name, x + 8, y + 4, Draw.alpha(Colors.VALUE, am), true);
                                                                      // soft glow behind the bar
            endLine(g, x, y, w, eh, c, am);                                                              // the | line at the end of the row
        } else {                                                       // compact: one rounded body, no border
            Draw.roundG(g, x, y, w, eh, eh / 2, Draw.alpha(top, am), Draw.alpha(bot, am), false);
            Draw.text(g, f, name, x + 7, y + (eh - 7) / 2, Draw.alpha(Colors.VALUE, am), true);
            endLine(g, x, y, w, eh, c, am);                                                          // the | line at the end of the row
        }
    }

    /** One keystroke key. p = how pressed it is (0..1, already smoothed by the caller). */
    public static void key(GuiGraphics g, Font f, int x, int y, int w, int h, String label, float p, float a, int col) {
        int topC = Colors.lerp(Colors.B(0xD02B2362), Colors.lerp(col, 0xFFFFFFFF, 0.55f), p);
        int botC = Colors.lerp(Colors.B(0xD0181040), col, p);
        var ps = g.pose();
        ps.pushMatrix();
        ps.translate(0f, p * 1f);                                                                   // the key sinks a pixel while pressed
        if (p > 0.04f) Draw.roundR(g, x - 3, y - 3, w + 6, h + 6, 8, Draw.alpha(col, a * 0.22f * p), false);   // glow
        Draw.roundG(g, x - 1, y - 1, w + 2, h + 2, 6, Draw.alpha(Draw.lighten(Colors.B(0x558A78F0), 0.25f), a), Draw.alpha(Draw.darken(Colors.B(0x558A78F0), 0.3f), a), false);
        Draw.roundG(g, x, y, w, h, 5, Draw.alpha(topC, a), Draw.alpha(botC, a), true);
        if (p < 0.9f) g.fill(x + 4, y, x + w - 4, y + 1, Draw.alpha(0x22FFFFFF, a * (1f - p)));       // top sheen fades when pressed
        int tc = Colors.lerp(0xFFFFFFFF, 0xFF1A1240, p);
        Draw.str(g, f, label, x + (w - Draw.w(f, label)) / 2, y + (h - 7) / 2, Draw.alpha(tc, a), false);
        ps.popMatrix();
    }
}
