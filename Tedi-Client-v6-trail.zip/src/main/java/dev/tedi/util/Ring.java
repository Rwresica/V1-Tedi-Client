package dev.tedi.util;

import net.minecraft.client.gui.GuiGraphics;

import java.util.HashMap;
import java.util.Map;

/** Draws flat circles / polygons lying in the world (built from projected line segments). */
public final class Ring {
    private Ring() {}

    public interface Colorer { int at(int segment, int segments); }

    private static final Map<Integer, double[][]> TABLE = new HashMap<>();

    private static double[][] table(int n) {
        double[][] t = TABLE.get(n);
        if (t == null) {
            t = new double[2][n + 1];
            for (int i = 0; i <= n; i++) {
                t[0][i] = Math.cos(i * Math.PI * 2.0 / n);
                t[1][i] = Math.sin(i * Math.PI * 2.0 / n);
            }
            TABLE.put(n, t);
        }
        return t;
    }

    /** Horizontal ring around (cx,cy,cz). rot = rotation in radians, colours come from the colorer. */
    public static void draw(GuiGraphics g, double cx, double cy, double cz, double r, int segs, double rot, float width, Colorer col) {
        if (r <= 0.001) return;
        double[][] t = table(segs);
        double cr = Math.cos(rot), sr = Math.sin(rot);
        double px = 0, pz = 0;
        for (int i = 0; i <= segs; i++) {
            double ux = t[0][i] * cr - t[1][i] * sr, uz = t[0][i] * sr + t[1][i] * cr;
            double x = cx + ux * r, z = cz + uz * r;
            if (i > 0) {
                int c = col.at(i - 1, segs);
                if (((c >>> 24) & 255) > 2) Proj.line3d(g, px, cy, pz, x, cy, z, width, c);
            }
            px = x; pz = z;
        }
    }

    public static void draw(GuiGraphics g, double cx, double cy, double cz, double r, int segs, double rot, float width, int argb) {
        draw(g, cx, cy, cz, r, segs, rot, width, (i, n) -> argb);
    }

    private static final double[] DISC = new double[3 * 64];

    /** Translucent filled disc lying in the world (one convex polygon). */
    public static void disc(GuiGraphics g, double cx, double cy, double cz, double r, int segs, double rot, int argb) {
        if (r <= 0.001 || segs > 64 || ((argb >>> 24) & 255) < 3) return;
        double[][] t = table(segs);
        double cr = Math.cos(rot), sr = Math.sin(rot);
        for (int i = 0; i < segs; i++) {
            double ux = t[0][i] * cr - t[1][i] * sr, uz = t[0][i] * sr + t[1][i] * cr;
            DISC[i * 3] = cx + ux * r; DISC[i * 3 + 1] = cy; DISC[i * 3 + 2] = cz + uz * r;
        }
        Proj.poly(g, DISC, segs, argb);
    }
}
