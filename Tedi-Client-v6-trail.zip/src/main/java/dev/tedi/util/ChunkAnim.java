package dev.tedi.util;

import java.util.HashMap;
import java.util.Map;

/** Remembers when each flagged chunk first appeared, so its plate can grow in smoothly. */
public final class ChunkAnim {
    private final Map<Long, long[]> seen = new HashMap<>();    // key -> {firstSeen, lastSeen}
    private int frame;

    private static long key(int cx, int cz) { return (((long) cx) << 32) ^ (cz & 0xFFFFFFFFL); }

    /** 0..1 progress of the appear animation (about half a second). */
    public float appear(int cx, int cz, long now) {
        long k = key(cx, cz);
        long[] e = seen.get(k);
        if (e == null) { e = new long[]{now, now}; seen.put(k, e); }
        e[1] = now;
        return Math.min(1f, (now - e[0]) / 520f);
    }

    /** Call once per frame after drawing: forgets chunks that have not been drawn for a while. */
    public void endFrame(long now) {
        if (++frame % 90 == 0) seen.values().removeIf(e -> now - e[1] > 1500);
    }

    public void clear() { seen.clear(); }
}
