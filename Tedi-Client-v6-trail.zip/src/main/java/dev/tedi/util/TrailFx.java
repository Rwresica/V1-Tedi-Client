package dev.tedi.util;

import net.minecraft.client.gui.GuiGraphics;

/**
 * How one tile of BlockTrail looks. A tile is the top face of a block you walked on: it flashes when you step on it,
 * glows, and then shrinks and dissolves. Three styles; every tile is only a few polygons / lines.
 */
public final class TrailFx {
    private TrailFx() {}

    private static final double[] Q = new double[12];

    /**
     * @param x,z  block corner   @param y  height of the top face
     * @param t    age 0..1 (0 = just stepped on)   @param ageSec age in seconds (for the first flash)
     * @param c1,c2 argb colours   @param opa overall opacity
     */
    public static void tile(GuiGraphics g, double x, double y, double z, float t, float ageSec, int style, int c1, int c2, float opa, boolean outline, double time, int seed, boolean cheap) {
        float fade = (float) Math.pow(1f - t, 1.5);
        if (fade * opa < 0.035f) return;                                           // practically invisible: draw nothing
        float flash = Math.max(0f, 1f - ageSec / 0.22f);                         // bright pop right when you step on it
        int hot = Colors.lerp(c1, 0xFFFFFFFF, 0.55f * flash);
        double yy = y + 0.012;
        switch (style) {
            case 2 -> ripple(g, x, yy, z, t, fade, flash, c1, c2, opa, outline && !cheap);
            case 3 -> pad(g, x, yy, z, t, ageSec, fade, flash, c1, c2, opa, time, seed, cheap);
            default -> {
                double in = 0.035 + 0.24 * t * t;                                 // the tile shrinks while it fades
                square(g, x, yy, z, in, Draw.alpha(Colors.lerp(hot, c2, t * 0.6f), opa * fade * 0.70f));
                if (!cheap) {                                                       // far away tiles only get the base square
                    square(g, x, yy, z, in + 0.20, Draw.alpha(Colors.lerp(hot, 0xFFFFFFFF, 0.40f), opa * fade * (0.50f + 0.35f * flash)));
                    if (outline && fade > 0.3f) edges(g, x, yy, z, in, 1.5f, Draw.alpha(Colors.lerp(hot, 0xFFFFFFFF, 0.35f), Math.min(1f, opa * 1.5f) * fade));
                }
            }
        }
    }

    private static void ripple(GuiGraphics g, double x, double y, double z, float t, float fade, float flash, int c1, int c2, float opa, boolean outline) {
        double e = 1 - Math.pow(1 - t, 2.2);
        double in1 = 0.46 - 0.44 * e;                                             // a square ring that spreads out to the block edge
        double in2 = 0.46 - 0.44 * Math.max(0, e - 0.28) / 0.72;
        square(g, x, y, z, 0.03, Draw.alpha(Colors.lerp(c1, c2, t), opa * fade * 0.38f));
        edges(g, x, y, z, Math.max(0.0, in1), 2.6f, Draw.alpha(Colors.lerp(c1, 0xFFFFFFFF, 0.3f + 0.4f * flash), Math.min(1f, opa * 1.2f) * fade));
        if (outline && fade > 0.3f) edges(g, x, y, z, Math.max(0.0, in2), 1.6f, Draw.alpha(c2, opa * fade * 0.7f));
    }

    private static void pad(GuiGraphics g, double x, double y, double z, float t, float ageSec, float fade, float flash, int c1, int c2, float opa, double time, int seed, boolean cheap) {
        double breathe = 1.0 + 0.04 * Math.sin(time * 6 + seed);
        int layers = cheap ? 2 : 3;
        for (int k = 0; k < layers; k++) {                                         // stacked squares = a soft glow pad
            double in = (0.04 + k * (cheap ? 0.20 : 0.13) + 0.12 * t) / breathe;
            square(g, x, y, z, in, Draw.alpha(Colors.lerp(c1, c2, k / 2f), opa * fade * (0.34f + 0.18f * k + 0.25f * flash * (k / 2f))));
        }
        if (cheap || fade < 0.3f) return;
        for (int i = 0; i < 2; i++) {                                              // little sparks lifting off the tile
            double ax = x + 0.2 + 0.6 * (((seed * 31 + i * 17) & 15) / 15.0), az = z + 0.2 + 0.6 * (((seed * 17 + i * 29) & 15) / 15.0);
            double h = (0.15 + 0.55 * ((i + 1) / 4.0)) * (0.3 + t * 1.4);
            if (!Proj.project(ax, y + h, az)) continue;
            int px = (int) Proj.px, py = (int) Proj.py;
            float a = opa * fade;
            g.fill(px - 1, py - 1, px + 2, py + 2, Draw.alpha(c1, a * 0.28f));
            g.fill(px, py, px + 1, py + 1, Draw.alpha(0xFFFFFFFF, a));
        }
    }

    /** Filled square lying on the top face, `in` blocks in from every edge. */
    private static void square(GuiGraphics g, double x, double y, double z, double in, int argb) {
        if (((argb >>> 24) & 255) < 3 || in >= 0.5) return;
        Q[0] = x + in; Q[1] = y; Q[2] = z + in;
        Q[3] = x + 1 - in; Q[4] = y; Q[5] = z + in;
        Q[6] = x + 1 - in; Q[7] = y; Q[8] = z + 1 - in;
        Q[9] = x + in; Q[10] = y; Q[11] = z + 1 - in;
        Proj.poly(g, Q, 4, argb);
    }

    private static void edges(GuiGraphics g, double x, double y, double z, double in, float w, int argb) {
        if (((argb >>> 24) & 255) < 3 || in >= 0.5) return;
        double a = x + in, b = x + 1 - in, c = z + in, d = z + 1 - in;
        Proj.line3d(g, a, y, c, b, y, c, w, argb);
        Proj.line3d(g, b, y, c, b, y, d, w, argb);
        Proj.line3d(g, b, y, d, a, y, d, w, argb);
        Proj.line3d(g, a, y, d, a, y, c, w, argb);
    }
}
