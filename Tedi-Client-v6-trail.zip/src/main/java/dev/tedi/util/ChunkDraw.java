package dev.tedi.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Flagged-chunk markers: a flat, glossy plate with rounded corners (+ optional radar ripples). */
public final class ChunkDraw {
    private ChunkDraw() {}

    /** Rounded rectangle on the XZ plane at height y, as 3D points going around the edge. */
    private static double[] roundedRect(double x0, double z0, double x1, double z1, double r, double y, int seg) {
        int n = 4 * (seg + 1);
        double[] p = new double[n * 3];
        double[][] c = {{x1 - r, z0 + r, -90}, {x1 - r, z1 - r, 0}, {x0 + r, z1 - r, 90}, {x0 + r, z0 + r, 180}};
        int k = 0;
        for (double[] corner : c) {
            for (int i = 0; i <= seg; i++) {
                double a = Math.toRadians(corner[2] + 90.0 * i / seg);
                p[k++] = corner[0] + r * Math.cos(a);
                p[k++] = y;
                p[k++] = corner[1] + r * Math.sin(a);
            }
        }
        return p;
    }

    /**
     * Animated plate: grows in when the chunk appears, breathes, has glowing corner brackets and a light sweep.
     * top = one of the strongest chunks: also gets a rising light beam and an expanding ripple.
     * strength 0..1 = how sure we are (faster / brighter). Costs ~10 draw calls per chunk (~25 for the top ones).
     */
    public static void plate(GuiGraphics g, int cx, int cz, double y, int rgb, int alpha, int edgeArgb, float appear, float strength, boolean top, boolean animate) {
        double now = System.currentTimeMillis() / 1000.0;
        double ph = cx * 0.83 + cz * 1.37;
        float fa = animate ? Draw.easeOut(appear) : 1f;
        double s = animate ? 0.55 + 0.45 * Draw.easeOutBack(appear) : 1.0;
        double mx = cx * 16 + 8, mz = cz * 16 + 8, h = 7.6 * s;
        double x0 = mx - h, x1 = mx + h, z0 = mz - h, z1 = mz + h;
        float pulse = animate ? (float) (0.88 + 0.12 * Math.sin(now * (2.0 + strength * 2.0) + ph)) : 1f;
        int a = Math.max(0, Math.min(255, (int) (alpha * fa * pulse * (0.75 + 0.25 * strength))));
        if (a < 4) return;

        double[] outer = roundedRect(x0, z0, x1, z1, 3.4 * s, y, 2);
        int n = outer.length / 3;
        Proj.poly(g, outer, n, (a << 24) | (rgb & 0xFFFFFF));
        int lr = ((rgb >> 16 & 255) + 255 * 2) / 3, lg = ((rgb >> 8 & 255) + 255 * 2) / 3, lb = ((rgb & 255) + 255 * 2) / 3;
        double[] inner = roundedRect(x0 + 1.6 * s, z0 + 1.6 * s, x1 - 1.6 * s, z1 - 1.6 * s, 2.0 * s, y + 0.02, 2);
        Proj.poly(g, inner, n, ((int) (a * 0.40) << 24) | (lr << 16) | (lg << 8) | lb);

        // glowing corner brackets that breathe outward
        double o = animate ? 0.18 * (0.5 + 0.5 * Math.sin(now * 2.6 + ph)) : 0.0;
        double arm = 3.6 * s;
        int core = Draw.alpha(edgeArgb, fa), glow = Draw.alpha(edgeArgb, 0.16f * fa);
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                double px = mx + sx * (h + o), pz = mz + sz * (h + o);
                if (top) {
                    Proj.line3d(g, px, y, pz, px - sx * arm, y, pz, 4.6f, glow);
                    Proj.line3d(g, px, y, pz, px, y, pz - sz * arm, 4.6f, glow);
                }
                Proj.line3d(g, px, y, pz, px - sx * arm, y, pz, 2.0f, core);
                Proj.line3d(g, px, y, pz, px, y, pz - sz * arm, 2.0f, core);
            }
        }
        if (!animate) return;

        // light sweep gliding across the glass
        if (top || strength > 0.55f) {
            double u = (now * 0.5 + ph * 0.13) % 1.0;
            double bx = x0 + 2.2 + (x1 - x0 - 4.4) * u, bw = 1.5 * s, sk = 1.4 * s;
            double lo = x0 + 1.2 * s, hi = x1 - 1.2 * s;
            double[] q = {
                Math.max(lo, bx - bw + sk), y + 0.04, z0 + 1.8 * s,
                Math.min(hi, bx + bw + sk), y + 0.04, z0 + 1.8 * s,
                Math.min(hi, bx + bw - sk), y + 0.04, z1 - 1.8 * s,
                Math.max(lo, bx - bw - sk), y + 0.04, z1 - 1.8 * s};
            Proj.poly(g, q, 4, ((int) (86 * Math.sin(Math.PI * u) * fa) << 24) | 0xFFFFFF);
        }
        if (top) {
            // rising beam
            double bh = 14.0 * Draw.easeOut(appear);
            Proj.line3d(g, mx, y, mz, mx, y + bh * 0.5, mz, 7f, Draw.alpha(edgeArgb, 0.10f));
            Proj.line3d(g, mx, y, mz, mx, y + bh * 0.5, mz, 2.2f, Draw.alpha(edgeArgb, 0.55f));
            Proj.line3d(g, mx, y + bh * 0.5, mz, mx, y + bh, mz, 5f, Draw.alpha(edgeArgb, 0.05f));
            Proj.line3d(g, mx, y + bh * 0.5, mz, mx, y + bh, mz, 1.8f, Draw.alpha(edgeArgb, 0.22f));
            // one expanding ripple
            double pr = (now / 2.6 + ph * 0.1) % 1.0;
            Ring.draw(g, mx, y + 0.03, mz, 0.8 + pr * 6.4, 12, 0, 1.2f, Draw.alpha(edgeArgb, (float) Math.pow(1.0 - pr, 1.2) * fa));
        }
    }

    /**
     * Glossy rounded plate over a whole chunk. detail 0 = cheap (fill only), 1 = + border, 2 = + glow border.
     * rings > 0 adds expanding radar ripples in the middle.
     */
    public static void glass(GuiGraphics g, int cx, int cz, double y, int rgb, int alpha, int edgeArgb, int rings, int detail) {
        double x0 = cx * 16 + 0.4, z0 = cz * 16 + 0.4, x1 = cx * 16 + 15.6, z1 = cz * 16 + 15.6;
        int seg = 3;
        double[] outer = roundedRect(x0, z0, x1, z1, 3.4, y, seg);
        int n = outer.length / 3;
        Proj.poly(g, outer, n, (Math.max(0, Math.min(255, alpha)) << 24) | (rgb & 0xFFFFFF));
        // lighter inner plate = glass depth
        int lr = ((rgb >> 16 & 255) + 255 * 2) / 3, lg = ((rgb >> 8 & 255) + 255 * 2) / 3, lb = ((rgb & 255) + 255 * 2) / 3;
        double[] inner = roundedRect(x0 + 1.6, z0 + 1.6, x1 - 1.6, z1 - 1.6, 2.0, y + 0.02, seg);
        Proj.poly(g, inner, n, ((int) (alpha * 0.40) << 24) | (lr << 16) | (lg << 8) | lb);
        if (detail >= 1) {
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                if (detail >= 2) Proj.line3d(g, outer[i * 3], y, outer[i * 3 + 2], outer[j * 3], y, outer[j * 3 + 2], 3.2f, Draw.alpha(edgeArgb, 0.18f));
                Proj.line3d(g, outer[i * 3], y, outer[i * 3 + 2], outer[j * 3], y, outer[j * 3 + 2], 1.2f, edgeArgb);
            }
        }
        if (rings > 0) {
            double mx = cx * 16 + 8, mz = cz * 16 + 8;
            double t = (System.currentTimeMillis() % 3000) / 3000.0;
            int segs = 18;
            for (int k = 0; k < rings; k++) {
                double ph = (t + k / (double) rings) % 1.0;
                double rad = 0.8 + ph * 6.4;
                int col = Draw.alpha(edgeArgb, (float) (1.0 - ph));
                for (int i = 0; i < segs; i++) {
                    double a0 = Math.PI * 2 * i / segs, a1 = Math.PI * 2 * (i + 1) / segs;
                    Proj.line3d(g, mx + rad * Math.cos(a0), y + 0.03, mz + rad * Math.sin(a0),
                            mx + rad * Math.cos(a1), y + 0.03, mz + rad * Math.sin(a1), 1.1f, col);
                }
            }
        }
    }
}
