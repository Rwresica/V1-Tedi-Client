package dev.tedi.util;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;

/** World tags (broken-item tags): a glass pill with an item slot, a coloured edge bar and a pin that touches the block. */
public final class Tags {
    private Tags() {}

    /** Pill centred horizontally on (x, y); y is the vertical middle of the pill. */
    public static void item(GuiGraphics g, Font f, ItemStack st, String text, double x, double y, float a, float scale, int accent) {
        int tw = Draw.width(f, text, true), w = tw + 38, left = -w / 2;
        var ps = g.pose();
        ps.pushMatrix();
        ps.translate((float) x, (float) y);
        ps.scale(scale, scale);
        Draw.shadow(g, left, -9, w, 19, 8);
        Draw.panel(g, left, -9, w, 19, 8, Colors.NAVY, Colors.NAVY_BORDER, a);
        Draw.roundG(g, left + 2, -7, 17, 15, 6, Draw.alpha(Colors.withAlpha(Draw.lighten(accent, 0.2f), 0x44), a), Draw.alpha(Colors.withAlpha(accent, 0x1C), a), false);   // item slot
        if (a > 0.35f && st != null) g.renderItem(st, left + 3, -8);
        Draw.text(g, f, text, left + 23, -4, Draw.alpha(Colors.VALUE, a), true);
        Draw.roundG(g, left + w - 7, -5, 3, 11, 1, Draw.alpha(Draw.lighten(accent, 0.4f), a), Draw.alpha(accent, a), false);                                              // accent bar
        ps.popMatrix();
    }

    /** Stem + glowing dot that ties a tag to the exact block it came from. (x, y) = the point on the block. */
    public static void pin(GuiGraphics g, double x, double y, float a, float scale, int accent) {
        var ps = g.pose();
        ps.pushMatrix();
        ps.translate((float) x, (float) y);
        ps.scale(scale, scale);
        g.fillGradient(0, -10, 1, -1, Draw.alpha(Draw.lighten(accent, 0.3f), 0f), Draw.alpha(Draw.lighten(accent, 0.3f), a * 0.85f));   // stem fades in towards the block
        g.fill(-3, -3, 4, 4, Draw.alpha(accent, a * 0.22f));                                                                                              // glow
        g.fill(-2, -2, 3, 3, Draw.alpha(accent, a * 0.55f));
        g.fill(-1, -1, 2, 2, Draw.alpha(0xFFFFFFFF, a));                                                                                                  // dot on the block
        ps.popMatrix();
    }
}
