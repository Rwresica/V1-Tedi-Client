package dev.tedi.util;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.AABB;

import java.util.Random;

/**
 * The look of the block highlight: glass fill, lit hit face, corner brackets, a light sweep that runs around the block,
 * and while you mine: heat colour (cool -> orange -> red), cracks that grow out of the hit face, a little shake just
 * before it breaks, and a burst of shards when it is gone.
 *
 * Everything is a handful of projected lines / polygons (about 40 elements idle, about 90 while mining) and the
 * crack pattern is generated once per block, so it costs next to nothing.
 */
public final class BlockFx {
    private BlockFx() {}

    private static final int HOT = 0xFFFF4D5E;
    private static final double[] POLY = new double[12];

    // ---------------------------------------------------------------- the highlight
    /**
     * @param face     Direction.ordinal() of the face you look at (0 down, 1 up, 2 north, 3 south, 4 west, 5 east) or -1
     * @param progress mining progress 0..1 (0 = not mining)
     */
    public static void draw(GuiGraphics g, AABB bb, int face, float progress, int baseArgb, float opacity, boolean outline, boolean extras, double time, long seed) {
        float p = Math.max(0f, Math.min(1f, progress));
        boolean mining = p > 0.015f;
        float heat = Draw.smooth(Math.min(1f, p * 1.15f));
        int col = heatColor(baseArgb, heat);
        double pulse = 0.5 + 0.5 * Math.sin(time * 3.2);

        // the block "tenses up" while it is being mined: it shrinks a little and shakes just before it breaks
        double sh = mining ? 0.004 + 0.05 * p * p : 0.0;
        double jx = 0, jz = 0;
        if (p > 0.82f) { double k = (p - 0.82) * 0.06; jx = Math.sin(time * 70) * k; jz = Math.cos(time * 83) * k; }
        AABB b = new AABB(bb.minX + sh + jx, bb.minY + sh, bb.minZ + sh + jz, bb.maxX - sh + jx, bb.maxY - sh, bb.maxZ - sh + jz);

        Proj.fillBox(g, b, Draw.alpha(col, opacity * (0.85f + 0.5f * p)));
        if (face >= 0) {                                              // the face under the crosshair is lit stronger
            facePoly(b, face, 1.0, 1.0, 0.0);
            Proj.poly(g, POLY, 4, Draw.alpha(Colors.lerp(col, 0xFFFFFFFF, 0.35f), (float) ((0.16 + 0.16 * pulse) * (1f - 0.3f * p) + 0.12 * p)));
            facePoly(b, face, 0.72, 0.72, 0.0);
            Proj.poly(g, POLY, 4, Draw.alpha(Colors.lerp(col, 0xFFFFFFFF, 0.55f), (float) (0.10 + 0.10 * pulse)));
        }
        if (outline) Proj.box(g, b, 1.2f, Draw.alpha(Colors.lerp(col, 0xFFFFFFFF, 0.35f - 0.2f * heat), 0.55f + 0.4f * heat));
        if (extras) {
            corners(g, b, Colors.lerp(col, 0xFFFFFFFF, 0.55f), (float) (0.75 + 0.25 * pulse));
            sweep(g, b, Colors.lerp(col, 0xFFFFFFFF, 0.7f), time * (0.55 + 2.2 * p), 1f - 0.4f * p);
        }
        if (mining && face >= 0) cracks(g, b, face, p, seed, heat);
    }

    // the colour walks base -> mint -> yellow -> orange -> red (like a health bar), so it never turns grey on the way
    private static final int[] HEAT = {0xFF6BF2C0, 0xFFFFE066, 0xFFFF9A4A, 0xFFFF4D5E};

    private static int heatColor(int base, float heat) {
        if (heat <= 0.001f) return base;
        float s = heat * HEAT.length;
        int i = Math.min(HEAT.length - 1, (int) s);
        int from = i == 0 ? base : HEAT[i - 1];
        return Colors.lerp(from, HEAT[i], Draw.smooth(s - i));
    }

    /** Fills POLY with the 4 corners of a face, optionally scaled around its centre (sa, sb) and pushed out by `out`. */
    private static void facePoly(AABB b, int face, double sa, double sb, double out) {
        double cx = (b.minX + b.maxX) / 2, cy = (b.minY + b.maxY) / 2, cz = (b.minZ + b.maxZ) / 2;
        double hx = (b.maxX - b.minX) / 2, hy = (b.maxY - b.minY) / 2, hz = (b.maxZ - b.minZ) / 2;
        for (int i = 0; i < 4; i++) {
            double a = (i == 0 || i == 3) ? -sa : sa, c = (i < 2) ? -sb : sb;
            double x, y, z;
            switch (face) {
                case 0: x = cx + a * hx; y = b.minY - out; z = cz + c * hz; break;
                case 1: x = cx + a * hx; y = b.maxY + out; z = cz + c * hz; break;
                case 2: x = cx + a * hx; y = cy + c * hy; z = b.minZ - out; break;
                case 3: x = cx + a * hx; y = cy + c * hy; z = b.maxZ + out; break;
                case 4: x = b.minX - out; y = cy + c * hy; z = cz + a * hz; break;
                default: x = b.maxX + out; y = cy + c * hy; z = cz + a * hz; break;
            }
            POLY[i * 3] = x; POLY[i * 3 + 1] = y; POLY[i * 3 + 2] = z;
        }
    }

    private static void corners(GuiGraphics g, AABB b, int argb, float a) {
        double dx = (b.maxX - b.minX) * 0.24, dy = (b.maxY - b.minY) * 0.24, dz = (b.maxZ - b.minZ) * 0.24;
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? b.minX : b.maxX, y = (i & 2) == 0 ? b.minY : b.maxY, z = (i & 4) == 0 ? b.minZ : b.maxZ;
            double sx = (i & 1) == 0 ? dx : -dx, sy = (i & 2) == 0 ? dy : -dy, sz = (i & 4) == 0 ? dz : -dz;
            int c = Draw.alpha(argb, a);
            Proj.line3d(g, x, y, z, x + sx, y, z, 2.2f, c);
            Proj.line3d(g, x, y, z, x, y + sy, z, 2.2f, c);
            Proj.line3d(g, x, y, z, x, y, z + sz, 2.2f, c);
        }
    }

    // the sweep runs around the top square, down one pillar, and back around the bottom square
    private static final double[][] LOOP = {
        {0, 1, 0}, {1, 1, 0}, {1, 1, 1}, {0, 1, 1}, {0, 1, 0}, {0, 0, 0}, {1, 0, 0}, {1, 0, 1}, {0, 0, 1}, {0, 0, 0}};

    private static void sweep(GuiGraphics g, AABB b, int argb, double t, float a) {
        double[] pos = new double[3], prev = new double[3];
        final int N = 6;
        double head = (t % 1.0 + 1.0) % 1.0, tail = 0.17;
        boolean have = false;
        for (int i = 0; i <= N; i++) {
            double u = head - tail * i / N;
            u = (u % 1.0 + 1.0) % 1.0;
            loopPoint(b, u, pos);
            if (have) {
                float f = 1f - (float) (i - 1) / N;
                Proj.line3d(g, prev[0], prev[1], prev[2], pos[0], pos[1], pos[2], 2.6f * f + 0.8f, Draw.alpha(argb, a * f * f));
            }
            prev[0] = pos[0]; prev[1] = pos[1]; prev[2] = pos[2]; have = true;
        }
    }

    private static void loopPoint(AABB b, double u, double[] out) {
        double s = u * (LOOP.length - 1);
        int i = Math.min(LOOP.length - 2, (int) s);
        double f = s - i;
        double[] a = LOOP[i], c = LOOP[i + 1];
        out[0] = b.minX + (b.maxX - b.minX) * (a[0] + (c[0] - a[0]) * f);
        out[1] = b.minY + (b.maxY - b.minY) * (a[1] + (c[1] - a[1]) * f);
        out[2] = b.minZ + (b.maxZ - b.minZ) * (a[2] + (c[2] - a[2]) * f);
    }

    // ---------------------------------------------------------------- cracks
    private static long crackSeed = Long.MIN_VALUE;
    private static final int BR = 7, PT = 5;
    private static final double[][] CRACK = new double[BR][PT * 2];       // face coordinates -1..1

    private static void buildCracks(long seed) {
        crackSeed = seed;
        Random r = new Random(seed * 0x9E3779B97F4A7C15L + 12345);
        for (int k = 0; k < BR; k++) {
            double ang = (k + r.nextDouble() * 0.6) * (Math.PI * 2 / BR), x = 0, y = 0;
            CRACK[k][0] = 0; CRACK[k][1] = 0;
            for (int i = 1; i < PT; i++) {
                ang += (r.nextDouble() - 0.5) * 1.0;
                double len = 0.20 + r.nextDouble() * 0.16;
                x = Math.max(-0.97, Math.min(0.97, x + Math.cos(ang) * len));
                y = Math.max(-0.97, Math.min(0.97, y + Math.sin(ang) * len));
                CRACK[k][i * 2] = x; CRACK[k][i * 2 + 1] = y;
            }
        }
    }

    private static void facePoint(AABB b, int face, double a, double c, double[] out) {
        double cx = (b.minX + b.maxX) / 2, cy = (b.minY + b.maxY) / 2, cz = (b.minZ + b.maxZ) / 2;
        double hx = (b.maxX - b.minX) / 2, hy = (b.maxY - b.minY) / 2, hz = (b.maxZ - b.minZ) / 2;
        double o = 0.004;
        switch (face) {
            case 0: out[0] = cx + a * hx; out[1] = b.minY - o; out[2] = cz + c * hz; break;
            case 1: out[0] = cx + a * hx; out[1] = b.maxY + o; out[2] = cz + c * hz; break;
            case 2: out[0] = cx + a * hx; out[1] = cy + c * hy; out[2] = b.minZ - o; break;
            case 3: out[0] = cx + a * hx; out[1] = cy + c * hy; out[2] = b.maxZ + o; break;
            case 4: out[0] = b.minX - o; out[1] = cy + c * hy; out[2] = cz + a * hz; break;
            default: out[0] = b.maxX + o; out[1] = cy + c * hy; out[2] = cz + a * hz; break;
        }
    }

    private static void cracks(GuiGraphics g, AABB b, int face, float p, long seed, float heat) {
        if (seed != crackSeed) buildCracks(seed);
        double[] a = new double[3], c = new double[3];
        int dark = Draw.alpha(0xFF0A0614, 0.62f), light = Draw.alpha(Colors.lerp(0xFFFFE9CF, HOT, heat * 0.6f), 0.55f + 0.4f * p);
        for (int k = 0; k < BR; k++) {
            double reveal = Math.max(0, Math.min(1, (p * 1.35 - k * 0.045)));       // branches appear one after another
            double segs = reveal * (PT - 1);
            for (int i = 0; i < PT - 1 && segs > i; i++) {
                double f = Math.min(1.0, segs - i);
                double x0 = CRACK[k][i * 2], y0 = CRACK[k][i * 2 + 1];
                double x1 = x0 + (CRACK[k][i * 2 + 2] - x0) * f, y1 = y0 + (CRACK[k][i * 2 + 3] - y0) * f;
                facePoint(b, face, x0, y0, a);
                facePoint(b, face, x1, y1, c);
                Proj.line3d(g, a[0], a[1], a[2], c[0], c[1], c[2], 2.6f, dark);
                Proj.line3d(g, a[0], a[1], a[2], c[0], c[1], c[2], 1.1f, light);
            }
        }
    }

    // ---------------------------------------------------------------- shards when the block breaks
    private static final int MAX = 44;
    private static final double[][] SH = new double[MAX][9];             // x y z vx vy vz life size rgbIndex
    private static final int[] SHC = new int[MAX];
    private static int shards;
    private static long lastNano = System.nanoTime();

    public static void burst(double x, double y, double z, int argb, long seed) {
        Random r = new Random(seed);
        for (int i = 0; i < 26 && shards < MAX; i++) {
            double[] s = SH[shards];
            s[0] = x + (r.nextDouble() - 0.5) * 0.7; s[1] = y + (r.nextDouble() - 0.5) * 0.7; s[2] = z + (r.nextDouble() - 0.5) * 0.7;
            double ang = r.nextDouble() * Math.PI * 2, sp = 1.0 + r.nextDouble() * 2.6;
            s[3] = Math.cos(ang) * sp; s[4] = 1.2 + r.nextDouble() * 2.6; s[5] = Math.sin(ang) * sp;
            s[6] = 0.55 + r.nextDouble() * 0.4; s[7] = 1 + r.nextInt(3);
            SHC[shards] = Colors.lerp(argb, 0xFFFFFFFF, (float) (r.nextDouble() * 0.5));
            shards++;
        }
    }

    public static void drawShards(GuiGraphics g) {
        long now = System.nanoTime();
        double dt = Math.min(0.05, (now - lastNano) / 1e9);
        lastNano = now;
        for (int i = shards - 1; i >= 0; i--) {
            double[] s = SH[i];
            s[6] -= dt;
            if (s[6] <= 0) {                                              // remove by swapping with the last
                shards--;
                if (i != shards) { System.arraycopy(SH[shards], 0, s, 0, 9); SHC[i] = SHC[shards]; }
                continue;
            }
            s[4] -= 9.0 * dt;
            s[0] += s[3] * dt; s[1] += s[4] * dt; s[2] += s[5] * dt;
            if (!Proj.project(s[0], s[1], s[2])) continue;
            int x = (int) Proj.px, y = (int) Proj.py, z = (int) s[7];
            float a = (float) Math.min(1.0, s[6] * 2.2);
            g.fill(x - 1, y - 1, x + z + 1, y + z + 1, Draw.alpha(SHC[i], a * 0.25f));
            g.fill(x, y, x + z, y + z, Draw.alpha(SHC[i], a));
        }
    }
}
