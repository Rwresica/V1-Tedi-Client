package dev.tedi.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.*;

/** Groups neighbouring flagged chunks into one "base" and floats a small tag over each group. */
public final class BaseTags {
    private BaseTags() {}

    public record Cluster(double x, double y, double z, int size, int pct, int level, boolean ug) {}

    private static long key(int x, int z) { return (((long) x) << 32) ^ (z & 0xFFFFFFFFL); }

    /** chunks: {chunkX, chunkZ, percent, plateY}. Chunks touching each other (also diagonally) form one cluster. */
    public static List<Cluster> build(List<int[]> chunks) {
        Map<Long, int[]> map = new HashMap<>();
        for (int[] c : chunks) map.put(key(c[0], c[1]), c);
        Set<Long> seen = new HashSet<>();
        List<Cluster> out = new ArrayList<>();
        for (int[] c : chunks) {
            if (!seen.add(key(c[0], c[1]))) continue;
            ArrayDeque<int[]> stack = new ArrayDeque<>();
            stack.push(c);
            double sx = 0, sy = 0, sz = 0; int n = 0, best = 0, lvl = 0; boolean anyUg = false;
            while (!stack.isEmpty()) {
                int[] cur = stack.pop();
                sx += cur[0] * 16 + 8; sz += cur[1] * 16 + 8; sy += cur[3]; n++; best = Math.max(best, cur[2]);
                lvl = Math.max(lvl, cur.length > 4 ? cur[4] : 0); anyUg |= cur.length > 5 && cur[5] == 1;
                for (int dx = -1; dx <= 1; dx++)
                    for (int dz = -1; dz <= 1; dz++) {
                        int[] nb = map.get(key(cur[0] + dx, cur[1] + dz));
                        if (nb != null && seen.add(key(nb[0], nb[1]))) stack.push(nb);
                    }
            }
            out.add(new Cluster(sx / n, sy / n, sz / n, n, best, lvl, anyUg));
        }
        return out;
    }

    private record Cand(Cluster c, double dist) {}

    /** Draws a tag pill (title + percent, chunk count, distance) above each of the nearest clusters. */
    public static void draw(GuiGraphics g, Minecraft mc, List<Cluster> list, String title, int rgb) {
        draw(g, mc, list, title, rgb, false, Double.MAX_VALUE, 4);
    }

    /** Overload kept for callers that only want the \"while looking\" behaviour. */
    public static void draw(GuiGraphics g, Minecraft mc, List<Cluster> list, String title, int rgb, boolean onlyWhenLooking) {
        draw(g, mc, list, title, rgb, onlyWhenLooking, Double.MAX_VALUE, 4);
    }

    /**
     * onlyWhenLooking: only tags near the centre of your view are drawn.
     * maxDist: tags beyond this many blocks are hidden; they fade out over the last 20% of the range.
     * maxShown: how many tags at most (nearest first). Tags that would overlap an already drawn one are skipped.
     */
    public static void draw(GuiGraphics g, Minecraft mc, List<Cluster> list, String title, int rgb,
                            boolean onlyWhenLooking, double maxDist, int maxShown) {
        if (list.isEmpty()) return;
        Font f = mc.font;
        int W = g.guiWidth(), H = g.guiHeight();

        List<Cand> cands = new ArrayList<>();
        for (Cluster c : list) {
            double dist = Math.sqrt(sq(c.x() - Proj.cx) + sq(c.y() - Proj.cy) + sq(c.z() - Proj.cz));
            if (dist <= maxDist) cands.add(new Cand(c, dist));
        }
        cands.sort(Comparator.comparingDouble(Cand::dist));

        List<int[]> placed = new ArrayList<>();
        int shown = 0;
        for (Cand cd : cands) {
            if (shown >= maxShown) break;
            Cluster c = cd.c();
            double dist = cd.dist();
            if (!Proj.project(c.x(), c.y() + 4.0, c.z())) continue;
            if (onlyWhenLooking && (Math.abs(Proj.px - W / 2.0) > W * 0.22 || Math.abs(Proj.py - H / 2.0) > H * 0.22)) continue;

            float a = (float) Math.max(0.45, Math.min(1.0, 1.4 - dist / 320.0));
            if (maxDist < Double.MAX_VALUE) a *= (float) Math.max(0.0, Math.min(1.0, (maxDist - dist) / (maxDist * 0.2)));
            if (a <= 0.02f) continue;

            String lvl = c.level() >= 3 ? "HIGH" : c.level() == 2 ? "MED" : c.level() == 1 ? "LOW" : "";
            String t1 = title + " " + c.pct() + "%" + (lvl.isEmpty() ? "" : "  " + lvl);
            String t2 = c.size() + "CH" + (c.ug() ? "  UG" : "") + "  " + Math.round(dist) + "M";
            int w1 = Draw.w(f, t1), w2 = Draw.w(f, t2);
            int w = 14 + w1 + 9 + w2 + 9, h = 18;
            int px = (int) Proj.px, py = (int) Proj.py;
            int x = Math.max(4, Math.min(W - w - 4, px - w / 2));
            int y = Math.max(4, Math.min(H - h - 10, py - h - 7));
            if (overlaps(placed, x, y, w, h)) continue;
            placed.add(new int[]{x, y, w, h});

            Draw.drop(g, x, y, w, h, 8, a);
            Draw.panel(g, x, y, w, h, 8, Colors.NAVY, Colors.NAVY_BORDER, a);
            g.fillGradient(x + 6, y + 5, x + 8, y + h - 5, Draw.alpha(Draw.lighten(0xFF000000 | rgb, 0.4f), a), Draw.alpha(0xFF000000 | rgb, a));
            Draw.str(g, f, t1, x + 13, y + 5, Draw.alpha(Colors.VALUE, a), true);
            Draw.str(g, f, t2, x + 13 + w1 + 9, y + 5, Draw.alpha(Colors.LABEL, a), false);
            if (px > x + 6 && px < x + w - 6) {                                            // little pointer toward the base
                Proj.fillPoly2d(g, new double[]{px - 4, px + 4, px}, new double[]{y + h - 1, y + h - 1, y + h + 5}, 3, Draw.alpha(Colors.B(0xFF181244), a));
            }
            shown++;
        }
    }

    private static boolean overlaps(List<int[]> ps, int x, int y, int w, int h) {
        for (int[] p : ps) {
            if (x < p[0] + p[2] && p[0] < x + w && y < p[1] + p[3] && p[1] < y + h) return true;
        }
        return false;
    }

    private static double sq(double v) { return v * v; }
}
