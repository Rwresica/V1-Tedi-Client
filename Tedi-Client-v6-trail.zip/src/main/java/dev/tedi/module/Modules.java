package dev.tedi.module;

import dev.tedi.util.Toasts;

import java.util.ArrayList;
import java.util.List;

public final class Modules {
    public static final List<Module> all = new ArrayList<>();
    private Modules() {}

    public static void init() {
        Toasts.mute = true;
        // COMBAT
        all.add(new AutoTotem());
        all.add(new CrystalOptimizer());
        all.add(new AnchorMacro());
        all.add(new TriggerBot());
        all.add(new ShieldBreaker());
        all.add(new AutoJumpReset());
        all.add(new AutoWeapon());
        // MISC
        all.add(new Freecam());
        all.add(new Freelook());
        all.add(new NameProtect());
        all.add(new FastPlace());
        all.add(new AutoTool());
        all.add(new CustomFov());
        all.add(new CustomCrosshair());
        // RENDER
        all.add(new Fullbright());
        Hud hud = new Hud();
        all.add(hud);
        all.add(new PlayerEsp());
        all.add(new StorageEsp());
        all.add(new BlockEsp());
        BlockOutline blockOutline = new BlockOutline();
        all.add(blockOutline);
        all.add(new SkyChanger());
        TargetHud targetHud = new TargetHud();
        PotionHud potionHud = new PotionHud();
        Radar radar = new Radar();
        Compass compass = new Compass();
        Zoom zoom = new Zoom();
        all.add(targetHud); all.add(potionHud); all.add(radar); all.add(compass); all.add(zoom);
        HitMarker hitMarker = new HitMarker();
        Vignette vignette = new Vignette();
        OffscreenArrows arrows = new OffscreenArrows();
        all.add(hitMarker); all.add(vignette); all.add(new Cinematic()); all.add(new Trails());
        all.add(new Particles()); all.add(arrows); all.add(new RgbTheme());
        JumpCircles jumpCircles = new JumpCircles();
        TargetRing targetRing = new TargetRing();
        all.add(new AttackCooldown()); all.add(new ReachDisplay()); all.add(new MaceInfo());
        all.add(jumpCircles); all.add(targetRing); all.add(new ChinaHat()); all.add(new SpeedLines()); all.add(new Aurora()); all.add(new BlockTrail());
        // DONUT
        all.add(new SpawnerBeam());
        all.add(new SusChunk());
        all.add(new PlayerDetection());
        // CLIENT
        TediClientPlus plus = new TediClientPlus();
        all.add(plus);
        hud.setEnabled(true);
        plus.setEnabled(true);
        blockOutline.setEnabled(true);
        targetHud.setEnabled(true); potionHud.setEnabled(true); radar.setEnabled(true); compass.setEnabled(true); zoom.setEnabled(true);
        hitMarker.setEnabled(true); vignette.setEnabled(true); arrows.setEnabled(true);
        jumpCircles.setEnabled(true); targetRing.setEnabled(true);
        Toasts.mute = false;
    }
}
