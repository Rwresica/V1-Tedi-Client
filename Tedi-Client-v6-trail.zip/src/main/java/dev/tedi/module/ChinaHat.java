package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import dev.tedi.util.Ring;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** A glowing cone hat over your head (you see it in third person / freecam). */
public class ChinaHat extends Module {
    public final Setting.Bool rainbow = add(new Setting.Bool("Rainbow", true));
    public final Setting.Hue color = add(new Setting.Hue("Color", 270, 0.6, 1.0));
    public final Setting.Num size = add(new Setting.Num("Size", 1.0, 0.6, 1.8, 0.05));

    public ChinaHat() {
        super("ChinaHat", "Glowing cone hat above your head (third person).", "VISUALS", true);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null) return;
        if (mc.options.getCameraType().isFirstPerson() && !Freecam.active()) return;
        drawHat(g, mc.player.getX(), mc.player.getY() + mc.player.getBbHeight() + 0.04, mc.player.getZ(), System.currentTimeMillis() / 1000.0);
    }

    /** The hat standing on (x, yBase, z). Public for the preview. */
    public void drawHat(GuiGraphics g, double x, double yBase, double z, double time) {
        double s = size.value;
        double yTip = yBase + 0.42 * s, r = 0.52 * s;
        int segs = 14;
        double spin = time * 0.9;
        // translucent cone: one triangle between every two ribs, tinted along the rim
        double[] tri = new double[9];
        for (int i = 0; i < segs; i++) {
            double a0 = spin + i * Math.PI * 2.0 / segs, a1 = spin + (i + 1) * Math.PI * 2.0 / segs;
            tri[0] = x; tri[1] = yTip; tri[2] = z;
            tri[3] = x + Math.cos(a0) * r; tri[4] = yBase; tri[5] = z + Math.sin(a0) * r;
            tri[6] = x + Math.cos(a1) * r; tri[7] = yBase; tri[8] = z + Math.sin(a1) * r;
            Proj.poly(g, tri, 3, Draw.alpha(hue(i, segs, time, 1f), 0.20f + 0.10f * (float) Math.sin(time * 2.0 + i)));
        }
        Ring.draw(g, x, yBase, z, r, segs, spin, 2.6f, (i, n) -> hue(i, n, time, 0.95f));
        for (int i = 0; i < segs; i += 2) {                                    // ribs from the rim up to the tip
            double a = spin + i * Math.PI * 2.0 / segs;
            Proj.line3d(g, x + Math.cos(a) * r, yBase, z + Math.sin(a) * r, x, yTip, z, 1.6f, hue(i, segs, time, 0.6f));
        }
        if (Proj.project(x, yTip, z)) {                                        // glint on the tip
            int px = (int) Proj.px, py = (int) Proj.py;
            g.fill(px - 2, py - 2, px + 3, py + 3, Draw.alpha(hue(0, segs, time, 1f), 0.30f));
            g.fill(px - 1, py - 1, px + 2, py + 2, 0xFFFFFFFF);
        }
    }

    private int hue(int i, int n, double time, float alpha) {
        if (rainbow.value) return Draw.alpha(0xFF000000 | Colors.hsv(time * 80.0 + i * 360.0 / n, 0.65, 1.0), alpha);
        return Draw.alpha(color.argb(), alpha);
    }
}
