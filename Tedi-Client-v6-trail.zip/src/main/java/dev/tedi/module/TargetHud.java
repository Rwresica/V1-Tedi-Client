package dev.tedi.module;

import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

import java.util.Locale;

/** Name, distance and a smooth health bar of whatever you look at. Drawn by the HUD (move / resize it with T). */
public class TargetHud extends VisualBase {
    public static TargetHud I;
    public static final int W = 132, H = 40;
    private LivingEntity target;
    private long lastSeen;
    private float alpha, hpShown = -1f;

    public TargetHud() {
        super("TargetHUD", "Health bar of the player / mob you look at.", "VISUALS");
        I = this;
    }

    /** Tracks the target (the drawing itself happens in drawLocal, called by the HUD). */
    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null) return;
        float dt = dt();
        long now = System.currentTimeMillis();
        Entity e = mc.crosshairPickEntity;
        if (e instanceof LivingEntity le && e != mc.player && le.isAlive()) {
            if (le != target) hpShown = -1f;
            target = le;
            lastSeen = now;
        }
        if (target == null) return;
        boolean show = target.isAlive() && now - lastSeen < 1500;
        alpha = approach(alpha, show ? 1f : 0f, 10f, dt);
        if (alpha < 0.02f && !show) target = null;
        else if (target != null) {
            float cur = Math.max(0f, target.getHealth());
            hpShown = hpShown < 0f ? cur : approach(hpShown, cur, 8f, dt);
        }
    }

    /** Draws at (0,0) of the current transform. */
    public void drawLocal(GuiGraphics g, Minecraft mc, float a0) {
        boolean preview = editing(mc);
        boolean live = target != null && alpha >= 0.02f;
        if (!live && !preview) return;
        Font f = mc.font;
        String name; float cur, max, shown; double dist;
        if (live) {
            name = target.getName().getString(); cur = Math.max(0f, target.getHealth()); max = Math.max(1f, target.getMaxHealth());
            shown = hpShown < 0 ? cur : hpShown; dist = mc.player.distanceTo(target);
        } else { name = "Notch"; cur = 14f; max = 20f; shown = 14f; dist = 4.2; }
        float a = (live ? alpha : 1f) * a0;
        float ratio = Math.max(0f, Math.min(1f, shown / max));
        int col = color.argb();

        Draw.drop(g, 0, 0, W, H, 9, a);
        Draw.panel(g, 0, 0, W, H, 9, Colors.NAVY, Colors.NAVY_BORDER, a);
        String ds = String.format(Locale.ROOT, "%.1fM", dist);
        int dw = Draw.w(f, ds);
        Draw.str(g, f, clip(f, name, W - 26 - dw), 9, 7, Draw.alpha(Colors.VALUE, a), true);
        Draw.str(g, f, ds, W - 9 - dw, 7, Draw.alpha(Colors.LABEL, a), true);
        int bx = 9, by = 19, bw = W - 18, bh = 6;
        Draw.roundR(g, bx, by, bw, bh, 3, Draw.alpha(Colors.B(0xFF0C0A2A), a), false);
        int fw = Math.max(bh, (int) (bw * ratio));
        int hc = Colors.lerp(0xFFFF5470, 0xFF4ADE80, ratio);
        Draw.roundG(g, bx, by, fw, bh, 3, Draw.alpha(Draw.lighten(hc, 0.3f), a), Draw.alpha(hc, a), false);
        Draw.str(g, f, String.format(Locale.ROOT, "%.1f / %.1f", cur, max), 9, 29, Draw.alpha(Draw.lighten(col, 0.35f), a), true);
    }
}
