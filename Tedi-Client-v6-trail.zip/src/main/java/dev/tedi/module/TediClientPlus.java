package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import net.minecraft.client.Minecraft;

/** Client badge + the colour theme of the whole UI (menu, HUD, notifications, tags). */
public class TediClientPlus extends Module {
    /** Pick any colour: panels, borders, accents and text tints of the menu and the HUD follow it. */
    public final Setting.Hue theme = add(new Setting.Hue("Theme Color", 262, 0.6, 1.0));

    /** Colour of every panel, pill, list, key and field background (default violet). Independent of the accent theme above. */
    public final Setting.Hue background = add(new Setting.Hue("Background", 272, 0.62, 1.0));

    public TediClientPlus() {
        super("TediClient+", "Tedi Client Plus - pick the colour of the menu and HUD here.", "CLIENT", false);
    }

    @Override
    public void onTick(Minecraft mc) {
        Colors.setTheme(theme.hue, theme.sat, theme.val);
        Colors.setBackground(background.hue, background.sat, background.val);
    }
}
