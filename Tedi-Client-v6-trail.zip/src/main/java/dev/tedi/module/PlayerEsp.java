package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class PlayerEsp extends Module {
    public final Setting.Hue color = add(new Setting.Hue("Color", 0, 0.8, 1.0));
    public final Setting.Bool fill = add(new Setting.Bool("Fill", true));
    public final Setting.Num fillAlpha = add(new Setting.Num("Fill Opacity", 0.25, 0.05, 1.0, 0.05));
    public final Setting.Bool boxes = add(new Setting.Bool("Outline", true));
    public final Setting.Bool tracers = add(new Setting.Bool("Tracers", true));
    public final Setting.Num tracerWidth = add(new Setting.Num("Tracer Width", 1.0, 0.5, 4.0, 0.5));
    public final Setting.Num range = add(new Setting.Num("Range", 128, 16, 512, 8));
    public final Setting.Bool showSelf = add(new Setting.Bool("Show Self In Freecam", true));

    public PlayerEsp() {
        super("PlayerESP", "Highlights other players through walls.", "RENDER", true);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        int sx = g.guiWidth() / 2, sy = g.guiHeight() / 2;
        double r2 = range.value * range.value;
        int col = color.argb();
        boolean fast = mc.level.players().size() > 9;
        int W = g.guiWidth(), H = g.guiHeight();
        for (AbstractClientPlayer p : mc.level.players()) {
            if (p == mc.player && !(showSelf.value && (Freecam.active() || Freelook.active()))) continue;
            AABB bb = p.getBoundingBox().move(p.getPosition(pt).subtract(p.position()));
            Vec3 c = bb.getCenter();
            if (c.distanceToSqr(Proj.cx, Proj.cy, Proj.cz) > r2) continue;
            if (fill.value) Proj.shadedBoxExact(g, bb, col & 0xFFFFFF, (int) (fillAlpha.value * 255), true, col, boxes.value ? 1f : 0f);
            else if (boxes.value) Proj.box(g, bb, 1f, col);
            if (tracers.value) {
                float dk = (float) Math.min(1.0, Math.sqrt(c.distanceToSqr(Proj.cx, Proj.cy, Proj.cz)) / range.value);
                int tc = Colors.lerp(col, 0xFFFFFFFF, dk * 0.55f);          // far players = lighter line
                if (fast) Proj.tracerFast(g, c.x, c.y, c.z, tracerWidth.f(), tc);
                else Proj.tracer(g, c.x, c.y, c.z, tracerWidth.f(), tc);
                if (Proj.project(c.x, c.y, c.z) && Proj.px > 2 && Proj.px < W - 2 && Proj.py > 2 && Proj.py < H - 2) {
                    int ex = (int) Proj.px, ey = (int) Proj.py;               // dot where the tracer ends
                    g.fill(ex - 2, ey - 2, ex + 2, ey + 2, 0xCC000000);
                    g.fill(ex - 1, ey - 1, ex + 1, ey + 1, tc | 0xFF000000);
                }
            }
        }
    }
}
