package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/** Solid arrows around the crosshair pointing at players outside your view, with a small name + distance tag. */
public class OffscreenArrows extends FxBase {
    public final Setting.Hue color = add(new Setting.Hue("Color", 350, 0.75, 1.0));
    public final Setting.Num range = add(new Setting.Num("Range", 80, 20, 150, 1));
    public final Setting.Bool names = add(new Setting.Bool("Show Names", true));

    private static final int MAX = 6;
    private final Map<Integer, float[]> state = new HashMap<>();   // id -> {smoothed angle, alpha, lastSeenFrame}
    private int frame;

    public OffscreenArrows() {
        super("OffscreenArrows", "Arrows pointing to players outside your view.", "VISUALS");
    }

    @Override
    public void onDisable() { state.clear(); }

    private static double wrap(double a) {
        while (a > Math.PI) a -= Math.PI * 2;
        while (a < -Math.PI) a += Math.PI * 2;
        return a;
    }

    private static void tri(GuiGraphics g, double ex, double ey, double tx, double ty, double b1x, double b1y, double b2x, double b2y, double grow, int argb) {
        double[] xs = {ex + (tx - ex) * grow, ex + (b1x - ex) * grow, ex + (b2x - ex) * grow};
        double[] ys = {ey + (ty - ey) * grow, ey + (b1y - ey) * grow, ey + (b2y - ey) * grow};
        Proj.fillPoly2d(g, xs, ys, 3, argb);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null || mc.screen != null) { state.clear(); return; }
        float dt = dt();
        frame++;
        Font f = mc.font;
        int W = g.guiWidth(), H = g.guiHeight();
        double cx = W / 2.0, cy = H / 2.0, rx = W * 0.36, ry = H * 0.34;
        double yaw = Math.toRadians(mc.player.getYRot());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        int base = color.argb();
        double now = System.currentTimeMillis() / 1000.0;
        int drawn = 0;
        for (AbstractClientPlayer p : mc.level.players()) {
            if (p == mc.player) continue;
            double dx = p.getX() - mc.player.getX(), dz = p.getZ() - mc.player.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > range.value || dist < 1.0) continue;
            double ang = Math.atan2(dx * -cos + dz * -sin, dx * -sin + dz * cos);   // 0 = straight ahead, + = to your right
            float[] st = state.get(p.getId());
            if (st == null) { st = new float[]{(float) ang, 0f, 0f}; state.put(p.getId(), st); }
            st[2] = frame;
            st[0] += (float) (wrap(ang - st[0]) * Math.min(1f, dt * 16f));
            boolean visible = Proj.project(p.getX(), p.getY() + 1.0, p.getZ())
                    && Proj.px >= 0 && Proj.px <= W && Proj.py >= 0 && Proj.py <= H;
            st[1] = approach(st[1], visible ? 0f : 1f, 11f, dt);
            if (st[1] < 0.03f || drawn >= MAX) continue;
            drawn++;

            float al = st[1];
            double ux = Math.sin(st[0]), uy = -Math.cos(st[0]);
            double ex = cx + ux * rx, ey = cy + uy * ry;
            double vx = -uy, vy = ux;
            double sc = 1.25 - 0.5 * Math.min(1.0, dist / range.value);                 // closer = bigger
            if (dist < 20) al *= (float) (0.82 + 0.18 * Math.sin(now * 9.0));
            int c = Draw.alpha(Colors.lerp(base, 0xFFFFFFFF, (float) Math.min(0.6, dist / range.value * 0.6)), al);

            double len = 17 * sc, half = 10.5 * sc;
            double tx = ex + ux * len * 0.6, ty = ey + uy * len * 0.6;
            double b1x = ex - ux * len * 0.4 + vx * half, b1y = ey - uy * len * 0.4 + vy * half;
            double b2x = ex - ux * len * 0.4 - vx * half, b2y = ey - uy * len * 0.4 - vy * half;
            tri(g, ex, ey, tx, ty, b1x, b1y, b2x, b2y, 1.32, Draw.alpha(0xFF000000, 0.5f * al));    // dark outline
            tri(g, ex, ey, tx, ty, b1x, b1y, b2x, b2y, 1.0, c);                                      // solid arrow
            tri(g, ex, ey, tx, ty, b1x, b1y, b2x, b2y, 0.5, Draw.alpha(0xFFFFFFFF, 0.28f * al));      // soft highlight

            String label = Math.round(dist) + "M";
            if (names.value) {
                String n = p.getName().getString();
                label = (n.length() > 10 ? n.substring(0, 10) : n) + " " + label;
            }
            int w = Draw.w(f, label) + 10, h = 12;
            int px = (int) Math.max(4, Math.min(W - w - 4, ex - ux * (len + 13) - w / 2.0));
            int py = (int) Math.max(4, Math.min(H - h - 4, ey - uy * (len + 8) - h / 2.0));
            Draw.roundG(g, px, py, w, h, 5, Draw.alpha(Colors.B(0xF0382E86), al), Draw.alpha(Colors.B(0xF01B1555), al), false);
            Draw.str(g, f, label, px + 5, py + 2, Draw.alpha(Colors.VALUE, al), false);
        }
        if (frame % 60 == 0) {                                                                         // forget players that are gone
            for (Iterator<float[]> it = state.values().iterator(); it.hasNext(); ) if (frame - it.next()[2] > 60) it.remove();
        }
    }
}
