package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.BlockFx;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Highlights the block you are looking at (see-through glass fill, lit face, corner brackets, light sweep).
 * While you mine it: heat colour, cracks growing out of the face, a shake before it breaks and a burst of shards (BlockFx).
 */
public class BlockOutline extends Module {
    public static BlockOutline I;
    public final Setting.Hue color = add(new Setting.Hue("Color", 200, 0.45, 1.0));
    public final Setting.Num opacity = add(new Setting.Num("Fill Opacity", 0.22, 0.05, 0.8, 0.01));
    public final Setting.Bool outline = add(new Setting.Bool("Outline", true));
    public final Setting.Bool extras = add(new Setting.Bool("Corners + Sweep", true));
    public final Setting.Bool breakAnim = add(new Setting.Bool("Break Animation", true));

    // mining state (mirrors the game's own progress: the per-tick value of BlockState.getDestroyProgress is added up)
    private BlockPos mining;
    private float prog, shown;
    private AABB lastBox;

    public BlockOutline() {
        super("BlockOutline", "Glass highlight on the block you look at, with a cracking animation while you mine it.", "VISUALS", true);
        I = this;
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        // the block we were mining is gone -> shards
        if (mining != null && prog > 0.05f && mc.level.getBlockState(mining).isAir() && lastBox != null) {
            if (breakAnim.value) {
                BlockFx.burst((lastBox.minX + lastBox.maxX) / 2, (lastBox.minY + lastBox.maxY) / 2, (lastBox.minZ + lastBox.maxZ) / 2, color.argb(), mining.asLong());
            }
            mining = null; prog = 0;
        }
        boolean down = mc.options.keyAttack.isDown() && mc.screen == null;
        if (down && mc.hitResult instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
            BlockPos p = hit.getBlockPos();
            if (!p.equals(mining)) { mining = p; prog = 0; }
            BlockState st = mc.level.getBlockState(p);
            if (mc.player.getAbilities().instabuild) prog = 1f;
            else prog = Math.min(1f, prog + st.getDestroyProgress(mc.player, mc.level, p));
        } else if (!down) {
            prog = 0;
            if (!(mc.hitResult instanceof BlockHitResult)) mining = null;
        }
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.level == null || mc.player == null) return;
        BlockFx.drawShards(g);
        float target = breakAnim.value ? prog : 0f;
        shown += (target - shown) * (target > shown ? 0.5f : 0.3f);          // follows the progress smoothly, falls back quickly
        if (shown < 0.004f) shown = 0f;
        if (mc.screen != null) return;
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        BlockPos p = hit.getBlockPos();
        VoxelShape shape = mc.level.getBlockState(p).getShape(mc.level, p);
        if (shape.isEmpty()) return;
        AABB bb = shape.bounds().move(p).inflate(0.002);
        lastBox = bb;
        BlockFx.draw(g, bb, hit.getDirection().ordinal(), p.equals(mining) ? shown : 0f, color.argb(), (float) opacity.value,
                outline.value, extras.value, System.nanoTime() / 1e9, p.asLong());
    }
}
