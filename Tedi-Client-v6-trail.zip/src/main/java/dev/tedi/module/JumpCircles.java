package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import dev.tedi.util.Ring;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/** A ring that bursts out of the ground where you jumped, expands, fades and stays fixed in the world. */
public class JumpCircles extends Module {
    public final Setting.Num mode = add(new Setting.Num("Style", 2, 1, 4, 1).labels("Classic", "Double", "Shockwave", "Hexagon"));          // 1 classic, 2 double, 3 shockwave, 4 hexagon
    public final Setting.Bool rainbow = add(new Setting.Bool("Rainbow", false));
    public final Setting.Hue color = add(new Setting.Hue("Color", 265, 0.65, 1.0));
    public final Setting.Hue color2 = add(new Setting.Hue("Second Color", 190, 0.65, 1.0));
    public final Setting.Num radius = add(new Setting.Num("Radius", 1.8, 0.8, 3.5, 0.1));
    public final Setting.Num life = add(new Setting.Num("Lifetime", 0.9, 0.4, 2.0, 0.05));
    public final Setting.Num thickness = add(new Setting.Num("Thickness", 2.6, 1, 6, 0.1));

    private static final class C { final double x, y, z; final long born; C(double x, double y, double z, long b) { this.x = x; this.y = y; this.z = z; born = b; } }
    private final List<C> circles = new ArrayList<>();
    private double lastVy;
    private long lastSpawn;

    public JumpCircles() {
        super("JumpCircles", "Glowing rings burst out of the ground when you jump.", "VISUALS", true);
    }

    @Override
    public void onDisable() { circles.clear(); }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null) { circles.clear(); return; }
        long now = System.currentTimeMillis();
        double vy = mc.player.getDeltaMovement().y;
        if (vy > 0.30 && lastVy < 0.25 && now - lastSpawn > 250) {
            circles.add(new C(mc.player.getX(), mc.player.getY() + 0.03, mc.player.getZ(), now));
            lastSpawn = now;
            if (circles.size() > 5) circles.remove(0);
        }
        lastVy = vy;
        if (circles.isEmpty()) return;

        float lifeMs = life.f() * 1000f;
        double time = now / 1000.0;
        for (int k = circles.size() - 1; k >= 0; k--) {
            C c = circles.get(k);
            float t = (now - c.born) / lifeMs;
            if (t >= 1f) { circles.remove(k); continue; }
            double dx = c.x - mc.player.getX(), dz = c.z - mc.player.getZ();
            if (dx * dx + dz * dz > 48 * 48) continue;
            drawOne(g, c.x, c.y, c.z, t, time, c.born);
        }
    }

    /** One ring at age t (0..1). Public so the preview can call it without a running game. */
    public void drawOne(GuiGraphics g, double x, double y, double z, float t, double time, long seed) {
        int m = mode.i();
        float e = Draw.easeOut(t);
        float fade = (float) Math.pow(1f - t, 1.4);
        float w = thickness.f() * (1f - 0.45f * t);
        double r = radius.value * e;
        int segs = m == 4 ? 6 : 22;
        double rot = m == 4 ? t * 1.4 : 0;

        Ring.Colorer main = (i, n) -> Draw.alpha(shade(i, n, time, 0.0f), fade);
        Ring.Colorer alt = (i, n) -> Draw.alpha(shade(i, n, time, 0.5f), fade * 0.85f);
        int glow = shade(3, 8, time, 0.25f);
        Ring.disc(g, x, y, z, r, segs, rot, Draw.alpha(glow, fade * 0.16f));                       // soft light on the ground inside the ring
        if (m == 3) {                                                    // shockwave: thick band + soft trailing ring
            Ring.draw(g, x, y, z, r, segs, 0, w * 2.1f, (i, n) -> Draw.alpha(shade(i, n, time, 0.0f), fade * 0.55f));
            Ring.draw(g, x, y, z, r * 0.86, segs, 0, w, alt);
        } else {
            Ring.draw(g, x, y, z, r, segs, rot, w, main);
            if (m == 2 || m == 4) {                                       // inner ring follows a little later
                float t2 = Math.max(0f, t - 0.14f) / 0.86f;
                Ring.draw(g, x, y, z, radius.value * 0.62 * Draw.easeOut(t2), segs, -rot, w * 0.8f, alt);
            }
        }
        // sparks lifting off the edge of the ring
        java.util.Random rnd = new java.util.Random(seed);
        for (int i = 0; i < 9; i++) {
            double ang = rnd.nextDouble() * Math.PI * 2, rr = r * (0.9 + 0.12 * rnd.nextDouble()), rise = (0.25 + rnd.nextDouble() * 0.75) * 1.1 * Draw.easeOut(t);
            if (!Proj.project(x + Math.cos(ang) * rr, y + rise, z + Math.sin(ang) * rr)) continue;
            int px = (int) Proj.px, py = (int) Proj.py;
            int sc = shade(i, 9, time, 0.0f);
            float sa = fade * (1f - 0.4f * t);
            g.fill(px - 1, py - 1, px + 2, py + 2, Draw.alpha(sc, sa * 0.28f));
            g.fill(px, py, px + 1, py + 1, Draw.alpha(0xFFFFFFFF, sa));
        }
    }

    /** Colour of a ring segment: rainbow, or a gradient between the two chosen colours. */
    private int shade(int i, int n, double time, float offset) {
        if (rainbow.value) return 0xFF000000 | Colors.hsv(time * 120.0 + i * (360.0 / n) + offset * 120.0, 0.7, 1.0);
        float k = (float) (0.5 + 0.5 * Math.sin(i * 6.2832 / n + offset * 3.14159));
        return Colors.lerp(color.argb(), color2.argb(), k);
    }
}
