package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.BaseScan;
import dev.tedi.util.BaseTags;
import dev.tedi.util.ChunkAnim;
import dev.tedi.util.ChunkDraw;
import dev.tedi.util.Toasts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.*;

/**
 * Sus Chunk Finder. Flags chunks that were touched by players, with extra effort on underground bases.
 * Growth signals (kelp / cave vines / vines / bamboo / cocoa) are only trusted OUTSIDE your own simulation distance -
 * inside it the server is growing those things because of YOU, so they prove nothing.
 * Other signals: grown amethyst, deepslate that is NOT axis-Y, bee nests underground and - with Smart Adjustment -
 * dug tunnels, shafts, player-made blocks and torches/ladders/doors underground.
 * The marker is drawn on the surface, above the base.
 */
public class SusChunk extends Module {
    public static SusChunk I;
    public record Info(int cx, int cz, int score, int ug, int minY, int maxY, int surf) {}
    private record Vis(Info info, int eff, int level) {}
    private static class Cache { LevelChunk ch; long t; boolean near; Info info; }

    public final Setting.Num simDist = add(new Setting.Num("Simulation Distance", 8, 2, 32, 1));
    public final Setting.Num sensitivity = add(new Setting.Num("Sensitivity", 5, 1, 10, 1));
    public final Setting.Bool smart = add(new Setting.Bool("Smart Adjustment", true));
    public final Setting.Num alpha = add(new Setting.Num("Alpha", 90, 10, 255, 5));
    public final Setting.Num labelRange = add(new Setting.Num("Label Range", 220, 40, 1000, 20));
    public final Setting.Bool animate = add(new Setting.Bool("Animations", true));
    public final Setting.Bool kelp = add(new Setting.Bool("Kelp", true));
    public final Setting.Bool caveVines = add(new Setting.Bool("Cave Vines", true));
    public final Setting.Bool vines = add(new Setting.Bool("Vines", true));
    public final Setting.Bool amethyst = add(new Setting.Bool("Amethyst", true));
    public final Setting.Bool bamboo = add(new Setting.Bool("Bamboo", true));
    public final Setting.Bool cocoa = add(new Setting.Bool("Cocoa", true));
    public final Setting.Bool beeNest = add(new Setting.Bool("Bee Nest", true));
    public final Setting.Bool rotDeep = add(new Setting.Bool("Rotated Deepslate", true));

    private final Map<Long, Info> cand = new HashMap<>();
    private final Map<Long, Cache> cache = new HashMap<>();
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();
    private final Set<Long> notified = new HashSet<>();
    private final Map<Long, Integer> streak = new HashMap<>();
    private List<Vis> visible = new ArrayList<>();
    private List<BaseTags.Cluster> clusters = new ArrayList<>();
    private final ChunkAnim anim = new ChunkAnim();
    private int timer;

    public SusChunk() {
        super("SusChunk", "Finds chunks players touched, esp. underground bases.", "DONUT", true);
        I = this;
    }

    private void reset() { cand.clear(); cache.clear(); queue.clear(); visible = new ArrayList<>(); notified.clear(); streak.clear(); }
    private static long key(int x, int z) { return (((long) x) << 32) ^ (z & 0xFFFFFFFFL); }
    @Override public void onDisable() { reset(); }

    private double baseThreshold() { return Math.max(6.0, 48.0 - sensitivity.value * 4.2); }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
        if (queue.isEmpty()) {
            int r = Math.min(mc.options.getEffectiveRenderDistance(), 32);
            List<int[]> all = new ArrayList<>();
            for (int x = pcx - r; x <= pcx + r; x++)
                for (int z = pcz - r; z <= pcz + r; z++) all.add(new int[]{x, z});
            all.sort(Comparator.comparingInt(c -> (c[0] - pcx) * (c[0] - pcx) + (c[1] - pcz) * (c[1] - pcz)));   // nearest chunks first
            queue.addAll(all);
        }
        long now = System.currentTimeMillis();
        for (int n = 0; n < 4 && !queue.isEmpty(); n++) {
            int[] c = queue.poll();
            long k = key(c[0], c[1]);
            LevelChunk ch = mc.level.getChunkSource().getChunkNow(c[0], c[1]);
            if (ch == null) { cand.remove(k); cache.remove(k); continue; }
            Info info = analyze(ch, c[0], c[1], k, now, pcx, pcz);
            if (info == null) cand.remove(k); else cand.put(k, info);
        }
        if (++timer % 20 == 0) recompute(mc);
    }

    private Info analyze(LevelChunk ch, int cx, int cz, long k, long now, int pcx, int pcz) {
        boolean near = Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) <= simDist.i();
        Cache c = cache.get(k);
        if (c != null && c.ch == ch && c.near == near && now - c.t < 45000) return c.info;
        int yLo = -64, yHi = 320, depth = 8;
        int[] surf = BaseScan.surface(ch);
        int sum = 0;
        for (int v : surf) sum += v;
        int surfAvg = sum / 256;
        boolean grow = !near;   // growth only counts outside the area YOU keep simulating
        BaseScan.Growth gr = BaseScan.growth(ch, cx, cz, yLo, yHi, depth, surf, kelp.value && grow, caveVines.value && grow,
                vines.value && grow, bamboo.value && grow, cocoa.value && grow, beeNest.value, rotDeep.value);
        int score = gr.score(), ug = gr.ug();
        int minY = gr.minY(), maxY = gr.maxY();
        if (amethyst.value || smart.value) {
            BaseScan.Blocks_ b = BaseScan.blocks(ch, amethyst.value, smart.value, smart.value, yLo, yHi, depth, surf);
            score += b.am() * 6;
            if (smart.value) score += Math.min(b.pm(), 60);
            ug += b.ug();
            if (b.minY() != Integer.MAX_VALUE) { minY = Math.min(minY, b.minY()); maxY = Math.max(maxY, b.maxY()); }
        }
        if (smart.value) {
            BaseScan.Tunnels tu = BaseScan.tunnels(ch, yLo, yHi, depth, surf);
            score += Math.min(tu.tunnels(), 6) * 8 + Math.min(tu.shafts(), 4) * 6;
            ug += (tu.tunnels() + tu.shafts()) * 3;
            if (tu.minY() != Integer.MAX_VALUE) { minY = Math.min(minY, tu.minY()); maxY = Math.max(maxY, tu.maxY()); }
        }
        Info info = null;
        if (score >= baseThreshold() * 0.3 && minY != Integer.MAX_VALUE) info = new Info(cx, cz, score, ug, minY, maxY, surfAvg);
        c = new Cache();
        c.ch = ch; c.t = now; c.near = near; c.info = info;
        cache.put(k, c);
        return info;
    }

    private void recompute(Minecraft mc) {
        List<Vis> out = new ArrayList<>();
        for (Info i : cand.values()) {
            int eff = i.score(), nb = 0;
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dz == 0) continue;
                    Info n = cand.get(key(i.cx() + dx, i.cz() + dz));
                    if (n != null) nb += n.score();
                }
            eff += (int) (nb * 0.35);
            double t = baseThreshold();
            if (smart.value && i.ug() >= 3) t *= 0.7;
            if (eff < t) continue;
            int lv = eff >= t * 3 ? 3 : eff >= t * 1.8 ? 2 : 1;
            out.add(new Vis(i, eff, lv));
        }
        out.sort(Comparator.comparingInt((Vis v) -> -v.eff()));
        visible = out;
        List<int[]> cl = new ArrayList<>();
        for (int i = 0; i < out.size() && i < 32; i++) {
            Vis v = out.get(i);
            cl.add(new int[]{v.info().cx(), v.info().cz(), Math.min(99, 52 + v.level() * 15), (int) (v.info().surf() + 2.0), v.level(), v.info().ug() >= 3 ? 1 : 0});
        }
        clusters = BaseTags.build(cl);

        // Toast only for chunks that stayed flagged for 3 checks in a row, are among the ones drawn, and are not just "weak".
        Set<Long> current = new HashSet<>();
        int rank = 0;
        for (Vis v : out) {
            long k = key(v.info().cx(), v.info().cz());
            current.add(k);
            int s = streak.merge(k, 1, Integer::sum);
            if (rank++ < 16 && s >= 3 && (v.level() >= 2 || v.info().ug() >= 6) && notified.add(k)) {
                String lvl = v.level() == 3 ? "HIGH" : v.level() == 2 ? "MED" : "LOW";
                Toasts.push("Sus Chunk Found", (v.info().cx() * 16) + ", " + (v.info().cz() * 16) + "  |  " + lvl
                        + (v.info().ug() >= 3 ? "  |  UNDERGROUND" : ""), 0xFFFF6B7A, "alert");
            }
        }
        streak.keySet().retainAll(current);
        notified.retainAll(current);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        int shown = 0;
        long now = System.currentTimeMillis();
        for (Vis v : visible) {
            if (shown++ >= 16) break;
            Info i = v.info();
            double y = i.surf() + 2.0;   // on the surface, above the base
            int a = Math.min(255, (int) (alpha.value * (0.7 + 0.15 * (v.level() - 1))));
            float strength = Math.min(1f, 0.35f + 0.22f * (v.level() - 1));
            ChunkDraw.plate(g, i.cx(), i.cz(), y, 0xFF6F91, a, 0xFFFFC2D1, anim.appear(i.cx(), i.cz(), now), strength, shown <= 2, animate.value);
        }
        anim.endFrame(now);
        BaseTags.draw(g, mc, clusters, "SUS", 0xFF8FA8, true, labelRange.value, 2);
    }
}
