package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import dev.tedi.util.Ring;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/** A glowing ring that glides up and down around the entity you look at. */
public class TargetRing extends FxBase {
    public final Setting.Bool rainbow = add(new Setting.Bool("Rainbow", false));
    public final Setting.Hue color = add(new Setting.Hue("Color", 262, 0.6, 1.0));
    public final Setting.Hue color2 = add(new Setting.Hue("Second Color", 320, 0.6, 1.0));

    private LivingEntity target;
    private long lastSeen;
    private float alpha;

    public TargetRing() {
        super("TargetRing", "Glowing ring that glides around your target.", "VISUALS");
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null) return;
        float dt = dt();
        long now = System.currentTimeMillis();
        Entity e = mc.crosshairPickEntity;
        if (e instanceof LivingEntity le && e != mc.player && le.isAlive()) { target = le; lastSeen = now; }
        if (target == null) return;
        boolean show = target.isAlive() && now - lastSeen < 1200;
        alpha = approach(alpha, show ? 1f : 0f, 9f, dt);
        if (alpha < 0.02f) { if (!show) target = null; return; }

        var tp = target.getPosition(pt);                       // partial-tick position: no lag or stepping between game ticks
        drawAt(g, tp.x, tp.y, tp.z, target.getBbWidth(), target.getBbHeight(), now / 1000.0, alpha);
    }

    /** The ring around something at (x, y, z) that is `width` wide and `height` tall. Public for the preview. */
    public void drawAt(GuiGraphics g, double x, double base, double z, double width, double h, double time, float a) {
        double r = width * 0.78 + 0.12;
        double ph = 0.5 + 0.5 * Math.sin(time * 2.4);
        double dir = Math.signum(Math.cos(time * 2.4));
        for (int k = 0; k < 3; k++) {                                         // main ring + two fading ghosts
            double y = base + h * Math.max(0.0, Math.min(1.0, ph - k * 0.07 * dir));
            float ka = a * (k == 0 ? 1f : k == 1 ? 0.42f : 0.2f);
            final double tt = time;
            if (k == 0) Ring.disc(g, x, y, z, r, 18, time * 1.6, Draw.alpha(ringColor(2, 8, tt), a * 0.13f));     // glass disc at the ring height
            Ring.draw(g, x, y, z, r, 18, time * 1.6, k == 0 ? 2.6f : 2f, (i, n) -> Draw.alpha(ringColor(i, n, tt), ka));
        }
        // a bright orb circles the ring and drags a comet tail behind it
        double y0 = base + h * Math.max(0.0, Math.min(1.0, ph));
        double ang = time * 3.4;
        final int tail = 7;
        double lx = 0, lz = 0;
        for (int i = 0; i <= tail; i++) {
            double aa = ang - i * 0.11;
            double px = x + Math.cos(aa) * r, pz = z + Math.sin(aa) * r;
            if (i > 0) {
                float f = 1f - (float) i / (tail + 1);
                Proj.line3d(g, lx, y0, lz, px, y0, pz, 3.4f * f + 0.8f, Draw.alpha(Colors.lerp(ringColor(i, tail, time), 0xFFFFFFFF, 0.5f), a * f * f));
            }
            lx = px; lz = pz;
        }
        if (Proj.project(x + Math.cos(ang) * r, y0, z + Math.sin(ang) * r)) {
            int ox = (int) Proj.px, oy = (int) Proj.py;
            g.fill(ox - 3, oy - 3, ox + 4, oy + 4, Draw.alpha(ringColor(0, 8, time), a * 0.25f));
            g.fill(ox - 2, oy - 2, ox + 3, oy + 3, Draw.alpha(0xFFFFFFFF, a * 0.55f));
            g.fill(ox - 1, oy - 1, ox + 2, oy + 2, Draw.alpha(0xFFFFFFFF, a));
        }
    }

    private int ringColor(int i, int n, double tt) {
        if (rainbow.value) return 0xFF000000 | Colors.hsv(tt * 90.0 + i * 360.0 / n, 0.7, 1.0);
        float f = (float) (0.5 + 0.5 * Math.sin(i * 6.2832 / n + tt * 2.0));
        return Colors.lerp(color.argb(), color2.argb(), f);
    }
}
