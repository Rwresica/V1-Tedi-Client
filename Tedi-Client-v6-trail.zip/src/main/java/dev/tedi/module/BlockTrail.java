package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.TrailFx;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.List;

/**
 * Every block you walk over lights up for a moment: the top of the block flashes where you stepped, glows, then
 * shrinks and fades away, so you leave a short glowing path behind you.
 */
public class BlockTrail extends Module {
    public final Setting.Num style = add(new Setting.Num("Style", 1, 1, 3, 1).labels("Glass Tile", "Ripple", "Glow Pad"));
    public final Setting.Bool rainbow = add(new Setting.Bool("Rainbow", false));
    public final Setting.Hue color = add(new Setting.Hue("Color", 270, 0.6, 1.0));
    public final Setting.Hue color2 = add(new Setting.Hue("Second Color", 195, 0.6, 1.0));
    public final Setting.Num fade = add(new Setting.Num("Fade Time", 1.6, 0.5, 5.0, 0.1));
    public final Setting.Num opacity = add(new Setting.Num("Opacity", 0.75, 0.1, 1.0, 0.05));
    public final Setting.Bool outline = add(new Setting.Bool("Outline", true));

    private static final class Tile {
        final int x, z, seed; final double top; final long born;
        Tile(int x, double top, int z, long born, int seed) { this.x = x; this.top = top; this.z = z; this.born = born; this.seed = seed; }
    }

    private static final int MAX = 40;
    private final List<Tile> tiles = new ArrayList<>();
    private BlockPos last;
    private int counter;

    public BlockTrail() {
        super("BlockTrail", "The blocks you walk over light up, glow for a moment and fade away.", "VISUALS", true);
    }

    @Override
    public void onDisable() { tiles.clear(); last = null; }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null) { tiles.clear(); last = null; return; }
        if (!mc.player.onGround()) return;                                            // only blocks you actually stand on
        BlockPos p = BlockPos.containing(mc.player.getX(), mc.player.getY() - 0.05, mc.player.getZ());
        if (p.equals(last)) return;
        BlockState st = mc.level.getBlockState(p);
        if (st.isAir()) return;
        VoxelShape shape = st.getShape(mc.level, p);
        if (shape.isEmpty()) return;
        last = p;
        tiles.add(new Tile(p.getX(), p.getY() + shape.max(Direction.Axis.Y), p.getZ(), System.currentTimeMillis(), counter++));
        while (tiles.size() > MAX) tiles.remove(0);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null || tiles.isEmpty()) return;
        long now = System.currentTimeMillis();
        double time = now / 1000.0;
        float life = fade.f() * 1000f;
        for (int i = tiles.size() - 1; i >= 0; i--) {
            Tile t = tiles.get(i);
            float age = (now - t.born) / life;
            if (age >= 1f) { tiles.remove(i); continue; }
            double dx = t.x + 0.5 - mc.player.getX(), dz = t.z + 0.5 - mc.player.getZ();
            double d2 = dx * dx + dz * dz;
            if (d2 > 28 * 28) continue;                                               // far tiles are not worth drawing
            int c1, c2;
            if (rainbow.value) {
                c1 = 0xFF000000 | Colors.hsv(time * 70.0 + t.seed * 14.0, 0.6, 1.0);
                c2 = 0xFF000000 | Colors.hsv(time * 70.0 + t.seed * 14.0 + 60.0, 0.6, 1.0);
            } else { c1 = color.argb(); c2 = color2.argb(); }
            TrailFx.tile(g, t.x, t.top, t.z, age, (now - t.born) / 1000f, style.i(), c1, c2, (float) opacity.value, outline.value, time, t.seed, d2 > 14 * 14);   // tiles further than 14 blocks use a cheaper look
        }
    }
}
