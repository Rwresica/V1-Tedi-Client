package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Icons;
import dev.tedi.util.Keys;
import dev.tedi.util.Logo;
import dev.tedi.util.Proj;
import dev.tedi.util.Toasts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

public class Hud extends Module {
    public static Hud I;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static final int[] REGION_COL = {0xFFF28C1E, 0xFF2F6FDF, 0xFF29A8E0, 0xFF8BC34A, 0xFF2EBD59, 0xFFF2B01E};
    private static final String[] REGION_NAME = {"NORTH WEST", "NORTH", "NORTH EAST", "SOUTH EAST", "SOUTH", "SOUTH WEST"};
    private static int BG = Colors.NAVY, BORDER = Colors.NAVY_BORDER;

    private static class Broken {
        final BlockPos pos; final long time; final List<Integer> ids = new ArrayList<>();
        Broken(BlockPos pos, long time) { this.pos = pos; this.time = time; }
    }

    /**
     * A movable + resizable HUD element. x/y is the top-left corner, except: right-anchored elements use the RIGHT edge
     * for x and bottom-anchored ones use the BOTTOM edge for y. x < 0 = not placed yet.
     */
    public abstract static class El {
        public final String name;
        public int x = -1, y = -1, w = 60, h = 16, bw = 60, bh = 16;
        public float scale = 1f;
        public final boolean right, bottom, big;
        final int defY;
        float aw = -1f;

        El(String name, boolean right, boolean bottom, boolean big, int defY) {
            this.name = name; this.right = right; this.bottom = bottom; this.big = big; this.defY = defY;
            if (right && !bottom) y = defY;
        }
        int left() { return right ? x - w : x; }
        int top() { return bottom ? y - h : y; }
        void reset() { x = -1; y = (right && !bottom) ? defY : -1; scale = 1f; }
        int smoothW(int target, float dt) {
            if (aw < 0) aw = target;
            aw += (target - aw) * (1f - (float) Math.exp(-dt * 18.0));
            if (Math.abs(target - aw) < 0.6f) aw = target;
            return Math.round(aw);
        }
        abstract boolean visible();
        abstract void measure(Font f, Minecraft mc, float dt);
        abstract void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col);
    }

    // ------------------------------------------------------------------ settings
    public final Setting.Bool watermark = add(new Setting.Bool("TediClient Name", true));
    public final Setting.Bool bps = add(new Setting.Bool("Speed HUD", true));
    public final Setting.Bool fps = add(new Setting.Bool("FPS HUD", true));
    public final Setting.Bool clock = add(new Setting.Bool("Time HUD", true));
    public final Setting.Bool server = add(new Setting.Bool("Server HUD", true));
    public final Setting.Bool session = add(new Setting.Bool("Session HUD", false));
    public final Setting.Bool ping = add(new Setting.Bool("Ping HUD", true));
    public final Setting.Bool cps = add(new Setting.Bool("CPS HUD", false));
    public final Setting.Bool coords = add(new Setting.Bool("Coordinates HUD", false));
    public final Setting.Bool user = add(new Setting.Bool("Username HUD", false));
    public final Setting.Bool armor = add(new Setting.Bool("Armor HUD", false));
    public final Setting.Bool hotkeys = add(new Setting.Bool("Hotkeys HUD", false));
    public final Setting.Bool keystrokes = add(new Setting.Bool("Keystrokes HUD", true));
    public final Setting.Bool regionMap = add(new Setting.Bool("Region Map HUD", false));
    public final Setting.Num regionSize = add(new Setting.Num("Region Size", 1000, 250, 5000, 250));
    public final Setting.Bool list = add(new Setting.Bool("Module List", true));
    public final Setting.Hue color = add(new Setting.Hue("HUD Color", 262, 0.5, 1.0));
    public final Setting.Bool toasts = add(new Setting.Bool("Toast Notifications", true));
    public final Setting.Bool pixel = add(new Setting.Bool("Bungee Font", true));
    public final Setting.Action reset = add(new Setting.Action("Reset HUD Positions", () -> { if (I != null) I.resetPositions(); }));
    public final Setting.Bool players = add(new Setting.Bool("Player Nametags", true));
    public final Setting.Bool showHealth = add(new Setting.Bool("Show Health", true));
    public final Setting.Bool showDist = add(new Setting.Bool("Show Distance", true));
    public final Setting.Num playerRange = add(new Setting.Num("Player Range", 128, 16, 256, 8));
    public final Setting.Bool broken = add(new Setting.Bool("Broken Item Nametags", true));
    public final Setting.Num brokenTime = add(new Setting.Num("Nametag Secs", 30, 3, 120, 1));
    public final Setting.Num nametagScale = add(new Setting.Num("Nametag Size", 1.0, 0.5, 2.0, 0.1));

    // ------------------------------------------------------------------ state
    private final List<Broken> brokenList = new ArrayList<>();
    private final Map<Integer, double[]> smooth = new HashMap<>();
    private final Map<Integer, Long> born = new HashMap<>();
    private final Map<Object, Float> fade = new HashMap<>();
    private final Map<Module, Float> listY = new HashMap<>();
    private final List<Long> leftClicks = new ArrayList<>(), rightClicks = new ArrayList<>();
    private final long sessionStart = System.currentTimeMillis();
    private int flowX = 6, flowY = 4;
    private boolean lastL, lastR;
    private BlockPos mining;
    private El dragging, resizing;
    private int offX, offY, guideX = -1, guideY = -1;
    private int screenH = 300;
    private boolean wasDown, wasRight;
    private long lastNano = System.nanoTime();
    private float frameDt = 0.016f;
    private double lastX, lastZ, bpsVal;
    private boolean haveLast;

    // ------------------------------------------------------------------ element types
    private class LabelPill extends El {
        final BooleanSupplier vis; final String icon, label; final Supplier<String> val; final boolean hl;
        LabelPill(String name, BooleanSupplier vis, String icon, String label, Supplier<String> val, boolean hl) {
            super(name, false, false, false, 0);
            this.vis = vis; this.icon = icon; this.label = label; this.val = val; this.hl = hl;
        }
        boolean visible() { return vis.getAsBoolean(); }
        String cur = "";
        void measure(Font f, Minecraft mc, float dt) {
            cur = val.get();
            int t = 19 + (label.isEmpty() ? 0 : Draw.width(f, label, true) + 5) + Draw.width(f, cur, true) + 10;
            bw = smoothW(t, dt); bh = 16;
        }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) {
            Draw.panel(g, 0, 0, bw, 16, 8, hl ? Colors.NAVY_HL : BG, hl ? Draw.lighten(col, 0.5f) : BORDER, a);
            Draw.roundR(g, 2, 2, 12, 12, 5, Draw.alpha(Colors.withAlpha(col, 0x40), a));
            Icons.draw(g, icon, 3, 3, Draw.alpha(Draw.lighten(col, 0.35f), a));
            int t = 19;
            if (!label.isEmpty()) { Draw.text(g, f, label, t, 4, Draw.alpha(Colors.LABEL, a), true); t += Draw.width(f, label, true) + 5; }
            Draw.text(g, f, cur, t, 4, Draw.alpha(Colors.VALUE, a), true);
        }
    }

    private class IconPill extends El {
        final BooleanSupplier vis; final String icon; final Supplier<String> text;
        IconPill(String name, BooleanSupplier vis, String icon, Supplier<String> text) {
            super(name, false, false, false, 0);
            this.vis = vis; this.icon = icon; this.text = text;
        }
        boolean visible() { return vis.getAsBoolean(); }
        String cur = "";
        void measure(Font f, Minecraft mc, float dt) {
            cur = text.get();
            bw = smoothW(19 + Draw.width(f, cur, true) + 10, dt); bh = 16;
        }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) {
            Draw.panel(g, 0, 0, bw, 16, 8, BG, BORDER, a);
            Draw.roundR(g, 2, 2, 12, 12, 5, Draw.alpha(Colors.withAlpha(col, 0x40), a));
            Icons.draw(g, icon, 3, 3, Draw.alpha(Draw.lighten(col, 0.35f), a));
            Draw.text(g, f, cur, 19, 4, Draw.alpha(Colors.VALUE, a), true);
        }
    }

    private String sessionText() {
        long m = (System.currentTimeMillis() - sessionStart) / 60000L;
        return m >= 60 ? (m / 60) + "H " + (m % 60) + "M" : m + "M";
    }

    private int pingMs() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getConnection() != null && mc.player != null) {
            PlayerInfo pi = mc.getConnection().getPlayerInfo(mc.player.getUUID());
            if (pi != null) return pi.getLatency();
        }
        return 0;
    }

    private String serverName() {
        Minecraft mc = Minecraft.getInstance();
        ServerData sd = mc.getCurrentServer();
        return (sd != null ? sd.ip : (mc.hasSingleplayerServer() ? "SINGLEPLAYER" : "OFFLINE")).toUpperCase(Locale.ROOT);
    }

    // ------------------------------------------------------------------ elements
    public final El markEl = new El("Watermark", false, false, false, 0) {
        boolean visible() { return watermark.value; }
        void measure(Font f, Minecraft mc, float dt) {
            int t = 24 + Draw.width(f, "Tedi", true) + Draw.width(f, "Client", true) + 6 + Draw.width(f, "v1.0.0", true) + 9;
            bw = smoothW(t, dt); bh = 20;
        }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) {
            Draw.panel(g, 0, 0, bw, 20, 10, BG, BORDER, a);
            Logo.draw(g, 7, 2, 1, Draw.alpha(0xFF0A99FF, a), Draw.alpha(0xFF05070D, a));
            int t = 24;
            Draw.text(g, f, "Tedi", t, 6, Draw.alpha(0xFFFFFFFF, a), true);
            t += Draw.width(f, "Tedi", true);
            Draw.text(g, f, "Client", t, 6, Draw.alpha(Draw.lighten(col, 0.4f), a), true);
            t += Draw.width(f, "Client", true) + 6;
            Draw.text(g, f, "v1.0.0", t, 6, Draw.alpha(0xFF7E8AA0, a), true);
        }
    };
    public final El userEl = new IconPill("Username", () -> user.value, "user", () -> Minecraft.getInstance().getUser().getName());
    public final El pingEl = new LabelPill("Ping", () -> ping.value, "ping", "PING", () -> pingMs() + "MS", false);
    public final El fpsEl = new LabelPill("FPS", () -> fps.value, "fps", "FPS", () -> String.valueOf(Minecraft.getInstance().getFps()), false);
    public final El bpsEl = new LabelPill("Speed", () -> bps.value, "bps", "SPEED", () -> String.format(Locale.ROOT, "%.1f B/S", bpsVal), false);
    public final El clockEl = new LabelPill("Time", () -> clock.value, "clock", "TIME", () -> LocalTime.now().format(CLOCK), false);
    public final El sessionEl = new LabelPill("Session", () -> session.value, "clock", "SESSION", () -> sessionText(), false);
    public final El serverEl = new LabelPill("Server", () -> server.value, "server", "", this::serverName, true);
    public final El cpsEl = new IconPill("CPS", () -> cps.value, "cps", () -> clicks(leftClicks) + " | " + clicks(rightClicks) + " CPS");
    /** X / Y / Z with coloured axis letters. */
    public final El coordsEl = new El("Coordinates", false, false, false, 0) {
        String[] parts() {
            Minecraft mc = Minecraft.getInstance();
            BlockPos bp = mc.player != null ? mc.player.blockPosition() : BlockPos.ZERO;
            return new String[]{"X", String.valueOf(bp.getX()), "Y", String.valueOf(bp.getY()), "Z", String.valueOf(bp.getZ())};
        }
        boolean visible() { return coords.value; }
        String[] cp = {"X", "0", "Y", "0", "Z", "0"};
        void measure(Font f, Minecraft mc, float dt) {
            cp = parts();
            int t = 10;
            for (String p : cp) t += Draw.width(f, p, true) + 5;
            bw = smoothW(t + 4, dt); bh = 16;
        }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) {
            Draw.panel(g, 0, 0, bw, 16, 8, BG, BORDER, a);
            String[] p = cp;
            int t = 10;
            for (int i = 0; i < p.length; i++) {
                Draw.text(g, f, p[i], t, 4, Draw.alpha(i % 2 == 0 ? Draw.lighten(col, 0.3f) : Colors.VALUE, a), true);
                t += Draw.width(f, p[i], true) + 5;
            }
        }
    };

    public final El armorEl = new El("Armor", false, false, true, 0) {
        boolean visible() { return armor.value; }
        void measure(Font f, Minecraft mc, float dt) { bw = 112; bh = 4 * 19 + 6; }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            Draw.panel(g, 0, 0, bw, bh, 12, BG, BORDER, a);
            for (int i = 0; i < 4; i++) {
                ItemStack st = mc.player.getItemBySlot(slots[i]);
                int ry = 4 + i * 19, bx = 28, barW = 52;
                Draw.roundR(g, bx, ry + 7, barW, 3, 1, Draw.alpha(0x40FFFFFF, a));
                if (st.isEmpty()) { Draw.str(g, f, "-", bw - 8 - Draw.w(f, "-"), ry + 4, Draw.alpha(Colors.DIM, a), false); continue; }
                if (a > 0.5f) g.renderItem(st, 7, ry);
                int pc = 100;
                if (st.isDamageableItem() && st.getMaxDamage() > 0)
                    pc = (int) ((st.getMaxDamage() - st.getDamageValue()) * 100f / st.getMaxDamage());
                int pcol = pctColor(pc);
                Draw.roundR(g, bx, ry + 7, Math.max(2, barW * pc / 100), 3, 1, Draw.alpha(pcol, a));
                String t = pc + "%";
                Draw.text(g, f, t, bw - 8 - Draw.width(f, t, true), ry + 4, Draw.alpha(pcol, a), true);
            }
        }
    };

    public final El hotkeysEl = new El("Hotkeys", false, false, true, 0) {
        List<Module> hk() { List<Module> l = new ArrayList<>(); for (Module m : Modules.all) if (m.key > 0) l.add(m); return l; }
        boolean visible() { return hotkeys.value; }
        void measure(Font f, Minecraft mc, float dt) {
            List<Module> hk = hk();
            int nameW = 40;
            for (Module m : hk) nameW = Math.max(nameW, Draw.w(f, m.name));
            bw = Math.max(110, 19 + nameW + 14 + 26); bh = 30 + Math.max(1, hk.size()) * 14 + 3;
        }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) {
            List<Module> hk = hk();
            Draw.panel(g, 0, 0, bw, bh, 12, BG, BORDER, a);
            Draw.roundR(g, 7, 6, 16, 16, 5, Draw.alpha(Colors.withAlpha(col, 0x44), a));
            Icons.draw(g, "keys", 10, 9, Draw.alpha(col, a));
            Draw.text(g, f, "Hotkeys", 29, 10, Draw.alpha(0xFFFFFFFF, a), true);
            g.fill(8, 26, bw - 8, 27, Draw.alpha(0x30FFFFFF, a));
            if (hk.isEmpty()) Draw.str(g, f, "none bound", 10, 32, Draw.alpha(Colors.DIM, a), false);
            for (int i = 0; i < hk.size(); i++) {
                Module m = hk.get(i);
                int ry = 30 + i * 14;
                Draw.roundR(g, 9, ry + 4, 5, 5, 2, Draw.alpha(m.enabled ? 0xFF6BEA9A : 0xFF9AA0A8, a));
                Draw.str(g, f, m.name, 19, ry + 3, Draw.alpha(0xFFE8EAEE, a), false);
                String kn = Keys.name(m.key);
                int kw = Draw.w(f, kn) + 9;
                Draw.roundR(g, bw - 8 - kw, ry + 1, kw, 11, 5, Draw.alpha(0x34FFFFFF, a));
                Draw.str(g, f, kn, bw - 8 - kw + 4, ry + 3, Draw.alpha(0xFFFFFFFF, a), false);
            }
        }
    };

    /** WASD / mouse buttons / space, keys light up smoothly while pressed. */
    public final El keysEl = new El("Keystrokes", false, false, true, 0) {
        final float[] pr = new float[7];
        boolean visible() { return keystrokes.value; }
        void measure(Font f, Minecraft mc, float dt) { bw = 72; bh = 83; }
        void key(GuiGraphics g, Font f, int i, boolean down, int x, int y, int w, int h, String label, float a) {
            pr[i] += ((down ? 1f : 0f) - pr[i]) * Math.min(1f, frameDt * 22f);
            float p = pr[i];
            int top = Colors.lerp(Colors.T(0xD02B2362), 0xFFFFFFFF, p), bot = Colors.lerp(Colors.T(0xD0181040), 0xFFFFFFFF, p);
            Draw.roundR(g, x - 1, y - 1, w + 2, h + 2, 6, Draw.alpha(Colors.T(0x558A78F0), a), false);
            Draw.roundG(g, x, y, w, h, 5, Draw.alpha(top, a), Draw.alpha(bot, a), true);
            int tc = Colors.lerp(0xFFFFFFFF, 0xFF000000, p);
            Draw.str(g, f, label, x + (w - Draw.w(f, label)) / 2, y + (h - 7) / 2, Draw.alpha(tc, a), false);
        }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) {
            var o = mc.options;
            key(g, f, 0, o.keyUp.isDown(), 25, 0, 22, 20, "W", a);
            key(g, f, 1, o.keyLeft.isDown(), 0, 23, 22, 20, "A", a);
            key(g, f, 2, o.keyDown.isDown(), 25, 23, 22, 20, "S", a);
            key(g, f, 3, o.keyRight.isDown(), 50, 23, 22, 20, "D", a);
            key(g, f, 4, o.keyAttack.isDown(), 0, 46, 34, 18, "LMB", a);
            key(g, f, 5, o.keyUse.isDown(), 37, 46, 35, 18, "RMB", a);
            key(g, f, 6, o.keyJump.isDown(), 0, 67, 72, 16, "SPACE", a);
        }
    };

    // ---- the visual modules draw through the HUD so they can be moved / resized with T like everything else
    public final El targetEl = new El("TargetHUD", false, false, true, 0) {
        boolean visible() { return TargetHud.I != null && TargetHud.I.enabled; }
        void measure(Font f, Minecraft mc, float dt) { bw = TargetHud.W; bh = TargetHud.H; }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) { TargetHud.I.drawLocal(g, mc, a); }
    };
    public final El potionEl = new El("PotionHUD", false, false, true, 0) {
        boolean visible() { return PotionHud.I != null && PotionHud.I.enabled; }
        void measure(Font f, Minecraft mc, float dt) { int[] s = PotionHud.I.measure(f, mc); bw = s[0]; bh = s[1]; }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) { PotionHud.I.drawLocal(g, mc, a); }
    };
    public final El radarEl = new El("Radar", false, false, true, 0) {
        boolean visible() { return Radar.I != null && Radar.I.enabled; }
        void measure(Font f, Minecraft mc, float dt) { bw = Radar.I.sizePx(); bh = bw; }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) { Radar.I.drawLocal(g, mc, a); }
    };
    public final El compassEl = new El("Compass", false, false, true, 0) {
        boolean visible() { return Compass.I != null && Compass.I.enabled; }
        void measure(Font f, Minecraft mc, float dt) { bw = Compass.W; bh = Compass.H; }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) { Compass.I.drawLocal(g, mc, a); }
    };

    public final El mapEl = new El("RegionMap", false, false, true, 0) {
        boolean visible() { return regionMap.value; }
        void measure(Font f, Minecraft mc, float dt) { bw = 9 * 25 - 1 + 14; bh = 7 + 9 * 15 - 1 + 8 + 24 + 6 + 3 * 13 + 7; }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) { drawRegionMap(g, f, mc, col, bw, bh); }
    };

    public final El listEl = new El("ModuleList", true, false, false, 4) {
        boolean visible() { return list.value || !listY.isEmpty(); }
        void measure(Font f, Minecraft mc, float dt) {
            List<Integer> ws = new ArrayList<>();
            for (Module m : Modules.all) {
                if (fade.getOrDefault(m, 0f) > 0.02f || (m.enabled && list.value)) ws.add(Draw.width(f, m.name, true) + 24);
            }
            ws.sort(Comparator.reverseOrder());
            int[] lay = listLayout(ws.size());
            int cols = Math.max(1, (ws.size() + lay[2] - 1) / lay[2]), total = 0;
            for (int c = 0; c < cols; c++) { int mw = 40; for (int i = c * lay[2]; i < Math.min(ws.size(), (c + 1) * lay[2]); i++) mw = Math.max(mw, ws.get(i)); total += mw + (c > 0 ? 4 : 0); }
            bw = Math.max(40, total); bh = Math.max(17, Math.min(ws.size(), lay[2]) * lay[0]);
        }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) { drawModuleList(g, f, col); }
    };

    /** Anchor of the notification cards (drawn by Toasts). */
    public final El toastEl = new El("Notifications", true, true, false, 0) {
        boolean visible() { return true; }
        void measure(Font f, Minecraft mc, float dt) { bw = Toasts.CW; bh = Toasts.CH + 6; }
        void draw(GuiGraphics g, Font f, Minecraft mc, float a, int col) { }
    };

    public final List<El> elements = List.of(markEl, bpsEl, fpsEl, clockEl, sessionEl, serverEl, pingEl, userEl, cpsEl, coordsEl, armorEl, hotkeysEl, keysEl, targetEl, potionEl, radarEl, compassEl, mapEl, listEl, toastEl);

    public Hud() {
        super("HUD", "Pick which HUDs show. Press T (or EDIT HUD) to move / resize them.", "RENDER", true);
        I = this;
    }

    public void resetPositions() { for (El e : elements) e.reset(); flowX = 6; flowY = 4; }

    private float step(Object key, float target, float dt) {
        float v = fade.getOrDefault(key, target);
        v += (target - v) * Math.min(1f, dt * 12f);
        if (Math.abs(target - v) < 0.004f) v = target;
        fade.put(key, v);
        return v;
    }

    public void captureTarget(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        HitResult hr = mc.hitResult;
        if (mc.options.keyAttack.isDown() && hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.level.getBlockState(bhr.getBlockPos());
            if (!st.isAir()) mining = bhr.getBlockPos().immutable();
        }
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        long now = System.currentTimeMillis();
        double px = mc.player.getX(), pz = mc.player.getZ();
        if (haveLast) bpsVal += (Math.hypot(px - lastX, pz - lastZ) * 20.0 - bpsVal) * 0.25;
        lastX = px; lastZ = pz; haveLast = true;

        if (mining != null) {
            if (mc.level.getBlockState(mining).isAir()) { brokenList.add(new Broken(mining, now)); mining = null; }
            else if (!mc.options.keyAttack.isDown()) mining = null;
        }
        long life = (long) (brokenTime.value * 1000);
        Set<Integer> claimed = new HashSet<>();
        for (Broken b : brokenList) claimed.addAll(b.ids);
        for (Broken b : brokenList) {
            if (now - b.time < 1200) {
                Vec3 c = b.pos.getCenter();
                for (Entity e : mc.level.entitiesForRendering()) {
                    if (e instanceof ItemEntity && !claimed.contains(e.getId()) && e.position().distanceToSqr(c) < 9.0) {
                        b.ids.add(e.getId()); claimed.add(e.getId());
                    }
                }
            } else b.ids.removeIf(id -> mc.level.getEntity(id) == null);
        }
        brokenList.removeIf(b -> now - b.time > life || (now - b.time >= 1200 && b.ids.isEmpty()));
    }

    // ------------------------------------------------------------------ helpers
    private static int pctColor(int pc) {
        return pc > 60 ? 0xFF6BEA9A : pc > 40 ? 0xFFFFE066 : pc > 20 ? 0xFFFFB066 : 0xFFFF6B7A;
    }

    private int clicks(List<Long> l) {
        long now = System.currentTimeMillis();
        l.removeIf(t -> now - t > 1000);
        return l.size();
    }

    private static int spiral(int x, int y) {
        int k = Math.max(Math.abs(x), Math.abs(y));
        if (k == 0) return 1;
        int s = (2 * k - 1) * (2 * k - 1);
        if (x == k && y > -k) return s + (y + k);
        if (y == k) return s + 2 * k + (k - x);
        if (x == -k) return s + 4 * k + (k - y);
        return s + 6 * k + (x + k);
    }

    private static int sector(int gx, int gz) {
        double ang = Math.atan2(gz, gx);
        return Math.max(0, Math.min(5, (int) Math.floor((ang + Math.PI) / (Math.PI / 3.0))));
    }

    private void tagPill(GuiGraphics g, int left, int top, int w, int h, int barCol, float a) {
        Draw.panel(g, left, top, w, h, Math.min(8, h / 2), BG, BORDER, a);
        Draw.roundR(g, left + w - 6, top + 4, 3, h - 8, 1, Draw.alpha(barCol, a));
    }

    private void playerTag(GuiGraphics g, Font f, String name, float hp, float maxHp, double dist, double x, double y, float scale) {
        String hs = String.format(Locale.ROOT, "%.1f", hp), ds = (int) dist + "M";
        int nw = Draw.w(f, name);
        int hw = showHealth.value ? Draw.w(f, hs) + 7 : 0, dw = showDist.value ? Draw.w(f, ds) + 7 : 0;
        int w = Math.max(56, nw + hw + dw + 18), h = 22, left = -w / 2;
        float a = (float) Math.max(0.6, 1.0 - dist / 170.0);                 // far tags fade a little
        int hc = hp > 14 ? 0xFF6BEA9A : hp > 7 ? 0xFFFFE066 : 0xFFFF6B7A;
        var ps = g.pose();
        ps.pushMatrix();
        ps.translate((float) x, (float) y);
        ps.scale(scale, scale);
        Draw.panel(g, left, -11, w, h, 8, BG, BORDER, a);
        int tx = left + 9;
        Draw.str(g, f, name, tx, -7, Draw.alpha(Colors.VALUE, a), true);
        tx += nw + 7;
        if (showHealth.value) { Draw.str(g, f, hs, tx, -7, Draw.alpha(hc, a), false); tx += hw; }
        if (showDist.value) Draw.str(g, f, ds, tx, -7, Draw.alpha(Colors.LABEL, a), false);
        float pct = Math.max(0f, Math.min(1f, hp / maxHp));
        int bx = left + 8, bw = w - 16, fw = Math.max(2, (int) (bw * pct));
        g.fill(bx, 4, bx + bw, 7, Draw.alpha(0x66000000, a));
        g.fillGradient(bx, 4, bx + fw, 7, Draw.alpha(Draw.lighten(hc, 0.35f), a), Draw.alpha(hc, a));
        ps.popMatrix();
    }

    private void itemTag(GuiGraphics g, Font f, ItemStack st, String text, double x, double y, float a, float scale) {
        int tw = Draw.width(f, text, true), w = tw + 36, left = -w / 2;
        var ps = g.pose();
        ps.pushMatrix();
        ps.translate((float) x, (float) y);
        ps.scale(scale, scale);
        tagPill(g, left, -9, w, 19, color.argb(), a);
        if (a > 0.35f) g.renderItem(st, left + 3, -8);
        Draw.text(g, f, text, left + 23, -4, Draw.alpha(0xFFFFFFFF, a), true);
        ps.popMatrix();
    }

    private void drawRegionMap(GuiGraphics g, Font f, Minecraft mc, int col, int w, int h) {
        int size = regionSize.i(), cols = 9, cw = 24, chh = 14, gap = 1;
        BlockPos bp = mc.player.blockPosition();
        int rx = Math.floorDiv(bp.getX(), size), rz = Math.floorDiv(bp.getZ(), size);
        Draw.panel(g, 0, 0, w, h, 12, 0xEE0F1626, BORDER, 1f);
        for (int r = 0; r < cols; r++) {
            for (int c = 0; c < cols; c++) {
                int gx = rx + c - 4, gz = rz + r - 4;
                int cx = 7 + c * (cw + gap), cy = 7 + r * (chh + gap);
                int rc = REGION_COL[sector(gx, gz)];
                boolean cur = r == 4 && c == 4;
                Draw.roundR(g, cx, cy, cw, chh, 3, (cur ? 0xFF : 0xDD) << 24 | (rc & 0xFFFFFF));
                String num = String.valueOf(spiral(gx, gz));
                Draw.str(g, f, num, cx + (cw - Draw.w(f, num)) / 2, cy + (chh - 8) / 2 + 1, 0xFFFFFFFF, false);
                if (cur) Draw.outline(g, cx - 1, cy - 1, cw + 2, chh + 2, 0xFFFFFFFF);
            }
        }
        int ty = 7 + cols * (chh + gap) - gap + 8;
        int cur = spiral(rx, rz), cs = sector(rx, rz);
        Draw.str(g, f, "POSITION  X: " + bp.getX() + "  Z: " + bp.getZ(), 8, ty, 0xFFFFFFFF, false);
        Draw.str(g, f, "CURRENT REGION: " + cur + " (" + REGION_NAME[cs] + ")", 8, ty + 12, col, false);
        int ly = ty + 30;
        for (int i = 0; i < 6; i++) {
            int lx = 8 + (i / 3) * (w / 2), lyy = ly + (i % 3) * 13;
            Draw.roundR(g, lx, lyy, 8, 8, 2, REGION_COL[i]);
            Draw.str(g, f, REGION_NAME[i], lx + 12, lyy, 0xFFE8EAEE, false);
        }
    }

    /** Module list: tight dark pills, right-aligned, coloured bar on the right. Local origin = top-right corner. */
    /** {row pitch, entry height, rows per column} so that n entries fit the screen height. */
    private int[] listLayout(int n) {
        int avail = (int) ((screenH - 10) / Math.max(0.5f, listEl.scale));
        if (n * 17 <= avail) return new int[]{17, 15, Math.max(1, n)};
        int pitch = avail / Math.max(1, n);
        if (pitch >= 12) return new int[]{pitch, pitch - 1, n};              // squeeze into one column
        return new int[]{13, 12, Math.max(1, avail / 13)};                  // otherwise extra columns to the left
    }

    private void drawModuleList(GuiGraphics g, Font f, int col) {
        List<Module> act = new ArrayList<>();
        for (Module m : Modules.all) {
            float am = step(m, (m.enabled && list.value) ? 1f : 0f, frameDt);
            if (am > 0.02f) act.add(m); else listY.remove(m);
        }
        act.sort(Comparator.comparingInt((Module m) -> -Draw.width(f, m.name, true)));
        // many modules: the entries shrink and then continue in extra columns to the left, so the list always fits the screen height
        int[] lay = listLayout(act.size());
        int pitch = lay[0], eh = lay[1], rows = lay[2];
        int cols = Math.max(1, (act.size() + rows - 1) / rows);
        int[] colW = new int[cols];
        for (int i = 0; i < act.size(); i++) colW[i / rows] = Math.max(colW[i / rows], Draw.width(f, act.get(i).name, true) + 24);
        int[] colRight = new int[cols];
        for (int c = 1; c < cols; c++) colRight[c] = colRight[c - 1] - colW[c - 1] - 4;
        int idx = 0;
        for (Module m : act) {
            float am = fade.getOrDefault(m, 1f);
            int c = idx / rows, row = idx % rows;
            float ty = row * (float) pitch;
            float cy = listY.containsKey(m) ? listY.get(m) : ty;
            cy += (ty - cy) * (1f - (float) Math.exp(-frameDt * 18.0));
            listY.put(m, cy);
            int w = Draw.width(f, m.name, true) + 24;
            int x = colRight[c] - w + (int) ((1f - Draw.easeOut(am)) * 20), y = Math.round(cy);
            if (eh >= 15) {
                Draw.roundR(g, x - 1, y - 1, w + 2, 17, 8, Draw.alpha(Colors.T(0x668A78F0), am), false);
                Draw.roundG(g, x, y, w, 15, 7, Draw.alpha(Colors.T(0xF03C3292), am), Draw.alpha(Colors.T(0xF01B1555), am), true);
                Draw.text(g, f, m.name, x + 8, y + 4, Draw.alpha(Colors.VALUE, am), true);
                g.fillGradient(x + w - 7, y + 4, x + w - 5, y + 11, Draw.alpha(Draw.lighten(col, 0.45f), am), Draw.alpha(col, am));
            } else {                                                    // compact entry: one rounded body, no border
                Draw.roundG(g, x, y, w, eh, eh / 2, Draw.alpha(Colors.T(0xF03C3292), am), Draw.alpha(Colors.T(0xF01B1555), am), false);
                Draw.text(g, f, m.name, x + 7, y + (eh - 7) / 2, Draw.alpha(Colors.VALUE, am), true);
                g.fillGradient(x + w - 6, y + 2, x + w - 4, y + eh - 2, Draw.alpha(Draw.lighten(col, 0.45f), am), Draw.alpha(col, am));
            }
            idx++;
        }
    }

    // ------------------------------------------------------------------ editing (chat open = press T)
    private int snapX(int nl, El e, int W, boolean[] hit) {
        int best = nl, bd = 6;
        List<Integer> c = new ArrayList<>(List.of(6, W - e.w - 6, (W - e.w) / 2));
        for (El o : elements) if (o != e && o.x >= 0 && o.visible() && o != toastEl) { c.add(o.left()); c.add(o.left() + o.w - e.w); }
        for (int v : c) if (Math.abs(v - nl) < bd) { bd = Math.abs(v - nl); best = v; hit[0] = true; }
        return best;
    }

    private int snapY(int nt, El e, int H, boolean[] hit) {
        int best = nt, bd = 6;
        List<Integer> c = new ArrayList<>(List.of(6, H - e.h - 6, (H - e.h) / 2));
        for (El o : elements) if (o != e && o.x >= 0 && o.visible() && o != toastEl) { c.add(o.top()); c.add(o.top() + o.h - e.h); }
        for (int v : c) if (Math.abs(v - nt) < bd) { bd = Math.abs(v - nt); best = v; hit[0] = true; }
        return best;
    }

    private boolean onHandle(El e, double mx, double my) {
        int hx = e.right ? e.left() : e.left() + e.w, hy = e.bottom ? e.top() : e.top() + e.h;
        return Math.abs(mx - hx) <= 5 && Math.abs(my - hy) <= 5;
    }

    private boolean onBody(El e, double mx, double my) {
        return mx >= e.left() && mx < e.left() + e.w && my >= e.top() && my < e.top() + e.h;
    }

    private void editMode(GuiGraphics g, Font f, Minecraft mc, long win, boolean mL, boolean mR, int W, int H, int col) {
        double[] cx = new double[1], cy = new double[1];
        int[] ww = new int[1], wh = new int[1];
        GLFW.glfwGetCursorPos(win, cx, cy);
        GLFW.glfwGetWindowSize(win, ww, wh);
        double mx = cx[0] * W / Math.max(1, ww[0]), my = cy[0] * H / Math.max(1, wh[0]);

        if (mL && !wasDown) {
            dragging = null; resizing = null;
            for (int i = elements.size() - 1; i >= 0; i--) {
                El e = elements.get(i);
                if (!e.visible() || e.x < 0) continue;
                if (onHandle(e, mx, my)) { resizing = e; break; }
                if (onBody(e, mx, my)) { dragging = e; offX = (int) mx - e.left(); offY = (int) my - e.top(); break; }
            }
        }
        if (mR && !wasRight) {
            for (int i = elements.size() - 1; i >= 0; i--) {
                El e = elements.get(i);
                if (e.visible() && e.x >= 0 && onBody(e, mx, my)) { e.reset(); break; }
            }
        }
        guideX = -1; guideY = -1;
        if (mL && resizing != null) {
            El e = resizing;
            double dx = e.right ? (e.x - mx) : (mx - e.left());
            e.scale = Math.max(0.5f, Math.min(3f, Math.round(dx / Math.max(1, e.bw) * 20f) / 20f));
        }
        if (mL && dragging != null) {
            El e = dragging;
            boolean[] hx = {false}, hy = {false};
            int nl = snapX((int) mx - offX, e, W, hx), nt = snapY((int) my - offY, e, H, hy);
            nl = Math.max(0, Math.min(W - e.w, nl)); nt = Math.max(0, Math.min(H - e.h, nt));
            if (hx[0]) guideX = nl; if (hy[0]) guideY = nt;
            e.x = e.right ? nl + e.w : nl;
            e.y = e.bottom ? nt + e.h : nt;
        }
        if (!mL) { dragging = null; resizing = null; }
        wasDown = mL; wasRight = mR;

        if (guideX >= 0) g.fill(guideX, 0, guideX + 1, H, Draw.alpha(col, 0.55f));
        if (guideY >= 0) g.fill(0, guideY, W, guideY + 1, Draw.alpha(col, 0.55f));
        for (El e : elements) {
            if (!e.visible() || e.x < 0) continue;
            boolean act = e == dragging || e == resizing;
            int oc = act ? 0xFFFFFFFF : Draw.alpha(col, 0.9f);
            Draw.outline(g, e.left() - 1, e.top() - 1, e.w + 2, e.h + 2, oc);
            int hx = e.right ? e.left() : e.left() + e.w, hy = e.bottom ? e.top() : e.top() + e.h;
            Draw.roundR(g, hx - 3, hy - 3, 7, 7, 3, 0xFFFFFFFF);
            Draw.roundR(g, hx - 2, hy - 2, 5, 5, 2, col);
            String tag = e.name + (Math.abs(e.scale - 1f) > 0.01f ? "  x" + String.format(Locale.ROOT, "%.2f", e.scale) : "");
            int tw = Draw.w(f, tag);
            int ty = e.top() - 11 < 1 ? e.top() + e.h + 3 : e.top() - 11;
            Draw.roundR(g, e.left(), ty, tw + 8, 10, 4, 0xCC000000);
            Draw.str(g, f, tag, e.left() + 4, ty + 1, 0xFFFFFFFF, false);
        }
        String hint = "HUD EDITOR   DRAG = MOVE    DOT = RESIZE    RIGHT CLICK = RESET";
        int hw = Draw.width(f, hint, true);
        Draw.panel(g, (W - hw) / 2 - 8, 4, hw + 16, 15, 7, BG, BORDER, 1f);
        Draw.text(g, f, hint, (W - hw) / 2, 8, col, true);
    }

    // ------------------------------------------------------------------ render
    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        BG = Colors.NAVY; BORDER = Colors.NAVY_BORDER;
        Font f = mc.font;
        int col = color.argb();
        int W = g.guiWidth(), H = g.guiHeight();
        long now = System.currentTimeMillis();
        long nn = System.nanoTime();
        float dt = Math.min(0.05f, (nn - lastNano) / 1e9f);
        lastNano = nn;
        frameDt = dt;

        long win = GLFW.glfwGetCurrentContext();
        boolean mL = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean mR = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (mc.screen == null) {
            if (mL && !lastL) leftClicks.add(now);
            if (mR && !lastR) rightClicks.add(now);
        }
        lastL = mL; lastR = mR;
        float ns = nametagScale.f();

        // ---------- world nametags ----------
        if (players.value) {
            for (AbstractClientPlayer p : mc.level.players()) {
                if (p == mc.player && !(Freecam.active() || Freelook.active())) continue;
                Vec3 pos = p.getPosition(pt);
                double d = Math.sqrt(pos.distanceToSqr(Proj.cx, Proj.cy, Proj.cz));
                if (d > playerRange.value) continue;
                if (!Proj.project(pos.x, pos.y + p.getBbHeight() + 0.85, pos.z)) continue;
                float scale = (float) Math.max(0.7, Math.min(1.2, 1.25 - d * 0.015)) * ns;
                playerTag(g, f, p.getName().getString(), p.getHealth(), Math.max(1f, p.getMaxHealth()), d, Proj.px, Proj.py, scale);
            }
        }
        if (broken.value) {
            long life = (long) (brokenTime.value * 1000);
            Set<Integer> seen = new HashSet<>();
            for (Broken b : brokenList) {
                float endFade = Math.min(1f, (life - (now - b.time)) / 1500f);
                for (int id : b.ids) {
                    Entity e = mc.level.getEntity(id);
                    if (!(e instanceof ItemEntity ie)) continue;
                    Vec3 pos = e.getPosition(pt);
                    if (!Proj.project(pos.x, pos.y + e.getBbHeight() + 0.6, pos.z)) continue;
                    seen.add(id);
                    double d = Math.sqrt(pos.distanceToSqr(Proj.cx, Proj.cy, Proj.cz));
                    double[] sp = smooth.get(id);
                    if (sp == null) { sp = new double[]{Proj.px, Proj.py}; smooth.put(id, sp); born.put(id, now); }
                    else { double k = 1.0 - Math.exp(-dt * 16.0); sp[0] += (Proj.px - sp[0]) * k; sp[1] += (Proj.py - sp[1]) * k; }
                    float appear = Math.min(1f, (now - born.getOrDefault(id, now)) / 260f);
                    appear = 1f - (1f - appear) * (1f - appear);
                    ItemStack st = ie.getItem();
                    String name = st.getHoverName().getString() + (st.getCount() > 1 ? " x" + st.getCount() : "");
                    float scale = (float) Math.max(0.65, Math.min(1.15, 1.2 - d * 0.02)) * (0.85f + 0.15f * appear) * ns;
                    itemTag(g, f, st, name, sp[0], sp[1] - (1f - appear) * 6, appear * endFade, scale);
                }
            }
            smooth.keySet().retainAll(seen);
            born.keySet().retainAll(seen);
        } else { smooth.clear(); born.clear(); }

        // ---------- HUD elements ----------
        for (El e : elements) {
            if (!e.visible() && fade.getOrDefault(e, 0f) < 0.02f) continue;
            e.measure(f, mc, dt);
            e.w = Math.max(1, Math.round(e.bw * e.scale));
            e.h = Math.max(1, Math.round(e.bh * e.scale));
        }
        if (listEl.x < 0) listEl.x = W - 4;
        if (listEl.y < 0) listEl.y = 4;
        if (toastEl.x < 0) { toastEl.x = W - 8; toastEl.y = H - 10; }
        if (targetEl.x < 0 && targetEl.visible()) { targetEl.x = W / 2 + 20; targetEl.y = H / 2 + 20; }
        if (potionEl.x < 0 && potionEl.visible()) { potionEl.x = 6; potionEl.y = H / 2 - 24; }
        if (radarEl.x < 0 && radarEl.visible()) { radarEl.x = 6; radarEl.y = H - radarEl.h - 8; }
        if (compassEl.x < 0 && compassEl.visible()) { compassEl.x = (W - compassEl.w) / 2; compassEl.y = 6; }
        screenH = H;
        for (El e : elements) {
            if (e == listEl || e == toastEl || e.x >= 0 || !e.visible()) continue;
            if (e.big) {
                int by = flowY + 20;
                for (El o : elements) if (o != e && !o.right && o.x >= 0 && o.x < W / 2 && o.visible()) by = Math.max(by, o.y + o.h + 4);
                e.x = 6; e.y = by;
            } else {
                if (flowX > 6 && flowX + e.w > 340) { flowX = 6; flowY += 20; }
                e.x = flowX; e.y = flowY;
                flowX += e.w + 4;
            }
        }
        var ps = g.pose();
        for (El e : elements) {
            if (e == toastEl) continue;
            float a = step(e, e.visible() ? 1f : 0f, dt);
            if (a < 0.02f || e.x < 0) continue;
            ps.pushMatrix();
            ps.translate((float) e.x, (float) e.y);
            ps.scale(e.scale, e.scale);
            e.draw(g, f, mc, a, col);
            ps.popMatrix();
        }

        if (mc.screen instanceof ChatScreen || mc.screen instanceof dev.tedi.gui.HudEditorScreen) editMode(g, f, mc, win, mL, mR, W, H, col);
        else { dragging = null; resizing = null; wasDown = false; wasRight = false; }
    }
}
