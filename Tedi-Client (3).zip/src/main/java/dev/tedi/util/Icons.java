package dev.tedi.util;

import net.minecraft.client.gui.GuiGraphics;

import java.util.HashMap;
import java.util.Map;

/** Tiny 9x9 pixel icons for the HUD pills. */
public final class Icons {
    private static final Map<String, String[]> MAP = new HashMap<>();
    static {
        MAP.put("fps", new String[]{"..#.#.#..", ".#.....#.", "#.......#", ".........", "#.......#", ".........", "#.......#", ".#.....#.", "..#.#.#.."});
        MAP.put("clock", new String[]{"..#####..", ".#.....#.", "#...#...#", "#...#...#", "#...###.#", "#.......#", "#.......#", ".#.....#.", "..#####.."});
        MAP.put("bps", new String[]{".........", "#..#.....", ".#..#....", "..#..#...", "...#..#..", "..#..#...", ".#..#....", "#..#.....", "........."});
        MAP.put("coords", new String[]{"..#####..", ".#.....#.", "#.......#", "#...#...#", "#..###..#", "#...#...#", "#.......#", ".#.....#.", "..#####.."});
        MAP.put("ping", new String[]{".........", "......#..", "......#..", "....#.#..", "....#.#..", "..#.#.#..", "..#.#.#..", "#.#.#.#..", "#.#.#.#.."});
        MAP.put("user", new String[]{"...###...", "..#####..", "..#####..", "...###...", ".........", ".#######.", "#########", "#########", "........."});
        MAP.put("cps", new String[]{"#........", "##.......", "###......", "####.....", "#####....", "######...", "###......", "#.##.....", "...#....."});
        MAP.put("check", new String[]{".........", "........#.", "......##..", "#....##...", "##..##....", ".####.....", "..##......", ".........", "........."});
        MAP.put("cross", new String[]{"#.......#", ".#.....#.", "..#...#..", "...#.#...", "....#....", "...#.#...", "..#...#..", ".#.....#.", "#.......#"});
        MAP.put("alert", new String[]{"....#....", "...###...", "...###...", "...###...", "....#....", "....#....", ".........", "....#....", "....#...."});
        MAP.put("combat", new String[]{"#########", "#.......#", "#.......#", "#.......#", ".#.....#.", ".#.....#.", "..#...#..", "...#.#...", "....#...."});
        MAP.put("misc", new String[]{"###.###..", "###.###..", "###.###..", ".........", "###.###..", "###.###..", "###.###..", ".........", "........."});
        MAP.put("render", new String[]{".........", "..#####..", ".#.....#.", "#...#...#", "#..###..#", "#...#...#", ".#.....#.", "..#####..", "........."});
        MAP.put("donut", new String[]{"..#####..", ".#######.", "###...###", "###...###", "###...###", "###...###", "###...###", ".#######.", "..#####.."});
        MAP.put("client", new String[]{"....#....", "...###...", "..#####..", ".#######.", "#########", ".#######.", "..#####..", "...###...", "....#...."});
        MAP.put("search", new String[]{".###.....", "#...#....", "#...#....", "#...#....", ".###.....", ".....#...", "......#..", ".......#.", "........."});
        MAP.put("logo", new String[]{"..#####..", ".#######.", "###...###", "##..#..##", "##.###.##", "##..#..##", "###...###", ".#######.", "..#####.."});
        MAP.put("server", new String[]{"..#####..", ".#..#..#.", "#...#...#", "#########", "#...#...#", "#...#...#", "#########", ".#..#..#.", "..#####.."});
        MAP.put("keys", new String[]{"#########", "#.......#", "#.#.#.#.#", "#.......#", "#.#####.#", "#.......#", "#########", ".........", "........."});
    }

    private Icons() {}

    /** Pixel rows merged into as few rectangles as possible (computed once per icon). */
    private static final Map<String, int[][]> RECTS = new HashMap<>();

    static int[][] rects(String[] rows) {
        java.util.List<int[]> out = new java.util.ArrayList<>();
        java.util.List<int[]> open = new java.util.ArrayList<>();    // rectangles still growing downwards: x, y, w, h
        for (int r = 0; r <= rows.length; r++) {
            String row = r < rows.length ? rows[r] : "";
            java.util.List<int[]> next = new java.util.ArrayList<>();
            int start = -1;
            for (int c = 0; c <= row.length(); c++) {
                boolean on = c < row.length() && row.charAt(c) == '#';
                if (on && start < 0) start = c;
                if (!on && start >= 0) {
                    int[] hit = null;
                    for (int[] o : open) if (o[0] == start && o[2] == c - start && o[1] + o[3] == r) { hit = o; break; }
                    if (hit != null) { hit[3]++; open.remove(hit); next.add(hit); }
                    else next.add(new int[]{start, r, c - start, 1});
                    start = -1;
                }
            }
            out.addAll(open);
            open = next;
        }
        return out.toArray(new int[0][]);
    }

    public static void draw(GuiGraphics g, String name, int x, int y, int color) {
        int[][] rc = RECTS.get(name);
        if (rc == null) {
            String[] rows = MAP.get(name);
            if (rows == null) return;
            rc = rects(rows);
            RECTS.put(name, rc);
        }
        for (int[] r : rc) g.fill(x + r[0], y + r[1], x + r[0] + r[2], y + r[1] + r[3], color);
    }
}
