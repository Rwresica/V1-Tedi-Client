package dev.tedi.util;

public final class Colors {
    public static final int ACCENT = 0xFFB79CFF;   // soft violet
    public static final int TEXT = 0xFFD9DCE1;
    public static final int DIM = 0xFF8A9099;
    // dark-blue theme used by every panel / pill / card
    public static final int NAVY = 0xF2231B58;
    public static final int NAVY_DEEP = 0xF5130F3A;
    public static final int NAVY_FIELD = 0xFF0C0A2A;
    public static final int NAVY_BORDER = 0xB08A78F0;
    public static final int NAVY_HL = 0xF03D3294;
    /** label colour (periwinkle) and value colour used on every HUD pill */
    public static final int LABEL = 0xFFC2B8FF;
    public static final int VALUE = 0xFFF8F5FF;

    private Colors() {}

    public static int hsv(double hue) { return hsv(hue, 0.75, 1.0); }

    public static int hsv(double hue, double s, double v) {
        hue = ((hue % 360.0) + 360.0) % 360.0;
        s = Math.max(0, Math.min(1, s));
        v = Math.max(0, Math.min(1, v));
        double h = hue / 60.0;
        int i = ((int) Math.floor(h)) % 6;
        double f = h - Math.floor(h);
        double p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        double r, g, b;
        switch (i) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    public static int withAlpha(int color, int alpha) { return (alpha << 24) | (color & 0xFFFFFF); }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (a >>> 24), ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = (b >>> 24), br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }
}
