package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;

/** Arrows around the crosshair pointing at players that are outside your view. */
public class OffscreenArrows extends Module {
    public final Setting.Hue color = add(new Setting.Hue("Color", 350, 0.75, 1.0));
    public final Setting.Num range = add(new Setting.Num("Range", 80, 20, 150, 1));

    public OffscreenArrows() {
        super("OffscreenArrows", "Arrows pointing to players outside your view.", "VISUALS", true);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null || mc.screen != null) return;
        Font f = mc.font;
        int W = g.guiWidth(), H = g.guiHeight();
        double cx = W / 2.0, cy = H / 2.0, rx = W * 0.36, ry = H * 0.34;
        double yaw = Math.toRadians(mc.player.getYRot());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        int base = color.argb();
        float pulse = (float) (0.75 + 0.25 * Math.sin(System.currentTimeMillis() / 220.0));
        int shown = 0;
        for (AbstractClientPlayer p : mc.level.players()) {
            if (p == mc.player || shown >= 10) continue;
            double dx = p.getX() - mc.player.getX(), dz = p.getZ() - mc.player.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > range.value || dist < 1.0) continue;
            boolean visible = Proj.project(p.getX(), p.getY() + 1.0, p.getZ())
                    && Proj.px >= 0 && Proj.px <= W && Proj.py >= 0 && Proj.py <= H;
            if (visible) continue;
            double a = dx * -cos + dz * -sin;       // right of you
            double b = dx * -sin + dz * cos;        // in front of you
            double ang = Math.atan2(a, b);
            double ux = Math.sin(ang), uy = -Math.cos(ang);
            double ex = cx + ux * rx, ey = cy + uy * ry;
            double vx = -uy, vy = ux;               // perpendicular
            int c = Draw.alpha(Colors.lerp(base, 0xFFFFFFFF, (float) Math.min(0.7, dist / range.value * 0.7)), pulse);
            int sh = Draw.alpha(0xFF000000, 0.5f * pulse);
            double tx = ex + ux * 8, ty = ey + uy * 8;
            double w1x = ex - ux * 5 + vx * 7, w1y = ey - uy * 5 + vy * 7;
            double w2x = ex - ux * 5 - vx * 7, w2y = ey - uy * 5 - vy * 7;
            for (int pass = 0; pass < 2; pass++) {
                float w = pass == 0 ? 4.2f : 2.2f;
                int col = pass == 0 ? sh : c;
                Proj.line(g, tx, ty, w1x, w1y, w, col);
                Proj.line(g, tx, ty, w2x, w2y, w, col);
                Proj.line(g, w1x, w1y, ex - ux * 1, ey - uy * 1, w, col);
                Proj.line(g, w2x, w2y, ex - ux * 1, ey - uy * 1, w, col);
            }
            String s = Math.round(dist) + "M";
            Draw.str(g, f, s, (int) (ex - ux * 20) - Draw.w(f, s) / 2, (int) (ey - uy * 16) - 3, Draw.alpha(0xFFFFFFFF, pulse), true);
            shown++;
        }
    }
}
