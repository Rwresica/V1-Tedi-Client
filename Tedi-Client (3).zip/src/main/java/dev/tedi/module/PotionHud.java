package dev.tedi.module;

import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.HashMap;
import java.util.Map;

/** Your active potion effects: name, level, time left and a progress line. */
public class PotionHud extends VisualBase {
    private static final String[] ROMAN = {"", "", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
    private final Map<String, Integer> maxDur = new HashMap<>();

    public PotionHud() {
        super("PotionHUD", "Shows your active potion effects with timers.", "VISUALS");
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null) return;
        var effects = mc.player.getActiveEffects();
        if (effects.isEmpty()) { if (!maxDur.isEmpty()) maxDur.clear(); return; }
        Font f = mc.font;
        int col = color.argb();
        int x = 8 + offX.i();
        int y = g.guiHeight() / 2 - 24 + offY.i();
        int shown = 0;
        for (MobEffectInstance inst : effects) {
            if (shown >= 8) break;
            String name = inst.getEffect().value().getDisplayName().getString();
            int amp = inst.getAmplifier();
            if (amp > 0) name += " " + (amp + 1 < ROMAN.length ? ROMAN[amp + 1] : String.valueOf(amp + 1));
            boolean inf = inst.isInfiniteDuration();
            int dur = inst.getDuration();
            String time = inf ? "INF" : String.format("%d:%02d", dur / 1200, (dur / 20) % 60);
            int max = Math.max(maxDur.getOrDefault(name, 0), dur);
            maxDur.put(name, max);
            float frac = inf ? 1f : (max <= 0 ? 0f : Math.max(0f, Math.min(1f, dur / (float) max)));

            int tw = Draw.w(f, time), nw = Draw.w(f, name);
            int w = Math.max(96, 9 + nw + 14 + tw + 9);
            int h = 20;
            Draw.panel(g, x, y, w, h, 7, Colors.NAVY, Colors.NAVY_BORDER, 1f);
            Draw.str(g, f, name, x + 9, y + 4, Colors.VALUE, true);
            boolean low = !inf && dur < 200;
            Draw.str(g, f, time, x + w - 9 - tw, y + 4, low ? 0xFFFF7A90 : Colors.LABEL, true);
            int lx = x + 9, lw = w - 18;
            g.fill(lx, y + 14, lx + lw, y + 16, 0x55000000);
            int fw = Math.max(1, (int) (lw * frac));
            g.fillGradient(lx, y + 14, lx + fw, y + 16, Draw.lighten(col, 0.4f), col);
            y += h + 3;
            shown++;
        }
    }
}
