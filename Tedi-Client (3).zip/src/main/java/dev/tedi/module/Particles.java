package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.Random;

/** Ambient particles over your screen: 1 = snow, 2 = twinkling stars, 3 = rising embers. */
public class Particles extends FxBase {
    public final Setting.Num mode = add(new Setting.Num("Mode (1-3)", 1, 1, 3, 1));
    public final Setting.Num amount = add(new Setting.Num("Amount", 45, 10, 120, 1));

    private static final int MAX = 120;
    private final float[] x = new float[MAX], y = new float[MAX], sp = new float[MAX], ph = new float[MAX], sz = new float[MAX];
    private final Random rnd = new Random();
    private boolean init;
    private int lastMode = -1;

    public Particles() {
        super("Particles", "Snow, stars or embers drifting over your screen.", "VISUALS");
    }

    private void spawn(int i, int W, int H, boolean anywhere) {
        x[i] = rnd.nextFloat() * W;
        y[i] = anywhere ? rnd.nextFloat() * H : (mode.i() == 3 ? H + 4 : -4);
        sp[i] = 18f + rnd.nextFloat() * 30f;
        ph[i] = rnd.nextFloat() * 6.28f;
        sz[i] = 1f + rnd.nextInt(3) * 0.5f;
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        int W = g.guiWidth(), H = g.guiHeight();
        int m = mode.i();
        if (!init || m != lastMode) {
            for (int i = 0; i < MAX; i++) spawn(i, W, H, true);
            init = true; lastMode = m;
        }
        float dt = dt();
        double time = System.currentTimeMillis() / 1000.0;
        int n = Math.min(MAX, amount.i());
        for (int i = 0; i < n; i++) {
            int size = Math.max(1, Math.round(sz[i]));
            int color;
            if (m == 1) {                                   // snow: falls and sways
                y[i] += sp[i] * dt;
                x[i] += (float) Math.sin(time * 0.9 + ph[i]) * 10f * dt;
                if (y[i] > H + 4) spawn(i, W, H, false);
                color = 0xCCFFFFFF;
            } else if (m == 2) {                            // stars: stay and twinkle
                float tw = (float) (0.35 + 0.65 * Math.abs(Math.sin(time * (0.8 + sp[i] / 40.0) + ph[i])));
                color = ((int) (230 * tw) << 24) | (i % 3 == 0 ? 0xCFE3FF : 0xFFFFFF);
            } else {                                        // embers: rise and flicker
                y[i] -= sp[i] * dt * 1.2f;
                x[i] += (float) Math.sin(time * 1.4 + ph[i]) * 14f * dt;
                if (y[i] < -4) spawn(i, W, H, false);
                float fl = (float) (0.55 + 0.45 * Math.sin(time * 9 + ph[i] * 3));
                color = ((int) (230 * fl) << 24) | (i % 2 == 0 ? 0xFF9A3C : 0xFFD166);
            }
            int px = (int) x[i], py = (int) y[i];
            g.fill(px, py, px + size, py + size, color);
        }
    }
}
