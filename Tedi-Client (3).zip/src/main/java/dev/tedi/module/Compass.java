package dev.tedi.module;

import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Heading strip at the top of the screen (N / E / S / W with ticks and degrees). */
public class Compass extends VisualBase {
    private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    public Compass() {
        super("Compass", "Heading strip with cardinal directions.", "VISUALS");
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null) return;
        Font f = mc.font;
        int col = color.argb();
        int w = 176, h = 18;
        int x = g.guiWidth() / 2 - w / 2 + offX.i();
        int y = 6 + offY.i();
        int cx = x + w / 2;
        float heading = ((mc.player.getYRot() + 180f) % 360f + 360f) % 360f;     // 0 = north, 90 = east
        float span = 72f;                                                         // degrees visible each side
        float pxPerDeg = (w / 2f - 8f) / span;

        Draw.panel(g, x, y, w, h, 8, Colors.NAVY, Colors.NAVY_BORDER, 0.95f);

        for (int t = 0; t < 360; t += 10) {
            float d = ((t - heading + 540f) % 360f) - 180f;
            if (Math.abs(d) > span) continue;
            int px = cx + Math.round(d * pxPerDeg);
            float fade = 1f - Math.abs(d) / span;
            boolean major = t % 30 == 0;
            g.fill(px, y + h - (major ? 7 : 5), px + 1, y + h - 3, Draw.alpha(0xFFFFFFFF, 0.55f * fade + 0.1f));
        }
        for (int i = 0; i < 8; i++) {
            float d = ((i * 45 - heading + 540f) % 360f) - 180f;
            if (Math.abs(d) > span - 6f) continue;
            int px = cx + Math.round(d * pxPerDeg);
            float fade = 1f - Math.abs(d) / span;
            String s = DIRS[i];
            boolean cardinal = i % 2 == 0;
            int c = cardinal ? Draw.lighten(col, 0.45f) : Colors.LABEL;
            Draw.str(g, f, s, px - Draw.w(f, s) / 2, y + 3, Draw.alpha(c, Math.max(0.25f, fade)), true);
        }
        // centre marker
        g.fill(cx - 2, y + h - 2, cx + 3, y + h - 1, col);
        g.fill(cx - 1, y + h - 3, cx + 2, y + h - 2, col);
        g.fill(cx, y + h - 4, cx + 1, y + h - 3, col);

        String deg = String.valueOf(Math.round(heading) % 360);
        Draw.str(g, f, deg, cx - Draw.w(f, deg) / 2, y + h + 4, Draw.alpha(Colors.VALUE, 0.95f), true);
    }
}
