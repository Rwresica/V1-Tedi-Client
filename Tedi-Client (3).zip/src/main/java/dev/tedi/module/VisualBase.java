package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Draw;
import net.minecraft.client.gui.Font;

/** Shared bits of the HUD-style visual modules: colour, position offsets and a frame timer. */
public abstract class VisualBase extends Module {
    public final Setting.Hue color = add(new Setting.Hue("Color", 262, 0.5, 1.0));
    public final Setting.Num offX = add(new Setting.Num("X Offset", 0, -600, 600, 1));
    public final Setting.Num offY = add(new Setting.Num("Y Offset", 0, -400, 400, 1));
    private long lastNano = System.nanoTime();

    protected VisualBase(String name, String description, String category) {
        super(name, description, category, true);
    }

    /** Seconds since the previous call (capped), for smooth animations. */
    protected float dt() {
        long n = System.nanoTime();
        float d = Math.min(0.05f, (n - lastNano) / 1e9f);
        lastNano = n;
        return d;
    }

    protected static float approach(float cur, float target, float speed, float dt) {
        return cur + (target - cur) * Math.min(1f, dt * speed);
    }

    protected static String clip(Font f, String s, int maxW) {
        if (Draw.w(f, s) <= maxW) return s;
        while (s.length() > 1 && Draw.w(f, s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
}
