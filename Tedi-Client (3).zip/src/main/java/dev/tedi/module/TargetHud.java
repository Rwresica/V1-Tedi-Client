package dev.tedi.module;

import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

import java.util.Locale;

/** Name, distance and a smooth health bar of whatever you are looking at (stays 1.5 s after you look away). */
public class TargetHud extends VisualBase {
    private LivingEntity target;
    private long lastSeen;
    private float alpha, hpShown = -1f;

    public TargetHud() {
        super("TargetHUD", "Health bar of the player / mob you look at.", "VISUALS");
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null) return;
        float dt = dt();
        long now = System.currentTimeMillis();
        Entity e = mc.crosshairPickEntity;
        if (e instanceof LivingEntity le && e != mc.player && le.isAlive()) {
            if (le != target) hpShown = -1f;
            target = le;
            lastSeen = now;
        }
        if (target == null) return;
        boolean show = target.isAlive() && now - lastSeen < 1500;
        alpha = approach(alpha, show ? 1f : 0f, 10f, dt);
        if (alpha < 0.02f) { if (!show) target = null; return; }

        float max = Math.max(1f, target.getMaxHealth());
        float cur = Math.max(0f, target.getHealth());
        hpShown = hpShown < 0f ? cur : approach(hpShown, cur, 8f, dt);
        float ratio = Math.max(0f, Math.min(1f, hpShown / max));

        Font f = mc.font;
        int w = 132, h = 40;
        int x = g.guiWidth() / 2 + 20 + offX.i();
        int y = g.guiHeight() / 2 + 20 + offY.i();
        float a = alpha;
        int col = color.argb();

        Draw.drop(g, x, y, w, h, 9, a);
        Draw.panel(g, x, y, w, h, 9, Colors.NAVY, Colors.NAVY_BORDER, a);

        String dist = String.format(Locale.ROOT, "%.1fM", mc.player.distanceTo(target));
        int dw = Draw.w(f, dist);
        Draw.str(g, f, clip(f, target.getName().getString(), w - 26 - dw), x + 9, y + 7, Draw.alpha(Colors.VALUE, a), true);
        Draw.str(g, f, dist, x + w - 9 - dw, y + 7, Draw.alpha(Colors.LABEL, a), true);

        int bx = x + 9, by = y + 19, bw = w - 18, bh = 6;
        Draw.roundR(g, bx, by, bw, bh, 3, Draw.alpha(0xFF0C0A2A, a), false);
        int fw = Math.max(bh, (int) (bw * ratio));
        int hc = Colors.lerp(0xFFFF5470, 0xFF4ADE80, ratio);
        Draw.roundG(g, bx, by, fw, bh, 3, Draw.alpha(Draw.lighten(hc, 0.3f), a), Draw.alpha(hc, a), false);

        String hp = String.format(Locale.ROOT, "%.1f / %.1f", cur, max);
        Draw.str(g, f, hp, x + 9, y + 29, Draw.alpha(Draw.lighten(col, 0.35f), a), true);
    }
}
