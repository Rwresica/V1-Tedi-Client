package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayDeque;
import java.util.Iterator;

/** A glowing ribbon that follows you through the world (shown in third person / freecam / when you look back). */
public class Trails extends Module {
    public final Setting.Num length = add(new Setting.Num("Length", 60, 15, 140, 1));
    public final Setting.Num width = add(new Setting.Num("Width", 2.6, 1, 6, 0.1));
    public final Setting.Bool rainbow = add(new Setting.Bool("Rainbow", true));
    public final Setting.Bool glow = add(new Setting.Bool("Glow", false));
    public final Setting.Hue color = add(new Setting.Hue("Color", 262, 0.6, 1.0));

    private final ArrayDeque<double[]> pts = new ArrayDeque<>();

    public Trails() {
        super("Trails", "Rainbow ribbon trail behind you.", "VISUALS", true);
    }

    @Override
    public void onDisable() { pts.clear(); }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null) { pts.clear(); return; }
        double x = mc.player.getX(), y = mc.player.getY() + 0.12, z = mc.player.getZ();
        double[] last = pts.peekLast();
        if (last == null || (last[0] - x) * (last[0] - x) + (last[1] - y) * (last[1] - y) + (last[2] - z) * (last[2] - z) > 0.0009) {
            pts.addLast(new double[]{x, y, z});
        }
        while (pts.size() > length.i()) pts.pollFirst();
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        int n = pts.size();
        if (n < 2) return;
        double time = System.currentTimeMillis() / 18.0;
        double[] prev = null;
        int i = 0;
        for (Iterator<double[]> it = pts.iterator(); it.hasNext(); i++) {
            double[] cur = it.next();
            if (prev != null) {
                float t = i / (float) n;
                int rgb = rainbow.value ? Colors.hsv(time + (n - i) * 4.0, 0.65, 1.0) : color.rgb();
                float w = width.f() * (0.35f + 0.65f * t);
                if (glow.value) Proj.line3d(g, prev[0], prev[1], prev[2], cur[0], cur[1], cur[2], w * 2.4f, Draw.alpha(0xFF000000 | rgb, 0.16f * t));
                Proj.line3d(g, prev[0], prev[1], prev[2], cur[0], cur[1], cur[2], w, Draw.alpha(0xFF000000 | rgb, 0.15f + 0.8f * t));
            }
            prev = cur;
        }
    }
}
