package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;

/**
 * Changes the colours of the Minecraft sky. Sky 1 = Galaxy violet, 2 = Nebula rose, 3 = Cotton clouds, 4 = Aurora.
 * The sky blends from the horizon colour to the zenith colour while you look up.
 */
public class SkyChanger extends Module {
    public static SkyChanger I;
    public final Setting.Num sky = add(new Setting.Num("Sky (1-4)", 1, 1, 4, 1));

    //                       zenith,    horizon,   clouds
    private static final int[][] PRESETS = {
        {0x2A0B5E, 0xB52FD9, 0xE0B3FF},   // 1 galaxy violet
        {0x4A1470, 0xFF3FC8, 0xFFB8EE},   // 2 nebula rose
        {0x3A9BE6, 0xFFB7D6, 0xFFEAF3},   // 3 cotton clouds
        {0x2D6BFF, 0xD7A6F2, 0xB8F5EA},   // 4 aurora
    };

    public SkyChanger() {
        super("SkyChanger", "Pretty skies: 1 Galaxy, 2 Nebula Rose, 3 Cotton Clouds, 4 Aurora.", "RENDER", true);
        I = this;
    }

    public static boolean active() { return I != null && I.enabled; }

    private int[] preset() { return PRESETS[Math.max(0, Math.min(PRESETS.length - 1, sky.i() - 1))]; }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Sky colour, blended by how far up the player looks. */
    public static int skyColor() {
        Minecraft mc = Minecraft.getInstance();
        float up = mc.player == null ? 0.5f : Math.max(0f, Math.min(1f, -mc.player.getXRot() / 70f + 0.25f));
        int[] p = I.preset();
        return mix(p[1], p[0], up * up * (3f - 2f * up));
    }

    public static int cloudColor() { return 0xFF000000 | I.preset()[2]; }
}
