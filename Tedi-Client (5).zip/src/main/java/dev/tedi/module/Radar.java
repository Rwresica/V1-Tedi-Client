package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;

/** Round radar: nearby players as dots, you are in the centre and "up" is where you look. */
public class Radar extends VisualBase {
    public final Setting.Num range = add(new Setting.Num("Range", 48, 16, 128, 1));
    public final Setting.Num size = add(new Setting.Num("Size", 72, 50, 110, 2));

    public Radar() {
        super("Radar", "Round radar with nearby players.", "VISUALS");
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null) return;
        Font f = mc.font;
        int R = size.i() & ~1;
        int x = 8 + offX.i();
        int y = g.guiHeight() - R - 8 + offY.i();
        int cx = x + R / 2, cy = y + R / 2;
        int col = color.argb();
        double rng = range.value;
        float inner = R / 2f - 5f;

        Draw.panel(g, x, y, R, R, R / 2, Colors.NAVY, Colors.NAVY_BORDER, 0.94f);
        g.fill(cx, y + 7, cx + 1, y + R - 7, 0x26FFFFFF);
        g.fill(x + 7, cy, x + R - 7, cy + 1, 0x26FFFFFF);

        double yaw = Math.toRadians(mc.player.getYRot());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);

        // north marker
        int nx = cx + (int) (sin * (R / 2.0 - 8)), ny = cy - (int) (-cos * (R / 2.0 - 8));
        Draw.str(g, f, "N", nx - Draw.w(f, "N") / 2, ny - 3, Draw.alpha(Draw.lighten(col, 0.4f), 0.95f), false);

        double px = mc.player.getX(), pz = mc.player.getZ();
        int count = 0;
        for (AbstractClientPlayer p : mc.level.players()) {
            if (p == mc.player || count >= 24) continue;
            double dx = p.getX() - px, dz = p.getZ() - pz;
            double a = dx * -cos + dz * -sin;       // right of you
            double b = dx * -sin + dz * cos;        // in front of you
            double d = Math.sqrt(a * a + b * b);
            if (d > rng) { a *= rng / d; b *= rng / d; }
            int sx = cx + (int) Math.round(a / rng * inner), sy = cy - (int) Math.round(b / rng * inner);
            g.fill(sx - 2, sy - 2, sx + 2, sy + 2, 0xCC000000);
            g.fill(sx - 1, sy - 1, sx + 1, sy + 1, d > rng ? 0xFFFFC857 : 0xFFFF5470);
            count++;
        }
        // rotating sweep
        double sw = System.currentTimeMillis() / 1000.0 * 1.7;
        for (int k = 0; k < 3; k++) {
            double aa = sw - k * 0.22;
            Proj.line(g, cx, cy, cx + Math.cos(aa) * (R / 2.0 - 4), cy + Math.sin(aa) * (R / 2.0 - 4), 1.6f, Draw.alpha(Draw.lighten(col, 0.3f), 0.38f - k * 0.12f));
        }
        // you
        Proj.fillPoly2d(g, new double[]{cx, cx + 4.2, cx - 4.2}, new double[]{cy - 5.2, cy + 3.6, cy + 3.6}, 3, 0xCC000000);
        Proj.fillPoly2d(g, new double[]{cx, cx + 3, cx - 3}, new double[]{cy - 3.6, cy + 2.4, cy + 2.4}, 3, 0xFFFFFFFF);
    }
}
