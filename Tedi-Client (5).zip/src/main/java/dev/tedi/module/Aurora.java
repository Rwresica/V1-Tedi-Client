package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Northern-lights curtains that shimmer along the top of the screen. */
public class Aurora extends FxBase {
    public final Setting.Num opacity = add(new Setting.Num("Opacity", 0.30, 0.1, 0.7, 0.01));
    public final Setting.Num height = add(new Setting.Num("Height %", 34, 15, 60, 1));
    private static final int N = 26;

    public Aurora() {
        super("Aurora", "Shimmering northern lights across the top of your screen.", "VISUALS");
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        int W = g.guiWidth(), H = g.guiHeight();
        double time = System.currentTimeMillis() / 1000.0;
        int sw = Math.max(1, (W + N - 1) / N);
        for (int i = 0; i < N; i++) {
            double k = i / (double) (N - 1);
            double hh = H * height.value / 100.0 * (0.62 + 0.38 * Math.sin(time * 0.55 + i * 0.55));
            double hue = 150.0 + 140.0 * k + 38.0 * Math.sin(time * 0.35 + i * 0.3);       // green -> teal -> violet -> pink
            float a = (float) (opacity.value * (0.62 + 0.38 * Math.sin(time * 0.9 + i * 0.7)));
            int rgb = Colors.hsv(hue, 0.62, 1.0);
            g.fillGradient(i * sw, 0, Math.min(W, (i + 1) * sw), (int) hh, ((int) (255 * a) << 24) | rgb, rgb);
        }
    }
}
