package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.Random;

/** Ambient particles over your screen: 1 snow, 2 stars, 3 embers, 4 sakura petals, 5 fireflies. */
public class Particles extends FxBase {
    public final Setting.Num mode = add(new Setting.Num("Mode (1-5)", 1, 1, 5, 1));
    public final Setting.Num amount = add(new Setting.Num("Amount", 36, 10, 100, 1));

    private static final int MAX = 100;
    private final float[] x = new float[MAX], y = new float[MAX], sp = new float[MAX], ph = new float[MAX], sz = new float[MAX];
    private final Random rnd = new Random();
    private boolean init;
    private int lastMode = -1;

    public Particles() {
        super("Particles", "Snow, stars, embers, sakura or fireflies drifting over your screen.", "VISUALS");
    }

    private void spawn(int i, int W, int H, boolean anywhere) {
        int m = mode.i();
        x[i] = rnd.nextFloat() * W;
        y[i] = anywhere ? rnd.nextFloat() * H : (m == 3 ? H + 4 : -4);
        sp[i] = 16f + rnd.nextFloat() * 28f;
        ph[i] = rnd.nextFloat() * 6.28f;
        sz[i] = 1f + rnd.nextInt(3) * 0.5f;
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        int W = g.guiWidth(), H = g.guiHeight();
        int m = mode.i();
        if (!init || m != lastMode) {
            for (int i = 0; i < MAX; i++) spawn(i, W, H, true);
            init = true; lastMode = m;
        }
        float dt = dt();
        double time = System.currentTimeMillis() / 1000.0;
        int n = Math.min(MAX, amount.i());
        for (int i = 0; i < n; i++) {
            int size = Math.max(1, Math.round(sz[i]));
            int px, py;
            if (m == 1) {                                         // snow
                y[i] += sp[i] * dt;
                x[i] += (float) Math.sin(time * 0.9 + ph[i]) * 10f * dt;
                if (y[i] > H + 4) spawn(i, W, H, false);
                px = (int) x[i]; py = (int) y[i];
                g.fill(px, py, px + size, py + size, 0xCCFFFFFF);
            } else if (m == 2) {                                  // twinkling stars
                float tw = (float) (0.35 + 0.65 * Math.abs(Math.sin(time * (0.8 + sp[i] / 40.0) + ph[i])));
                px = (int) x[i]; py = (int) y[i];
                int c = ((int) (230 * tw) << 24) | (i % 3 == 0 ? 0xCFE3FF : 0xFFFFFF);
                g.fill(px, py, px + size, py + size, c);
                if (size > 1 && tw > 0.8f) {                      // little sparkle cross on the brightest
                    int cc = ((int) (120 * tw) << 24) | 0xFFFFFF;
                    g.fill(px - 2, py, px, py + 1, cc); g.fill(px + size, py, px + size + 2, py + 1, cc);
                    g.fill(px, py - 2, px + 1, py, cc); g.fill(px, py + size, px + 1, py + size + 2, cc);
                }
            } else if (m == 3) {                                  // embers
                y[i] -= sp[i] * dt * 1.2f;
                x[i] += (float) Math.sin(time * 1.4 + ph[i]) * 14f * dt;
                if (y[i] < -4) spawn(i, W, H, false);
                float fl = (float) (0.55 + 0.45 * Math.sin(time * 9 + ph[i] * 3));
                px = (int) x[i]; py = (int) y[i];
                g.fill(px, py, px + size, py + size, ((int) (230 * fl) << 24) | (i % 2 == 0 ? 0xFF9A3C : 0xFFD166));
            } else if (m == 4) {                                  // sakura petals: drift sideways while falling
                y[i] += sp[i] * dt * 0.7f;
                x[i] += (14f + (float) Math.sin(time * 1.3 + ph[i]) * 16f) * dt;
                if (y[i] > H + 4 || x[i] > W + 6) { spawn(i, W, H, false); x[i] = rnd.nextFloat() * W * 0.8f; }
                px = (int) x[i]; py = (int) y[i];
                int c = (i % 2 == 0) ? 0xE6FFB7D5 : 0xE6FF8FB8;
                g.fill(px, py, px + size + 1, py + size, c);
                g.fill(px + 1, py - 1, px + size, py, c);
            } else {                                              // fireflies: wander and pulse with a soft halo
                x[i] += (float) Math.sin(time * 0.7 + ph[i] * 2) * 9f * dt;
                y[i] += (float) Math.cos(time * 0.6 + ph[i]) * 9f * dt;
                float pu = (float) (0.5 + 0.5 * Math.sin(time * 1.8 + ph[i] * 4));
                px = (int) x[i]; py = (int) y[i];
                int halo = ((int) (30 * pu) << 24) | 0xC8FF6B;               // octagon-shaped glow (two overlapping bars)
                g.fill(px - 1, py - 2, px + 2, py + 3, halo);
                g.fill(px - 2, py - 1, px + 3, py + 2, halo);
                g.fill(px, py, px + 1, py + 1, ((int) (255 * (0.4 + 0.6 * pu)) << 24) | 0xF4FFB0);
            }
        }
    }
}
