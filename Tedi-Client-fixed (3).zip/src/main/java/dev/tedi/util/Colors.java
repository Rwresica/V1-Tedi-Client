package dev.tedi.util;

public final class Colors {
    // The palette below follows the "Theme Color" you pick in TediClient+ (default = soft violet).
    public static int ACCENT, TEXT, DIM, NAVY, NAVY_DEEP, NAVY_FIELD, NAVY_BORDER, NAVY_HL, LABEL;
    /** value colour on every HUD pill (warm cream, never themed) */
    public static final int VALUE = 0xFFFFF8F0;

    private static double dh = 0, sm = 1, vm = 1;

    static { apply(); }

    private Colors() {}

    private static void apply() {
        ACCENT = T(0xFFB79CFF); TEXT = T(0xFFF7F0FF); DIM = T(0xFFA99DCB);
        NAVY = T(0xF2231B58); NAVY_DEEP = T(0xF5130F3A); NAVY_FIELD = T(0xFF0C0A2A);
        NAVY_BORDER = T(0xB08A78F0); NAVY_HL = T(0xF03D3294); LABEL = T(0xFFCDBFFF);
    }

    /** Sets the theme: hue/saturation/value of the picked colour (262 / 0.6 / 1.0 = the default violet, no change). */
    public static void setTheme(double hue, double sat, double val) {
        double ndh = hue - 262.0, nsm = Math.max(0.05, sat / 0.6), nvm = Math.max(0.3, Math.min(1.0, val));
        if (ndh == dh && nsm == sm && nvm == vm) return;
        dh = ndh; sm = nsm; vm = nvm;
        apply();
    }

    /** Moves a palette colour (alpha kept) to the current theme. */
    public static int T(int argb) {
        if (dh == 0 && sm == 1 && vm == 1) return argb;
        double r = ((argb >> 16) & 255) / 255.0, g = ((argb >> 8) & 255) / 255.0, b = (argb & 255) / 255.0;
        double mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b)), d = mx - mn;
        double h = 0;
        if (d > 1e-6) {
            if (mx == r) h = 60 * (((g - b) / d) % 6);
            else if (mx == g) h = 60 * ((b - r) / d + 2);
            else h = 60 * ((r - g) / d + 4);
        }
        double s = mx <= 1e-6 ? 0 : d / mx;
        return (argb & 0xFF000000) | hsv(h + dh, Math.min(1.0, s * sm), Math.min(1.0, mx * vm));
    }

    public static int hsv(double hue) { return hsv(hue, 0.75, 1.0); }

    public static int hsv(double hue, double s, double v) {
        hue = ((hue % 360.0) + 360.0) % 360.0;
        s = Math.max(0, Math.min(1, s));
        v = Math.max(0, Math.min(1, v));
        double h = hue / 60.0;
        int i = ((int) Math.floor(h)) % 6;
        double f = h - Math.floor(h);
        double p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        double r, g, b;
        switch (i) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    public static int withAlpha(int color, int alpha) { return (alpha << 24) | (color & 0xFFFFFF); }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (a >>> 24), ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = (b >>> 24), br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }
}
