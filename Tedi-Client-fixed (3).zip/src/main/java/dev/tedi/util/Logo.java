package dev.tedi.util;

import net.minecraft.client.gui.GuiGraphics;

/** The client's profile picture as tiny pixel art (a few merged rectangles, so it is free to draw). */
public final class Logo {
    public static final int W = 12, H = 15;
    private static final String[] BLUE = {
        "...##.......",
        "..###.###...",
        "..###.##....",
        ".####.##....",
        ".########...",
        "..########..",
        "..###.#..###",
        "..###.#..###",
        "..###.######",
        "#..########.",
        "##..#####...",
        "####........",
        ".#####...#..",
        "....##...#..",
        ".....####..."
    };
    private static final String[] BLACK = {
        "............",
        "............",
        "............",
        "............",
        "............",
        "............",
        ".....#.#....",
        ".....#.##...",
        ".....#......",
        "............",
        "...#........",
        "....###.#...",
        "......###...",
        "............",
        "............"
    };
    private static int[][] blue, black;

    private Logo() {}

    /** Draws the logo at (x,y); size = W*scale x H*scale GUI pixels (scale is a whole number). */
    public static void draw(GuiGraphics g, int x, int y, int scale, int blueArgb, int blackArgb) {
        if (blue == null) { blue = Icons.rects(BLUE); black = Icons.rects(BLACK); }
        for (int[] r : blue) g.fill(x + r[0] * scale, y + r[1] * scale, x + (r[0] + r[2]) * scale, y + (r[1] + r[3]) * scale, blueArgb);
        for (int[] r : black) g.fill(x + r[0] * scale, y + r[1] * scale, x + (r[0] + r[2]) * scale, y + (r[1] + r[3]) * scale, blackArgb);
    }
}
