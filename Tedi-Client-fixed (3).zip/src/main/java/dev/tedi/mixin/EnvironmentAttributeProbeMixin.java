package dev.tedi.mixin;

import dev.tedi.module.SkyChanger;
import net.minecraft.world.attribute.EnvironmentAttribute;
import net.minecraft.world.attribute.EnvironmentAttributeProbe;
import net.minecraft.world.attribute.EnvironmentAttributes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Minecraft 1.21.11 reads sky / cloud / fog colours from "environment attributes" (the camera's probe).
 * SkyChanger swaps those values while it is on.
 */
@Mixin(EnvironmentAttributeProbe.class)
public abstract class EnvironmentAttributeProbeMixin {
    @SuppressWarnings("unchecked")
    @Inject(method = "getValue", at = @At("RETURN"), cancellable = true, require = 0)
    private <T> void tedi$sky(EnvironmentAttribute<T> attribute, float partialTick, CallbackInfoReturnable<T> cir) {
        if (!SkyChanger.active()) return;
        if (attribute == EnvironmentAttributes.SKY_COLOR) cir.setReturnValue((T) (Object) Integer.valueOf(SkyChanger.skyColor()));
        else if (attribute == EnvironmentAttributes.CLOUD_COLOR) cir.setReturnValue((T) (Object) Integer.valueOf(SkyChanger.cloudColor()));
        else if (attribute == EnvironmentAttributes.FOG_COLOR) cir.setReturnValue((T) (Object) Integer.valueOf(SkyChanger.fogColor()));
    }
}
