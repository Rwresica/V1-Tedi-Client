package dev.tedi.mixin;

import dev.tedi.module.SkyChanger;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Sky / cloud colour for SkyChanger (skipped silently if this Minecraft version computes them elsewhere). */
@Mixin(ClientLevel.class)
public abstract class ClientLevelSkyMixin {
    @Inject(method = "getSkyColor", at = @At("HEAD"), cancellable = true, require = 0)
    private void tedi$sky(Vec3 pos, float partialTick, CallbackInfoReturnable<Integer> cir) {
        if (SkyChanger.active()) cir.setReturnValue(SkyChanger.skyColor());
    }

    @Inject(method = "getCloudColor", at = @At("HEAD"), cancellable = true, require = 0)
    private void tedi$cloud(float partialTick, CallbackInfoReturnable<Integer> cir) {
        if (SkyChanger.active()) cir.setReturnValue(SkyChanger.cloudColor());
    }
}
