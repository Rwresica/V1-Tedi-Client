package dev.tedi.mixin;

import dev.tedi.module.CustomFov;
import dev.tedi.module.Fullbright;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Fullbright (gamma reads huge) and CustomFOV (fov reads your value). */
@Mixin(OptionInstance.class)
public abstract class OptionInstanceMixin<T> {
    @SuppressWarnings("unchecked")
    @Inject(method = "get", at = @At("HEAD"), cancellable = true, require = 0)
    private void tedi$get(CallbackInfoReturnable<T> cir) {
        // get() is called thousands of times per frame: bail out before touching anything when nothing is overridden
        if (!Fullbright.gammaOn() && !CustomFov.active()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.options == null) return;
        if (Fullbright.gammaOn() && (Object) this == mc.options.gamma()) {
            cir.setReturnValue((T) (Object) Double.valueOf(15.0));
        } else if (CustomFov.active() && (Object) this == mc.options.fov()) {
            int v = CustomFov.value();
            cir.setReturnValue((T) (Object) Integer.valueOf(dev.tedi.module.Zoom.engaged() ? dev.tedi.module.Zoom.apply(v) : v));
        }
    }

    /** Zoom: blends the (normal) field of view toward the zoom value while C is held. */
    @SuppressWarnings("unchecked")
    @Inject(method = "get", at = @At("RETURN"), cancellable = true, require = 0)
    private void tedi$zoom(CallbackInfoReturnable<T> cir) {
        if (!dev.tedi.module.Zoom.engaged()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.options == null || (Object) this != mc.options.fov()) return;
        if (cir.getReturnValue() instanceof Integer i) cir.setReturnValue((T) (Object) Integer.valueOf(dev.tedi.module.Zoom.apply(i)));
    }
}
