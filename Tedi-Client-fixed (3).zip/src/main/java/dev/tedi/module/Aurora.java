package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Northern-lights curtains that shimmer along the top of the screen. */
public class Aurora extends FxBase {
    public final Setting.Num opacity = add(new Setting.Num("Opacity", 0.30, 0.1, 0.7, 0.01));
    public final Setting.Num height = add(new Setting.Num("Height %", 34, 15, 60, 1));
    public final Setting.Bool threeD = add(new Setting.Bool("3D", true));
    public final Setting.Num curtains = add(new Setting.Num("3D Curtains", 1, 1, 3, 1));
    private static final int N = 26;

    /** Glowing curtains hanging in the sky far around you (they turn with the world, not with the screen). */
    private void render3d(GuiGraphics g) {
        double time = System.currentTimeMillis() / 1000.0;
        double cx = Proj.cx, cy = Proj.cy, cz = Proj.cz;
        int K = curtains.i(), N = 20;
        for (int k = 0; k < K; k++) {
            double baseAng = 0.4 + k * 2.2 + 0.08 * Math.sin(time * 0.15 + k);
            for (int i = 0; i <= N; i++) {
                double t = i / (double) N;
                double phi = baseAng + (t - 0.5) * 1.3;
                double rad = 88 + 8 * Math.sin(time * 0.2 + t * 4 + k);
                double x = cx + Math.sin(phi) * rad, z = cz - Math.cos(phi) * rad;
                double bottom = cy + 24 + 5 * Math.sin(time * 0.5 + t * 7 + k * 2);
                double top = bottom + 22 + 10 * Math.sin(time * 0.35 + t * 5 + k);
                double mid = bottom + (top - bottom) * 0.45;
                double hue = 150 + 130 * t + 30 * Math.sin(time * 0.3 + k);
                float a = (float) (opacity.value * (0.65 + 0.35 * Math.sin(time * 0.9 + t * 9 + k)));
                int rgb = 0xFF000000 | Colors.hsv(hue, 0.6, 1.0);
                Proj.line3d(g, x, bottom, z, x, mid, z, 14f, Draw.alpha(rgb, Math.min(1f, a * 1.25f)));
                Proj.line3d(g, x, mid, z, x, top, z, 12f, Draw.alpha(rgb, Math.min(1f, a * 0.4f)));
            }
        }
    }

    public Aurora() {
        super("Aurora", "Shimmering northern lights across the top of your screen.", "VISUALS");
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (threeD.value && mc.player != null) { render3d(g); return; }
        int W = g.guiWidth(), H = g.guiHeight();
        double time = System.currentTimeMillis() / 1000.0;
        int sw = Math.max(1, (W + N - 1) / N);
        for (int i = 0; i < N; i++) {
            double k = i / (double) (N - 1);
            double hh = H * height.value / 100.0 * (0.62 + 0.38 * Math.sin(time * 0.55 + i * 0.55));
            double hue = 150.0 + 140.0 * k + 38.0 * Math.sin(time * 0.35 + i * 0.3);       // green -> teal -> violet -> pink
            float a = (float) (opacity.value * (0.62 + 0.38 * Math.sin(time * 0.9 + i * 0.7)));
            int rgb = Colors.hsv(hue, 0.62, 1.0);
            g.fillGradient(i * sw, 0, Math.min(W, (i + 1) * sw), (int) hh, ((int) (255 * a) << 24) | rgb, rgb);
        }
    }
}
