package dev.tedi.module;

import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Locale;

/** Shows the distance of your last hit ("REACH 2.84M") under the crosshair for a moment. */
public class ReachDisplay extends FxBase {
    private int lastId = -1;
    private float lastHp;
    private long shownAt;
    private double reach;

    public ReachDisplay() {
        super("ReachDisplay", "Shows how far away your last hit was.", "VISUALS");
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null || mc.screen != null) return;
        long now = System.currentTimeMillis();
        Entity e = mc.crosshairPickEntity;
        if (e instanceof LivingEntity le && e != mc.player) {
            float hp = le.getHealth();
            if (le.getId() == lastId && lastHp - hp > 0.05f) {
                Vec3 eye = mc.player.getEyePosition();
                AABB b = le.getBoundingBox();
                double dx = Math.max(b.minX - eye.x, Math.max(0, eye.x - b.maxX));
                double dy = Math.max(b.minY - eye.y, Math.max(0, eye.y - b.maxY));
                double dz = Math.max(b.minZ - eye.z, Math.max(0, eye.z - b.maxZ));
                reach = Math.sqrt(dx * dx + dy * dy + dz * dz);
                shownAt = now;
            }
            lastId = le.getId();
            lastHp = hp;
        }
        float t = (now - shownAt) / 2200f;
        if (shownAt == 0 || t >= 1f) return;
        float a = t < 0.75f ? 1f : 1f - (t - 0.75f) / 0.25f;
        Font f = mc.font;
        String s1 = "REACH", s2 = String.format(Locale.ROOT, "%.2fM", reach);
        int w1 = Draw.w(f, s1), w2 = Draw.w(f, s2);
        int w = 10 + w1 + 7 + w2 + 10, h = 16;
        int x = g.guiWidth() / 2 - w / 2, y = g.guiHeight() / 2 + 24;
        Draw.panel(g, x, y, w, h, 7, Colors.NAVY, Colors.NAVY_BORDER, a);
        Draw.str(g, f, s1, x + 10, y + 4, Draw.alpha(Colors.LABEL, a), true);
        int c = reach > 3.0 ? 0xFFFFE066 : 0xFFFFF8F0;
        Draw.str(g, f, s2, x + 10 + w1 + 7, y + 4, Draw.alpha(c, a), true);
    }
}
