package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Highlights the block you are looking at with a see-through light-blue fill (the block stays visible) and a thin outline. */
public class BlockOutline extends Module {
    public static BlockOutline I;
    public final Setting.Hue color = add(new Setting.Hue("Color", 200, 0.45, 1.0));
    public final Setting.Num opacity = add(new Setting.Num("Fill Opacity", 0.22, 0.05, 0.8, 0.01));
    public final Setting.Bool outline = add(new Setting.Bool("Outline", true));

    public BlockOutline() {
        super("BlockOutline", "Light-blue see-through highlight on the block you look at.", "VISUALS", true);
        I = this;
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.level == null || mc.player == null || mc.screen != null) return;
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        BlockPos p = hit.getBlockPos();
        VoxelShape shape = mc.level.getBlockState(p).getShape(mc.level, p);
        if (shape.isEmpty()) return;
        AABB bb = shape.bounds().move(p).inflate(0.002);
        int col = color.argb();
        Proj.fillBox(g, bb, Draw.alpha(col, (float) opacity.value));
        if (outline.value) Proj.box(g, bb, 1f, Draw.alpha(Colors.lerp(col, 0xFFFFFFFF, 0.3f), 0.95f));
    }
}
