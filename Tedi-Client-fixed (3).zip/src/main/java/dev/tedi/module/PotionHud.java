package dev.tedi.module;

import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.HashMap;
import java.util.Map;

/** Your active potion effects: name, level, time left and a progress line. Drawn by the HUD (move / resize it with T). */
public class PotionHud extends VisualBase {
    public static PotionHud I;
    private static final String[] ROMAN = {"", "", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
    private final Map<String, Integer> maxDur = new HashMap<>();

    public PotionHud() {
        super("PotionHUD", "Shows your active potion effects with timers.", "VISUALS");
        I = this;
    }

    private record Row(String name, String time, float frac, boolean low) {}

    private java.util.List<Row> rows(Minecraft mc) {
        java.util.List<Row> out = new java.util.ArrayList<>();
        if (mc.player != null) {
            for (MobEffectInstance inst : mc.player.getActiveEffects()) {
                if (out.size() >= 8) break;
                String name = inst.getEffect().value().getDisplayName().getString();
                int amp = inst.getAmplifier();
                if (amp > 0) name += " " + (amp + 1 < ROMAN.length ? ROMAN[amp + 1] : String.valueOf(amp + 1));
                boolean inf = inst.isInfiniteDuration();
                int dur = inst.getDuration();
                String time = inf ? "INF" : String.format("%d:%02d", dur / 1200, (dur / 20) % 60);
                int max = Math.max(maxDur.getOrDefault(name, 0), dur);
                maxDur.put(name, max);
                out.add(new Row(name, time, inf ? 1f : (max <= 0 ? 0f : Math.max(0f, Math.min(1f, dur / (float) max))), !inf && dur < 200));
            }
        }
        if (out.isEmpty()) { if (!maxDur.isEmpty()) maxDur.clear(); if (editing(mc)) { out.add(new Row("Speed II", "3:42", 0.62f, false)); out.add(new Row("Absorption", "1:53", 0.45f, false)); } }
        return out;
    }

    private int rowW(Font f, Row r) { return Math.max(96, 9 + Draw.w(f, r.name()) + 14 + Draw.w(f, r.time()) + 9); }

    /** Size of the whole list (for the HUD editor). */
    public int[] measure(Font f, Minecraft mc) {
        int w = 96, n = 0;
        for (Row r : rows(mc)) { w = Math.max(w, rowW(f, r)); n++; }
        return new int[]{w, Math.max(20, n * 23 - 3)};
    }

    public void drawLocal(GuiGraphics g, Minecraft mc, float a) {
        Font f = mc.font;
        int col = color.argb();
        int y = 0;
        for (Row r : rows(mc)) {
            int w = rowW(f, r), h = 20;
            Draw.drop(g, 0, y, w, h, 7, a);
            Draw.panel(g, 0, y, w, h, 7, Colors.NAVY, Colors.NAVY_BORDER, a);
            Draw.str(g, f, r.name(), 9, y + 4, Draw.alpha(Colors.VALUE, a), true);
            int tw = Draw.w(f, r.time());
            Draw.str(g, f, r.time(), w - 9 - tw, y + 4, Draw.alpha(r.low() ? 0xFFFF7A90 : Colors.LABEL, a), true);
            int lx = 9, lw = w - 18;
            g.fill(lx, y + 14, lx + lw, y + 16, Draw.alpha(0x55000000, a));
            g.fillGradient(lx, y + 14, lx + Math.max(1, (int) (lw * r.frac())), y + 16, Draw.alpha(Draw.lighten(col, 0.4f), a), Draw.alpha(col, a));
            y += h + 3;
        }
    }
}
