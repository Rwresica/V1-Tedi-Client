package dev.tedi.module;

import com.mojang.blaze3d.platform.InputConstants;
import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import org.lwjgl.glfw.GLFW;

/** Hold C to zoom in (smoothly), release to zoom back out. */
public class Zoom extends Module {
    public static Zoom I;
    public final Setting.Num zoomFov = add(new Setting.Num("Zoom FOV", 25, 5, 60, 1));
    public final Setting.Bool smooth = add(new Setting.Bool("Smooth", true));
    private float t;
    private long last = System.nanoTime();

    public Zoom() {
        super("Zoom", "Hold C to zoom in.", "MISC", true);
        I = this;
    }

    public static boolean engaged() { return I != null && I.enabled && I.t > 0.002f; }

    /** Blends the normal field of view toward the zoom value. */
    public static int apply(int base) {
        float e = I.t * I.t * (3f - 2f * I.t);
        return Math.max(1, Math.round(base + (I.zoomFov.i() - base) * e));
    }

    @Override
    public void onDisable() { t = 0f; }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        long n = System.nanoTime();
        float dt = Math.min(0.05f, (n - last) / 1e9f);
        last = n;
        boolean hold = mc.screen == null && InputConstants.isKeyDown(mc.getWindow(), GLFW.GLFW_KEY_C);
        float target = hold ? 1f : 0f;
        t += (target - t) * Math.min(1f, dt * (smooth.value ? 11f : 100f));
        if (Math.abs(target - t) < 0.002f) t = target;
    }
}
