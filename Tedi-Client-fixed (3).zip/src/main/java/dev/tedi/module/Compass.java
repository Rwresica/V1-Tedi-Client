package dev.tedi.module;

import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Heading strip (N / E / S / W with ticks and degrees). Drawn by the HUD (move / resize it with T). */
public class Compass extends VisualBase {
    public static Compass I;
    public static final int W = 176, STRIP = 18, H = 30;
    private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    public Compass() {
        super("Compass", "Heading strip with cardinal directions.", "VISUALS");
        I = this;
    }

    public void drawLocal(GuiGraphics g, Minecraft mc, float a) {
        if (mc.player == null) return;
        Font f = mc.font;
        int col = color.argb();
        int cx = W / 2;
        float heading = ((mc.player.getYRot() + 180f) % 360f + 360f) % 360f;     // 0 = north, 90 = east
        float span = 72f, pxPerDeg = (W / 2f - 8f) / span;

        Draw.drop(g, 0, 0, W, STRIP, 8, a);
        Draw.panel(g, 0, 0, W, STRIP, 8, Colors.NAVY, Colors.NAVY_BORDER, a);
        for (int t = 0; t < 360; t += 10) {
            float d = ((t - heading + 540f) % 360f) - 180f;
            if (Math.abs(d) > span) continue;
            int px = cx + Math.round(d * pxPerDeg);
            float fade = 1f - Math.abs(d) / span;
            g.fill(px, STRIP - (t % 30 == 0 ? 7 : 5), px + 1, STRIP - 3, Draw.alpha(0xFFFFFFFF, (0.55f * fade + 0.1f) * a));
        }
        for (int i = 0; i < 8; i++) {
            float d = ((i * 45 - heading + 540f) % 360f) - 180f;
            if (Math.abs(d) > span - 6f) continue;
            int px = cx + Math.round(d * pxPerDeg);
            float fade = 1f - Math.abs(d) / span;
            String s = DIRS[i];
            int c = i % 2 == 0 ? Draw.lighten(col, 0.45f) : Colors.LABEL;
            Draw.str(g, f, s, px - Draw.w(f, s) / 2, 3, Draw.alpha(c, Math.max(0.25f, fade) * a), true);
        }
        g.fill(cx - 2, STRIP - 2, cx + 3, STRIP - 1, Draw.alpha(col, a));
        g.fill(cx - 1, STRIP - 3, cx + 2, STRIP - 2, Draw.alpha(col, a));
        g.fill(cx, STRIP - 4, cx + 1, STRIP - 3, Draw.alpha(col, a));
        String deg = String.valueOf(Math.round(heading) % 360);
        Draw.str(g, f, deg, cx - Draw.w(f, deg) / 2, STRIP + 4, Draw.alpha(Colors.VALUE, 0.95f * a), true);
    }
}
