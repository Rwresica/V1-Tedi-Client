package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayDeque;
import java.util.Iterator;

/** A glowing ribbon that follows you through the world (visible in third person / freecam / when you look back). */
public class Trails extends Module {
    public final Setting.Num style = add(new Setting.Num("Style", 1, 1, 4, 1).labels("Rainbow", "Aurora", "Fire", "My Color"));     // 1 rainbow, 2 aurora, 3 fire, 4 your colour
    public final Setting.Num length = add(new Setting.Num("Length", 45, 15, 120, 1));
    public final Setting.Num width = add(new Setting.Num("Width", 2.8, 1, 6, 0.1));
    public final Setting.Bool glow = add(new Setting.Bool("Glow", false));
    public final Setting.Hue color = add(new Setting.Hue("Color", 262, 0.6, 1.0));

    private final ArrayDeque<double[]> pts = new ArrayDeque<>();

    public Trails() {
        super("Trails", "Glowing ribbon trail behind you.", "VISUALS", true);
    }

    @Override
    public void onDisable() { pts.clear(); }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null) { pts.clear(); return; }
        double x = mc.player.getX(), y = mc.player.getY() + 0.12, z = mc.player.getZ();
        double[] last = pts.peekLast();
        // a new point only every ~0.13 blocks: fewer segments to draw, the same trail length
        if (last == null || (last[0] - x) * (last[0] - x) + (last[1] - y) * (last[1] - y) + (last[2] - z) * (last[2] - z) > 0.017) {
            pts.addLast(new double[]{x, y, z});
        }
        while (pts.size() > length.i()) pts.pollFirst();
    }

    private int pick(int st, float t, int i, int n, double time) {
        switch (st) {
            case 2: return Colors.lerp(0xFF35E0C8, 0xFFB78CFF, (float) (0.5 + 0.5 * Math.sin(time * 0.05 + t * 3.0)));
            case 3: return Colors.lerp(0xFFFF3B30, 0xFFFFD166, t);
            case 4: return color.argb();
            default: return 0xFF000000 | Colors.hsv(time + (n - i) * 5.0, 0.65, 1.0);
        }
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        int n = pts.size();
        if (n < 2) return;
        double time = System.currentTimeMillis() / 18.0;
        int st = style.i(), stride = n > 70 ? 2 : 1;
        double[] prev = null;
        int i = 0;
        for (Iterator<double[]> it = pts.iterator(); it.hasNext(); i++) {
            double[] cur = it.next();
            if (prev == null) { prev = cur; continue; }
            if (i % stride != 0 && i != n - 1) continue;
            float t = i / (float) n;
            int base = pick(st, t, i, n, time);
            float w = width.f() * (0.3f + 0.7f * t);
            if (glow.value) Proj.line3d(g, prev[0], prev[1], prev[2], cur[0], cur[1], cur[2], w * 2.4f, Draw.alpha(base, 0.16f * t));
            Proj.line3d(g, prev[0], prev[1], prev[2], cur[0], cur[1], cur[2], w, Draw.alpha(base, 0.12f + 0.85f * t));
            prev = cur;
        }
    }
}
