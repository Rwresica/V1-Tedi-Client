package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Soft coloured screen edges; they turn into a pulsing red warning when your health is low. */
public class Vignette extends FxBase {
    public final Setting.Hue color = add(new Setting.Hue("Color", 268, 0.7, 1.0));
    public final Setting.Num strength = add(new Setting.Num("Strength", 0.30, 0.05, 0.8, 0.01));
    public final Setting.Bool lowHealth = add(new Setting.Bool("Low Health Pulse", true));

    public Vignette() {
        super("Vignette", "Soft glowing screen edges, red pulse when your health is low.", "VISUALS");
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null) return;
        int W = g.guiWidth(), H = g.guiHeight();
        float low = 0f;
        if (lowHealth.value) {
            float hp = mc.player.getHealth();
            if (hp <= 8f) low = 1f - hp / 8f;
        }
        double time = System.currentTimeMillis() / 1000.0;
        float pulse = (float) (0.5 + 0.5 * Math.sin(time * (4.0 + low * 6.0)));
        float breathe = (float) (0.88 + 0.12 * Math.sin(time * 0.9));
        float a = strength.f() * breathe + low * (0.25f + 0.30f * pulse);
        a = Math.min(0.85f, a);
        int rgb = low > 0f ? lerpRgb(color.rgb(), 0xFF2040, Math.min(1f, low * 1.6f)) : color.rgb();

        int edge = (int) (Math.min(W, H) * 0.24f);
        int top = ((int) (255 * a) << 24) | rgb, none = rgb;
        g.fillGradient(0, 0, W, edge, top, none);
        g.fillGradient(0, H - edge, W, H, none, top);
        int strips = 6, sw = Math.max(1, edge / strips);
        for (int i = 0; i < strips; i++) {
            float k = 1f - i / (float) strips;
            int c = ((int) (255 * a * k * k) << 24) | rgb;
            g.fill(i * sw, 0, (i + 1) * sw, H, c);
            g.fill(W - (i + 1) * sw, 0, W - i * sw, H, c);
        }
    }

    private static int lerpRgb(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }
}
