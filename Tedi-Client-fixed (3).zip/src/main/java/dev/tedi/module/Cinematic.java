package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Black movie bars that slide in from the top and bottom of the screen. */
public class Cinematic extends FxBase {
    public final Setting.Num size = add(new Setting.Num("Bar Height %", 11, 4, 25, 1));
    private float t;

    public Cinematic() {
        super("Cinematic", "Movie-style black bars that slide in.", "VISUALS");
    }

    @Override
    public void onEnable() { t = 0f; }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        t = approach(t, 1f, 5f, dt());
        float e = Draw.easeOut(Math.min(1f, t));
        int W = g.guiWidth(), H = g.guiHeight();
        int bar = (int) (H * size.value / 100.0 * e);
        if (bar <= 0) return;
        g.fill(0, 0, W, bar, 0xFF000000);
        g.fill(0, H - bar, W, H, 0xFF000000);
        g.fillGradient(0, bar, W, bar + 8, 0x66000000, 0x00000000);
        g.fillGradient(0, H - bar - 8, W, H - bar, 0x00000000, 0x66000000);
    }
}
