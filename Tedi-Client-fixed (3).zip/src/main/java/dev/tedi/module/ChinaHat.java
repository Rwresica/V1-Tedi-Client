package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import dev.tedi.util.Ring;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** A glowing cone hat over your head (you see it in third person / freecam). */
public class ChinaHat extends Module {
    public final Setting.Bool rainbow = add(new Setting.Bool("Rainbow", true));
    public final Setting.Hue color = add(new Setting.Hue("Color", 270, 0.6, 1.0));
    public final Setting.Num size = add(new Setting.Num("Size", 1.0, 0.6, 1.8, 0.05));

    public ChinaHat() {
        super("ChinaHat", "Glowing cone hat above your head (third person).", "VISUALS", true);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null) return;
        if (mc.options.getCameraType().isFirstPerson() && !Freecam.active()) return;
        double time = System.currentTimeMillis() / 1000.0;
        double s = size.value;
        double x = mc.player.getX(), z = mc.player.getZ();
        double yBase = mc.player.getY() + mc.player.getBbHeight() + 0.04;
        double yTip = yBase + 0.42 * s, r = 0.52 * s;
        int segs = 14;
        double spin = time * 0.9;
        Ring.draw(g, x, yBase, z, r, segs, spin, 2.4f, (i, n) -> hue(i, n, time, 0.9f));
        for (int i = 0; i < segs; i += 2) {                                    // ribs from the rim up to the tip
            double a = spin + i * Math.PI * 2.0 / segs;
            Proj.line3d(g, x + Math.cos(a) * r, yBase, z + Math.sin(a) * r, x, yTip, z, 1.6f, hue(i, segs, time, 0.6f));
        }
    }

    private int hue(int i, int n, double time, float alpha) {
        if (rainbow.value) return Draw.alpha(0xFF000000 | Colors.hsv(time * 80.0 + i * 360.0 / n, 0.65, 1.0), alpha);
        return Draw.alpha(color.argb(), alpha);
    }
}
