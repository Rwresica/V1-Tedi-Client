package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** An X flashes around the crosshair when the target loses health, and the damage floats up as a number. */
public class HitMarker extends Module {
    public final Setting.Hue color = add(new Setting.Hue("Color", 0, 0.0, 1.0));
    public final Setting.Bool numbers = add(new Setting.Bool("Damage Numbers", true));

    private static final class Pop {
        final double x, y, z; final float amount; final long born; final boolean kill;
        Pop(double x, double y, double z, float amount, long born, boolean kill) { this.x = x; this.y = y; this.z = z; this.amount = amount; this.born = born; this.kill = kill; }
    }

    private final List<Pop> pops = new ArrayList<>();
    private int lastId = -1;
    private float lastHp;
    private long hitAt;
    private boolean killHit;

    public HitMarker() {
        super("HitMarker", "X on your crosshair + floating damage numbers when you hurt something.", "VISUALS", true);
    }

    @Override
    public void onDisable() { pops.clear(); lastId = -1; }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null) return;
        long now = System.currentTimeMillis();
        Entity e = mc.crosshairPickEntity;
        if (e instanceof LivingEntity le && e != mc.player) {
            float hp = le.getHealth();
            if (le.getId() == lastId && lastHp - hp > 0.05f) {
                hitAt = now;
                killHit = hp <= 0.01f;
                if (numbers.value) {
                    pops.add(new Pop(le.getX(), le.getY() + le.getBbHeight() * 0.75, le.getZ(), lastHp - hp, now, killHit));
                    if (pops.size() > 12) pops.remove(0);
                }
            }
            lastId = le.getId();
            lastHp = hp;
        }

        int W = g.guiWidth(), H = g.guiHeight();
        float t = (now - hitAt) / (killHit ? 480f : 320f);
        if (t >= 0f && t < 1f) {
            float a = 1f - t;
            float gap = 4f + (killHit ? 8f : 5f) * Draw.easeOut(t), len = killHit ? 9f : 6f;
            double cx = W / 2.0, cy = H / 2.0;
            int c = Draw.alpha(killHit ? 0xFFFF4D6D : (0xFF000000 | color.rgb()), a);
            int sh = Draw.alpha(0xFF000000, a * 0.55f);
            for (int pass = 0; pass < 2; pass++) {
                for (int sx = -1; sx <= 1; sx += 2) {
                    for (int sy = -1; sy <= 1; sy += 2) {
                        Proj.line(g, cx + sx * gap, cy + sy * gap, cx + sx * (gap + len), cy + sy * (gap + len), pass == 0 ? 4f : 2f, pass == 0 ? sh : c);
                    }
                }
            }
        }

        if (pops.isEmpty()) return;
        Font f = mc.font;
        for (int i = pops.size() - 1; i >= 0; i--) {
            Pop p = pops.get(i);
            float age = (now - p.born) / 1000f;
            if (age > 1.1f) { pops.remove(i); continue; }
            if (!Proj.project(p.x, p.y + Draw.easeOut(Math.min(1f, age * 1.3f)) * 0.9, p.z)) continue;
            String s = "-" + (p.amount >= 10f ? String.valueOf(Math.round(p.amount)) : String.format(Locale.ROOT, "%.1f", p.amount));
            float a = Math.max(0f, 1f - age * age * 0.85f);
            int c = p.kill ? Colors.lerp(0xFFFF9AA8, 0xFFFF2D55, Math.min(1f, age * 1.2f)) : Colors.lerp(0xFFFFE08A, 0xFFFF7A59, Math.min(1f, age * 1.2f));
            int x = (int) Proj.px - Draw.w(f, s) / 2, y = (int) Proj.py - 4;
            Draw.str(g, f, s, x, y, Draw.alpha(c, a), true);
        }
    }
}
