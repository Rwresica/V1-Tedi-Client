package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.Random;

/**
 * Changes the colours of the Minecraft sky (and clouds + fog), and adds twinkling stars and shooting stars in the sky.
 * The sky blends horizon -> middle -> top while you look up, like the reference photos.
 */
public class SkyChanger extends Module {
    public static SkyChanger I;
    public final Setting.Num sky = add(new Setting.Num("Sky", 1, 1, 4, 1).labels("Galaxy", "Nebula Rose", "Cotton Clouds", "Aurora"));
    public final Setting.Bool stars = add(new Setting.Bool("Stars", true));
    public final Setting.Bool shooting = add(new Setting.Bool("Shooting Stars", true));

    //                    top,      middle,   horizon,  clouds
    private static final int[][] PRESETS = {
        {0x1A0640, 0x5B28C8, 0xB04AE6, 0xC9A6FF},   // 1 galaxy: deep violet space, violet, magenta glow
        {0x2E0C52, 0xA3239A, 0xFF4FD2, 0xFFAEEA},   // 2 nebula rose: dark plum, berry, hot pink
        {0x3FA4EE, 0x8CC8F0, 0xFFC2D9, 0xFFF1F7},   // 3 cotton clouds: sky blue, pale blue, peach pink
        {0x2B63E8, 0x36E0CF, 0xE9B2F0, 0xCDBBFF},   // 4 aurora: blue, teal glow, lilac
    };

    private static final int STARS = 70;
    private final double[] sx = new double[STARS], sy = new double[STARS], sz = new double[STARS], sph = new double[STARS];
    private final Random rnd = new Random(7);
    // one shooting star at a time
    private double[] dir0 = new double[3], vel = new double[3];
    private long shotStart, nextShot;

    public SkyChanger() {
        super("SkyChanger", "Pretty skies (Galaxy, Nebula Rose, Cotton Clouds, Aurora) with stars and shooting stars.", "VISUALS", true);
        I = this;
        for (int i = 0; i < STARS; i++) {                      // fixed star directions on the upper sky
            double a = rnd.nextDouble() * Math.PI * 2, e = 0.28 + rnd.nextDouble() * 1.25;
            sx[i] = Math.cos(a) * Math.cos(e); sy[i] = Math.sin(e); sz[i] = Math.sin(a) * Math.cos(e);
            sph[i] = rnd.nextDouble() * 6.28;
        }
    }

    public static boolean active() { return I != null && I.enabled; }

    private int[] preset() { return PRESETS[Math.max(0, Math.min(PRESETS.length - 1, sky.i() - 1))]; }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Sky colour, blended horizon -> middle -> top by how far up the player looks. */
    public static int skyColor() {
        Minecraft mc = Minecraft.getInstance();
        float u = mc.player == null ? 0.5f : Math.max(0f, Math.min(1f, -mc.player.getXRot() / 65f + 0.3f));
        u = u * u * (3f - 2f * u);
        int[] p = I.preset();
        return u < 0.5f ? mix(p[2], p[1], u * 2f) : mix(p[1], p[0], (u - 0.5f) * 2f);
    }

    public static int cloudColor() { return 0xFF000000 | I.preset()[3]; }

    /** Fog = the horizon colour, so the ground fades into the sky instead of into grey. */
    public static int fogColor() { return 0xFF000000 | I.preset()[2]; }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null || mc.screen != null) return;
        boolean night = sky.i() != 3;                          // pastel day sky has no stars
        long now = System.currentTimeMillis();
        double time = now / 1000.0;
        int W = g.guiWidth(), H = g.guiHeight();
        double cx = Proj.cx, cy = Proj.cy, cz = Proj.cz;
        if (stars.value && night) {
            for (int i = 0; i < STARS; i++) {
                if (!Proj.project(cx + sx[i] * 80, cy + sy[i] * 80, cz + sz[i] * 80)) continue;
                int x = (int) Proj.px, y = (int) Proj.py;
                if (x < 0 || x >= W || y < 0 || y >= H) continue;
                float tw = (float) (0.35 + 0.65 * Math.abs(Math.sin(time * (0.7 + (i % 5) * 0.2) + sph[i])));
                int c = ((int) (235 * tw) << 24) | (i % 4 == 0 ? 0xCFE3FF : i % 7 == 0 ? 0xFFD6F5 : 0xFFFFFF);
                int s = i % 6 == 0 ? 2 : 1;
                g.fill(x, y, x + s, y + s, c);
                if (s == 2 && tw > 0.85f) {
                    int cc = ((int) (110 * tw) << 24) | 0xFFFFFF;
                    g.fill(x - 2, y, x, y + 1, cc); g.fill(x + 2, y, x + 4, y + 1, cc); g.fill(x, y - 2, x + 1, y, cc); g.fill(x, y + 2, x + 1, y + 4, cc);
                }
            }
        }
        if (shooting.value && night) {
            if (nextShot == 0) nextShot = now + 1500;
            if (now >= nextShot && now - shotStart > 900) {    // launch a new streak
                double a = rnd.nextDouble() * Math.PI * 2, e = 0.45 + rnd.nextDouble() * 0.8;
                dir0 = new double[]{Math.cos(a) * Math.cos(e), Math.sin(e), Math.sin(a) * Math.cos(e)};
                double b = rnd.nextDouble() * Math.PI * 2;
                vel = new double[]{Math.cos(b) * 1.6, -0.9 - rnd.nextDouble() * 0.5, Math.sin(b) * 1.6};
                shotStart = now;
                nextShot = now + 2200 + rnd.nextInt(3500);
            }
            double age = (now - shotStart) / 650.0;
            if (age >= 0 && age < 1.0) {
                int tail = Colors.lerp(0xFFB78CFF, 0xFFFFFFFF, 0.5f);
                double px = 0, py = 0; boolean havePrev = false;
                for (int k = 0; k <= 6; k++) {                  // head first, tail behind it, fading out
                    double t = age * 0.5 - k * 0.035;
                    if (t < 0) break;
                    double dx = dir0[0] + vel[0] * t * 0.4, dy = dir0[1] + vel[1] * t * 0.4, dz = dir0[2] + vel[2] * t * 0.4;
                    double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    dx = dx / len * 80; dy = dy / len * 80; dz = dz / len * 80;
                    if (!Proj.project(cx + dx, cy + dy, cz + dz)) { havePrev = false; continue; }
                    double x = Proj.px, y = Proj.py;
                    if (havePrev) {
                        float f = (float) (1.0 - k / 7.0) * (float) Math.sin(Math.min(1.0, age * 1.1) * Math.PI);
                        Proj.line(g, px, py, x, y, 2.6f * (1f - k / 8f), Draw.alpha(k == 1 ? 0xFFFFFFFF : tail, f));
                    }
                    px = x; py = y; havePrev = true;
                }
            }
        }
    }
}
