package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.Random;

/**
 * Ambient particles: snow, stars, embers, sakura petals or fireflies.
 * 3D on: they live in the world around you (parallax when you move, closer = bigger). 3D off: flat overlay on the screen.
 */
public class Particles extends FxBase {
    public final Setting.Num mode = add(new Setting.Num("Style", 1, 1, 5, 1).labels("Snow", "Stars", "Embers", "Sakura", "Fireflies"));
    public final Setting.Bool threeD = add(new Setting.Bool("3D", true));
    public final Setting.Num amount = add(new Setting.Num("Amount", 50, 10, 100, 1));

    private static final int MAX = 100;
    private static final double RAD = 13.0;                       // half-size of the 3D box around you
    private final float[] x = new float[MAX], y = new float[MAX], sp = new float[MAX], ph = new float[MAX], sz = new float[MAX];
    private final double[] wx = new double[MAX], wy = new double[MAX], wz = new double[MAX];
    private final Random rnd = new Random();
    private boolean init;
    private int lastMode = -1;
    private boolean last3d;

    public Particles() {
        super("Particles", "Snow, stars, embers, sakura or fireflies - in 3D around you or flat on the screen.", "VISUALS");
    }

    private void spawn2d(int i, int W, int H, boolean anywhere) {
        int m = mode.i();
        x[i] = rnd.nextFloat() * W;
        y[i] = anywhere ? rnd.nextFloat() * H : (m == 3 ? H + 4 : -4);
        sp[i] = 16f + rnd.nextFloat() * 28f;
        ph[i] = rnd.nextFloat() * 6.28f;
        sz[i] = 1f + rnd.nextInt(3) * 0.5f;
    }

    private void spawn3d(int i) {
        ph[i] = rnd.nextFloat() * 6.28f;
        sp[i] = 16f + rnd.nextFloat() * 28f;
        sz[i] = 1f + rnd.nextInt(3) * 0.5f;
        if (mode.i() == 2) {                                        // stars: a direction on the upper sky
            double a = rnd.nextDouble() * Math.PI * 2, e = 0.12 + rnd.nextDouble() * 1.3;
            wx[i] = Math.cos(a) * Math.cos(e); wy[i] = Math.sin(e); wz[i] = Math.sin(a) * Math.cos(e);
        } else {
            wx[i] = Proj.cx + (rnd.nextDouble() * 2 - 1) * RAD;
            wy[i] = Proj.cy + (rnd.nextDouble() * 2 - 1) * 9;
            wz[i] = Proj.cz + (rnd.nextDouble() * 2 - 1) * RAD;
        }
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        int W = g.guiWidth(), H = g.guiHeight();
        int m = mode.i();
        boolean d3 = threeD.value && mc.player != null;
        if (!init || m != lastMode || d3 != last3d) {
            for (int i = 0; i < MAX; i++) { if (d3) spawn3d(i); else spawn2d(i, W, H, true); }
            init = true; lastMode = m; last3d = d3;
        }
        float dt = dt();
        double time = System.currentTimeMillis() / 1000.0;
        int n = Math.min(MAX, amount.i());
        if (d3) render3d(g, m, n, dt, time, W, H); else render2d(g, m, n, dt, time, W, H);
    }

    private void render3d(GuiGraphics g, int m, int n, float dt, double time, int W, int H) {
        double cx = Proj.cx, cy = Proj.cy, cz = Proj.cz;
        for (int i = 0; i < n; i++) {
            double px3, py3, pz3;
            float alphaMul = 1f;
            if (m == 2) {                                           // stars: fixed on a far dome around you
                px3 = cx + wx[i] * 70; py3 = cy + wy[i] * 70; pz3 = cz + wz[i] * 70;
                alphaMul = (float) (0.35 + 0.65 * Math.abs(Math.sin(time * (0.8 + sp[i] / 40.0) + ph[i])));
            } else {
                double fall = 1.0 + sp[i] / 22.0;
                if (m == 1) { wy[i] -= fall * dt; wx[i] += Math.sin(time * 0.8 + ph[i]) * 0.35 * dt; }
                else if (m == 3) { wy[i] += fall * 0.9 * dt; wx[i] += Math.sin(time * 1.4 + ph[i]) * 0.5 * dt; }
                else if (m == 4) { wy[i] -= fall * 0.45 * dt; wx[i] += (0.5 + Math.sin(time * 1.3 + ph[i]) * 0.6) * dt; }
                else { wx[i] += Math.sin(time * 0.7 + ph[i] * 2) * 0.5 * dt; wy[i] += Math.cos(time * 0.6 + ph[i]) * 0.35 * dt; wz[i] += Math.cos(time * 0.5 + ph[i]) * 0.4 * dt; }
                if (wx[i] - cx > RAD) wx[i] -= 2 * RAD; else if (wx[i] - cx < -RAD) wx[i] += 2 * RAD;
                if (wz[i] - cz > RAD) wz[i] -= 2 * RAD; else if (wz[i] - cz < -RAD) wz[i] += 2 * RAD;
                if (wy[i] - cy > 9) wy[i] -= 18; else if (wy[i] - cy < -9) wy[i] += 18;
                px3 = wx[i]; py3 = wy[i]; pz3 = wz[i];
            }
            if (!Proj.project(px3, py3, pz3)) continue;
            int sx = (int) Proj.px, sy = (int) Proj.py;
            if (sx < 0 || sx >= W || sy < 0 || sy >= H) continue;
            double dx = px3 - cx, dy = py3 - cy, dz = pz3 - cz;
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            int s = m == 2 ? (sz[i] > 1.5f ? 2 : 1) : (d < 2.2 ? 5 : d < 4 ? 4 : d < 7 ? 3 : d < 12 ? 2 : 1);   // closer = bigger
            if (m != 1) s = Math.min(s, 3);
            if (d < 1.0) alphaMul *= (float) d;
            drawParticle(g, m, i, sx, sy, s, alphaMul, time, (float) d);
        }
    }

    private void render2d(GuiGraphics g, int m, int n, float dt, double time, int W, int H) {
        for (int i = 0; i < n; i++) {
            int size = Math.max(1, Math.round(sz[i]));
            float alphaMul = 1f;
            if (m == 1) { y[i] += sp[i] * dt; x[i] += (float) Math.sin(time * 0.9 + ph[i]) * 10f * dt; if (y[i] > H + 4) spawn2d(i, W, H, false); }
            else if (m == 2) { alphaMul = (float) (0.35 + 0.65 * Math.abs(Math.sin(time * (0.8 + sp[i] / 40.0) + ph[i]))); }
            else if (m == 3) { y[i] -= sp[i] * dt * 1.2f; x[i] += (float) Math.sin(time * 1.4 + ph[i]) * 14f * dt; if (y[i] < -4) spawn2d(i, W, H, false); }
            else if (m == 4) {
                y[i] += sp[i] * dt * 0.7f; x[i] += (14f + (float) Math.sin(time * 1.3 + ph[i]) * 16f) * dt;
                if (y[i] > H + 4 || x[i] > W + 6) { spawn2d(i, W, H, false); x[i] = rnd.nextFloat() * W * 0.8f; }
            } else { x[i] += (float) Math.sin(time * 0.7 + ph[i] * 2) * 9f * dt; y[i] += (float) Math.cos(time * 0.6 + ph[i]) * 9f * dt; }
            drawParticle(g, m, i, (int) x[i], (int) y[i], size, alphaMul, time, 99f);
        }
    }

    /** d = distance to you in blocks (3D) or 99 for the flat 2D overlay. */
    private void drawParticle(GuiGraphics g, int m, int i, int px, int py, int s, float a, double time, float d) {
        boolean d3 = d < 90f;
        if (d3 && m != 2) a *= (float) Math.max(0.35, Math.min(1.0, 1.25 - d / 15.0));      // far = fainter (depth fog)
        if (m == 1) {
            if (!d3) { g.fill(px, py, px + s, py + s, ((int) (204 * a) << 24) | 0xFFFFFF); return; }
            if (d < 1.8f) {                                          // very close: big soft out-of-focus flake
                int c = ((int) (46 * a) << 24) | 0xFFFFFF;
                g.fill(px - 2, py - 3, px + 3, py + 4, c);
                g.fill(px - 3, py - 2, px + 4, py + 3, c);
                g.fill(px - 1, py - 1, px + 2, py + 2, ((int) (120 * a) << 24) | 0xFFFFFF);
            } else if (s >= 3) {                                     // near: glowing flake with a highlight
                int halo = ((int) (46 * a) << 24) | 0xDCEBFF;
                g.fill(px - 1, py, px + s + 1, py + s, halo);
                g.fill(px, py - 1, px + s, py + s + 1, halo);
                g.fill(px, py, px + s, py + s, ((int) (235 * a) << 24) | 0xFFFFFF);
                g.fill(px, py, px + 1, py + 1, 0xFFFFFFFF);
            } else if (s == 2) {
                g.fill(px, py, px + 2, py + 2, ((int) (215 * a) << 24) | 0xF4F8FF);
            } else {
                g.fill(px, py, px + 1, py + 1, ((int) (170 * a) << 24) | 0xE6EEFF);
            }
        } else if (m == 2) {
            g.fill(px, py, px + s, py + s, ((int) (230 * a) << 24) | (i % 3 == 0 ? 0xCFE3FF : 0xFFFFFF));
            if (s > 1 && a > 0.8f) {                                  // sparkle cross on the brightest ones
                int cc = ((int) (120 * a) << 24) | 0xFFFFFF;
                g.fill(px - 2, py, px, py + 1, cc); g.fill(px + s, py, px + s + 2, py + 1, cc);
                g.fill(px, py - 2, px + 1, py, cc); g.fill(px, py + s, px + 1, py + s + 2, cc);
            }
        } else if (m == 3) {
            float fl = (float) (0.55 + 0.45 * Math.sin(time * 9 + ph[i] * 3));
            int c = (i % 2 == 0 ? 0xFF9A3C : 0xFFD166);
            if (d3 && s >= 3) { int h = ((int) (40 * fl * a) << 24) | c; g.fill(px - 1, py - 1, px + s + 1, py + s + 1, h); }
            g.fill(px, py, px + s, py + s, ((int) (235 * fl * a) << 24) | c);
        } else if (m == 4) {
            int c = ((int) (230 * a) << 24) | (i % 2 == 0 ? 0xFFB7D5 : 0xFF8FB8);
            int c2 = ((int) (230 * a) << 24) | 0xFFE3EE;
            g.fill(px, py, px + s + 1, py + s, c);
            g.fill(px + 1, py - 1, px + s, py, c);
            if (d3 && s >= 3) g.fill(px + 1, py + 1, px + s - 1, py + 2, c2);   // lighter vein on big petals
        } else {
            float pu = (float) (0.5 + 0.5 * Math.sin(time * 1.8 + ph[i] * 4));
            int big = d3 ? Math.min(3, Math.max(1, s - 1)) : 1;
            int halo = ((int) (30 * pu * a) << 24) | 0xC8FF6B;
            g.fill(px - big, py - big - 1, px + big + 1, py + big + 2, halo);
            g.fill(px - big - 1, py - big, px + big + 2, py + big + 1, halo);
            g.fill(px, py, px + Math.min(2, Math.max(1, s - 1)), py + Math.min(2, Math.max(1, s - 1)), ((int) (255 * (0.4 + 0.6 * pu) * a) << 24) | 0xF4FFB0);
        }
    }
}
