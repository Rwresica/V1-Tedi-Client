package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Makes the HUD colour cycle through the rainbow (your colour comes back when you turn it off). */
public class RgbTheme extends Module {
    public final Setting.Num speed = add(new Setting.Num("Speed", 40, 5, 200, 1));
    private double original = -1;

    public RgbTheme() {
        super("RGBTheme", "HUD accent colour cycles through the rainbow.", "VISUALS", true);
    }

    @Override
    public void onEnable() { if (Hud.I != null) original = Hud.I.color.hue; }

    @Override
    public void onDisable() { if (Hud.I != null && original >= 0) Hud.I.color.hue = original; original = -1; }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (Hud.I == null) return;
        if (original < 0) original = Hud.I.color.hue;
        Hud.I.color.hue = (System.currentTimeMillis() * speed.value / 1000.0) % 360.0;
    }
}
