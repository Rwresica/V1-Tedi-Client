package dev.tedi.module;

import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.Items;

import java.util.Locale;

/** While you hold a mace: how far you have fallen and the smash damage you would deal, plus a ready marker. */
public class MaceInfo extends FxBase {
    private float shown;

    public MaceInfo() {
        super("MaceInfo", "Fall distance and expected smash damage while holding a mace.", "VISUALS");
    }

    /** Vanilla mace formula: 6 base + 4/block for the first 3 blocks, 2/block up to 8, then 1/block. */
    private static double smash(double fall) {
        double bonus = fall <= 3 ? 4 * fall : fall <= 8 ? 12 + 2 * (fall - 3) : 22 + (fall - 8);
        return 6 + Math.max(0, bonus);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.screen != null) return;
        float dt = dt();
        boolean holding = mc.player.getMainHandItem().is(Items.MACE);
        double fall = mc.player.fallDistance;
        shown = approach(shown, holding ? 1f : 0f, 10f, dt);
        if (shown < 0.03f) return;
        Font f = mc.font;
        float a = shown;
        boolean ready = fall > 1.5 && mc.player.getAttackStrengthScale(0f) >= 0.99f;
        String s1 = "MACE", s2 = String.format(Locale.ROOT, "%.1f DMG", smash(Math.max(0, fall))), s3 = String.format(Locale.ROOT, "%.1fM", Math.max(0, fall));
        int w1 = Draw.w(f, s1), w2 = Draw.w(f, s2), w3 = Draw.w(f, s3);
        int w = 12 + w1 + 8 + w2 + 8 + w3 + 10, h = 18;
        int x = g.guiWidth() / 2 - w / 2, y = g.guiHeight() / 2 + 46;
        Draw.drop(g, x, y, w, h, 8, a);
        Draw.panel(g, x, y, w, h, 8, Colors.NAVY, Colors.NAVY_BORDER, a);
        g.fill(x + 6, y + 5, x + 8, y + h - 5, Draw.alpha(ready ? 0xFF6BEA9A : 0xFF8A819F, a));       // green marker when a smash is worth it
        Draw.str(g, f, s1, x + 12, y + 5, Draw.alpha(Colors.LABEL, a), true);
        Draw.str(g, f, s2, x + 12 + w1 + 8, y + 5, Draw.alpha(ready ? 0xFF6BEA9A : Colors.VALUE, a), true);
        Draw.str(g, f, s3, x + 12 + w1 + 8 + w2 + 8, y + 5, Draw.alpha(Colors.LABEL, a), false);
    }
}
