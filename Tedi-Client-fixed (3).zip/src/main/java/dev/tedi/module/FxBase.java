package dev.tedi.module;

/** Small helper for the screen-effect modules: a frame timer and smoothing. */
public abstract class FxBase extends Module {
    private long lastNano = System.nanoTime();

    protected FxBase(String name, String description, String category) {
        super(name, description, category, true);
    }

    protected float dt() {
        long n = System.nanoTime();
        float d = Math.min(0.05f, (n - lastNano) / 1e9f);
        lastNano = n;
        return d;
    }

    protected static float approach(float cur, float target, float speed, float dt) {
        return cur + (target - cur) * Math.min(1f, dt * speed);
    }
}
