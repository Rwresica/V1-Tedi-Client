package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** A slim bar under the crosshair that fills while your weapon recharges (swing when it is full). */
public class AttackCooldown extends FxBase {
    public final Setting.Hue color = add(new Setting.Hue("Color", 262, 0.5, 1.0));
    public final Setting.Bool alwaysShow = add(new Setting.Bool("Always Visible", false));
    private float shown;

    public AttackCooldown() {
        super("AttackCooldown", "Recharge bar under the crosshair - swing when it is full.", "VISUALS");
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.screen != null) return;
        float dt = dt();
        float v = Math.max(0f, Math.min(1f, mc.player.getAttackStrengthScale(0f)));
        shown = approach(shown, v < 0.999f || alwaysShow.value ? 1f : 0f, 12f, dt);
        if (shown < 0.03f) return;
        int W = g.guiWidth(), H = g.guiHeight();
        int w = 34, h = 4, x = W / 2 - w / 2, y = H / 2 + 13;
        float a = shown;
        int col = color.argb();
        Draw.roundR(g, x - 1, y - 1, w + 2, h + 2, 3, Draw.alpha(0xAA0C0A2A, a), false);
        int fw = Math.max(h, (int) (w * v));
        int c = v >= 0.999f ? 0xFFFFF8F0 : Colors.lerp(Draw.lighten(col, 0.1f), Draw.lighten(col, 0.55f), v);
        Draw.roundG(g, x, y, fw, h, 2, Draw.alpha(Draw.lighten(c, 0.3f), a), Draw.alpha(c, a), false);
    }
}
