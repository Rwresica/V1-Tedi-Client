package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.Vec3;

/** Anime-style streaks rush past the edges of the screen when you move fast (sprinting, elytra, falling). */
public class SpeedLines extends FxBase {
    public final Setting.Num threshold = add(new Setting.Num("Min Speed (b/s)", 9, 4, 30, 1));
    public final Setting.Hue color = add(new Setting.Hue("Color", 255, 0.18, 1.0));
    private static final int N = 18;
    private float intensity;

    public SpeedLines() {
        super("SpeedLines", "Speed streaks at the screen edges when you move fast.", "VISUALS");
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.screen != null) return;
        float dt = dt();
        Vec3 v = mc.player.getDeltaMovement();
        double speed = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z) * 20.0;
        float target = (float) Math.max(0.0, Math.min(1.0, (speed - threshold.value) / Math.max(4.0, threshold.value)));
        intensity = approach(intensity, target, 6f, dt);
        if (intensity < 0.03f) return;
        int W = g.guiWidth(), H = g.guiHeight();
        double cx = W / 2.0, cy = H / 2.0;
        double time = System.currentTimeMillis() / 1000.0;
        int base = color.argb();
        for (int i = 0; i < N; i++) {
            double ang = i * 2.39996;                                         // golden angle: even spread
            double ph = (time * (1.1 + (i % 5) * 0.18) + i * 0.37) % 1.0;
            double r0 = 0.52 + ph * 0.5, r1 = r0 + 0.10 + 0.08 * (i % 3);
            double ca = Math.cos(ang), sa = Math.sin(ang);
            float a = (float) (Math.sin(ph * Math.PI) * intensity * 0.75);
            Proj.line(g, cx + ca * r0 * W * 0.62, cy + sa * r0 * H * 0.62, cx + ca * r1 * W * 0.62, cy + sa * r1 * H * 0.62, 1.4f, Draw.alpha(base, a));
        }
    }
}
