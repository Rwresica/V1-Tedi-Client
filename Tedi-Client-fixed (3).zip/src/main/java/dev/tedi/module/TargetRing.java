package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Ring;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/** A glowing ring that glides up and down around the entity you look at. */
public class TargetRing extends FxBase {
    public final Setting.Bool rainbow = add(new Setting.Bool("Rainbow", false));
    public final Setting.Hue color = add(new Setting.Hue("Color", 262, 0.6, 1.0));
    public final Setting.Hue color2 = add(new Setting.Hue("Second Color", 320, 0.6, 1.0));

    private LivingEntity target;
    private long lastSeen;
    private float alpha;

    public TargetRing() {
        super("TargetRing", "Glowing ring that glides around your target.", "VISUALS");
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        if (mc.player == null || mc.level == null) return;
        float dt = dt();
        long now = System.currentTimeMillis();
        Entity e = mc.crosshairPickEntity;
        if (e instanceof LivingEntity le && e != mc.player && le.isAlive()) { target = le; lastSeen = now; }
        if (target == null) return;
        boolean show = target.isAlive() && now - lastSeen < 1200;
        alpha = approach(alpha, show ? 1f : 0f, 9f, dt);
        if (alpha < 0.02f) { if (!show) target = null; return; }

        double time = now / 1000.0;
        double h = target.getBbHeight(), r = target.getBbWidth() * 0.78 + 0.12;
        double base = target.getY();
        double ph = 0.5 + 0.5 * Math.sin(time * 2.4);
        float a = alpha;
        for (int k = 0; k < 3; k++) {                                         // main ring + two fading ghosts
            double y = base + h * Math.max(0.0, Math.min(1.0, ph - k * 0.07 * Math.signum(Math.cos(time * 2.4))));
            float ka = a * (k == 0 ? 1f : k == 1 ? 0.42f : 0.2f);
            final double tt = time;
            Ring.draw(g, target.getX(), y, target.getZ(), r, 18, time * 1.6, k == 0 ? 2.6f : 2f, (i, n) -> {
                if (rainbow.value) return Draw.alpha(0xFF000000 | Colors.hsv(tt * 90.0 + i * 360.0 / n, 0.7, 1.0), ka);
                float f = (float) (0.5 + 0.5 * Math.sin(i * 6.2832 / n + tt * 2.0));
                return Draw.alpha(Colors.lerp(color.argb(), color2.argb(), f), ka);
            });
        }
    }
}
