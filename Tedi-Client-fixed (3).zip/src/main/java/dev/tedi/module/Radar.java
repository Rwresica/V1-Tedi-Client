package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Draw;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;

/** Round radar: nearby players as dots, you are in the centre and "up" is where you look. */
public class Radar extends VisualBase {
    public static Radar I;
    public final Setting.Num range = add(new Setting.Num("Range", 48, 16, 128, 1));
    public final Setting.Num size = add(new Setting.Num("Size", 72, 50, 110, 2));

    public Radar() {
        super("Radar", "Round radar with nearby players.", "VISUALS");
        I = this;
    }

    /** Diameter in pixels, used by the HUD to place and measure the radar. */
    public int sizePx() { return (int) size.value; }

    /** Draws at (0,0) of the current transform (the HUD places it; move / resize it with T). */
    public void drawLocal(GuiGraphics g, Minecraft mc, float a0) {
        if (mc.player == null || mc.level == null) return;
        Font f = mc.font;
        int R = sizePx();
        int x = 0;
        int y = 0;
        int cx = x + R / 2, cy = y + R / 2;
        int col = color.argb();
        double rng = range.value;
        float inner = R / 2f - 5f;

        Draw.panel(g, x, y, R, R, R / 2, Colors.NAVY, Colors.NAVY_BORDER, 0.94f * a0);
        g.fill(cx, y + 7, cx + 1, y + R - 7, 0x26FFFFFF);
        g.fill(x + 7, cy, x + R - 7, cy + 1, 0x26FFFFFF);

        double yaw = Math.toRadians(mc.player.getYRot());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);

        // compass letters (they rotate with you)
        String[] dirName = {"N", "E", "S", "W"};
        int[][] dirVec = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};
        for (int k = 0; k < 4; k++) {
            double ca = dirVec[k][0] * -cos + dirVec[k][1] * -sin;     // right of you
            double cb = dirVec[k][0] * -sin + dirVec[k][1] * cos;      // in front of you
            int nx = cx + (int) Math.round(ca * (R / 2.0 - 8)), ny = cy - (int) Math.round(cb * (R / 2.0 - 8));
            int lc = k == 0 ? 0xFFFF7A90 : Draw.lighten(col, 0.4f);
            Draw.str(g, f, dirName[k], nx - Draw.w(f, dirName[k]) / 2, ny - 3, Draw.alpha(lc, 0.95f), false);
        }

        double px = mc.player.getX(), pz = mc.player.getZ();
        int count = 0;
        for (AbstractClientPlayer p : mc.level.players()) {
            if (p == mc.player || count >= 24) continue;
            double dx = p.getX() - px, dz = p.getZ() - pz;
            double a = dx * -cos + dz * -sin;       // right of you
            double b = dx * -sin + dz * cos;        // in front of you
            double d = Math.sqrt(a * a + b * b);
            if (d > rng) { a *= rng / d; b *= rng / d; }
            int sx = cx + (int) Math.round(a / rng * inner), sy = cy - (int) Math.round(b / rng * inner);
            g.fill(sx - 2, sy - 2, sx + 2, sy + 2, 0xCC000000);
            g.fill(sx - 1, sy - 1, sx + 1, sy + 1, d > rng ? 0xFFFFC857 : 0xFFFF5470);
            count++;
        }
        // rotating sweep
        double sw = System.currentTimeMillis() / 1000.0 * 1.7;
        for (int k = 0; k < 3; k++) {
            double aa = sw - k * 0.22;
            Proj.line(g, cx, cy, cx + Math.cos(aa) * (R / 2.0 - 4), cy + Math.sin(aa) * (R / 2.0 - 4), 1.6f, Draw.alpha(Draw.lighten(col, 0.3f), 0.38f - k * 0.12f));
        }
        // you
        Proj.fillPoly2d(g, new double[]{cx, cx + 4.2, cx - 4.2}, new double[]{cy - 5.2, cy + 3.6, cy + 3.6}, 3, 0xCC000000);
        Proj.fillPoly2d(g, new double[]{cx, cx + 3, cx - 3}, new double[]{cy - 3.6, cy + 2.4, cy + 2.4}, 3, 0xFFFFFFFF);
    }
}
